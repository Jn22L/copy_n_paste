import KtngUtils from '@ktng/utils';
import _ from '@lodash';
import { loadMultiCodeList } from 'app/store/ktng/codeSlice';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';

/**
 * 다수의 공통코드 목록 조회
 *
 * @param {function} completeFunc 완료 콜백
 * @param {array}} deps 코드 목록
 */
const useCmmCodeLoadEffect = (completeFunc, deps) => {
	const [loadCmmCode] = deps;

	// 0, false : 처음 호출 상태
	// 1, true : 코드 서버에 요청한 상태
	const [loadingStatus, setLoadingStatus] = useState(0);
	const code = useSelector(({ ktng }) => ktng.code);
	const dispatch = useDispatch();

	useEffect(() => {
		if (_.isEmpty(code)) return;

		const isComplete = KtngUtils.isCheckCmmCode(loadCmmCode, code);
		if (isComplete) {
			completeFunc();
		}
		// eslint-disable-next-line
	}, [code]);

	// 코드 존재여부 체크
	const isComplete = KtngUtils.isCheckCmmCode(loadCmmCode, code);
	if (isComplete) return;

	if (loadingStatus === 0) {
		setLoadingStatus(1);
		dispatch(loadMultiCodeList(loadCmmCode));
	}
};

export default useCmmCodeLoadEffect;
