import { useEffect } from 'react';

const useImportScript = (resourceUrl, loadComplate) => {
	useEffect(() => {
		const script = document.createElement('script');
		script.src = resourceUrl;
		script.async = true;
		document.body.appendChild(script);
		script.addEventListener('load', loadComplate);
		return () => {
			document.body.removeChild(script);
		};
	}, [resourceUrl]);
};

export default useImportScript;
