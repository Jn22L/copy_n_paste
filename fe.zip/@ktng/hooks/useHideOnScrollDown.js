const { useState, useEffect } = require('react');

// Ex) scrollTarget: document.querySelector('.container div[class*=-contentWrapper-]');
const useHideOnScrollDown = ({ scrollableTarget }) => {
	const [scrollTop, setScrollTop] = useState(0);
	const [isHidden, setIsHidden] = useState(false);

	useEffect(() => {
		if (!scrollableTarget) return () => {};

		scrollableTarget.onscroll = e => {
			setIsHidden(e.target.scrollTop >= scrollTop); // 아래로 스크롤 시 숨김
			setScrollTop(e.target.scrollTop);
		};

		return () => {
			scrollableTarget.onscroll = null;
		};
	});

	return isHidden;
};

export default useHideOnScrollDown;
