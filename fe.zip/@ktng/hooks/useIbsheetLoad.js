import loader from '@ibsheet/loader';
import { useEffect } from 'react';
import _ from '@lodash';

const useIbsheetLoad = (ibsheet, loadNames, isLoadedIbs, loadComplate) => {
	useEffect(() => {
		if (isLoadedIbs) return;
		// console.log('useIbsheetLoad START', loadNames);
		// console.log(ibsheet);
		const temp = _.filter(ibsheet, lib => loadNames.includes(lib.name));
		const isEveryLoaded = _.every(temp, 'loaded');
		// console.log(temp);
		// console.log({ isEveryLoaded });
		// 이미 로드된 라이브러리를 호출한경우
		if (!isEveryLoaded) {
			loader.load(loadNames, false);
		} else {
			loadComplate();
		}
		// eslint-disable-next-line
	}, [ibsheet]);
};

export default useIbsheetLoad;
