export { default as KtngSpeedDial } from './KtngSpeedDial';
