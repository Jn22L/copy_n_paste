import { makeStyles, useTheme } from '@material-ui/core';
import { SpeedDial, SpeedDialIcon } from '@material-ui/lab';
import clsx from 'clsx';
import React, { forwardRef } from 'react';

const useStyles = makeStyles(theme => ({
	speedDial: {
		position: 'absolute',
		'&.MuiSpeedDial-directionUp, &.MuiSpeedDial-directionLeft': {
			bottom: theme.spacing(2),
			right: theme.spacing(2)
		},
		'&.MuiSpeedDial-directionDown, &.MuiSpeedDial-directionRight': {
			top: theme.spacing(2),
			left: theme.spacing(2)
		}
	}
}));

const KtngSpeedDial = forwardRef((props, ref) => {
	const { ariaLabel, className, children, icon, direction, hidden } = props;
	const theme = useTheme();
	const classes = useStyles(theme);

	const [open, setOpen] = React.useState(false);

	return (
		<SpeedDial
			ariaLabel={ariaLabel}
			className={clsx(classes.speedDial, className)}
			hidden={hidden}
			icon={icon}
			onClose={() => setOpen(false)}
			onOpen={() => setOpen(true)}
			open={open}
			direction={direction}
			FabProps={{ color: 'secondary' }}
		>
			{children}
		</SpeedDial>
	);
});

KtngSpeedDial.defaultProps = {
	icon: <SpeedDialIcon />,
	direction: 'up',
	hidden: false
};

export default KtngSpeedDial;
