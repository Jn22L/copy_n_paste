export { default } from './KtngIbSheet';
