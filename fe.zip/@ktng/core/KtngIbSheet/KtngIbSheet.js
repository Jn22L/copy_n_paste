import loader from '@ibsheet/loader';
import { KtngIbSheetUtils } from '@ktng/utils';
import { makeStyles, useTheme } from '@material-ui/core/styles';
import { array, func, object, string } from 'prop-types';
import React, { useCallback, useContext, useEffect, useState } from 'react';
import clsx from 'clsx';
import useIbsheetLoad from '@ktng/hooks/useIbsheetLoad';
import AppContext from 'app/AppContext';
import { useCmmCodeLoadEffect } from '@ktng/hooks';

const useStyles = makeStyles(theme => ({
	sheet: {
		'& div.IBSolidRow': {
			backgroundColor: 'white' // 그리드 배경색
		},
		'& td.IBCellHeader': {
			backgroundColor: theme.palette.primary.main // 헤더 배경색
		},
		'& td.IBCellHeader:hover': {
			backgroundColor: theme.palette.primary.light // 헤더 배경색
		},
		'& td.IBFocusRowBackground': {
			backgroundColor: theme.palette.secondary.dark // 선택된 행 배경색
		},
		'& td.IBClassFocusedCell': {
			backgroundColor: 'rgb(244, 244, 244)' // 선택된 셀 배경색
		},
		'& u.IBSheetButton': {
			background: theme.palette.secondary.dark,
			border: `0px solid ${theme.palette.secondary.dark}`,
			color: 'white',
			margin: '4px 8px 4px 8px'
		},
		'& u.IBSheetButton:active': {
			background: theme.palette.primary.dark,
			border: `0px solid ${theme.palette.primary.dark}`,
			color: 'white',
			margin: '4px 8px 4px 8px'
		}
	}
}));

function KtngIbSheet({
	sheetId,
	options,
	data,
	codes,
	onLoad,
	onRowAdd,
	onAfterClick,
	onAfterChange,
	className,
	style
}) {
	const theme = useTheme();
	const classes = useStyles(theme);
	const { ibsheet } = useContext(AppContext);
	const wrapperId = `${sheetId}-wrapper`;

	const [isLoadedIbs, setIsLoadedIbs] = useState(false);
	const [sheetObj, setSheetObj] = useState();
	const [reqCodes] = useState(codes || []);
	const [isLoadedCds, setIsLoadedCds] = useState(!codes);

	const handleRowAdd = useCallback(
		({ sheet, row }) => {
			row.rowStatus = 'I';
			onRowAdd({ sheet, row });
		},
		[onRowAdd]
	);

	const handleSheetClick = useCallback(
		({ sheet, row, col }) => {
			if (row.rowStatus !== 'D') {
				// 상태컬럼이 없거나 `삭제` 상태가 아니면 `OnClick` 호출
				onAfterClick({ sheet, row, col });
			}
		},
		[onAfterClick]
	);

	const handleSheetChange = useCallback(
		({ sheet, row, col, val, oldval }) => {
			/*
			 * 상태컬럼 변경
			 * - `rowStatus` 변경 -> 유지
			 * - `delYn` 변경 -> N/D
			 * - 그외 컬럼변경 -> N/U
			 * - 행 추가하는 경우에만 I로 변경됨
			 */
			KtngIbSheetUtils.updateRowStatus(sheet, row, col, val, oldval);

			// 사용자 콜백
			onAfterChange({ sheet, row, col, val, oldval });
		},
		[onAfterChange]
	);

	// 플러그인 추가
	useIbsheetLoad(ibsheet, ['ibsheet-excel'], isLoadedIbs, () => {
		setIsLoadedIbs(true);
	});

	// 공통코드 로드
	useCmmCodeLoadEffect(() => {
		setIsLoadedCds(true);
	}, [reqCodes]);

	// 그리드 생성
	useEffect(() => {
		if (!isLoadedIbs || !isLoadedCds) return () => {};

		// 공통 설정
		options.Cfg = {
			...options.Cfg,
			Export: {
				Down2ExcelUrl: '/api/ibsheet/down2excel',
				Down2TextUrl: '/api/ibsheet/down2text',
				Relative: true, // 주소의 상대경로 유무, false : 실제 주소(절대 경로), true : ibsheet.js 기준 상대 경로
				Method: 'POST'
			}
		};

		loader
			.createSheet({
				id: sheetId,
				el: wrapperId,
				options,
				data: []
			})
			.then(sheet => {
				sheet.bind('onRowAdd', handleRowAdd);
				sheet.bind('onAfterClick', handleSheetClick);
				sheet.bind('onAfterChange', handleSheetChange);

				onLoad(sheet);
				setSheetObj(sheet);
			});

		return () => {
			loader.removeSheet(sheetId);
			setSheetObj(null);
		};

		// eslint-disable-next-line
	}, [isLoadedIbs, isLoadedCds, wrapperId]); // 한번만 실행

	// 그리드에 데이터 삽입
	useEffect(() => {
		if (!sheetObj) return;

		if (data.length === 0) {
			sheetObj.removeAll();
		} else {
			/**
			 * @param {object} data (필수) json형식의 데이터
			 * @param {boolean} append (선택) 기존 데이터 하단에 append 여부(default:0(false))
			 * @param {function} callback (선택) 조회 후 호출할 콜백 함수
			 * @param {object} next (선택) 데이터 로우 객체
			 * 지정한 행 위에부터 데이터 append. (append:1(true)일때만 사용 가능)
			 * @param {boolean} strictParse (선택) json 파서 선택
			 * 일반적으로 유연한 파싱으로 구동되고 true 설정시에 브라우져의 JSON.parse()를 통해 파싱 default:false
			 */
			sheetObj.loadSearchData({
				data,
				append: false,
				strictParse: true
			});
		}
	}, [sheetObj, data]);

	// 이벤트 함수 리프레시 (안하면, 변경된 상태값이 콜백함수의 로직에 반영안됨)
	useEffect(() => {
		if (!sheetObj) return;

		sheetObj.unbind('onRowAdd');
		sheetObj.bind('onRowAdd', handleRowAdd);

		sheetObj.unbind('onAfterClick');
		sheetObj.bind('onAfterClick', handleSheetClick);

		sheetObj.unbind('onAfterChange');
		sheetObj.bind('onAfterChange', handleSheetChange);
	}, [sheetObj, handleRowAdd, handleSheetClick, handleSheetChange]);

	return <div className={clsx(classes.sheet, className)} style={style} id={wrapperId} />;
}

KtngIbSheet.propTypes = {
	sheetId: string.isRequired,
	options: object.isRequired,
	data: array.isRequired,
	codes: array,
	onLoad: func,
	onRowAdd: func,
	onAfterClick: func,
	onAfterChange: func,
	style: object
};

KtngIbSheet.defaultProps = {
	codes: null,
	onLoad: () => {},
	onRowAdd: () => {},
	onAfterClick: () => {},
	onAfterChange: () => {},
	className: {},
	style: {}
};

export default KtngIbSheet;
