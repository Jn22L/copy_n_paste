export { default } from './KtngSplashScreen';
