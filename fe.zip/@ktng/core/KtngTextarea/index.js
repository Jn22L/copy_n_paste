export { default } from './KtngTextarea';
