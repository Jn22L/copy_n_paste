import React from 'react';
import { Input, Typography } from '@material-ui/core';
import KtngUtils from '@ktng/utils';
import _ from '@lodash';
import clsx from 'clsx';

const KtngTextarea = props => {
	const { value } = props;
	const { maxByteLength } = props.inputProps;
	const isFullLength = maxByteLength && value && maxByteLength <= KtngUtils.getStrByteLength(value);

	return (
		<div className={clsx(props.className, 'text-left')}>
			<Input
				fullWidth
				type="text"
				multiline
				{..._.pick(props, ['placeholder', 'rows', 'value', 'onChange', 'inputProps'])}
				inputProps={{
					maxLength: maxByteLength,
					..._.drop(props.inputProps, ['maxByteLength'])
				}}
			/>
			{maxByteLength && (
				<Typography
					className={clsx('w-full text-left italic mt-4', isFullLength ? 'text-red' : 'text-blue')}
					variant="caption"
				>
					{KtngUtils.getStrByteLength(value) || 0} / {maxByteLength} bytes
				</Typography>
			)}
		</div>
	);
};

KtngTextarea.defaultProps = {
	value: '',
	inputProps: {}
};

export default KtngTextarea;
