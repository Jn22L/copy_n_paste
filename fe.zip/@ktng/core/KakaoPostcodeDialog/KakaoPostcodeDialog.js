// /* global kakao */ // 주석처리

// 1. React JS 컴포넌트 import
// 2. 디자인 컴포넌트 import
import { Box, Container, IconButton, makeStyles, Typography } from '@material-ui/core';
import CloseIcon from '@material-ui/icons/Close';
import { closeDialog } from 'app/store/fuse/dialogSlice';
import { setData } from 'app/store/ktng/kakaoPostcodeSlice';
import React from 'react';
import DaumPostcode from 'react-daum-postcode';
import { useDispatch } from 'react-redux';

const useStyles = makeStyles(theme => ({
	root: {
		backgroundColor: '#E5E5E5',
		display: 'flex',
		flexDirection: 'column',
		minHeight: '100vh'
	},
	banner: {
		backgroundColor: theme.palette.background.paper,
		paddingBottom: theme.spacing(1),
		paddingTop: theme.spacing(1),
		borderBottom: `1px solid ${theme.palette.divider}`
	},
	cardContent: {
		backgroundColor: theme.palette.background.paper,
		padding: theme.spacing(2)
	},
	listWrap: {
		backgroundColor: theme.palette.background.paper
	}
}));

function KakaoPostcodeDialog() {
	const classes = useStyles();
	const dispatch = useDispatch();

	// const [geocoder, setGeoCoder] = useState(null);

	// kakao 좌표찾기 api 로딩
	// useEffect(() => {
	// 	const script = document.createElement('script');
	// 	script.async = true;
	// 	script.src =
	// 		'https://dapi.kakao.com/v2/maps/sdk.js?appkey=112d346f05a09a5b82d6176d9495a41e&autoload=false&libraries=services';
	// 	document.head.appendChild(script);

	// 	script.onload = () => {
	// 		if (kakao.maps) {
	// 			kakao.maps.load(() => {
	// 				setGeoCoder(new kakao.maps.services.Geocoder());
	// 			});
	// 		}
	// 	};
	// }, []);

	const handleDaumPostcodeComplete = data => {
		let fullAddress = data.address;
		let extraAddress = '';

		if (data.addressType === 'R') {
			if (data.bname !== '') {
				extraAddress += data.bname;
			}
			if (data.buildingName !== '') {
				extraAddress += extraAddress !== '' ? `, ${data.buildingName}` : data.buildingName;
			}
			fullAddress += extraAddress !== '' ? ` (${extraAddress})` : '';
		}

		dispatch(
			setData({
				zonecode: data.zonecode,
				address: fullAddress
			})
		);

		// 주소를 좌표로 변환
		// geocoder.addressSearch(data.address, async (result, status) => {
		// 	// 정상적으로 검색이 완료됐으면
		// 	if (status === kakao.maps.services.Status.OK) {
		// 		const coords = new kakao.maps.LatLng(result[0].y, result[0].x);
		// 		await dispatch(
		// 			setData({
		// 				zonecode: data.zonecode,
		// 				address: data.address,
		// 				latitude: result[0].y,
		// 				longitude: result[0].x
		// 			})
		// 		);

		// 		// 네이버 지도에 표시
		// 		// ...
		// 		console.log(coords);
		// 	}
		// });

		dispatch(closeDialog());
	};

	return (
		<div className={classes.root}>
			<div className={classes.banner}>
				<Container maxWidth="md">
					<Box alignItems="center" display="flex" justifyContent="space-between">
						<Box p={3} />
						<Typography variant="h4" color="textPrimary">
							주소 검색
						</Typography>
						<IconButton aria-label="back" onClick={_ => dispatch(closeDialog())}>
							<CloseIcon />
						</IconButton>
					</Box>
				</Container>
			</div>
			<DaumPostcode onComplete={handleDaumPostcodeComplete} height={600} hideMapBtn hideEngBtn />
		</div>
	);
}

export default KakaoPostcodeDialog;
