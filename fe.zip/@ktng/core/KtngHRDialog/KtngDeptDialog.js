import _ from '@lodash';
import { Button, DialogActions, DialogContent, DialogTitle, TextField } from '@material-ui/core';
import AccountTree from '@material-ui/icons/AccountTree';
import { closeDialog2 } from 'app/store/fuse/dialogSlice2';
import PropTypes from 'prop-types';
import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
// import * as Actions from 'app/store/actions';
import DeptTreeView from './DeptTreeView';

function KtngDeptDialog(props) {
	// console.log("KtngDeptDialog");
	const dispatch = useDispatch();
	const [selectedItem, setSelectedItem] = useState({
		deptCd: props.deptCd,
		deptNm: ''
	});

	// useEffect(() => {
	//   const { deptCd } = selectedItem;
	//   const { onSelect } = props;
	//   if(deptCd && onSelect){
	//     onSelect()
	//   }
	// }, []);

	const handleClose = () => dispatch(closeDialog2());

	const handleOKBtnClick = () => {
		// console.log(selectedItem);
		const { onSelect } = props;
		if (onSelect) {
			onSelect(_.omit(selectedItem, 'children'));
		}
		dispatch(closeDialog2());
	};

	const deptItemSelect = item => {
		// console.log('deptItemSelect', item);
		if (item) {
			setSelectedItem(item);
		} else {
			setSelectedItem({
				deptCd: props.deptCd,
				deptNm: ''
			});
		}
	};

	return (
		<>
			<DialogTitle>
				<AccountTree /> 부서선택
			</DialogTitle>
			<div className="p-10 flex flex-row border-t border-b w-full">
				<TextField
					className="max-w-164 mx-4"
					label="부서코드"
					name="deptCd"
					size="small"
					variant="outlined"
					value={selectedItem.deptCd}
				/>
				<TextField
					className="mx-4"
					label="부서명"
					name="deptNm"
					size="small"
					variant="outlined"
					fullWidth
					value={selectedItem.deptNm}
				/>
			</div>
			<DialogContent className="border-b">
				<DeptTreeView onSelect={deptItemSelect} deptCd={selectedItem.deptCd} />
			</DialogContent>
			<DialogActions>
				<Button onClick={handleOKBtnClick} color="primary" autoFocus>
					선택
				</Button>
				<Button onClick={handleClose} color="primary">
					취소
				</Button>
			</DialogActions>
		</>
	);
}

KtngDeptDialog.propTypes = {
	onSelect: PropTypes.func,
	deptCd: PropTypes.string
};

export default KtngDeptDialog;
