import { usePrevious } from '@fuse/hooks';
import KtngUtils from '@ktng/utils';
import _ from '@lodash';
import { IconButton, InputAdornment, TextField } from '@material-ui/core';
import SearchIcon from '@material-ui/icons/Search';
import HrService from 'app/services/hrService';
import { openDialog2 } from 'app/store/fuse/dialogSlice2';
import PropTypes from 'prop-types';
import React, { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import KtngPersonDialog from './KtngPersonDialog';

function KtngPersonSelector(props) {
	const dispatch = useDispatch();
	// prettier-ignore
	const [selectedItem, setSelectedItem] = useState({empNm: '', empNo: ''});
	const preSelectedItem = usePrevious(selectedItem);
	const [label] = useState(props.label);
	const [textValue, setTextValue] = useState('');

	useEffect(() => {
		if (props.empNo) {
			HrService.getPersonDTO(props.empNo).then(data => {
				if (!_.isEmpty(data)) setSelectedItem(data);
			});
		}
	}, [props.empNo]);

	useEffect(() => {
		const _selectedItem = KtngUtils.removeEmptyAttr(selectedItem);
		if (_.isEmpty(_selectedItem)) {
			setTextValue('');
		} else {
			setTextValue(props.valueFunc(selectedItem));
		}
		if (preSelectedItem === undefined) return;
		const target = _.omit(props, ['onSelect', 'valueFunc']);
		props.onSelect(_selectedItem, target);
		// eslint-disable-next-line
	}, [selectedItem]);

	function handlePersonSelect(item) {
		setSelectedItem(item);
	}

	function showKtngPersonDialog() {
		dispatch(
			openDialog2({
				fullWidth: true,
				maxWidth: 'md',
				children: <KtngPersonDialog onSelect={handlePersonSelect} />
			})
		);
	}

	const handleChange = event => {
		setSelectedItem({ empNm: '', empNo: '' });
	};

	return (
		<TextField
			className={props.className}
			label={label}
			value={textValue}
			onClick={e => e.target.value === '' && showKtngPersonDialog()}
			onChange={handleChange}
			InputProps={{
				endAdornment: (
					<InputAdornment>
						<IconButton onClick={showKtngPersonDialog}>
							<SearchIcon />
						</IconButton>
					</InputAdornment>
				)
			}}
		/>
	);
}

KtngPersonSelector.propTypes = {
	label: PropTypes.string,
	className: PropTypes.string,
	onSelect: PropTypes.func,
	valueFunc: PropTypes.func
};

KtngPersonSelector.defaultProps = {
	label: '사용자선택',
	onSelect: item => {},
	valueFunc: item => `[${item.empNo}] ${item.empNm}`
};

export default KtngPersonSelector;
