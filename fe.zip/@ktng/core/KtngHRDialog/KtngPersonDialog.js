import React, { useState, useEffect } from 'react';
import { useDispatch } from 'react-redux';
import PersonIcon from '@material-ui/icons/Person';
import {
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  makeStyles,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody
} from '@material-ui/core';
import Pagination from '@material-ui/lab/Pagination';
import _ from '@lodash';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import { closeDialog2 } from 'app/store/fuse/dialogSlice2';
import HrService from 'app/services/hrService';
import KtngUtils from '@ktng/utils';
import DeptTreeView from './DeptTreeView';

const useStyles = makeStyles({
  left: {
    overflow: 'scroll',
    padding: 5,
    borderRightWidth: '1px',
    borderColor: 'rgba(0, 0, 0, 0.12)'
  },
  root: {
    width: '100%',
    minHeight: 380,
    overflow: 'scroll'
  },
  table: {
    minWidth: 980
  }
});

function KtngPersonDialog(props) {
  const { seletedDeptCd } = props;

  const classes = useStyles();
  const dispatch = useDispatch();

  // prettier-ignore
  const [selectedItem, setSelectedItem] = useState({deptCd: seletedDeptCd, deptNm: '', empNo: '', empNm: ''});
  const [searchItem, setSearchItem] = useState();
  const [list, setList] = useState(null);

  const [pageSize, setPageSize] = useState(8);
  const [pageNum, setPageNum] = useState(1);
  const [totalElements, setTotalElements] = useState(0);
  const [totalPages, setTotalPages] = useState(0);

  useEffect(() => {
    search(1, 8, selectedItem);
    // eslint-disable-next-line
  }, []);

  const search = (page, size, params) => {
    const { deptCd, empNo, empNm } = params;
    const _page = page - 1; // 서버에서는 0이 시작이고, 화면에서 1이 시작임.
    HrService.getListPersonDTO(_page, size, deptCd, empNo, empNm).then(data => {
      const [pageData, _params] = data;
      const { content, size: _size, number, totalElements: _totalElements, totalPages: _totalPages } = pageData;
      setPageSize(_size);
      setPageNum(number + 1); // 서버에서는 0이 시작이고, 화면에서 1이 시작임.
      setTotalElements(_totalElements);
      setTotalPages(_totalPages);
      setList(content);

      setSearchItem(_params); // 조회조건을 저장함.
    });
  };

  const isSelected = item => {
    const temp1 = _.pick(selectedItem, ['empNo', 'empNm', 'email']);
    const temp2 = _.pick(item, ['empNo', 'empNm', 'email']);

    return _.isEqual(temp1, temp2);
  };

  const handlePersonClick = (event, item) => {
    setSelectedItem({
      ...item,
      deptCd: '',
      deptNm: ''
    });
  };

  const handleTreeOnSelect = item => {
    const _selectedItem = {
      ...item,
      empNo: '',
      empNm: ''
    };
    setSelectedItem(_selectedItem);
    search(1, 8, _selectedItem);
  };

  const handleChange = event => {
    // prettier-ignore
    const { target: { name, value } } = event;
    // console.log(name, value);
    setSelectedItem({
      ...selectedItem,
      [name]: value
    });
  };

  function handleChangePageNumber(event, value) {
    console.log(event, value);
    search(value, pageSize, searchItem);
  }

  const handleClose = () => {
    dispatch(closeDialog2());
  };

  const handleOKBtnClick = () => {
    const _selectedItem = KtngUtils.removeEmptyAttr(selectedItem);
    if (_.isEmpty(_selectedItem)) return;

    const { onSelect } = props;
    if (onSelect) {
      onSelect(selectedItem);
    }
    dispatch(closeDialog2());
  };

  return (
    <>
      <DialogTitle>
        <PersonIcon /> 사용자선택
      </DialogTitle>
      <DialogContent className="grid  grid-flow-col grid-cols-4 grid-rows-1  gap-0 p-0 border-t border-b ">
        <div className={clsx(classes.left, 'row-span-3 col-span-1 w-full')}>
          <DeptTreeView onSelect={handleTreeOnSelect} deptCd={seletedDeptCd} />
        </div>
        <div className="row-span-1 col-span-3 p-10 border-b">
          <TextField
            className="max-w-128 mx-4"
            label="부서번호"
            name="deptCd"
            size="small"
            variant="outlined"
            value={selectedItem.deptCd}
            onChange={handleChange}
          />
          <TextField
            className="ml-20 max-w-96 mx-4"
            label="사원번호"
            name="empNo"
            size="small"
            variant="outlined"
            value={selectedItem.empNo}
            onChange={handleChange}
          />
          <TextField
            className="mx-4"
            label="사원명"
            name="empNm"
            size="small"
            variant="outlined"
            value={selectedItem.empNm}
            onChange={handleChange}
          />
          <Button className="ml-20" variant="contained" color="primary" onClick={() => search(1, 8, selectedItem)}>
            검색
          </Button>
        </div>
        <div className={clsx(classes.root, 'row-span-1 col-span-3 px-0')}>
          <Table size="small" className={classes.table}>
            <colgroup>
              <col style={{ width: 70 }} />
              <col style={{ width: 100 }} />
              <col style={{ width: 90 }} />
              <col style={{ width: 90 }} />
              <col style={{ width: 150 }} />
              <col style={{ width: 120 }} />
              <col style={{ width: 110 }} />
              <col style={{ width: 110 }} />
            </colgroup>
            <TableHead>
              <TableRow>
                <TableCell align="center">사번</TableCell>
                <TableCell align="center">사용자명</TableCell>
                <TableCell align="center">직급</TableCell>
                <TableCell align="center">직책</TableCell>
                <TableCell align="center">부서명</TableCell>
                <TableCell align="center">기관명</TableCell>
                <TableCell align="center">이메일</TableCell>
                <TableCell align="center">전화번호</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {list &&
                Object.entries(list).map(([key, item]) => {
                  const isItemSelected = isSelected(item);
                  return (
                    <TableRow
                      key={key}
                      className="cursor-pointer"
                      hover
                      selected={isItemSelected}
                      onClick={event => handlePersonClick(event, item)}
                    >
                      <TableCell align="left">{item.empNo}</TableCell>
                      <TableCell align="left">{item.empNm}</TableCell>
                      <TableCell align="center">{item.grdNm}</TableCell>
                      <TableCell align="center">{item.posNm}</TableCell>
                      <TableCell align="center">{item.groupNm}</TableCell>
                      <TableCell align="center">{item.parNm}</TableCell>
                      <TableCell align="center">{item.email}</TableCell>
                      <TableCell align="right">{item.phone}</TableCell>
                    </TableRow>
                  );
                })}
            </TableBody>
          </Table>
          <div className="flex justify-between items-baseline">
            <div className="pl-20">
              전체 : <span className="text-red">{totalElements}</span>건
            </div>
            <div className="flex justify-center my-20">
              <Pagination
                color="secondary"
                defaultPage={1}
                siblingCount={2}
                count={totalPages}
                page={pageNum}
                onChange={handleChangePageNumber}
              />
            </div>
            <div className="pr-20" />
          </div>
        </div>
      </DialogContent>
      <DialogActions>
        <Button onClick={handleOKBtnClick} color="primary" autoFocus>
          선택
        </Button>
        <Button onClick={handleClose} color="primary">
          취소
        </Button>
      </DialogActions>
    </>
  );
}

KtngPersonDialog.propTypes = {
  onSelect: PropTypes.func,
  seletedDeptCd: PropTypes.string
};

export default KtngPersonDialog;
