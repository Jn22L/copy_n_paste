import React, { useEffect, useState } from 'react';
import { makeStyles } from '@material-ui/core';
import Group from '@material-ui/icons/Group';
import TreeView from '@material-ui/lab/TreeView';
import _ from '@lodash';
import PropTypes from 'prop-types';
import HrService from 'app/services/hrService';
import { KtngTreeItem, KtngTreeUtils, MinusSquare, PlusSquare } from '../KtngTreeView';

const renderTreeItems = treeItems => {
  return treeItems.map(treeItemData => {
    // eslint-disable-next-line
    let children = undefined;
    if (treeItemData.children && treeItemData.children.length > 0) {
      children = renderTreeItems(treeItemData.children);
    }
    return (
      <KtngTreeItem
        key={treeItemData.deptCd}
        nodeId={treeItemData.deptCd}
        label={treeItemData.deptNm}
        // eslint-disable-next-line
        children={children}
      />
    );
  });
};

const useStyles = makeStyles({
  root: {
    height: 264,
    flexGrow: 1
  }
});

function DeptTreeView(props) {
  const classes = useStyles();

  const [deptTreeItems, setDeptTreeItems] = useState([]);
  const [expanded, setExpanded] = useState([]);
  const [deptCd, setDeptCd] = useState(props.deptCd);

  useEffect(() => {
    const { onSelect } = props;
    HrService.getListDeptDTO().then(list => {
      setDeptTreeItems(list);
      if (deptCd && onSelect) {
        setExpanded(KtngTreeUtils.findPath('deptCd', deptCd, list));
        onSelect(KtngTreeUtils.findItem('deptCd', deptCd, list));
      } else {
        setExpanded(_.map(list, 'deptCd'));
      }
    });

    // eslint-disable-next-line
  }, []);

  const handleToggle = (e, nodeIds) => {
    setExpanded(nodeIds);
  };

  const handleSelect = (e, nodeIds) => {
    const selectedItem = KtngTreeUtils.findItem('deptCd', nodeIds, deptTreeItems);
    const { onSelect } = props;
    if (onSelect) {
      onSelect(selectedItem);
      setDeptCd(nodeIds);
    }
  };

  return (
    <TreeView
      className={classes.root}
      defaultCollapseIcon={<MinusSquare />}
      defaultExpandIcon={<PlusSquare />}
      defaultEndIcon={<Group />}
      expanded={expanded}
      onNodeToggle={handleToggle}
      onNodeSelect={handleSelect}
      selected={deptCd ? [deptCd] : []}
    >
      {renderTreeItems(deptTreeItems)}
    </TreeView>
  );
}

DeptTreeView.propTypes = {
  onSelect: PropTypes.func,
  deptCd: PropTypes.string
};
export default DeptTreeView;
