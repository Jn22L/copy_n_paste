import { useForm } from '@fuse/hooks';
import KtngUtils from '@ktng/utils';
import _ from '@lodash';
import {
	Button,
	DialogActions,
	DialogContent,
	DialogTitle,
	makeStyles,
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableRow
} from '@material-ui/core';
import PersonIcon from '@material-ui/icons/Person';
import Pagination from '@material-ui/lab/Pagination';
import HrService from 'app/services/hrService';
import { closeDialog2 } from 'app/store/fuse/dialogSlice2';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import React, { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';

const useStyles = makeStyles(theme => ({
	left: {
		overflow: 'scroll',
		padding: 5,
		borderRightWidth: '1px',
		borderColor: 'rgba(0, 0, 0, 0.12)'
	},
	root: {
		width: '100%',
		minHeight: 380,
		overflow: 'scroll'
	},
	table: {
		minWidth: 980
	},
	select: {
		margin: theme.spacing(1),
		minWidth: 180
	}
}));

function KtngPersonDialogWithRole(props) {
	const classes = useStyles();
	const dispatch = useDispatch();

	// prettier-ignore
	const [selectedItem, setSelectedItem] = useState({});
	// const [parCodeList, setParCodeList] = useState([]);
	// const [deptCodeList, setDeptCodeList] = useState([]);
	const [list, setList] = useState([]);

	const [pageSize, setPageSize] = useState(8);
	const [pageNum, setPageNum] = useState(1);
	const [totalElements, setTotalElements] = useState(0);
	const [totalPages, setTotalPages] = useState(0);

	const { form, setForm } = useForm({ empNm: '', empNo: '', parCode: '', deptCode: '' });

	useEffect(() => {
		const { deptCd, parCd, roleCd } = props;
		// console.log(props);
		if (deptCd && parCd) {
			setForm({ ...form, deptCode: deptCd, parCode: parCd });
		}
		// HrService.getParCodeDTO().then(data => setParCodeList(data));
		search(1, 8, deptCd, parCd, roleCd);
		// eslint-disable-next-line
	}, []);

	// useEffect(() => {
	// 	if (form.parCode) {
	// 		HrService.getDeptCodeDTO(form.parCode).then(data => setDeptCodeList(data));
	// 	}
	// }, [form.parCode]);

	const search = (page, size, deptCd, parCd, roleCd) => {
		const _page = page - 1; // 서버에서는 0이 시작이고, 화면에서 1이 시작임.
		HrService.getPersonWidthRole(_page, size, { deptCd, parCd, roleCd }).then(data => {
			const [pageData] = data;
			const { content, size: _size, number, totalElements: _totalElements, totalPages: _totalPages } = pageData;
			setPageSize(_size);
			setPageNum(number + 1); // 서버에서는 0이 시작이고, 화면에서 1이 시작임.
			setTotalElements(_totalElements);
			setTotalPages(_totalPages);
			setList(content);

			// setForm({ ...form, ..._params }); // 조회조건을 저장함.
		});
	};

	const isSelected = item => {
		const temp1 = _.pick(selectedItem, ['empNo', 'empNm', 'email']);
		const temp2 = _.pick(item, ['empNo', 'empNm', 'email']);

		return _.isEqual(temp1, temp2);
	};

	const handlePersonClick = (event, item) => {
		setSelectedItem({
			...item,
			deptCd: '',
			deptNm: ''
		});
	};

	function handleChangePageNumber(event, value) {
		search(value, pageSize, form);
	}

	const handleClose = () => {
		dispatch(closeDialog2());
	};

	const handleOKBtnClick = () => {
		const _selectedItem = KtngUtils.removeEmptyAttr(selectedItem);
		if (_.isEmpty(_selectedItem)) return;

		const { onSelect } = props;
		if (onSelect) {
			onSelect(selectedItem);
		}
		dispatch(closeDialog2());
	};

	return (
		<>
			<DialogTitle>
				<PersonIcon /> 결재권자 선택
			</DialogTitle>
			<DialogContent className="flex flex-col">
				<div className={clsx(classes.root, 'px-0')}>
					<Table size="small" className={classes.table}>
						<colgroup>
							<col style={{ width: 70 }} />
							<col style={{ width: 100 }} />
							<col style={{ width: 90 }} />
							<col style={{ width: 90 }} />
							<col style={{ width: 150 }} />
							<col style={{ width: 120 }} />
							<col style={{ width: 110 }} />
							<col style={{ width: 110 }} />
						</colgroup>
						<TableHead>
							<TableRow>
								<TableCell align="center">사번</TableCell>
								<TableCell align="center">사용자명</TableCell>
								<TableCell align="center">직급</TableCell>
								<TableCell align="center">직책</TableCell>
								<TableCell align="center">부서명</TableCell>
								<TableCell align="center">기관명</TableCell>
								<TableCell align="center">이메일</TableCell>
								<TableCell align="center">전화번호</TableCell>
							</TableRow>
						</TableHead>
						<TableBody>
							{list &&
								Object.entries(list).map(([key, item]) => {
									const isItemSelected = isSelected(item);
									return (
										<TableRow
											key={key}
											className="cursor-pointer"
											hover
											selected={isItemSelected}
											onClick={event => handlePersonClick(event, item)}
										>
											<TableCell align="left">{item.empNo}</TableCell>
											<TableCell align="left">{item.empNm}</TableCell>
											<TableCell align="center">{item.grdNm}</TableCell>
											<TableCell align="center">{item.posNm}</TableCell>
											<TableCell align="center">{item.groupNm}</TableCell>
											<TableCell align="center">{item.parNm}</TableCell>
											<TableCell align="center">{item.email}</TableCell>
											<TableCell align="right">{item.phone}</TableCell>
										</TableRow>
									);
								})}
						</TableBody>
					</Table>
					<div className="flex justify-between items-baseline">
						<div className="pl-20">
							전체 : <span className="text-red">{totalElements}</span>건
						</div>
						<div className="flex justify-center my-20">
							<Pagination
								color="secondary"
								defaultPage={1}
								siblingCount={2}
								count={totalPages}
								page={pageNum}
								onChange={handleChangePageNumber}
							/>
						</div>
						<div className="pr-20" />
					</div>
				</div>
			</DialogContent>
			<DialogActions>
				<Button onClick={handleOKBtnClick} color="primary" autoFocus>
					선택
				</Button>
				<Button onClick={handleClose} color="primary">
					취소
				</Button>
			</DialogActions>
		</>
	);
}

KtngPersonDialogWithRole.propTypes = {
	onSelect: PropTypes.func,
	orgCd: PropTypes.string,
	deptCd: PropTypes.string
};

export default KtngPersonDialogWithRole;
