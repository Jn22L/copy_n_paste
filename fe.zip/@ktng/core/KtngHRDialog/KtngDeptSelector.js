import { usePrevious } from '@fuse/hooks';
import KtngUtils from '@ktng/utils';
import _ from '@lodash';
import { IconButton, InputAdornment, TextField } from '@material-ui/core';
import SearchIcon from '@material-ui/icons/Search';
import HrService from 'app/services/hrService';
// import * as Actions from 'app/store/actions';
import { openDialog2 } from 'app/store/fuse/dialogSlice2';
import PropTypes from 'prop-types';
import React, { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import KtngDeptDialog from './KtngDeptDialog';

function KtngDeptSelector(props) {
	const dispatch = useDispatch();
	// prettier-ignore
	const [selectedItem, setSelectedItem] = useState({deptCd: props.deptCd, deptNm: ''});
	const preSelectedItem = usePrevious(selectedItem);
	const [label] = useState(props.label);
	const [textValue, setTextValue] = useState('');

	useEffect(() => {
		if (props.deptCd) {
			HrService.getDeptDTO(props.deptCd).then(data => {
				if (!_.isEmpty(data)) setSelectedItem(data);
			});
		}
	}, [props.deptCd]);

	useEffect(() => {
		const _selectedItem = KtngUtils.removeEmptyAttr(selectedItem);
		if (_.isEmpty(_selectedItem)) {
			setTextValue('');
		} else {
			const textVal = props.valueFunc(_selectedItem);
			if (textVal) setTextValue(textVal);
		}
		if (preSelectedItem === undefined) return;
		if (preSelectedItem !== _selectedItem) {
			const target = _.omit(props, ['onSelect', 'valueFunc']);
			props.onSelect(_selectedItem, target);
		}
		// eslint-disable-next-line
	}, [selectedItem]);

	function handleDeptSelect(item) {
		setSelectedItem(item);
	}

	function showKtngDeptDialog() {
		dispatch(
			openDialog2({
				fullWidth: true,
				maxWidth: 'sm',
				children: <KtngDeptDialog onSelect={handleDeptSelect} deptCd={selectedItem.deptCd} />
			})
		);
	}

	const handleChange = event => {
		setSelectedItem({ deptCd: '', deptNm: '' });
	};

	return (
		<TextField
			className={props.className}
			label={label}
			value={textValue}
			onChange={handleChange}
			InputProps={{
				endAdornment: (
					<InputAdornment>
						<IconButton onClick={showKtngDeptDialog}>
							<SearchIcon />
						</IconButton>
					</InputAdornment>
				)
			}}
		/>
	);
}

KtngDeptSelector.propTypes = {
	label: PropTypes.string,
	name: PropTypes.string,
	className: PropTypes.string,
	deptCd: PropTypes.string,
	onSelect: PropTypes.func,
	valueFunc: PropTypes.func
};

KtngDeptSelector.defaultProps = {
	onSelect: item => {},
	valueFunc: item => `[${item.deptCd}] ${item.deptNm}`
};

export default KtngDeptSelector;
