import React, { useEffect, useState } from 'react';
import { FormControl, InputLabel, Select, MenuItem } from '@material-ui/core';
import PropTypes from 'prop-types';
import HrService from 'app/services/hrService';

function KtngDeptSelect(props) {
  const { parCode, selected, name, className, required, label, onSelect, ...others } = props;

  const [selectedCode, setSelectedCode] = useState('');
  const [list, setList] = useState(null);

  useEffect(() => {
    const _parCode = props.parCode;
    if (!_parCode) return;
    if (_parCode === 'all') {
      setSelectedCode(_parCode);
      return;
    }
    // console.log(_parCode);
    setSelectedCode('all');
    HrService.getManDeptCodeDTObyParCode(_parCode).then(data => {
      setList(data);
      // 개선의 여지가 있음....
      if (onSelect) {
        onSelect({ target: { value: 'all' } });
      }
    });
    // eslint-disable-next-line
  }, [parCode]);

  const handleChange = event => {
    // console.log(event);
    const _code = event.target.value;
    setSelectedCode(_code);
    if (onSelect) {
      onSelect(event);
    }
  };

  return (
    <FormControl className={className} required={required}>
      {label && <InputLabel>{label}</InputLabel>}
      <Select value={selectedCode} onChange={handleChange} inputProps={{ name }} {...others}>
        <MenuItem value="all">
          <em>전체</em>
        </MenuItem>
        {list &&
          list.map(item => (
            <MenuItem key={item.code} value={item.code}>
              {item.name}
            </MenuItem>
          ))}
      </Select>
    </FormControl>
  );
}

KtngDeptSelect.propTypes = {
  parCode: PropTypes.string,
  label: PropTypes.string,
  selected: PropTypes.string,
  className: PropTypes.string,
  name: PropTypes.string,
  onSelect: PropTypes.func
};

KtngDeptSelect.defaultProps = {
  selected: 'all',
  required: false,
  disableUnderline: false
};

export default KtngDeptSelect;
