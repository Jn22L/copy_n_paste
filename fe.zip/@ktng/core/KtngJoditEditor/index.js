export { default as KtngJoditEditor } from './KtngJoditEditor';
