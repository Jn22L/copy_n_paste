import React, { forwardRef, useEffect, useLayoutEffect, useRef } from 'react';
import { Jodit } from 'jodit';
import { object, string, func, number } from 'prop-types';
import 'jodit/build/jodit.min.css';

const KtngJoditEditor = forwardRef((props, ref) => {
	const { config, id, name, onBlur, onChange, tabIndex, value, editorRef } = props;

	const textArea = useRef(null);

	useLayoutEffect(() => {
		if (ref) {
			if (typeof ref === 'function') {
				ref(textArea.current);
			} else {
				ref.current = textArea.current;
			}
		}
	}, [textArea, ref]);

	useEffect(() => {
		const element = textArea.current;
		textArea.current = Jodit.make(element, config);
		textArea.current.workplace.tabIndex = tabIndex || -1;

		textArea.current.events.on('blur', e => onBlur(e, textArea.current.value));
		textArea.current.events.on('change', e => onChange(e, textArea.current.value));

		if (id) element.id = id;
		if (name) element.name = name;

		if (typeof editorRef === 'function') {
			editorRef(textArea.current);
		}

		return () => {
			if (textArea.current) {
				textArea.current.destruct();
			}
			textArea.current = element;
		};
		// eslint-disable-next-line
	}, [config]);

	useEffect(() => {
		if (textArea?.current?.value !== value) {
			textArea.current.value = value;
		}
	}, [value]);

	return <textarea ref={textArea} />;
});

KtngJoditEditor.propTypes = {
	config: object,
	id: string,
	name: string,
	onBlur: func,
	onChange: func,
	tabIndex: number,
	value: string,
	editorRef: func
};

KtngJoditEditor.defaultProps = {
	onBlur: (/* e, value */) => {},
	onChange: (/* e, value */) => {}
};

export default KtngJoditEditor;
