import _ from '@lodash';
import ko from 'date-fns/locale/ko';
import PropTypes from 'prop-types';
import React, { useState } from 'react';
import { DateRangePicker, defaultInputRanges, defaultStaticRanges } from 'react-date-range';
import 'react-date-range/dist/styles.css';
import 'react-date-range/dist/theme/default.css';
import './styles.css';

// 라벨 영문-> 한글 전환
const staticRanges = _.map(defaultStaticRanges, range => {
	if (range.label === 'Today') {
		range.label = '오늘';
	} else if (range.label === 'Yesterday') {
		range.label = '어제';
	} else if (range.label === 'This Week') {
		range.label = '이번주';
	} else if (range.label === 'Last Week') {
		range.label = '저번주';
	} else if (range.label === 'This Month') {
		range.label = '이번달';
	} else if (range.label === 'Last Month') {
		range.label = '저번달';
	}
	return range;
});
const inputRanges = _.map(defaultInputRanges, range => {
	if (range.label === 'days up to today') {
		range.label = '오늘까지 선택';
	} else if (range.label === 'days starting today') {
		range.label = '오늘부터 선택';
	}
	return range;
});

function KtngDateRangePicker(props) {
	const [ranges, setRanges] = useState(props.ranges);

	function onChange(item) {
		setRanges([item.selection]);
		if (props.onChange) props.onChange(item);
	}

	return (
		<DateRangePicker
			showSelectionPreview="true"
			moveRangeOnFirstSelection={false}
			dateDisplayFormat="yyyy년 MMM dd일"
			monthDisplayFormat="yyyy년 MMM"
			months={2}
			direction="horizontal"
			ranges={ranges}
			locale={ko}
			staticRanges={staticRanges}
			inputRanges={inputRanges}
			onChange={onChange}
			footerContent={props.footerContent}
			{...props}
		/>
	);
}

KtngDateRangePicker.propTypes = {
	onChange: PropTypes.func,
	footerContent: PropTypes.element,
	ranges: PropTypes.arrayOf(
		PropTypes.shape({
			startDate: PropTypes.instanceOf(Date),
			endDate: PropTypes.instanceOf(Date)
		})
	)
};
KtngDateRangePicker.defaultProps = {
	ranges: [{ startDate: new Date(), endDate: new Date(), key: 'selection' }]
};
export default KtngDateRangePicker;
