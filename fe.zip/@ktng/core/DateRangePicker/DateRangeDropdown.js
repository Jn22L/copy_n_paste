import React, { useEffect, useRef, useState } from 'react';
import { Button, ClickAwayListener, makeStyles, Paper, Popper } from '@material-ui/core';
import moment from 'moment';
import PropTypes from 'prop-types';
import KtngDateRangePicker from './KtngDateRangePicker';

const useStyles = makeStyles(theme => ({
	popper: {
		zIndex: `${theme.zIndex.tooltip}!important`
	},
	paper: { color: '#000' },
	button: { color: '#000' }
}));

// value { startDate, endDate}
// options { placement }
function DateRangeDropdown(props) {
	const classes = useStyles();

	const anchorBtn = useRef();
	const [open, setOpen] = useState(false);
	const [label, setLabel] = useState(props.placeholder);
	const [placement] = useState(props.options.placement);
	const [fromto, setFromto] = useState(props.fromto);
	const [ranges, setRanges] = useState(null);

	useEffect(() => {
		const _fromto = props.fromto;
		if (_fromto) {
			setFromto(_fromto);
			const _label = fromtoToLabel(_fromto);
			setLabel(_label);
		}
	}, [props.fromto]);

	useEffect(() => {
		setRanges([{ ...fromto, key: 'selection' }]);
		// eslint-disable-next-line
	}, [open]);

	const handleClick = event => {
		setOpen(!open);
	};

	const onChangeDateRangePicker = item => {
		setRanges([item.selection]);
	};

	const onSummit = event => {
		setOpen(false);
		const [{ startDate, endDate }] = ranges;
		setFromto({ startDate, endDate });
		const { onChange } = props;
		if (onChange) {
			onChange({ startDate, endDate });
		}
	};

	const onCancel = event => setOpen(false);

	const fromtoToLabel = value => {
		const { startDate, endDate } = value;
		const fromStr = moment(startDate).format('YYYY.MM.DD');
		const toStr = moment(endDate).format('YYYY.MM.DD');
		return `${fromStr} ~ ${toStr}`;
	};

	return (
		<div>
			<Button ref={anchorBtn} variant="contained" color="secondary" onClick={handleClick}>
				{label}
			</Button>
			<Popper
				className={classes.popper}
				open={open}
				placement={placement}
				anchorEl={anchorBtn.current}
				transition
			>
				<ClickAwayListener onClickAway={onCancel}>
					<Paper className={classes.paper}>
						<KtngDateRangePicker
							ranges={ranges}
							onChange={onChangeDateRangePicker}
							footerContent={
								<div className="flex justify-center">
									<Button className={classes.button} onClick={onSummit}>
										선택
									</Button>
									<Button className={classes.button} onClick={onCancel}>
										취소
									</Button>
								</div>
							}
						/>
					</Paper>
				</ClickAwayListener>
			</Popper>
		</div>
	);
}

// { fromto, options, placeholder = '기간을 선택하세요', onChange
DateRangeDropdown.propTypes = {
	fromto: PropTypes.object,
	options: PropTypes.object,
	placeholder: PropTypes.string,
	onChange: PropTypes.func
};
DateRangeDropdown.defaultProps = {
	fromto: { startDate: new Date(), endDate: new Date() },
	placeholder: '기간을 선택하세요',
	options: { placement: 'top' }
};

export default DateRangeDropdown;
