import React, { useEffect, useRef, useState } from 'react';
import {
	Button,
	ClickAwayListener,
	IconButton,
	InputAdornment,
	makeStyles,
	Paper,
	Popper,
	TextField
} from '@material-ui/core';
import DateRangeIcon from '@material-ui/icons/DateRange';
import clsx from 'clsx';
import moment from 'moment';
import PropTypes from 'prop-types';
import KtngDateRangePicker from './KtngDateRangePicker';

const fromtoToLabel = value => {
	const { startDate, endDate } = value;
	const fromStr = moment(startDate).format('YYYY.MM.DD');
	const toStr = moment(endDate).format('YYYY.MM.DD');
	return `${fromStr} ~ ${toStr}`;
};

const useStyles = makeStyles(theme => ({
	popper: {
		zIndex: `${theme.zIndex.tooltip}!important`
	}
}));

function DateRangeSelecter(props) {
	const classes = useStyles();
	const [label] = useState(props.label);
	const [textValue, setTextValue] = useState('');

	const anchor = useRef();
	const [open, setOpen] = useState(false);
	const [placement] = useState(props.options.placement);
	const [fromto, setFromto] = useState(props.fromto);
	const [ranges, setRanges] = useState(null);

	useEffect(() => {
		const _label = fromtoToLabel(fromto);
		setTextValue(_label);
	}, [fromto]);

	useEffect(() => {
		setRanges([{ ...fromto, key: 'selection' }]);
		// eslint-disable-next-line
	}, [open]);

	function showDateRangePicker() {
		setOpen(!open);
	}

	const onChangeDateRangePicker = item => {
		setRanges([item.selection]);
	};

	const onSummit = event => {
		setOpen(false);
		const [{ startDate, endDate }] = ranges;
		setFromto({ startDate, endDate });
		const { onChange } = props;
		if (onChange) {
			onChange({ startDate, endDate });
		}
	};

	const onCancel = event => setOpen(false);

	return (
		<>
			<TextField
				ref={anchor}
				className={clsx(props.className, 'w-208')}
				label={label}
				value={textValue}
				InputProps={{
					endAdornment: (
						<InputAdornment>
							<IconButton onClick={showDateRangePicker}>
								<DateRangeIcon />
							</IconButton>
						</InputAdornment>
					)
				}}
			/>
			<Popper className={classes.popper} open={open} placement={placement} anchorEl={anchor.current} transition>
				<ClickAwayListener onClickAway={onCancel}>
					<Paper>
						<KtngDateRangePicker
							{...props}
							ranges={ranges}
							onChange={onChangeDateRangePicker}
							footerContent={
								<div className="flex justify-center">
									<Button onClick={onSummit}>선택</Button>
									<Button onClick={onCancel}>취소</Button>
								</div>
							}
						/>
					</Paper>
				</ClickAwayListener>
			</Popper>
		</>
	);
}

DateRangeSelecter.propTypes = {
	label: PropTypes.string,
	className: PropTypes.string,
	fromto: PropTypes.object,
	options: PropTypes.object,
	valueFunc: PropTypes.func,
	onChange: PropTypes.func
};

DateRangeSelecter.defaultProps = {
	fromto: { startDate: new Date(), endDate: new Date() },
	options: { placement: 'top-start' },
	valueFunc: fromtoToLabel,
	onChange: item => {}
};

export default DateRangeSelecter;
