class KtngTreeUtils {
  static findItem(keyNm, keyVal, items) {
    let i = 0;
    let found;
    for (; i < items.length; i += 1) {
      if (items[i][keyNm] === keyVal) {
        return items[i];
        // eslint-disable-next-line
      } else if (_.isArray(items[i].children)) {
        found = KtngTreeUtils.findItem(keyNm, keyVal, items[i].children);
        if (found) return found;
      }
    }
    return null;
  }

  static findPath(keyNm, keyVal, items, expanded = []) {
    let i = 0;
    let found;
    for (; i < items.length; i += 1) {
      if (items[i][keyNm] === keyVal) {
        return expanded;
        // eslint-disable-next-line
      } else if (_.isArray(items[i].children)) {
        expanded.push(items[i][keyNm]);
        found = KtngTreeUtils.findPath(keyNm, keyVal, items[i].children, expanded);
        if (found) {
          return found;
        }
        expanded.pop();
      }
    }
    return null;
  }
}

export default KtngTreeUtils;
