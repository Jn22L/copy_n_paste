import React, { useRef } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';
import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import interactionPlugin from '@fullcalendar/interaction';
import { string, array, object, func, bool } from 'prop-types';

const useStyles = makeStyles(theme => ({
	root: {
		'& a': {
			color: theme.palette.text.primary,
			textDecoration: 'normal!important'
		},
		'&  .fc-media-screen': {
			minHeight: '100%'
		},
		'& .fc-scrollgrid, & .fc-theme-standard td, & .fc-theme-standard th': {
			borderColor: `${theme.palette.divider}!important`
		},
		'&  .fc-scrollgrid-section > td': {
			border: 0
		},
		'& .fc-daygrid-day': {
			'&:last-child': {
				borderRight: 0
			}
		},
		'& .fc-col-header-cell': {
			borderWidth: '0 0 1px 0',
			padding: '16px 0',
			'& .fc-col-header-cell-cushion': {
				color: theme.palette.text.secondary,
				fontWeight: 500
			}
		},
		'& .fc-view ': {
			borderRadius: 20,
			overflow: 'hidden',
			border: `1px solid ${theme.palette.divider}`,
			'& > .fc-scrollgrid': {
				border: 0
			}
		},
		'& .fc-daygrid-day-number': {
			color: theme.palette.text.secondary,
			fontWeight: 500
		},
		'& .fc-event': {
			backgroundColor: `${theme.palette.primary.dark}!important`,
			color: `${theme.palette.primary.contrastText}!important`,
			border: 0,
			padding: '0 6px',
			borderRadius: '16px!important'
		}
	}
}));

function KtngCalendar(props) {
	const calendarRef = useRef();

	const classes = useStyles(props);

	const handleDateSelect = selectInfo => {
		const { start, end } = selectInfo;

		props.onDateSelect({ start, end }); // TODO: dispatch(openNewEventDialog({ start, end	}));
	};

	const handleEventClick = clickInfo => {
		const { id, title, allDay, start, end, extendedProps } = clickInfo.event;
		props.onEventClick({ id, title, allDay, start, end, extendedProps }); // TODO: dispatch(openEditEventDialog({ id, ... }));
	};

	const handleDates = rangeInfo => {
		props.onChangeCurrentDate(rangeInfo);
	};

	// const handleEventAdd = addInfo => {};

	// const handleEventChange = changeInfo => {};

	// const handleEventRemove = removeInfo => {};

	// const handleEventDrop = eventDropInfo => {};

	return (
		<div className={classes.root}>
			<FullCalendar
				plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
				headerToolbar={{
					start: 'title',
					center: '',
					end: 'prev,today,next dayGridMonth,timeGridWeek,timeGridDay'
				}}
				// initialView={initialView}
				editable={false} // 일정 수정 불가능
				selectable // 날짜 선택 가능
				// selectMirror // 날짜 드래그 시 잔상 보이기/숨김
				dayMaxEvents
				weekends
				datesSet={handleDates}
				select={handleDateSelect}
				events={props.events}
				eventContent={renderEventContent}
				eventClick={handleEventClick}
				// eventAdd={handleEventAdd}
				// eventChange={handleEventChange}
				// eventRemove={handleEventRemove}
				// eventDrop={handleEventDrop}
				eventTimeFormat={props.hideTime && (() => '')} // 이벤트내용 박스 내에 표시되는 시간문자열: 빈 문자열
				initialDate={new Date()}
				ref={calendarRef}
				locale="ko" // 표시언어 및 시간 한국으로 설정
				height="auto" // 캘린더 내부 스크롤 제거
				buttonText={{
					// prev,
					// next,
					// prevYear,
					// nextYear,
					today: '오늘',
					month: '월',
					week: '주',
					day: '일'
				}}
				buttonHints={{
					prev: '이전',
					next: '다음',
					// prevYear,
					// nextYear,
					today: '오늘',
					month: '월',
					week: '주',
					day: '일'
				}}
			/>
		</div>
	);
}

function renderEventContent(eventInfo) {
	console.log('renderEventContent', eventInfo);
	switch (eventInfo.view.type) {
		case 'dayGridMonth':
			return (
				<div className="flex items-center">
					<Typography className="text-12 font-semibold">{eventInfo.timeText}</Typography>
					<Typography className="text-12 px-4 truncate">{eventInfo.event.title}</Typography>
				</div>
			);
		case 'timeGridWeek':
			return (
				<div className="flex flex-col justify-center">
					<Typography className="text-12 font-semibold">{eventInfo.timeText}</Typography>
					<Typography className="text-12 px-4 truncate">{eventInfo.event.title}</Typography>
				</div>
			);
		case 'timeGridDay':
			return (
				<div className="flex flex-col justify-center">
					<Typography className="text-12 font-semibold">{eventInfo.timeText}</Typography>
					<Typography className="text-12 px-4 truncate">{eventInfo.event.title}</Typography>
				</div>
			);
		default:
			return null;
	}
}

KtngCalendar.propTypes = {
	title: string,
	views: array,
	events: array,
	currentDate: object,
	onDateSelect: func,
	onEventClick: func,
	onChangeCurrentDate: func,
	hideTime: bool
};

KtngCalendar.defaultProps = {
	title: '',
	onDateSelect: data => {
		console.log('onDateSelect', data);
	},
	onEventClick: data => {
		console.log('onEventClick', data);
	},
	onChangeCurrentDate: data => {
		console.log('onChangeCurrentDate', data);
	}
};

export default KtngCalendar;
