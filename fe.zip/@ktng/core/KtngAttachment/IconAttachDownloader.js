import React, { useEffect, useState } from 'react';
import { IconButton, Tooltip, Menu, MenuItem } from '@material-ui/core';
import AttachFileIcon from '@material-ui/icons/AttachFile';
import GetAppIcon from '@material-ui/icons/GetApp';
import PropTypes from 'prop-types';
import { useDispatch } from 'react-redux';
import AttachService from 'app/services/attachService';

function IconAttachDownloader(props) {
	const dispatch = useDispatch();

	const [attachInfos, setAttachInfos] = useState([]);
	const [title, setTitle] = useState('파일명 다운');

	const [isMultiFile, setIsMultiFile] = useState(false);
	const [anchorEl, setAnchorEl] = useState(null);
	const open = Boolean(anchorEl);

	useEffect(() => {
		const _attachInfos = props.attachInfos;

		if (_attachInfos.length === 1) {
			// TODO 파일건수가 1건일 경우
			const attachInfo = _attachInfos[0];
			setTitle(`${attachInfo.fileNm} 파일다운`);
		} else if (_attachInfos.length > 1) {
			// 파일건수가 2건 이상일 경우
			setTitle(`첨부문서 ${_attachInfos.length}건`);
			setIsMultiFile(true);
		}
		setAttachInfos(props.attachInfos);
	}, [props.attachInfos]);

	function handleOnClick(ev) {
		if (isMultiFile) {
			setAnchorEl(ev.currentTarget);
		} else if (attachInfos.length === 1) {
			const attachInfo = attachInfos[0];
			downloadFile(attachInfo.attachNo);
		}
	}

	function handleMenuClose(ev) {
		setAnchorEl(null);
	}

	function downloadFile(attachNo) {
		if (isMultiFile) setAnchorEl(null);
		AttachService.downloadFile(attachNo, dispatch);
	}

	return (
		<>
			<Tooltip title={title}>
				<IconButton size="small" color="secondary" aria-label={title} onClick={handleOnClick}>
					<AttachFileIcon />
				</IconButton>
			</Tooltip>
			{isMultiFile && (
				<Menu anchorEl={anchorEl} keepMounted open={open} onClose={handleMenuClose}>
					{Object.entries(attachInfos).map(([key, atch]) => (
						<MenuItem key={key} className="text-xs" onClick={() => downloadFile(atch.attachNo)}>
							<GetAppIcon fontSize="small" /> {atch.fileNm}
						</MenuItem>
					))}
				</Menu>
			)}
		</>
	);
}
IconAttachDownloader.propTypes = {
	attachInfos: PropTypes.arrayOf(
		PropTypes.shape({
			attachNo: PropTypes.string,
			fileNm: PropTypes.string,
			fileSize: PropTypes.number,
			fileType: PropTypes.string,
			downCnt: PropTypes.number
		})
	)
};

export default IconAttachDownloader;
