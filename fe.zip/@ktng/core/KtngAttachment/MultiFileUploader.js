import React, { useEffect, useState } from 'react';
import { Button, CircularProgress, Fade, Icon, IconButton, makeStyles, Typography } from '@material-ui/core';
import PropTypes from 'prop-types';
import _ from '@lodash';
import { usePrevious } from '@fuse/hooks';
import KtngUtils from '@ktng/utils';
import AttachService from 'app/services/attachService';
import AttachLabel from './AttachLabel';

const useStyles = makeStyles({
	button: {
		textTransform: 'none'
	}
});

function MultiFileUploader(props) {
	const classes = useStyles();
	// TODO 파일번호 기반의 첨부파일리스트의 수정처리
	const [, setAttachNos] = useState([]);
	const [attachInfos, setAttachInfos] = useState([]);
	const preAttachInfos = usePrevious(attachInfos);
	const [btnFileId, setBtnFileId] = useState(null);
	const [isUpload, setIsUpload] = useState(true);
	const [query, setQuery] = useState('idle');

	const [maxUploadCnt] = useState(props.maxUploadCnt);
	const [type] = useState(props.type);

	useEffect(() => {
		const id = KtngUtils.getUid('upload-button-file');
		setBtnFileId(id);
	}, []);

	useEffect(() => {
		// console.log('props.attachNos', props.attachNos);
		const _attachNos = props.attachNos;
		if (Array.isArray(_attachNos)) {
			setAttachNos(_attachNos);
			AttachService.getFileInfos(_attachNos).then(list => setAttachInfos(list));
		}
	}, [props.attachNos]);

	useEffect(() => {
		const uploadAttachInfos = _.filter(attachInfos, o => {
			return o.file;
		});
		setIsUpload(uploadAttachInfos.length === 0);

		// 파일 리스트 변경시 callback 처리
		if (preAttachInfos === undefined) return;
		if (preAttachInfos !== attachInfos) {
			const { onChageAttachInfos } = props;
			if (onChageAttachInfos) onChageAttachInfos(attachInfos);
		}

		console.log('attachInfos', attachInfos);

		// eslint-disable-next-line
	}, [attachInfos]);

	function onSelectFile(event) {
		// console.log(event.target.files);
		let { files } = event.target;
		// maxUploadCnt 만큼 자름
		if (maxUploadCnt !== -1) {
			files = [...files];
			files = files.slice(undefined, maxUploadCnt);
		}
		const _attachInfos = _.map(files, file => {
			return { fileNm: file.name, fileSize: file.size, file };
		});
		// console.log(_attachInfos);
		setAttachInfos(_attachInfos);
	}

	function removeFile(item) {
		// console.log(item);
		// {attachNo: null, attachInfo: {…}}
		const { attachNo, attachInfo } = item;
		if (attachNo === null) {
			setAttachInfos(_.remove(attachInfos, n => n.file !== attachInfo.file));
		}
	}

	function upoload(e) {
		const config = {
			onUploadProgress: progressEvent => {
				const percentCompleted = Math.round((progressEvent.loaded * 100) / progressEvent.total);
				console.log(percentCompleted);
			}
		};

		setQuery('progress');
		const files = _.map(attachInfos, 'file');
		AttachService.uploadFiles(files, config).then(list => {
			// console.log(list);
			setQuery('success');
			setAttachInfos(list);
			// console.log(_.map(list, 'attachNo'));
		});
	}

	return (
		<>
			<label htmlFor={btnFileId}>
				<input
					id={btnFileId}
					type="file"
					className="hidden"
					disabled={props.disabled}
					multiple
					onChange={onSelectFile}
				/>
				<IconButton color="secondary" aria-label="파일선택" component="span" disabled={props.disabled}>
					<Icon fontSize="small">folder</Icon>
				</IconButton>
			</label>
			{type === 'uploader' &&
				Object.entries(attachInfos).map(([key, attachInfo]) => (
					<AttachLabel key={key} attachInfo={attachInfo} onRemove={removeFile} disabled={props.disabled} />
				))}
			{type === 'uploader' && (
				<div className="flex items-center">
					<Button
						className={classes.button}
						component="span"
						variant="outlined"
						color="default"
						size="small"
						disabled={isUpload}
						startIcon={<Icon fontSize="small">arrow_upward</Icon>}
						onClick={upoload}
					>
						업로드
					</Button>
					<span className="ml-10">
						{query === 'success' ? (
							<Typography color="secondary">Success!</Typography>
						) : (
							<Fade
								in={query === 'progress'}
								style={{
									transitionDelay: query === 'progress' ? '800ms' : '0ms'
								}}
								unmountOnExit
							>
								<CircularProgress color="secondary" style={{ width: 20, height: 20 }} />
							</Fade>
						)}
					</span>
				</div>
			)}
			{maxUploadCnt !== -1 && (
				<Typography className="ml-5" variant="caption" color="textSecondary" component="div">
					최대 <b>{maxUploadCnt}</b>개까지 업로드 가능합니다.
				</Typography>
			)}
		</>
	);
}
MultiFileUploader.propTypes = {
	label: PropTypes.string,
	attachNos: PropTypes.arrayOf(PropTypes.string),
	attachInfos: PropTypes.arrayOf(
		PropTypes.shape({
			attachNo: PropTypes.string,
			fileNm: PropTypes.string,
			fileSize: PropTypes.number,
			fileType: PropTypes.string,
			downCnt: PropTypes.number
		})
	),
	maxUploadCnt: PropTypes.number,
	type: PropTypes.oneOf(['uploader', 'selecter']),
	onChageAttachInfos: PropTypes.func
};
MultiFileUploader.defaultProps = {
	label: '파일선택',
	iconLbl: 'attach_file',
	maxUploadCnt: -1,
	type: 'uploader'
};
export default MultiFileUploader;
