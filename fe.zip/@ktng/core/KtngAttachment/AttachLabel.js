import React, { useEffect, useState } from 'react';
import { Icon, IconButton, Link, makeStyles, Typography, Chip } from '@material-ui/core';
import { useDispatch } from 'react-redux';
import _ from '@lodash';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import KtngUtils from '@ktng/utils';
import AttachService from 'app/services/attachService';

const useStyles = makeStyles({
	root: {
		fontSize: 13,
		backgroundColor: 'rgba(0, 0, 0, 0.08)',
		border: '1px solid rgba(0, 0, 0, 0.16)',
		paddingLeft: 16,
		// marginBottom: 8,
		borderRadius: 2,
		display: 'flex',
		justifyContent: 'space-between',
		alignItems: 'center'
	},
	filename: {
		fontWeight: 600,
		cursor: 'pointer'
	},
	size: {
		marginLeft: 8,
		fontWeight: 300
	}
});

// attachNo, attachInfo
function AttachLabel(props) {
	const classes = useStyles();
	const [attachNo, setAttachNo] = useState(null);
	const [attachInfo, setAttachInfo] = useState(null);
	const dispatch = useDispatch();

	useEffect(() => {
		// console.log('attachNo:', attachNo);
		const _attachNo = props.attachNo;
		if (_attachNo) {
			setAttachNo(_attachNo);
			AttachService.getFileInfo(_attachNo, dispatch).then(dto => setAttachInfo(dto));
		} else {
			setAttachNo(null);
		}
		// eslint-disable-next-line
	}, [props.attachNo]);

	useEffect(() => {
		// console.log('attachInfo:', props.attachInfo);
		const _attachInfo = props.attachInfo;
		if (_.isEmpty(_attachInfo)) {
			setAttachInfo(null);
			return;
		}
		if (_attachInfo.attachNo && attachNo !== _attachInfo.attachNo) setAttachNo(_attachInfo.attachNo);
		setAttachInfo(_attachInfo);
		// eslint-disable-next-line
	}, [props.attachInfo]);

	function downloadHandle(e) {
		AttachService.downloadFile(attachNo, dispatch);
	}

	function onCloseHandle(e) {
		// const _attachNo = attachNo;
		// const _attachInfo = attachInfo;

		// // 즉시 파일삭제
		// AttachService.deleteFiles([attachNo]).then(data => {
		// 	console.log(data);
		// 	const { onRemove } = props;
		// 	if (onRemove) {
		// 		onRemove({ attachNo: _attachNo, attachInfo: _attachInfo });
		// 	}
		// });
		if (props.onRemove) {
			props.onRemove({ attachNo, attachInfo });
		}
	}

	return (
		<div className={clsx(classes.root, props.className)}>
			{attachInfo ? (
				<>
					<Typography noWrap className="flex" component="div">
						{attachInfo.attachNo ? (
							<>
								{attachInfo.edmsYn && (
									<Chip className="h-20 rounded mr-4" size="small" label="EDMS" color="primary" />
								)}
								{/* eslint-disable-next-line jsx-a11y/anchor-is-valid */}
								<Link noWrap className={classes.filename} onClick={downloadHandle}>
									{attachInfo.fileNm}
								</Link>
							</>
						) : (
							<>
								<Icon fontSize="small" className="text-gray-500">
									add_circle
								</Icon>
								<Typography variant="caption" noWrap className="ml-4">
									{attachInfo.fileNm}
								</Typography>
							</>
						)}
						<Typography variant="caption" noWrap className={classes.size}>
							({KtngUtils.formatBytes(attachInfo.fileSize)})
						</Typography>
					</Typography>
					<IconButton onClick={onCloseHandle} disabled={props.readOnly}>
						<Icon className="text-16">{attachInfo.attachNo ? 'delete' : 'close'}</Icon>
					</IconButton>
				</>
			) : (
				<>
					<Typography noWrap className="flex">
						<Icon className="text-red-500" fontSize="small">
							help_outline
						</Icon>
						<Typography variant="caption" className="ml-4 text-red-500">
							해당 파일정보를 찾을수가 없습니다.
						</Typography>
					</Typography>
					<IconButton onClick={onCloseHandle}>
						<Icon className="text-16">close</Icon>
					</IconButton>
				</>
			)}
		</div>
	);
}

AttachLabel.propTypes = {
	attachNo: PropTypes.string,
	attachInfo: PropTypes.shape({
		attachNo: PropTypes.string,
		fileNm: PropTypes.string,
		fileSize: PropTypes.number,
		fileType: PropTypes.string,
		downCnt: PropTypes.number
	}),
	onRemove: PropTypes.func
};

export default AttachLabel;
