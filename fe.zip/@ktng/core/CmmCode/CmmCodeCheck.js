import PropTypes from 'prop-types';
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { loadCodeList } from 'app/store/ktng/codeSlice';
import { FormGroup, FormControlLabel, Checkbox } from '@material-ui/core';
import _ from '@lodash';

const CmmCodeCheck = ({ name, row, code1, code2, selected, onSelect, className, disabled }) => {
	const dispatch = useDispatch();
	const code = useSelector(({ ktng }) => ktng.code);

	useEffect(() => {
		dispatch(loadCodeList({ code1, code2 }));
		// eslint-disable-next-line
	}, [code1, code2, selected]);

	const handleChange = (item, { value, checked }) => {
		if (checked) onSelect([...selected, item]);
		else onSelect(_.xor(selected, [item]));
	};

	return (
		<FormGroup className={className} aria-label="position" row={row}>
			{code[`${code1}_${code2}`] &&
				code[`${code1}_${code2}`].map(item => (
					<FormControlLabel
						key={item.code}
						value={item.code}
						control={
							<Checkbox
								checked={_.includes(selected, item)}
								name={name}
								color="primary"
								onChange={event => handleChange(item, event.target)}
								disabled={disabled}
							/>
						}
						label={item.name}
						labelPlacement="end"
					/>
				))}
		</FormGroup>
	);
};

CmmCodeCheck.propTypes = {
	row: PropTypes.bool,
	code1: PropTypes.string,
	code2: PropTypes.string,
	selected: PropTypes.array,
	onSelect: PropTypes.func,
	disabled: PropTypes.bool
};

CmmCodeCheck.defaultProps = {
	row: true,
	selected: [],
	onSelect: () => {}
};

export default CmmCodeCheck;
