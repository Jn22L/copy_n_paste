import KtngUtils from '@ktng/utils';
import _ from '@lodash';
import { FormControl, InputLabel, MenuItem, Select } from '@material-ui/core';
import { loadCodeList } from 'app/store/ktng/codeSlice';
import PropTypes from 'prop-types';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';

const SelectCmmCode = props => {
	const dispatch = useDispatch();
	const codeStore = useSelector(({ ktng }) => ktng.code);

	const { first, second, selected, name, className, required, label, onSelect, overall, ...others } = props;
	const [selectedCode, setSelectedCode] = useState('');
	const [loading, setLoading] = React.useState(true);

	useEffect(() => {
		dispatch(loadCodeList({ code1: first, code2: second }));
		// eslint-disable-next-line
	}, []);

	useEffect(() => {
		if (_.isEmpty(codeStore)) return;
		const _loading = !KtngUtils.isCheckCmmCode([{ code1: first, code2: second }], codeStore);
		setLoading(_loading);
		setSelectedCode(selected);
		// eslint-disable-next-line
	}, [codeStore]);

	const handleChange = event => {
		const _code = event.target.value;
		setSelectedCode(_code);
		if (onSelect) {
			onSelect(event);
		}
	};

	return (
		!loading && (
			<FormControl className={className} required={required}>
				{label && <InputLabel>{label}</InputLabel>}
				<Select value={selectedCode} onChange={handleChange} inputProps={{ name }} {...others}>
					{overall && <MenuItem value={overall}>전체</MenuItem>}
					{codeStore &&
						codeStore[`${first}_${second}`] &&
						codeStore[`${first}_${second}`].map(item => (
							<MenuItem key={item.code} value={item.code}>
								{item.name}
							</MenuItem>
						))}
				</Select>
			</FormControl>
		)
	);
};

SelectCmmCode.propTypes = {
	label: PropTypes.string,
	selected: PropTypes.string,
	className: PropTypes.string,
	first: PropTypes.string,
	second: PropTypes.string,
	name: PropTypes.string,
	onSelect: PropTypes.func,
	overall: PropTypes.string
};

SelectCmmCode.defaultProps = {
	selected: '',
	required: false,
	disableUnderline: false
};

export default SelectCmmCode;
