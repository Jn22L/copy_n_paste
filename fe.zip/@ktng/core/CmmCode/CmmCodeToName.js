import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { loadCodeList } from 'app/store/ktng/codeSlice';
import PropTypes from 'prop-types';
import _ from '@lodash';

const CmmCodeToName = ({ code1, code2, code3 }) => {
	const dispatch = useDispatch();
	const code = useSelector(({ ktng }) => ktng.code);

	const [name, setName] = useState('');

	useEffect(() => {
		dispatch(loadCodeList({ code1, code2 }));
		const obj = _.findLast(code[`${code1}_${code2}`], p => p.code === code3);
		if (obj) setName(obj.name);
		// eslint-disable-next-line
	}, [code1, code2, code3, code]);

	return <>{name}</>;
};

CmmCodeToName.propTypes = {
	code1: PropTypes.string,
	code2: PropTypes.string,
	code3: PropTypes.string
};

export default CmmCodeToName;
