import React, { useEffect, useState } from 'react';
import {
	Button,
	DialogActions,
	DialogContent,
	DialogTitle,
	FormControlLabel,
	Radio,
	RadioGroup,
	TextField
} from '@material-ui/core';
import PropTypes from 'prop-types';
import { useDispatch, useSelector } from 'react-redux';
import BallotIcon from '@material-ui/icons/Ballot';
import { loadCodeList } from 'app/store/ktng/codeSlice';
import { closeDialog } from 'app/store/fuse/dialogSlice';

const CodeDialog = ({ code1, code2, onSelect }) => {
	const dispatch = useDispatch();
	const code = useSelector(({ ktng }) => ktng.code);

	const [selectedItem, setSelectedItem] = useState({ name: '', code: '' });

	useEffect(() => {
		dispatch(loadCodeList({ code1, code2 }));
		// eslint-disable-next-line
	}, []);

	const handleClose = () => dispatch(closeDialog());

	const handleOKBtnClick = () => {
		if (onSelect) {
			onSelect(selectedItem);
		}
		dispatch(closeDialog());
	};

	const handleSelect = (event, value) => setSelectedItem(code[`${code1}_${code2}`].find(item => item.code === value));

	return (
		<>
			<DialogTitle>
				<BallotIcon /> 코드선택
			</DialogTitle>
			<div className="p-10 flex flex-row border-t border-b w-full">
				<TextField
					className="max-w-164 mx-4"
					label="코드"
					name="name"
					size="small"
					variant="outlined"
					value={selectedItem.code}
				/>
				<TextField
					className="mx-4"
					label="코드명"
					name="code"
					size="small"
					variant="outlined"
					fullWidth
					value={selectedItem.name}
				/>
			</div>
			<DialogContent className="border-b">
				<RadioGroup value={selectedItem.code} onChange={handleSelect}>
					{code[`${code1}_${code2}`] &&
						code[`${code1}_${code2}`].map(item => (
							<FormControlLabel
								value={item.code}
								key={item.code}
								control={<Radio color="primary" />}
								label={item.name}
							/>
						))}
				</RadioGroup>
			</DialogContent>
			<DialogActions>
				<Button onClick={handleOKBtnClick} color="primary" autoFocus>
					선택
				</Button>
				<Button onClick={handleClose} color="primary">
					취소
				</Button>
			</DialogActions>
		</>
	);
};

CodeDialog.propTypes = {
	label: PropTypes.string,
	name: PropTypes.string,
	selected: PropTypes.object,
	code1: PropTypes.string,
	code2: PropTypes.string,
	onSelect: PropTypes.func
};

CodeDialog.defaultProps = {
	label: '선택',
	selected: { code: '', name: '' }
};

export default CodeDialog;
