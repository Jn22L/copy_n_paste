import PropTypes from 'prop-types';
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { loadCodeList } from 'app/store/ktng/codeSlice';
import { Select, MenuItem } from '@material-ui/core';
import _ from '@lodash';

const CmmCodeSelect = ({ id, name, label, code1, code2, selected, onSelect, total, className, disabled }) => {
	const dispatch = useDispatch();
	const code = useSelector(({ ktng }) => ktng.code);

	useEffect(() => {
		dispatch(loadCodeList({ code1, code2 }));
		// eslint-disable-next-line
	}, [code1, code2, selected]);

	const handleChange = event => {
		const { value } = event.target;
		const _selected = _.findLast([total, ...code[`${code1}_${code2}`], total], { code: value });
		onSelect(_selected);
	};

	return (
		<Select
			className={className}
			value={selected.code}
			onChange={handleChange}
			label={label}
			inputProps={{ id, name }}
			defaultValue=""
			disabled={disabled}
		>
			{code[`${code1}_${code2}`] &&
				[total, ...code[`${code1}_${code2}`]].map(
					item =>
						item && (
							<MenuItem key={item.code} value={item.code}>
								{item.name}
							</MenuItem>
						)
				)}
		</Select>
	);
};

CmmCodeSelect.propTypes = {
	code1: PropTypes.string,
	code2: PropTypes.string,
	selected: PropTypes.object,
	onSelect: PropTypes.func,
	total: PropTypes.object,
	disabled: PropTypes.bool
};

CmmCodeSelect.defaultProps = {
	selected: {},
	onSelect: () => {}
};

export default CmmCodeSelect;
