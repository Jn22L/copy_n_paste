import PropTypes from 'prop-types';
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { loadCodeList } from 'app/store/ktng/codeSlice';
import { RadioGroup, FormControlLabel, Radio } from '@material-ui/core';
import _ from '@lodash';

const CmmCodeRadio = ({ name, row, code1, code2, selected, onSelect, total, className, disabled }) => {
	const dispatch = useDispatch();
	const code = useSelector(({ ktng }) => ktng.code);

	useEffect(() => {
		dispatch(loadCodeList({ code1, code2 }));
		// eslint-disable-next-line
	}, [code1, code2, selected]);

	const handleChange = event => {
		const { value } = event.target;
		const _selected = _.findLast([total, ...code[`${code1}_${code2}`], total], { code: value });
		onSelect(_selected);
	};

	return (
		<RadioGroup
			className={className}
			aria-label="position"
			name={name}
			row={row}
			onChange={handleChange}
			value={selected}
		>
			{code[`${code1}_${code2}`] &&
				[total, ...code[`${code1}_${code2}`]].map(
					item =>
						item && (
							<FormControlLabel
								key={item.code}
								value={item.code}
								control={
									<Radio checked={_.isEqual(selected, item)} color="primary" disabled={disabled} />
								}
								label={item.name}
								labelPlacement="end"
							/>
						)
				)}
		</RadioGroup>
	);
};

CmmCodeRadio.propTypes = {
	row: PropTypes.bool,
	code1: PropTypes.string,
	code2: PropTypes.string,
	selected: PropTypes.object,
	onSelect: PropTypes.func,
	total: PropTypes.object,
	disabled: PropTypes.bool
};

CmmCodeRadio.defaultProps = {
	row: true,
	selected: {},
	onSelect: () => {}
};

export default CmmCodeRadio;
