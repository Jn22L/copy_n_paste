export { default } from './KtngConfirmDialog';
export { default as KtngConfirmDialog4 } from './KtngConfirmDialog4';
export { default as KtngConfirmDialog5 } from './KtngConfirmDialog5';
