import React from 'react';
import Button from '@material-ui/core/Button';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import PropTypes from 'prop-types';

const KtngConfirmDialog5 = ({ title, children, okClick, cancelClick, showCancelBtn, okBtnLabel }) => {
	return (
		<>
			<DialogTitle id="confirm-dialog-title" color="red">
				{title}
			</DialogTitle>
			<DialogContent>{children}</DialogContent>
			<DialogActions>
				<Button onClick={okClick} color="secondary">
					{okBtnLabel}
				</Button>
				{showCancelBtn && (
					<Button onClick={cancelClick} color="default">
						아니오
					</Button>
				)}
			</DialogActions>
		</>
	);
};

KtngConfirmDialog5.propTypes = {
	title: PropTypes.string,
	okClick: PropTypes.func,
	cancelClick: PropTypes.func,
	showCancelBtn: PropTypes.bool,
	okBtnLabel: PropTypes.string
};

KtngConfirmDialog5.defaultProps = {
	label: '날자기간선택',
	okBtnLabel: '예',
	okClick: () => {},
	cancelClick: () => {},
	showCancelBtn: true
};
export default KtngConfirmDialog5;
