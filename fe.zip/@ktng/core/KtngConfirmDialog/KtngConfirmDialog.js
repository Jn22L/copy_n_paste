import React from 'react';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';

const KtngConfirmDialog = ({ title, children, open, setOpen, onConfirm }) => {
  return (
    <Dialog
      open={!!open}
      onClose={() => setOpen(false)}
      aria-labelledby="confirm-dialog-title"
      aria-describedby="confirm-dialog-description"
    >
      <DialogTitle className="min-w-sm" color="red" id="confirm-dialog-title">
        {title}
      </DialogTitle>
      <DialogContent className="min-w-sm ">
        <DialogContentText id="confirm-dialog-description">{children}</DialogContentText>
      </DialogContent>
      <DialogActions className="min-w-sm ">
        <Button
          onClick={() => {
            setOpen(false);
            onConfirm();
          }}
          color="secondary"
        >
          예
        </Button>
        <Button onClick={() => setOpen(false)} color="default">
          아니오
        </Button>
      </DialogActions>
    </Dialog>
  );
};
export default KtngConfirmDialog;
