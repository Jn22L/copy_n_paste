import React, { useRef, useState, useEffect } from 'react';
import { Tooltip, makeStyles } from '@material-ui/core';
import PropTypes from 'prop-types';
import clsx from 'clsx';
// 두줄 자르기
/*
    white-space: normal;
    line-height: 20px;
    height: 40px;
    text-align: left;
    display: -webkit-box;
    -webkit-line-clamp: 2;Z
    -webkit-box-orient: vertical;
    overflow: hidden;
*/
const useStyles = makeStyles(theme => ({
  tooltip: {
    boxShadow: theme.shadows[1],
    fontSize: 12
  },
  truncateTitle: {
    whiteSpace: 'normal',
    lineHeight: '20px',
    height: 40,
    textAlign: 'left',
    display: '-webkit-box',
    '-webkit-line-clamp': 2,
    '-webkit-box-orient': 'vertical',
    overflow: 'hidden'
  }
}));
function TruncateTitle(props) {
  const classes = useStyles();

  const [title] = useState(props.title);
  const [isOverflowed, setIsOverflow] = useState(false);

  const titleRef = useRef(null);

  useEffect(() => {
    setIsOverflow(titleRef.current.scrollWidth > titleRef.current.clientWidth);
  }, []);

  return (
    <Tooltip classes={{ tooltip: classes.tooltip }} title={title} disableHoverListener={!isOverflowed} arrow>
      <p
        ref={titleRef}
        className={clsx('truncate', props.className)}
        onClick={() => props.onClick && props.onClick()}
        role="presentation"
      >
        {title}
      </p>
    </Tooltip>
  );
}

TruncateTitle.propTypes = {
  title: PropTypes.string,
  onClick: PropTypes.func
};

export default TruncateTitle;
