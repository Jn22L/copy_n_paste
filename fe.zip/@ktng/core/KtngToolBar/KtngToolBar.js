import { Box, Typography } from '@material-ui/core';
import React from 'react';

const KtngToolBar = ({ title, variant, children, hr }) => {
	return (
		<>
			<div className="w-full flex mb-4">
				<Typography variant={variant || 'h6'}>{title}</Typography>
				<Box className="flex items-center ml-auto">{children}</Box>
			</div>
			{!!hr && <hr className="mb-8" />}
		</>
	);
};

export default KtngToolBar;
