export { default } from './KtngToolBar';
