import UutasFileInput from './UutasFileInput';

export default UutasFileInput;
