import { AttachLabel } from '@ktng/core/KtngAttachment';
import { Button, IconButton, Typography } from '@material-ui/core';
import { ArrowUpward, Close } from '@material-ui/icons';
import React from 'react';

const UutasFileInput = ({ newFile, prevAttachNo, onChange, onCancelNewFile, onRemovePrevFile, readOnly }) => {
	return (
		<>
			{newFile ? (
				// 새로 올릴 파일
				<div className="flex">
					<Typography>{newFile.name}</Typography>
					<IconButton
						size="small"
						onClick={e => {
							// setForm(state => ({ ...state, file: undefined }));
							onCancelNewFile();
						}}
					>
						<Close color="error" fontSize="small" />
					</IconButton>
				</div>
			) : (
				<div className="flex items-center">
					{/* file input */}
					<label className="mx-4" htmlFor="vhb0020-file">
						<input
							className="hidden"
							id="vhb0020-file"
							type="file"
							onChange={event => {
								// setForm(state => ({ ...state, file: event.target.files[0] }));
								onChange(event);
							}}
							// disabled={!hasMngAuth}
							disabled={readOnly}
						/>
						<Button
							component="span"
							variant="contained"
							color="secondary"
							startIcon={<ArrowUpward fontSize="small" />}
						>
							일정표첨부
						</Button>
					</label>
					{/* 기존 파일 */}
					{prevAttachNo && (
						<AttachLabel
							attachNo={prevAttachNo}
							onRemove={({ attachNo }) => {
								onRemovePrevFile({ attachNo });
							}}
							readOnly={readOnly}
						/>
					)}
				</div>
			)}
		</>
	);
};

export default UutasFileInput;
