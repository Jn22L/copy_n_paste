import UutasForm from './UutasForm';

export default UutasForm;
