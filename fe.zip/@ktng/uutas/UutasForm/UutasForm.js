import React, { Fragment } from 'react';
import { Collapse, makeStyles } from '@material-ui/core';
import Formsy from 'formsy-react';
import PropTypes from 'prop-types';
import clsx from 'clsx';

const useStyles = makeStyles(theme => ({
	form: {
		width: '100%',
		display: 'flex',
		alignItems: 'center',
		marginBottom: '0.4rem'
	}
}));

const UutasForm = props => {
	const classes = useStyles();

	return (
		<Collapse in={props.expanded} timeout="auto" unmountOnExit>
			<Formsy className={classes.form}>
				<div className="w-full" ref={props.srchRef}>
					<table className={clsx('table4', props.fullWidth && 'w-full')}>
						<tbody>
							{props.schema.map((row, rowIdx) => (
								<tr key={rowIdx}>
									{row.map((header, colIdx) => (
										<Fragment key={colIdx}>
											{/* 표시할 라벨이 있으면 헤더 그리기 */}
											{header.label && (
												<th
													className={header.required ? 'required' : ''}
													style={{ maxWidth: header.width }}
													rowSpan={header.rowSpan}
													colSpan={1} // 항상 1열씩만 차지
												>
													{header.label}
												</th>
											)}

											{/* 폼 안에 넣을 뷰가 있으면 칸 그리기 */}
											{props[header.id] && (
												<td
													align={header.align}
													style={{ maxWidth: header.width }}
													rowSpan={header.rowSpan}
													colSpan={header.colSpan}
												>
													{props[header.id]}
												</td>
											)}
										</Fragment>
									))}
								</tr>
							))}
						</tbody>
					</table>
				</div>
			</Formsy>
		</Collapse>
	);
};

UutasForm.propTypes = {
	expanded: PropTypes.bool,
	fullWidth: PropTypes.bool,
	srchRef: PropTypes.object,
	schema: PropTypes.array
};

UutasForm.defaultProps = {
	fullWidth: false,
	expanded: true,
	schema: []
};

export default UutasForm;
