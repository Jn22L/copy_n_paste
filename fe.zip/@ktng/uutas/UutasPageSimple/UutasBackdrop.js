import { Backdrop, CircularProgress } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import React from 'react';

const useStyles = makeStyles(() => ({
	root: {
		zIndex: 100,
		backgroundColor: '#8885'
	}
}));

const UutasBackdrop = ({ open, options }) => {
	const classes = useStyles();

	return (
		<Backdrop
			classes={classes}
			open={open}
			// onClick={() => {}}
			{...options}
		>
			<CircularProgress color="primary" />
		</Backdrop>
	);
};

export default UutasBackdrop;
