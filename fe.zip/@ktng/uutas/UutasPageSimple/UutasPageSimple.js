import React from 'react';
import FusePageSimple from '@fuse/core/FusePageSimple';
import { Typography } from '@material-ui/core';
import { List } from '@material-ui/icons';
import * as PropTypes from 'prop-types';
import UutasBackdrop from './UutasBackdrop';

const UutasPageSimple = props => {
	return (
		<FusePageSimple
			classes={{
				header: 'min-h-72 h-auto',
				content: 'flex p-16 sm:24',
				contentWrapper: 'mb-32'
			}}
			header={
				<div className="w-full">
					<div className="flex flex-1 items-center justify-between p-16 sm:p-24">
						<div className="flex items-center">
							<List className="text-32" />
							<Typography className="hidden sm:flex mx-0 sm:mx-12" variant="h6">
								{props.title}
							</Typography>
						</div>
					</div>
				</div>
			}
			content={
				<div className="w-full flex flex-col">
					{props.children}
					<UutasBackdrop open={props.loading} />
				</div>
			}
			{...props}
		/>
	);
};

UutasPageSimple.propTypes = {
	leftSidebarHeader: PropTypes.node,
	leftSidebarContent: PropTypes.node,
	leftSidebarVariant: PropTypes.node,
	rightSidebarHeader: PropTypes.node,
	rightSidebarContent: PropTypes.node,
	rightSidebarVariant: PropTypes.node,
	header: PropTypes.node,
	content: PropTypes.node,
	contentToolbar: PropTypes.node,
	sidebarInner: PropTypes.bool,
	innerScroll: PropTypes.bool,
	loading: PropTypes.bool
};

UutasPageSimple.defaultProps = {};

export default React.memo(UutasPageSimple);
