import UutasToolBar from './UutasToolBar';

export default UutasToolBar;
