import React from 'react';
import { Box, Typography, Button, IconButton, makeStyles } from '@material-ui/core';
import PropTypes from 'prop-types';
import { Add, Close, ExpandMore, Remove, Replay, Save, Search } from '@material-ui/icons';
import clsx from 'clsx';
import { KtngDateUtils, KtngIbSheetUtils } from '@ktng/utils';

const useStyles = makeStyles(theme => ({
	toolbar: {
		width: '100%',
		display: 'flex',
		marginBottom: '0.4rem',
		'& .expand': {
			marginLeft: '10px',
			transform: 'rotate(0deg)',
			transition: theme.transitions.create('transform', {
				duration: theme.transitions.duration.shortest
			})
		},
		'& .expandOpen': {
			transform: 'rotate(180deg)'
		}
	},
	toolbarButtonLabel: {
		display: 'none',
		paddingLeft: '0.8rem',
		[theme.breakpoints.up('sm')]: {
			display: 'flex'
		}
	}
}));

const UutasToolBar = props => {
	const classes = useStyles();

	function handleBtnAddClick() {
		if (!props.sheet) {
			console.debug('UutasToolBar 컴포넌트의 sheet 속성이 undefined 입니다.');
			return;
		}

		let newData = {};
		if (typeof props.onBtnAddClick === 'function') {
			newData = props.onBtnAddClick() || {};
		}

		KtngIbSheetUtils.addRow(props.sheet, newData);
	}

	function handleBtnDownExcelClick() {
		if (!props.sheet) {
			console.debug('UutasToolBar 컴포넌트의 sheet 속성이 undefined 입니다.');
			return;
		}

		let excelConfig = {};
		if (typeof props.onBtnDownExcelClick === 'function') {
			excelConfig = props.onBtnDownExcelClick() || {};
		}

		props.sheet.down2Excel({
			SheetDesign: 1,
			fileName: `${props.title}_${KtngDateUtils.getDateYYYYMMDD()}.xlsx`,
			merge: 1, // 그리드의 셀병합 유지여부
			...excelConfig
		});
	}

	return (
		<div className={classes.toolbar}>
			<Typography variant={props.variant}>{props.title}</Typography>
			{props.subtitle}
			<Box className="flex items-center ml-auto h-32">
				<>
					{props.children}

					{/* 조회 */}
					{props.onBtnSearchClick && (
						<Button
							aria-label="search"
							color="primary"
							onClick={props.onBtnSearchClick}
							disabled={props.btnSearchDisabled}
						>
							<Search />
							<span className={classes.toolbarButtonLabel}>조회</span>
						</Button>
					)}

					{/* 추가 */}
					{props.onBtnAddClick && (
						<Button
							aria-label="add"
							color="primary"
							onClick={handleBtnAddClick}
							disabled={props.btnAddDisabled}
						>
							<Add />
							<span className={classes.toolbarButtonLabel}>추가</span>
						</Button>
					)}

					{/* 삭제 */}
					{props.onBtnDeleteClick && (
						<Button
							aria-label="add"
							color="primary"
							onClick={props.onBtnDeleteClick}
							disabled={props.btnDeleteDisabled}
						>
							<Remove />
							<span className={classes.toolbarButtonLabel}>삭제</span>
						</Button>
					)}

					{/* 초기화 */}
					{props.onBtnInitSheetClick && (
						<Button
							aria-label="init"
							color="primary"
							onClick={props.onBtnInitSheetClick}
							disabled={props.btnInitSheetDisabled}
						>
							<Replay />
							<span className={classes.toolbarButtonLabel}>초기화</span>
						</Button>
					)}

					{/* 저장 */}
					{props.onBtnSaveClick && (
						<Button
							aria-label="save"
							color="primary"
							onClick={props.onBtnSaveClick}
							disabled={props.btnSaveDisabled}
						>
							<Save />
							<span className={classes.toolbarButtonLabel}>저장</span>
						</Button>
					)}

					{/* 엑셀 다운로드 */}
					{props.onBtnDownExcelClick && (
						<Button
							aria-label="search"
							color="primary"
							onClick={handleBtnDownExcelClick}
							disabled={props.btnDownExcelDisabled}
						>
							<img src="assets/images/ibsheet/excel-export.svg" width={24} alt="excel" />
							<span className={classes.toolbarButtonLabel}>엑셀 다운로드</span>
						</Button>
					)}

					{/* 취소 */}
					{props.onBtnCancelClick && (
						<Button
							aria-label="cancel"
							color="primary"
							onClick={props.onBtnCancelClick}
							disabled={props.btnCancelDisabled}
						>
							<Close />
							<span className={classes.toolbarButtonLabel}>취소</span>
						</Button>
					)}

					{/* 보이기/숨기기 */}
					{props.onBtnToggleClick && (
						<IconButton
							className={clsx('expand', {
								expandOpen: props.expanded
							})}
							onClick={() => props.onBtnToggleClick(!props.expanded)}
							aria-expanded={props.expanded}
							aria-label="보이기/숨기기"
							disabled={props.btnToggleDisabled}
						>
							<ExpandMore />
						</IconButton>
					)}
				</>
			</Box>
		</div>
	);
};

UutasToolBar.propTypes = {
	title: PropTypes.string,
	subtitle: PropTypes.string,
	variant: PropTypes.string,
	children: PropTypes.node,
	sheet: PropTypes.object,
	// 조회 버튼
	onBtnSearchClick: PropTypes.func,
	btnSearchDisabled: PropTypes.bool,
	// 추가 버튼
	onBtnAddClick: PropTypes.func,
	btnAddDisabled: PropTypes.bool,
	// 삭제 버튼
	onBtnDeleteClick: PropTypes.func,
	btnDeleteDisabled: PropTypes.bool,
	// 초기화 버튼
	onBtnInitSheetClick: PropTypes.func,
	btnInitSheetDisabled: PropTypes.bool,
	// 저장 버튼
	onBtnSaveClick: PropTypes.func,
	btnSaveDisabled: PropTypes.bool,
	// 엑셀다운로드 버튼
	onBtnDownExcelClick: PropTypes.func,
	btnDownExcelDisabled: PropTypes.bool,
	// 보이기/숨기기 버튼
	expanded: PropTypes.bool,
	onBtnToggleClick: PropTypes.func,
	btnToggleDisabled: PropTypes.bool
};

UutasToolBar.defaultProps = {
	title: '검색 조건',
	subtitle: '',
	variant: 'h6',
	btnSearchDisabled: false,
	btnAddDisabled: false,
	btnDeleteDisabled: false,
	btnInitSheetDisabled: false,
	btnSaveDisabled: false,
	btnDownExcelDisabled: false,
	expanded: true,
	btnToggleDisabled: false
};

export default UutasToolBar;
