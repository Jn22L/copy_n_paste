import format from 'date-fns/format';
import DateFnsUtils from '@date-io/date-fns';
import koLocale from 'date-fns/locale/ko';

class KtngFnsUtils extends DateFnsUtils {
	locale = koLocale;

	getCalendarHeaderText(date) {
		return format(date, 'yyyy년 MMM', { locale: this.locale });
	}

	getDatePickerHeaderText(date) {
		return format(date, 'yyyy년 MMM do', { locale: this.locale });
	}

	getDateTimePickerHeaderText(date) {
		return format(date, 'MMM do', { locale: this.locale });
	}
}

export default KtngFnsUtils;
