import React from 'react';
import numeral from 'numeral';
import moment from 'moment';
import { showMessage } from 'app/store/fuse/messageSlice';
import _ from '@lodash';
import { closeDialog, openDialog } from 'app/store/fuse/dialogSlice';
import { KtngConfirmDialog4 } from '@ktng/core/KtngConfirmDialog';
import store from 'app/store';

let lastId = 0;

const colorSet = [
	'#f44336', // red 50
	'#e91e63', // pink 50
	'#9c27b0', // purple 50
	'#673ab7', // deepPurple 50
	'#3f51b5', // indigo 50
	'#2196f3', // blue 50
	'#03a9f4', // lightBlue 50
	'#00bcd4', // cyan 50
	'#009688', // teal 50
	'#4caf50', // green 50
	'#8bc34a', // lightGreen 50
	'#cddc39', // lime 50
	'#ffeb3b', // yellow 50
	'#ffc107', // amber 50
	'#ff9800', // orange 50
	'#ff5722', // deepOrange 50
	'#795548', // brown 50
	'#9e9e9e', // grey 50
	'#607d8b' // blueGrey 50
]; // Material Design color system

const colorSet2 = [
	'#ef767a',
	'#456990',
	'#49beaa',
	'#80cb50',
	'#eeb868',
	'#1d2355',
	'#764583',
	'#ce5a4c',
	'#49dcb1',
	'#ffed77'
]; // mix
// https://coolors.co/ef767a-456990-49beaa-49dcb1-eeb868
// https://coolors.co/1d2355-764583-ce5a4c-80cb50-ffed77

class KtngUtils {
	static getCommaNum(val) {
		return numeral(val).format();
	}

	// axios response 처리 공통으로..
	static responseHandler(response, resolve, reject) {
		if (response.data) resolve(response.data);
		else reject(response.data.error);
	}

	// createAsyncThunk 에러 처리 공통으로..
	static catchThunkErrorHandler(err, dispatch, rejectWithValue) {
		dispatch(showMessage({ message: err.msg || '처리중 에러가 발생하였습니다.', variant: 'error' }));

		// eslint-disable-next-line
		let error = err; // cast the error for access
		if (!error.response) {
			throw err;
		}

		return rejectWithValue(error.response.data);
	}

	// Object 없는값 제거
	static removeEmptyAttr(obj) {
		Object.keys(obj).forEach(key => (obj[key] == null || obj[key] === '') && delete obj[key]);
		return obj;
	}

	static getUid(prefix = 'id') {
		lastId += 1;
		return `${prefix}${lastId}`;
	}

	// 공통코드 관련 유틸
	// checkCode: [ { commCodeChk: 'AUTH_GUBUN' } ]
	// codeStore: { 'AUTH_GUBUN': Array() }
	// checkCode의 코드값이 codeStore에 모두 존재할경우 true를 출력
	static isCheckCmmCode(checkCode, codeStore) {
		const load = _.map(checkCode, p => {
			const key = p.commCodeChk;
			return !_.isEmpty(codeStore[key]);
		});
		return !_.isEmpty(checkCode) && _.every(load);
	}

	static cmmCodeToName(commCodeChk, commCode) {
		const codeStore = store.getState().ktng.code;
		const codeList = codeStore[commCodeChk];
		const obj = _.findLast(codeList, p => p.commCode === commCode);
		if (obj) return obj.commCodeName;
		return null;
	}

	// https://stackoverflow.com/questions/15900485/correct-way-to-convert-size-in-bytes-to-kb-mb-gb-in-javascript
	static formatBytes(bytes, decimals = 2) {
		if (bytes === 0) return '0 Bytes';

		const k = 1024;
		const dm = decimals < 0 ? 0 : decimals;
		const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];

		const i = Math.floor(Math.log(bytes) / Math.log(k));

		const calcVal = parseFloat((bytes / k ** i).toFixed(dm));
		return `${calcVal} ${sizes[i]}`;
	}

	static formatTelNo(str) {
		/* eslint-disable no-else-return */
		if (!str) return '';
		str = str.replace(/[^0-9]/g, '');
		let tmp = '';
		if (str.length < 4) {
			return str;
		} else if (str.length < 7) {
			tmp += str.substr(0, 3);
			tmp += '-';
			tmp += str.substr(3);
			return tmp;
		} else if (str.length < 11) {
			tmp += str.substr(0, 3);
			tmp += '-';
			tmp += str.substr(3, 3);
			tmp += '-';
			tmp += str.substr(6);
			return tmp;
		} else {
			tmp += str.substr(0, 3);
			tmp += '-';
			tmp += str.substr(3, 4);
			tmp += '-';
			tmp += str.substr(7);
			return tmp;
		}
		// return str;
	}

	static getColors(type = 't2') {
		return type === 't2' ? colorSet2 : colorSet;
	}

	// 유니코드가 포함된 문자열의 바이트 수 카운팅 (한글 2byte로 인식)
	static getStrByteLength(str) {
		if (!str || typeof str !== 'string') return 0;

		let byteLength = 0;
		for (let i = 0; i < str.length; i += 1) {
			const char = escape(str.charAt(i));
			if (char.indexOf('%u') !== -1) {
				byteLength += 2; // 유니코드면 2byte
			} else {
				byteLength += 1; // 그외 1byte
			}
		}

		return byteLength;
	}

	/**
	 * validationComps
	 * 조회 및 저장 전 컴포넌트 체크
	 *
	 * comps 구성요소
	 * [
	 * 	{ key: , value: , required: , type: , maxLength: , minLength: , expression: }
	 * ]
	 *
	 * key(text) 					- 컴포넌트 이름(필수)
	 * value(text, number, date)	- 컴포넌트 값(필수)
	 * type(text, number, date) 	- 컴포넌트 타입(필수)
	 *
	 * required(boolean) 			- 필수여부(선택)
	 * maxLength(number) 			- 컴포넌트 최대길이(선택)
	 * minLength(number) 			- 컴포넌트 최소길이(선택)
	 * expression(expression) 		- 허용가능한 문자 expression(선택)
	 *
	 * @param 	{List} 		compsObj 컴포넌트 리스트
	 * @returns {boolean} 	validation 결과
	 */
	static validationComps(compsObj, dispatch, compsRef = null) {
		const MESSAGE_TYPE = 'error';

		try {
			if (!compsObj || !(compsObj instanceof Array)) {
				dispatch(showMessage({ message: 'compsObj는 Array로 입력해주세요.', variant: MESSAGE_TYPE }));
				throw new Error();
			}

			compsObj
				.map((compObj, idx) => {
					/* compObj 형식 검사 */
					if (!(compObj instanceof Object)) {
						dispatch(showMessage({ message: 'compObj는 Object로 입력해주세요.', variant: MESSAGE_TYPE }));
						throw new Error();
					}

					/* compObj 필수속성 검사 */
					['key', 'value', 'type'].map(requiredProp => {
						// eslint-disable-next-line no-prototype-builtins
						if (!compObj.hasOwnProperty(requiredProp)) {
							// prettier-ignore
							dispatch(showMessage({ message: `${idx}행의 ${requiredProp} 속성은 필수입니다.`, variant: MESSAGE_TYPE }));
							throw new Error();
						}

						return true;
					});

					return compObj;
				})
				.map(compObj => {
					/* 필수요소 검사 */
					// eslint-disable-next-line no-prototype-builtins
					if (compObj.hasOwnProperty('required') && compObj.required) {
						if (compObj.value === null || compObj.value === undefined || compObj.value === '') {
							// prettier-ignore
							dispatch(showMessage({ message: `${compObj.key}은(는) 필수값입니다.`, variant: MESSAGE_TYPE }));
							throw new Error(compObj.key);
						}
					}

					return compObj;
				})
				.map(compObj => {
					/*
					 * type 검사
					 *
					 * 1. text 		- 검사없음
					 * 2. number 	- 숫자인지 검사
					 * 3. date 		- date형식인지 검사
					 */
					if (compObj.type === 'text') {
						//
					} else if (compObj.type === 'number') {
						if (compObj.value != null && compObj.value !== '' && Number.isNaN(compObj.value)) {
							// prettier-ignore
							dispatch(showMessage({ message: `${compObj.key}이(가) number 형식이 아닙니다.`, variant: MESSAGE_TYPE }));
							throw new Error(compObj.key);
						}
					} else if (compObj.type === 'date') {
						if (compObj.value != null && compObj.value !== '' && !moment(compObj.value).isValid()) {
							// prettier-ignore
							dispatch(showMessage({ message: `${compObj.key}이(가) date 형식이 아닙니다.`, variant: MESSAGE_TYPE }));
							throw new Error(compObj.key);
						}
					} else {
						// prettier-ignore
						dispatch(showMessage({ message: `${compObj.key}의 type 속성이 잘못되었습니다.`, variant: MESSAGE_TYPE }));
						throw new Error(compObj.key);
					}

					return compObj;
				})
				.map(compObj => {
					/* length 검사 */
					// eslint-disable-next-line no-prototype-builtins
					if (compObj.hasOwnProperty('maxLength')) {
						if (!_.isEmpty(compObj.value) && compObj.value.toString().length > compObj.maxLength) {
							// prettier-ignore
							dispatch(showMessage({ message: `${compObj.key}은(는) ${compObj.maxLength}자 이하이어야 합니다.`, variant: MESSAGE_TYPE }));
							throw new Error(compObj.key);
						}
					}

					// eslint-disable-next-line no-prototype-builtins
					if (compObj.hasOwnProperty('minLength')) {
						if (!_.isEmpty(compObj.value) && compObj.value.toString().length < compObj.minLength) {
							// prettier-ignore
							dispatch(showMessage({ message: `${compObj.key}은(는) ${compObj.minLength}자 이상이어야 합니다.`, variant: MESSAGE_TYPE }));
							throw new Error(compObj.key);
						}
					}

					// eslint-disable-next-line no-prototype-builtins
					if (compObj.hasOwnProperty('maxByteLength')) {
						if (
							!_.isEmpty(compObj.value) &&
							this.getStrByteLength(compObj.value.toString()) > compObj.maxByteLength
						) {
							// prettier-ignore
							dispatch(showMessage({ message: `${compObj.key}은(는) ${compObj.maxByteLength}byte 이하이어야 합니다.`, variant: MESSAGE_TYPE }));
							throw new Error(compObj.key);
						}
					}

					// eslint-disable-next-line no-prototype-builtins
					if (compObj.hasOwnProperty('minByteLength')) {
						if (
							!_.isEmpty(compObj.value) &&
							this.getStrByteLength(compObj.value.toString()) < compObj.minByteLength
						) {
							// prettier-ignore
							dispatch(showMessage({ message: `${compObj.key}은(는) ${compObj.minByteLength}byte 이상이어야 합니다.`, variant: MESSAGE_TYPE }));
							throw new Error(compObj.key);
						}
					}

					return compObj;
				})
				.map(compObj => {
					/* expression 검사 */
					// eslint-disable-next-line no-prototype-builtins
					if (compObj.hasOwnProperty('expression')) {
						if (compObj.value != null && compObj.value !== '' && !compObj.expression.test(compObj.value)) {
							// prettier-ignore
							dispatch(showMessage({ message: `${compObj.key}에 허용되지 않는 문자가 포함되었습니다.`, variant: MESSAGE_TYPE }));
							throw new Error(compObj.key);
						}
					}

					return compObj;
				});
		} catch (err) {
			/* validation 실패한 컴포넌트 포커싱 */
			if (compsRef != null) {
				if (compsRef.current === null || compsRef.current === undefined) {
					return false;
				}
				const tbodyList = compsRef.current.getElementsByTagName('tbody');

				for (let tbodyIdx = 0; tbodyIdx < tbodyList.length; tbodyIdx += 1) {
					const trList = tbodyList[tbodyIdx];
					const thList = trList.getElementsByTagName('th');

					for (let thIdx = 0; thIdx < thList.length; thIdx += 1) {
						const th = thList[thIdx];

						if (th.innerText === err.message) {
							const td = th.nextElementSibling;
							const input = td.getElementsByTagName('input')[0];
							if (input) input.focus();
							return false;
						}
					}
				}
			}

			return false;
		}

		return true;
	}

	/**
	 * 서버 저장 시 리스트데이터 validation check
	 *
	 * @param list 저장할 리스트
	 * @param requiredProps 필수로 입력해야하는 속성 및 속성명
	 * Ex)
	 * {
	 *   id: '아이디',
	 *   name: '이름',
	 *   phone: '전화번호',
	 *   ...
	 * }
	 * @param dispatch
	 */
	static validationSaveData(list = [], requiredProps = {}, dispatch, onValidationSuccessCallback) {
		if (list.length === 0) {
			// prettier-ignore
			dispatch(showMessage({ message: '저장할 데이터가 없습니다.' }));
			return false;
		}

		const requiredPropKeys = Object.keys(requiredProps);
		let hasEmptyRequiredProp = false;
		for (let i = 0; i < list.length; i += 1) {
			const item = list[i];

			// list 항목(item)의 속성 중 필수 속성이 비어있는 경우
			hasEmptyRequiredProp = requiredPropKeys.some(key => _.isEmpty(String(item[key])));
			if (hasEmptyRequiredProp) {
				break;
			}

			// list 항목(item)의 속성 중 필수 속성이 Null 값인 경우
			hasEmptyRequiredProp = requiredPropKeys.some(key => _.isNull(item[key]));
			if (hasEmptyRequiredProp) {
				break;
			}
		}

		if (hasEmptyRequiredProp) {
			let strRequiredProps = Object.values(requiredProps).join(', ');
			strRequiredProps = strRequiredProps ? ` (${strRequiredProps})` : '';
			// prettier-ignore
			dispatch(showMessage({ message: `필수값${strRequiredProps}이 누락되었습니다. 입력사항을 다시한번 확인해주세요.`, variant: 'error' }));
			return false;
		}

		dispatch(
			openDialog({
				children: (
					<KtngConfirmDialog4
						title="저장 확인"
						okClick={() => {
							dispatch(closeDialog());
							onValidationSuccessCallback();
						}}
						cancelClick={() => dispatch(closeDialog())}
					>
						변경사항을 저장하시겠습니까?
					</KtngConfirmDialog4>
				)
			})
		);

		return true;
	}

	// 게시판 작성일시 표시
	static convertBoardDate(date) {
		if (moment(date).isBefore(moment().subtract(1, 'days'), 'days')) {
			return moment(date).format('YYYY.MM.DD'); // 9999-99-99
		}
		return moment(date).startOf('hour').fromNow(); // 00분 전, 00시간 전 ...
	}

	/**
	 * makRpad
	 * 문자열 뒷부분을 지정한 만큼 *로 마스킹합니다.
	 *
	 * param : abcded, len : 2 일 경우, abcd** 로 리턴됩니다.
	 *
	 * 1. len 값이 없거나, len 0보다 작으면
	 * 입력된 문자열 그대로 다시 리턴됩니다.
	 *
	 * 2. len 값이 문자열 길이보다 크다면
	 * 입력된 문자열 모두 *로 치환되서 리턴됩니다.
	 *
	 * @param {String} param 문자열
	 * @param {Number} len 마스킹적용길이
	 * @param {Number} strtIdx 마스킹시작위치 없을 경우는 뒤에서 부터 len 만큼 마스킹 처리
	 */
	static maskRpad = (param, len, strtIdx) => {
		// eslint-disable-next-line no-restricted-globals
		if (!param || param.length <= 0 || !len || isNaN(len)) {
			return param;
		}
		// eslint-disable-next-line no-restricted-globals
		if (!isNaN(param)) {
			param = param.toString();
		}
		if (param.length < len) {
			len = param.length;
		}
		if (strtIdx === null || strtIdx === undefined) {
			strtIdx = param.length - len;
		}
		let padParam = param.substr(0, strtIdx);
		for (let i = 0; i < len; i += 1) {
			padParam = padParam.concat('*');
		}
		for (let i = strtIdx + len; i < param.length; i += 1) {
			padParam = padParam.concat(param[i]);
		}
		return `${padParam}`;
	};

	// https://zero-jin.tistory.com/13
	// 쿠키설정
	static setCookie(name, value, expiredays) {
		const todayDate = new Date();
		todayDate.setDate(todayDate.getDate() + expiredays);
		document.cookie = `${name}=${escape(value)}; path=/; expires=${todayDate.toGMTString()};`;
	}

	static setCookie2(name, value) {
		document.cookie = `${name}=${escape(value)}; path=/;`;
	}

	// 쿠키 불러오기
	// eslint-disable-next-line
	static getCookie(name) {
		const obj = `${name}=`;
		let x = 0;
		while (x <= document.cookie.length) {
			const y = x + obj.length;
			if (document.cookie.substring(x, y) === obj) {
				let endOfCookie = document.cookie.indexOf(';', y);
				if (endOfCookie === -1) endOfCookie = document.cookie.length;
				return unescape(document.cookie.substring(y, endOfCookie));
			}
			x = document.cookie.indexOf(' ', x) + 1;
			if (x === 0) break;
		}
		return '';
	}

	static deleteCookie(name) {
		const todayDate = new Date();
		document.cookie = `${name}= ;expires=${todayDate.toUTCString()}; path=/`;
	}

	static appendPathParams(url, pathParams = []) {
		pathParams
			.filter(pathParam => !!pathParam)
			.forEach(pathParam => {
				url += `/${pathParam}`;
			});
		return url;
	}
}

export default KtngUtils;
