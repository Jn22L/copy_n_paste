import loader from '@ibsheet/loader';
import FuseUtils from '@fuse/utils/FuseUtils';

export const ibsheetLibs = [
	{
		name: 'ibsheet',
		baseUrl: '/assets/js/ibsheet/'
	},
	{
		name: 'ibsheet-common',
		url: '/assets/js/ibsheet/plugins/ibsheet-common.js'
	},
	{
		name: 'ibsheet-excel',
		url: '/assets/js/ibsheet/plugins/ibsheet-excel.js'
	},
	{
		name: 'ibsheet-dialog',
		url: '/assets/js/ibsheet/plugins/ibsheet-dialog.js'
	}
];

// 라이브러리 로딩 완료시 호출
class IbsheetEvent extends FuseUtils.EventEmitter {
	init() {
		this.super();
	}
}

const instance = new IbsheetEvent();

loader
	.config({
		registry: ibsheetLibs
		// debug: true
	})
	.on('loaded', evt => {
		// console.log(evt);
		const { name } = evt.target;
		// console.log(`loaded ${name}!!`);
		instance.emit('onLoaded', name);
	});
loader.load(); // ibsheet 로드

export default instance;
