class KtngDateUtils {
	// 날짜 YYYYMMDD로 가져오기
	static getDateYYYYMMDD(type) {
		const date = new Date();
		const year = date.getFullYear();
		let month = 1 + date.getMonth();
		month = month >= 10 ? month : `0${month}`;
		let day = date.getDate();
		day = day >= 10 ? day : `0${day}`;

		let prtDate = `${year}${month}${day}`;

		if (type === 1) prtDate = `${year}/${month}/${day}`;
		else if (type === 2) prtDate = `${year}년 ${month}월 ${day}일`;

		return prtDate;
	}

	// 날짜 YYYY로 가져오기
	static getDateYYYY() {
		const date = new Date();
		const year = date.getFullYear();
		return `${year}`;
	}

	// 유닉스 시간 mmdd변환
	static changeUnixMMDD(unix) {
		if (unix === '') {
			return '';
		}
		const date = new Date(unix);
		let month = 1 + date.getMonth();
		month = month >= 10 ? month : `0${month}`;
		let day = date.getDate();
		day = day >= 10 ? day : `0${day}`;
		return `${month}${day}`;
	}
}

export default KtngDateUtils;
