import _ from '@lodash';

class KtngIbSheetUtils {
	// IBSheet 상태컬럼 업데이트
	static updateRowStatus(sheet, row, col, val, oldval) {
		// 사이드이펙트 처리
		if (col === 'delYn') {
			if (row.rowStatus === 'I' && val) {
				sheet.removeRow(row);
			}
			if (row.rowStatus === 'N' || row.rowStatus === 'D') {
				// `N`/`D` 상태면 삭제/삭제취소
				sheet.deleteRow(row, val); // 0: 삭제취소, 1: 삭제
			}
		}

		// rowStatus 변경
		if (row.Added) {
			sheet.setValue(row, 'rowStatus', 'I');
		} else if (row.Deleted) {
			sheet.setValue(row, 'rowStatus', 'D');
		} else if (row.Changed) {
			sheet.setValue(row, 'rowStatus', 'U');
		} else {
			sheet.setValue(row, 'rowStatus', 'N');
		}

		// Enable/Disable
		if (row.rowStatus === 'D') {
			// 행 전체 Disable
			sheet.setAttribute(row, null, 'CanEdit', 0, true);
			// 삭제컬럼 Enable
			sheet.setAttribute(row, 'delYn', 'CanEdit', 1, true);
		} else if (row.rowStatus === 'U') {
			// 삭제컬럼 Disable
			sheet.setAttribute(row, 'delYn', 'CanEdit', 0, true);
		} else if (row.rowStatus === 'N') {
			// 행 전체 Enable
			sheet.setAttribute(row, null, 'CanEdit', 1, true);
			// 삭제컬럼 Enable
			sheet.setAttribute(row, 'delYn', 'CanEdit', 1, true);
		}

		return row.rowStatus;
	}

	// 공통코드를 IBSheet 선택박스 컬럼의 `EnumKeys`, `Enum` 형식으로 변환
	// EnumKey : '|001|002|003', Enum : '|작성중|진행중|완료'
	static cvtCodeToIbSheetEnumType(codeList) {
		let enumKeys = '';
		let enumVals = '';

		codeList.forEach(code => {
			enumKeys += `|${code.commCode}`;
			enumVals += `|${code.commCodeName}`;
		});

		return { enumKeys, enumVals };
	}

	// IBSheet CellEdit 업데이트
	static editColEnable(sheetObj, row, colList, cellEdit) {
		Object.keys(colList).forEach(key => {
			sheetObj.setAttribute(row, colList[key], 'CanEdit', cellEdit);
		});
	}

	// IBSheet 상태컬럼에 따라 가져오기
	// rowStatus: ['N', 'I', 'U', 'D']
	static getRowsByStatus(sheet, rowStatusList) {
		if (!sheet) return null;

		const rowStatusMap = {};
		rowStatusList.forEach(rowStatus => {
			rowStatusMap[rowStatus] = true;
		});

		return sheet.getDataRows().filter(row => rowStatusMap[row.rowStatus]);
	}

	// IBSheet 행 추가
	static addRow(sheet, newData = {}, readOnlyCols = []) {
		if (!sheet) return null;

		// 순번 생성
		// const seq = Number.isNaN(sheet.getLastRow()) ? sheet.getLastRow().seq + 1 : 1;

		/**
		 * IBSheet 행 추가 API
		 *
		 * @param next 추가할 위치의 다음 행 객체
		 * @param visible 그리드뷰에 반영 여부
		 * @param focus 포커스 여부
		 * @param parent ... (트리구조 행에서 사용)
		 * @param init 데이터
		 * @return 추가된 행 데이터
		 */
		const data = sheet.addRow(null, true, true, null, {
			// seq, // 순번
			rowStatus: 'I', // `추가(I)` 상태
			...newData
		}); // 새 행 추가

		// 추가 시, 셀 속성 변경
		this.editColEnable(sheet, sheet.getFocusedRow(), _.drop(Object.keys(newData, readOnlyCols)), 1);

		return data;
	}
}

export default KtngIbSheetUtils;
