import Dialog from '@material-ui/core/Dialog';
import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { closeDialog } from 'app/store/fuse/dialogSlice';
import { closeDialog2 } from 'app/store/fuse/dialogSlice2';
import PropTypes from 'prop-types';

function FuseDialog(props) {
	const dispatch = useDispatch();
	const state = useSelector(({ fuse }) => {
		return fuse[props.dialogName].state;
	});
	const options = useSelector(({ fuse }) => {
		return fuse[props.dialogName].options;
	});

	const onCloseHandle = ev => {
		if (props.dialogName === 'dialog') {
			dispatch(closeDialog());
		} else {
			dispatch(closeDialog2());
		}
	}

	return (
		<Dialog
			open={state}
			onClose={onCloseHandle}
			aria-labelledby="fuse-dialog-title"
			classes={{
				paper: 'rounded-8'
			}}
			{...options}
		/>
	);
}

FuseDialog.propTypes = {
	dialogName: PropTypes.string
};

FuseDialog.defaultProps = {
	dialogName: 'dialog'
};

export default FuseDialog;
