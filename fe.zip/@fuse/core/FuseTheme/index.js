export { default } from './FuseTheme';
