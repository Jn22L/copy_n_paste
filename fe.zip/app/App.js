import FuseLayout from '@fuse/core/FuseLayout';
import FuseTheme from '@fuse/core/FuseTheme';
import KtngFnsUtils from '@ktng/utils/KtngFnsUtils';
import { createGenerateClassName, jssPreset, StylesProvider } from '@material-ui/core/styles';
import { MuiPickersUtilsProvider } from '@material-ui/pickers';
import { create } from 'jss';
import jssExtend from 'jss-plugin-extend';
import rtl from 'jss-rtl';
import 'moment/locale/ko';
import React from 'react';
import Provider from 'react-redux/es/components/Provider';
import { HashRouter } from 'react-router-dom';
import { LastLocationProvider } from 'react-router-last-location';
import routes from './fuse-configs/routesConfig';
import { AppContextProvider } from './AppContext';
import { Auth, Role } from './auth';
import store from './store';

const jss = create({
	...jssPreset(),
	plugins: [...jssPreset().plugins, jssExtend(), rtl()],
	insertionPoint: document.getElementById('jss-insertion-point')
});

const generateClassName = createGenerateClassName();

const App = () => {
	React.useEffect(
		() =>
			// prettier-ignore
			console.log(
			' a,  8a \n'+
			' `8, `8)                            ,adPPRg, \n'+
			'  8)  ]8                        ,ad888888888b \n'+
			' ,8\' ,8\'                    ,gPPR888888888888 \n'+
			',8\' ,8\'                 ,ad8""   `Y888888888P \n'+
			'8)  8)              ,ad8""        (8888888"" \n'+
			'8,  8,          ,ad8""            d888"" \n'+
			'`8, `8,     ,ad8""            ,ad8"" \n'+
			' `8, `" ,ad8""            ,ad8"" \n'+
			'    ,gPPR8b           ,ad8"" \n'+
			'   dP:::::Yb      ,ad8"" \n'+
			'   8):::::(8  ,ad8"" \n'+
			'   Yb:;;;:d888""  Hello, KT&G World!! \n'+
			'    "8ggg8P"        Run uutas-fe App \n'+
			'                                         \n'+
			'-------------------------------------------------- \n'+
			` :: KT&G 배차관리시스템 Ver ${process.env.REACT_APP_VERSION} :: \n`+
			'-------------------------------------------------- \n'
		  ),
		[]
	);

	return (
		<AppContextProvider routes={routes}>
			<StylesProvider jss={jss} generateClassName={generateClassName}>
				<Provider store={store}>
					<MuiPickersUtilsProvider utils={KtngFnsUtils}>
						<HashRouter>
							<LastLocationProvider>
								<Auth>
									<Role>
										<FuseTheme>
											<FuseLayout />
										</FuseTheme>
									</Role>
								</Auth>
							</LastLocationProvider>
						</HashRouter>
					</MuiPickersUtilsProvider>
				</Provider>
			</StylesProvider>
		</AppContextProvider>
	);
};

export default App;
