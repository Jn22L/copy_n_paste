import IbsheetNavigation from 'app/main/guide/ibsheet/IbsheetNavigation';

const navigationConfig = [
	{
		type: 'divider',
		id: 'divider-1'
	},
	{
		id: 'applications',
		title: 'Applications',
		translate: 'APPLICATIONS',
		type: 'group',
		icon: 'apps',
		children: [
			// {
			// 	id: 'example-component',
			// 	title: 'Example',
			// 	type: 'item',
			// 	icon: 'whatshot',
			// 	url: '/example'
			// },
			// {
			// 	id: 'board',
			// 	title: '게시판',
			// 	type: 'collapse',
			// 	icon: 'toc',
			// 	children: [
			// 		// {
			// 		// 	id: 'simple-board',
			// 		// 	title: '게시판1',
			// 		// 	type: 'item',
			// 		// 	icon: 'toc',
			// 		// 	url: '/board/menu0501/list'
			// 		// },
			// 		// {
			// 		// 	id: 'simple-board2',
			// 		// 	title: '게시판2',
			// 		// 	type: 'item',
			// 		// 	icon: 'toc',
			// 		// 	url: '/board2/menu0501/list'
			// 		// },
			// 		{
			// 			id: 'community-board1',
			// 			title: '커뮤니티형 게시판(모바일)',
			// 			type: 'item',
			// 			icon: 'toc',
			// 			url: '/board/community/BRDMST00000000000001/list'
			// 		},
			// 		{
			// 			id: 'eueim-infinite-list',
			// 			title: '모바일용 스크롤 테스트',
			// 			type: 'item',
			// 			icon: 'toc',
			// 			url: '/board/community/infinite-scroll-page'
			// 		}
			// 	]
			// },
			{
				id: 'comp-guide',
				title: '컴포넌트 활용',
				type: 'collapse',
				icon: 'widgets',
				children: [
					// {
					// 	id: 'code-sample',
					// 	title: '코드 샘플',
					// 	type: 'item',
					// 	icon: 'ballot',
					// 	url: '/guide/comp/code'
					// },
					// {
					// 	id: 'GuideHrPopup',
					// 	title: 'HR관련 컴포넌트',
					// 	type: 'item',
					// 	icon: 'ballot',
					// 	url: '/guide/comp/hr'
					// },
					{
						id: 'code-sample2',
						title: '코드 샘플2',
						type: 'item',
						icon: 'ballot',
						url: '/guide/comp/code2'
					},
					{
						id: 'file-upload',
						title: '파일업로드',
						type: 'item',
						icon: 'unarchive',
						url: '/guide/comp/fileupload'
					},
					{
						id: 'comm-comp',
						title: '공통 컴포넌트',
						type: 'item',
						icon: 'widgets',
						url: '/guide/comp/commcomp'
					},
					{
						id: 'date-picker',
						title: '기간선택기',
						type: 'item',
						icon: 'date_range',
						url: '/guide/comp/daterangepicker'
					},
					{
						id: 'calendar',
						title: '캘린더',
						type: 'item',
						icon: 'calendar_view_day',
						url: '/guide/comp/calendar'
					}
					// {
					// 	id: 'address-search',
					// 	title: '주소검색',
					// 	type: 'item',
					// 	icon: 'search',
					// 	url: '/guide/comp/addresssearch'
					// }
				]
			},
			{
				id: 'uutas-page-guide',
				title: '배차관리 화면 가이드',
				type: 'collapse',
				icon: 'desktop_windows',
				children: [
					{
						id: 'uutas-popup-guide',
						title: '공통팝업',
						type: 'item',
						icon: 'desktop_windows',
						url: '/guide/uutas-page/popup'
					},
					{
						id: 'uutas-picker-guide',
						title: '공통Picker',
						type: 'item',
						icon: 'desktop_windows',
						url: '/guide/uutas-page/picker'
					}
				]
			}
			// {
			// 	id: 'cult-page-guide',
			// 	title: '신경작 화면 가이드',
			// 	type: 'collapse',
			// 	icon: 'desktop_windows',
			// 	children: [
			// 		{
			// 			id: 'cult-ibsheet-board',
			// 			title: 'IBSheet 게시판',
			// 			type: 'item',
			// 			icon: 'desktop_windows',
			// 			url: '/guide/cult-page/cult001'
			// 		}
			// 	]
			// }
		]
	},
	{
		type: 'divider',
		id: 'divider-1'
	},
	// {
	// 	id: 'KT&G Approval',
	// 	title: 'KT&G 전자결재',
	// 	type: 'group',
	// 	icon: 'settings_input_component',
	// 	children: [
	// 		{
	// 			id: 'MENU810000',
	// 			title: 'KT&G 전자결재',
	// 			type: 'collapse',
	// 			icon: 'widgets',
	// 			children: [
	// 				{
	// 					id: 'aprv4j/draft',
	// 					title: '결재 상신목록',
	// 					type: 'item',
	// 					icon: 'library_books',
	// 					url: '/uadit/aprv4j/draft'
	// 				},
	// 				{
	// 					id: 'aprv4j/receive',
	// 					title: '결재 수신목록',
	// 					type: 'item',
	// 					icon: 'library_books',
	// 					url: '/uadit/aprv4j/receive'
	// 				}
	// 			]
	// 		}
	// 	]
	// },
	// {
	// 	type: 'divider',
	// 	id: 'divider-2'
	// },
	{
		id: '3rd-party-components',
		title: '타시스템 구현화면',
		type: 'group',
		icon: 'settings_input_component',
		children: [
			IbsheetNavigation
			// {
			// 	id: 'uadit',
			// 	title: 'e감사 시스템',
			// 	type: 'collapse',
			// 	icon: 'desktop_windows',
			// 	children: [
			// 		{
			// 			id: 'ms001',
			// 			title: '판매점 광고비 계약',
			// 			type: 'item',
			// 			icon: 'bar_chart',
			// 			url: '/uadit/ms001'
			// 		},
			// 		{
			// 			id: 'vm001',
			// 			title: '소명대상자관리',
			// 			type: 'item',
			// 			icon: 'bar_chart',
			// 			url: '/uadit/vm001'
			// 		},
			// 		{
			// 			id: 'appr/draft',
			// 			title: '결재 상신목록(e감사)',
			// 			type: 'item',
			// 			icon: 'library_books',
			// 			url: '/uadit/appr/draft'
			// 		},
			// 		{
			// 			id: 'appr/receive',
			// 			title: '결재 수신목록(e감사)',
			// 			type: 'item',
			// 			icon: 'library_books',
			// 			url: '/uadit/appr/receive'
			// 		}
			// 	]
			// }
		]
	}
];

export default navigationConfig;
