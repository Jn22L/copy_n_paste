import React from 'react';
import { Redirect } from 'react-router-dom';
import FuseUtils from '@fuse/utils';
import ExampleConfig from 'app/main/example/ExampleConfig';
import LoginConfig from 'app/main/login/LoginConfig';
import errorPagesConfig from 'app/main/errors/errorPagesConfig';
import guideConfig from 'app/main/guide/guideConfig';
import boardsConfig from 'app/main/boards/boardsConfig';
import uutasConfig from 'app/main/uutas/uutasConfig';

const routeConfigs = [LoginConfig, ...errorPagesConfig, ExampleConfig, ...guideConfig, ...boardsConfig, ...uutasConfig];

const routes = [
	...FuseUtils.generateRoutesFromConfigs(routeConfigs),
	{
		path: '/',
		component: () => <Redirect to="/main" />,
		isProxy: true,
		auth: { check: false }
	},
	{
		component: () => <Redirect to="/errors/error-404" />
	}
];

export default routes;
