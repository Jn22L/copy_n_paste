import Avatar from '@material-ui/core/Avatar';
import Button from '@material-ui/core/Button';
import Icon from '@material-ui/core/Icon';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import MenuItem from '@material-ui/core/MenuItem';
import { makeStyles } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';
import React from 'react';
import { useSelector } from 'react-redux';
import { Link } from 'react-router-dom';
import NssoLogoutForm from 'app/main/login/NssoLogoutForm';

const useStyles = makeStyles(theme => ({
	separator: {
		width: 1,
		height: 64,
		backgroundColor: theme.palette.divider
	}
}));

function UserMenu(props) {
	const classes = useStyles(props);

	const user = useSelector(({ auth }) => auth.user);

	// 로그인 상태가 아닌경우
	if (!user.role || user.role.length === 0) {
		return (
			<>
				<MenuItem component={Link} to="/login" role="button">
					<ListItemIcon className="min-w-40">
						<Icon>lock</Icon>
					</ListItemIcon>
					<ListItemText primary="로그인" />
				</MenuItem>

				<div className={classes.separator} />

				<MenuItem component={Link} to="/register" role="button">
					<ListItemIcon className="min-w-40">
						<Icon>person_add</Icon>
					</ListItemIcon>
					<ListItemText primary="회원가입" />
				</MenuItem>
			</>
		);
	}

	return (
		<>
			<Button className="h-64">
				<div className="hidden md:flex flex-col mx-12 items-end">
					<div className="md:flex flex-row items-center">
						<Typography component="span" className="normal-case font-600 flex">
							{user.data.displayName}
						</Typography>
						<Typography className="text-11 capitalize ml-4" color="textSecondary">
							({user.id})
						</Typography>
					</div>
					<Typography className="text-11 capitalize" color="textSecondary">
						{user.dept.deptName}
					</Typography>
				</div>
				{user.data.photoURL ? (
					<Avatar className="md:mx-4" alt="user photo" src={user.data.photoURL} />
				) : (
					<Avatar className="md:mx-4">{user.data.displayName[0]}</Avatar>
				)}
			</Button>
			<div className={classes.separator} />

			<NssoLogoutForm />
		</>
	);
}

export default UserMenu;
