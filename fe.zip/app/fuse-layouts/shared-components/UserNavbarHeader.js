import AppBar from '@material-ui/core/AppBar';
import Avatar from '@material-ui/core/Avatar';
import { makeStyles } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';
import clsx from 'clsx';
import React from 'react';
import moment from 'moment/moment';
import { useSelector } from 'react-redux';

const useStyles = makeStyles(theme => ({
	root: {
		'&.user': {
			'& .username, & .email': {
				transition: theme.transitions.create('opacity', {
					duration: theme.transitions.duration.shortest,
					easing: theme.transitions.easing.easeInOut
				})
			}
		}
	},
	avatar: {
		width: 72,
		height: 72,
		position: 'absolute',
		top: 107,
		padding: 8,
		background: theme.palette.background.default,
		boxSizing: 'content-box',
		left: '50%',
		transform: 'translateX(-50%)',
		transition: theme.transitions.create('all', {
			duration: theme.transitions.duration.shortest,
			easing: theme.transitions.easing.easeInOut
		}),
		'& > img': {
			borderRadius: '50%'
		}
	},
	staticJwtBadge: {
		backgroundColor: '#E53935',
		color: '#FFF'
	}
}));

function UserNavbarHeader(props) {
	const classes = useStyles();
	const user = useSelector(({ auth }) => auth.user);

	return (
		<AppBar
			position="static"
			color="primary"
			classes={{ root: classes.root }}
			className="user relative flex flex-col items-center justify-center pt-24 pb-64 mb-32 z-0 shadow-0"
		>
			<Typography className="username text-16 whitespace-nowrap" color="inherit">
				{user.data.displayName}
			</Typography>
			<Typography className="email text-13 mt-8 opacity-50 whitespace-nowrap" color="inherit">
				{user.data.email}
			</Typography>
			{user.from === 'NSSO' && (
				<Typography className="email text-10 mt-8 opacity-50 whitespace-no-wrap" color="inherit">
					{user.data.lastTime
						? `최근 접속 : ${moment(user.data.lastTime).format('YYYY.MM.DD HH:mm')} (${user.data.location})`
						: null}
				</Typography>
			)}
			{user.from === 'staticJwt' && (
				<div className={clsx(classes.staticJwtBadge, 'flex items-center mt-4 py-2 px-8 rounded')}>
					<span className="react-text text-12 mx-4">자체로그인</span>
				</div>
			)}
			<Avatar
				className={clsx(classes.avatar, 'avatar')}
				alt="user photo"
				src={
					user.data.photoURL && user.data.photoURL !== ''
						? user.data.photoURL
						: 'assets/images/avatars/profile.jpg'
				}
			/>
		</AppBar>
	);
}

export default UserNavbarHeader;
