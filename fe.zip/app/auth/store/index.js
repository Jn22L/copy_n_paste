import { combineReducers } from '@reduxjs/toolkit';
import user from './userSlice';
import page from './pageSlice';

const authReducers = combineReducers({
	user,
	page
});

export default authReducers;
