import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import qs from 'qs';
import axios from 'axios';

export const validatePage = createAsyncThunk(
	'auth/page/validatePage',
	async ({ url, rscType }, { dispatch, rejectWithValue }) => {
		try {
			const response = await axios.get(`/api/main/page?${qs.stringify({ url, rscType })}`, {
				useInterceptors: false
			});
			return { success: true, url, ...response.payload };
		} catch (err) {
			return rejectWithValue({ success: false, url, ...err.response.data });
		}
	}
);

const initialState = {
	current: '',
	previous: '',
	loading: false
};

const pageSlice = createSlice({
	name: 'auth/page',
	initialState,
	reducers: {
		updatePage: (state, action) => {
			state.previous = state.current;
			state.current = action.payload;
		},
		setPageLoading: (state, action) => {
			state.loading = action.payload;
		}
	},
	extraReducers: {
		[validatePage.pending]: (state, action) => {
			state.loading = true;
		},
		[validatePage.fulfilled]: (state, action) => {
			state.previous = state.current;
			state.current = action.payload.url;
		},
		[validatePage.rejected]: (state, action) => {
			state.previous = state.current;
			state.current = action.payload.url;
		}
	}
});

export const { updatePage, setPageLoading } = pageSlice.actions;

export default pageSlice.reducer;
