import { createSlice } from '@reduxjs/toolkit';
import _ from '@lodash';
import { setNavigation } from 'app/store/fuse/navigationSlice';
import navigationConfig from 'app/fuse-configs/navigationConfig';

// set User Data
export const setUserData = user => {
	return dispatch => {
		// Set User Navigation
		// 메뉴관리 기능 적용 시 주석해제
		if (user.menus) {
			// dispatch(setNavigation(user.menus));
			dispatch(setNavigation([...user.menus, ...navigationConfig]));
		}

		// Set User Settings
		// if (user.data && user.data.settings) {
		// 	dispatch(setDefaultSettings(user.data.settings));
		// }

		// Set User Data
		dispatch(setUser(user));
	};
};

// Remove User Data
export const removeUserData = () => {
	return dispatch => {
		// 사용자 권한이 필요한 메뉴 삭제
		// dispatch(removeNavigationItem(navItemId));
		dispatch(removeUser());
	};
};

// Update User Settings
export const updateUserSettings = settings => {
	return (dispatch, getState) => {
		const oldUser = getState().auth.user;
		const user = _.merge({}, oldUser, { data: { settings } });

		updateUserData(user, dispatch);

		return dispatch(setUserData(user));
	};
};

// Update User Shortcuts
export const updateUserShortcuts = shortcuts => {
	return (dispatch, getState) => {
		const { user } = getState().auth;
		const newUser = {
			...user,
			data: {
				...user.data,
				shortcuts
			}
		};

		updateUserData(newUser, dispatch);

		return dispatch(setUserData(newUser));
	};
};

// Update User Data
const updateUserData = (user, dispatch) => {
	if (!user.role || user.role.length === 0) {
		// is guest
	}
};

const initialState = {
	id: 'guest',
	role: [], // guest
	data: {
		displayName: '방문자',
		email: 'guest@ktng.com',
		lastTime: new Date(),
		location: ''
	},
	dept: {
		deptNo: '',
		deptName: 'KT&G 임시사용자'
	}
};

const userSlice = createSlice({
	name: 'auth/user',
	initialState,
	reducers: {
		setUser: (state, action) => action.payload,
		removeUser: (state, action) => initialState,
		userLoggedOut: (state, action) => initialState
	},
	extraReducers: {}
});

export const { setUser, removeUser, userLoggedOut } = userSlice.actions;

export default userSlice.reducer;
