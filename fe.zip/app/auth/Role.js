import AppContext from 'app/AppContext';
import React, { useContext, useEffect } from 'react';
import { withRouter } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { matchRoutes } from 'react-router-config';
import KtngSplashScreen from '@ktng/core/KtngSplashScreen';
// import { setPageLoading, updatePage, validatePage } from 'app/auth/store/pageSlice';
import { setPageLoading, updatePage } from 'app/auth/store/pageSlice';
// import { showMessage } from 'app/store/fuse/messageSlice';
import _ from '@lodash';

const Role = ({ children, location, history }) => {
	const dispatch = useDispatch();
	const context = useContext(AppContext);

	const user = useSelector(({ auth }) => auth.user);
	const page = useSelector(({ auth }) => auth.page);

	useEffect(() => {
		const matched = matchRoutes(context.routes, location.pathname)[0];
		const { route, match } = matched;
		// const { path, auth, isProxy, component } = route;
		const { auth } = route;
		const { url } = match;

		// 권한없을 시
		if (_.isEmpty(user.role)) {
			// 권한체크가 없는 페이지인지 (라우터 설정)
			if (auth && auth.check === false) {
				// console.log(location.pathname, auth);
				dispatch(updatePage(location.pathname));
			} else {
				redirectRoute('login');
			}
			return;
		}

		// 권한있는데 login페이지 요청 시
		if (location.pathname === '/login') {
			redirectRoute('/');
			return;
		}

		// 유효한 URL PATH인지
		// 매치안될 경우 url='/'반환되기때문에 pathname과 같은지 비교
		if (url !== location.pathname) {
			redirectRoute('404');
			return;
		}

		// // 현재 path와 같은 요청이 아니면
		// // = 페이지 이동이 있을경우 권한검사
		// if (location.pathname !== page.current) {
		// 	// 프록시 페이지 요청일 경우 렌더링 진행하지 않음
		// 	if (isProxy) {
		// 		dispatch(setPageLoading(true));
		// 		const { props } = component(matched);
		// 		history.replace(props.to);
		// 	} else {
		// 		validate(location.pathname, isProxy);
		// 	}
		// }

		// 페이지검사 필요없을 시 이용
		dispatch(updatePage(location.pathname));
		dispatch(setPageLoading(false));

		// eslint-disable-next-line
	}, [user, location.pathname]);

	// 권한검사
	// const validate = async pathname => {
	// 	const response = await dispatch(validatePage({ url: pathname, rscType: 'RSTY03' }));

	// 	// 권한이 없을경우
	// 	const { success, url, msg } = response.payload;
	// 	if (!success) {
	// 		// dispatch(showMessage({ message: msg, variant: 'error' }));
	// 		redirectRoute('403');
	// 	}
	// 	dispatch(setPageLoading(false));
	// };

	const redirectRoute = type => {
		if (type === '/') {
			history.push({ pathname: '/' });
		} else if (type === 'login') {
			history.push({ pathname: '/login' });
		} else if (type === '401') {
			history.push({ pathname: '/errors/error-401' });
		} else if (type === '403') {
			history.push({ pathname: '/errors/error-403' });
		} else if (type === '404') {
			history.push({ pathname: '/errors/error-404' });
		} else {
			history.push({ pathname: '/errors/error-500' });
		}
	};

	return page.loading ? <KtngSplashScreen /> : children;
};

export default withRouter(Role);
