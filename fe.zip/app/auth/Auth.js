import { setUserData, removeUserData } from 'app/auth/store/userSlice';
import { showMessage } from 'app/store/fuse/messageSlice';
import authService from 'app/services/oidcService';
import React, { useEffect, useState } from 'react';
import KtngSplashScreen from '@ktng/core/KtngSplashScreen';
import { withRouter } from 'react-router-dom';
import { useDispatch } from 'react-redux';

const Auth = ({ children, history }) => {
	const dispatch = useDispatch();
	const [waitAuthCheck, setWaitAuthCheck] = useState(true);

	useEffect(() => {
		authCheck().then(() => setWaitAuthCheck(false));
		// eslint-disable-next-line
	}, []);

	const authCheck = () =>
		new Promise(resolve => {
			authService.on('onAutoLogin', message => {
				authService
					.sign()
					.then(user => {
						dispatch(setUserData(user));
						if (message) {
							dispatch(showMessage({ message, autoHideDuration: 6000 }));
						}
						resolve();
					})
					.catch(error => {
						console.log(error);
						dispatch(showMessage({ message: error }));
						resolve();
					});
			});

			authService.on('onAutoRevoke', message => {
				authService.revoke().then(() => {
					if (message) {
						dispatch(showMessage({ message }));
					}
					dispatch(removeUserData());
				});
				resolve();
			});

			authService.on('onMessage', message => {
				if (message) {
					dispatch(showMessage({ message }));
				}
				resolve();
			});

			authService.on('redirect', data => {
				const { message, type } = data;
				if (message) {
					dispatch(showMessage({ message }));
				}
				if (type) {
					redirectRoute(type);
				}
				resolve();
			});

			authService.init();

			return Promise.resolve();
		});

	const redirectRoute = type => {
		if (type === '/') {
			history.push({ pathname: '/' });
		} else if (type === 'login') {
			history.push({ pathname: '/login' });
		} else if (type === '401') {
			history.push({ pathname: '/errors/error-401' });
		} else if (type === '403') {
			history.push({ pathname: '/errors/error-403' });
		} else if (type === '404') {
			history.push({ pathname: '/errors/error-404' });
		} else {
			history.push({ pathname: '/errors/error-500' });
		}
	};

	return waitAuthCheck ? <KtngSplashScreen /> : <>{children}</>;
};

export default withRouter(Auth);
