import React, { useEffect, useState } from 'react';
import ibsheetEvent, { ibsheetLibs } from '@ktng/utils/IbsheetEvent';

// 참고 : https://stackoverflow.com/questions/54738681/how-to-change-context-value-while-using-react-hook-of-usecontext
const AppContext = React.createContext({});

export const AppContextProvider = ({ children, routes }) => {
	const [ibsheet, setIbsheet] = useState(
		ibsheetLibs.map(el => {
			return { name: el.name, loaded: false };
		})
	);

	useEffect(() => {
		// console.log('AppContextProvider START');

		// 라이브러리 로딩 완료시 호출
		ibsheetEvent.on('onLoaded', loadName => {
			console.log('AppContextProvider.loadedIbsheet', { loadName });
			const idx = ibsheet.findIndex(el => el.name === loadName);
			// console.log('ibsheet[idx].loaded', ibsheet[idx], ibsheet[idx].loaded);
			ibsheet[idx].loaded = true;
			setIbsheet([...ibsheet]);
		});
		// eslint-disable-next-line
	}, []);

	// const loadComplateIbsLib = loadNames => {};

	return <AppContext.Provider value={{ routes, ibsheet }}>{children}</AppContext.Provider>;
};

export const AppContextConsumer = AppContext.Consumer;

export default AppContext;
