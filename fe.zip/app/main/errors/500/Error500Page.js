import React from 'react';
import Typography from '@material-ui/core/Typography';
import Button from '@material-ui/core/Button';
import FuseAnimate from '@fuse/core/FuseAnimate';
import { useSelector } from 'react-redux';

function Error500Page() {
	const page = useSelector(({ auth }) => auth.page);
	return (
		<div className="flex flex-col flex-1 items-center justify-center p-16">
			<div className="max-w-512 text-center">
				<FuseAnimate animation="transition.expandIn" delay={100}>
					<Typography variant="h1" color="inherit" className="font-medium mb-16">
						500
					</Typography>
				</FuseAnimate>

				<FuseAnimate delay={500}>
					<Typography variant="h5" color="textSecondary" className="mb-16">
						서비스 이용에 불편을 드려 죄송합니다.
					</Typography>
				</FuseAnimate>

				<FuseAnimate delay={600}>
					<Typography variant="subtitle1" color="textSecondary" className="mb-48">
						일시적인 오류가 발생하여 서비스를 이용하실 수 없으니 잠시 후 다시 시도해 주십시오. 감사합니다.
						{page.previous && (
							<>
								<br />
								<span className="font-bold px-4">{page.previous}</span>
							</>
						)}
					</Typography>
				</FuseAnimate>

				<Button
					variant="outlined"
					color="primary"
					size="medium"
					className="normal-case w-192 mt-20 mb-8"
					href="/"
				>
					메인페이지로
				</Button>
			</div>
		</div>
	);
}

export default Error500Page;
