import FuseAnimate from '@fuse/core/FuseAnimate';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import React from 'react';
import { useLastLocation } from 'react-router-last-location';

function Error404Page() {
	const lastLocation = useLastLocation();
	// const page = useSelector(({ auth }) => auth.page);
	return (
		<div className="flex flex-col flex-1 items-center justify-center p-16">
			<div className="max-w-512 text-center">
				<FuseAnimate animation="transition.expandIn" delay={100}>
					<Typography variant="h1" color="inherit" className="font-medium mb-16">
						404
					</Typography>
				</FuseAnimate>

				<FuseAnimate delay={500}>
					<Typography variant="h5" color="textSecondary" className="mb-16">
						요청하신 페이지는 존재하지 않습니다.
					</Typography>
				</FuseAnimate>

				<FuseAnimate delay={600}>
					<Typography variant="subtitle1" color="textSecondary" className="mb-48">
						{lastLocation ? (
							<span className="font-bold px-4">{lastLocation.pathname}</span>
						) : (
							'요청하신 페이지의 URL을 확인해 주세요.'
						)}
					</Typography>
				</FuseAnimate>

				<Button
					variant="outlined"
					color="primary"
					size="medium"
					className="normal-case w-192 mt-20 mb-8"
					href="/"
				>
					메인페이지로
				</Button>
			</div>
		</div>
	);
}

export default Error404Page;
