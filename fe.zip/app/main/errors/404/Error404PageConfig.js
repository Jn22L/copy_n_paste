import React from 'react';

const Error404PageConfig = {
	settings: {
		layout: {
			config: {
				navbar: {
					display: true
				},
				toolbar: {
					display: true
				},
				footer: {
					display: false
				},
				leftSidePanel: {
					display: false
				},
				rightSidePanel: {
					display: false
				}
			}
		}
	},
	routes: [
		{
			path: '/errors/error-404',
			component: React.lazy(() => import('./Error404Page')),
			auth: { check: false }
		}
	]
};

export default Error404PageConfig;
