import React from 'react';

const Error403PageConfig = {
	settings: {
		layout: {
			config: {
				navbar: {
					display: true
				},
				toolbar: {
					display: true
				},
				footer: {
					display: false
				},
				leftSidePanel: {
					display: false
				},
				rightSidePanel: {
					display: false
				}
			}
		}
	},
	routes: [
		{
			path: '/errors/error-403',
			component: React.lazy(() => import('./Error403Page')),
			auth: { check: false }
		}
	]
};

export default Error403PageConfig;
