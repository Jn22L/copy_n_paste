import Error401PageConfig from './401/Error401PageConfig';
import Error403PageConfig from './403/Error403PageConfig';
import Error404PageConfig from './404/Error404PageConfig';
import Error500PageConfig from './500/Error500PageConfig';

const errorPagesConfig = [
	//
	Error401PageConfig,
	Error403PageConfig,
	Error404PageConfig,
	Error500PageConfig
];

export default errorPagesConfig;
