/*
 * 대메뉴 `기준정보`에 대한 메뉴경로 파일
 */

import VHA0010Config from './vha0010/VHA0010Config';
import VHA0020Config from './vha0020/VHA0020Config';
import VHA0030Config from './vha0030/VHA0030Config';
import VHA0040Config from './vha0040/VHA0040Config';

// 리스트로 된 Config는 파일명 소문자로 시작
const vhaMngConfig = [
	VHA0010Config, // 배차부서관리 메뉴 추가
	VHA0020Config, // 차량등록관리 메뉴 추가
	VHA0030Config, // 운전원관리 메뉴 추가
	VHA0040Config // 게시판관리 메뉴 추가
];

export default vhaMngConfig;
