// **************************************************************************
// 파    일    명   : VHA0010Page.js
// 업무      분류  : 배차부서관리
// 업    무    명   : 배차부서관리
// 프로그램   내용   : 배차부서를 조회/입력/수정/삭제하는 화면
// 기          타   :
// ==========================================================================
// 작    성    자   : 김 민 우
// 작    성    일   : 2021.12.20
// 최종    수정일   :
// 변 경    이 력   :
// **************************************************************************

import React from 'react';
import { useSelector } from 'react-redux';
import withReducer from 'app/store/withReducer';
import { UutasPageSimple } from '@ktng/uutas';
import { VHA0010Srch, VHA0010Grd1 } from './component';
import reducer from './store';

// vhaMng/vha0010/vha0010
const VHA0010Page = () => {
	/*
	 * ###################################################################################
	 * #### [Redux 설명 5] Store에 저장된 데이터 가져오기1 ##################################
	 * ###################################################################################
	 *
	 * > useSelector: Store에 저장된 데이터를 가져올 수 있다.
	 */
	const { vha0010MstLoading } = useSelector(
		/*
		 * rootState 객체로부터 현재 컴포넌트에서 사용할 데이터만 선택하여
		 * key-value 객체를 반환해주는 함수를 작성한다.
		 */
		(
			/* rootState 객체로부터 현재 컴포넌트에서 사용할 `Store집합`들만 선택 */
			{
				vha0010 // `Store집합`의 별명
			}
		) =>
			/*
			 * 파라미터로 받은 `Store집합`을 활용하여,
			 * `useSelector` 함수가 반환할 key-value 객체를 생성하여 반환한다.
			 */
			({
				vha0010MstLoading: vha0010.vha0010Mst.loading // 서버로부터 데이터로드 중이면 true, 아니면 false
			})
	);

	return (
		<UutasPageSimple
			title="배차부서관리" // 헤더에 표시할 페이지 이름
			loading={vha0010MstLoading} // 로딩 발생 시마다 화면에 로딩바를 표시해줌
		>
			{/* 검색조건 */}
			<VHA0010Srch />

			{/* 배차부서관리 그리드 */}
			<div className="flex flex-1">
				<VHA0010Grd1 />
			</div>
		</UutasPageSimple>
	);
};

/*
 * #############################################################################
 * #### [Redux 설명 1] 화면에 Redux 추가 ########################################
 * #############################################################################
 *
 * 화면을 여러 컴포넌트로 쪼갤 경우, 쪼갠 컴포넌트에서 공유하고 싶은 데이터를
 * Redux를 통해 관리할 수 있다.
 *
 * 먼저, VHA0010Page(Store를 함께 공유하고 싶은 하위 컴포넌트들을 가진 컴포넌트)에 Store를 추가한다.
 *
 * > withReducer: 컴포넌트에 사용할 Store를 추가해주는 함수
 */
export default withReducer(
	'vha0010', // {string} `useSelector`로 `Store집합`을 불러올 때 사용할 별명
	reducer //    {object} 컴포넌트에서 사용할 `Store집합`
)(VHA0010Page);
