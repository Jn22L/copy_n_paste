/*
 * VHA0010 업무화면에서 공유할 `하위store`들을 결합한 `store집합` 파일
 */

import { combineReducers } from 'redux';
import vha0010Mst from './vha0010MstSlice';

/*
 * #############################################################################
 * #### [Redux 설명 2] store/index.js 파일 작성 #################################
 * #############################################################################
 *
 * 화면에서 `마스터그리드의 데이터`와 `서브그리드의 데이터`를
 * 구분하여 관리하고 싶은 경우, 여러 개의 `하위store`로 만들 수 있다.
 * 각 데이터에 대한 Slice 파일을 작성하여 `하위store`를 생성한다.
 * `하위store`들을 결합한 `store집합`을 생성한다.
 *
 * 아래 children 객체에서 설정한 key값('vha0010Mst')으로 `하위store`를 불러올 수 있다.
 *
 * Ex) 하위store 접근하는 예시
 * `store집합`에 대한 별명 (화면에서 설정한 별명)	: vha0010
 * `하위store`에 대한 별명 (key값)				: vha0010Mst
 *
 * const { vha0010Mst } = useSelector(({ vha0010 }) => ({
 *     vha0010Mst: vha0010.vha0010Mst // {store집합의 별명}.{하위store의 별명}으로 하위store에 접근가능
 * }));
 */
const children = {
	vha0010Mst // `VHA001 마스터그리드`에서 사용할 store
	// 만약 서브그리드에서 사용할 store가 있으면 ','로 구분하여 이곳에 추가
};

/*
 * > combineReducers: 여러 `하위store`들을 모아 하나의 `store집합`으로 결합한다.
 */
const reducer = combineReducers(
	children // {object} 결합할 `하위store`들에 대한 key-value 객체
);

export default reducer;
