/*
 * VHA0010Grd 그리드의 설정 파일
 *
 * 더 많은 설정값은 IBSheet8 manual에서 확인 가능
 *
 * - IBSheet8 manual 다운로드 경로
 *   http://gitlab.ktng.com:8880/t0210023/dev-env/raw/master/install/ibsheet8-manual-v20201229.zip?inline=false
 */

const options = {
	/* 1. Cfg: 그리드 스타일 관련 설정 */
	Cfg: {
		CanSelect: true, // 시트 선택 가능
		SelectingCells: 1, // 개별 셀 선택 가능
		CanEdit: 1, // 수정 가능
		CustomScroll: 1 // 그리드와 스크롤 겹침 이슈 처리
	},

	/* 2. Def: 그리드 값 관련 설정 */
	Def: {
		// 2.1. Col: 그리드의 전체 열에 일괄적으로 적용할 설정
		// Col: {
		// 	RelWidth: 1 // 열 너비를 특정값으로 고정하지 않고 그리드 전체너비의 비율로 조정되도록 함
		// },

		// 2.2. Row: 그리드의 전체 행에 일괄적으로 적용할 설정
		Row: {
			CanFormula: 1, // {attribute}Formula 사용설정 Ex) `CanEditFormula`: 셀 수정가능 여부를 동적으로 결정할 수 있음
			CalcOrder: 'vhclDeptCdCanEdit' // Formula 계산순서 설정
		}
	},

	/* 3. Col: 그리드 컬럼 List */
	Cols: [
		/*
		 * `삭제` 컬럼. 편집가능한 그리드에 공통적으로 들어가는 컬럼
		 * - 조회만하는 그리드에서는 `삭제` 컬럼 주석처리할 것
		 * - 체크박스 체크 시 `삭제(D)` 상태로 변경
		 */
		{
			Header: {
				Value: '삭제',
				HeaderCheck: 1
			},
			Type: 'Bool',
			Name: 'delYn',
			Align: 'center',
			DefaultValue: false,
			NoChanged: true
		},
		/*
		 * `상태` 컬럼. 편집가능한 그리드에 공통적으로 넣어주는 컬럼
		 * - 조회만하는 그리드에서는 `상태` 컬럼 주석처리할 것
		 * - `상태` 셀은 직접 편집 불가능하고,
		 * - 행의 상태에 따라 자동으로 값이 변경됨.
		 */
		{
			Header: '상태',
			Name: 'rowStatus',
			Type: 'Enum',
			Align: 'center',
			DefaultValue: 'N',
			Enum: '||추가|수정|삭제',
			EnumKeys: '|N|I|U|D',
			CanEdit: 0,
			NoChanged: true
		},
		// ==== 여기부터 필요한 컬럼을 정의 =========================================================
		{
			Header: '부서코드',
			Name: 'vhclDeptCd',
			Type: 'Text',
			Align: 'Center',
			Required: 1,
			RelWidth: 1,
			CanEditFormula: param => {
				const { rowStatus } = param.Row;
				// `추가` 상태에서만 수정가능
				return rowStatus === 'I';
			},
			Icon: '/assets/images/ibsheet/search-small.png', // 좌측 아이콘 파일
			IconWidth: 15 // 아이콘 크기
		},
		{
			Header: '부서명',
			Name: 'vhclDeptNm',
			Type: 'Text',
			Align: 'Center',
			Required: 1,
			RelWidth: 1,
			CanEdit: 0
		},
		{
			Header: '전화번호',
			Name: 'vhclDeptPn',
			Type: 'Text',
			Align: 'Center',
			Required: 1,
			RelWidth: 1,
			CustomFormat: 'PhoneNo',
			EditMask: '^[\\d]*$' // 0-9숫자만 입력가능
		},
		{
			Header: '담당자전화번호',
			Name: 'vhclEmpPn',
			Type: 'Text',
			Align: 'Center',
			Required: 1,
			RelWidth: 1,
			CustomFormat: 'PhoneNo',
			EditMask: '^[\\d]*$' // 0-9숫자만 입력가능
		},
		{
			Header: '생성일',
			Name: 'recordDt',
			Type: 'Date',
			Align: 'Center',
			DataFormat: 'yyyy.MM.dd',
			Format: 'yyyy.MM.dd',
			Required: 1,
			RelWidth: 1
		},
		{
			Header: '종료일',
			Name: 'expireDt',
			Type: 'Date',
			Align: 'Center',
			DefaultValue: '2999.12.31',
			DataFormat: 'yyyy.MM.dd',
			Format: 'yyyy.MM.dd',
			Required: 1,
			RelWidth: 1
		},
		{
			Header: '사용',
			Name: 'useYn',
			Type: 'Enum',
			Align: 'Center',
			DefaultValue: 'Y', // 초기값 (Value)
			Enum: '|사용|미사용', // Label
			EnumKeys: '|Y|N', // Value
			Required: 1,
			RelWidth: 1
		},
		{
			Header: '권한구분',
			Name: 'authGubun',
			Type: 'Enum',
			Align: 'Center',
			DefaultValue: '', // 초기값 (Value)
			Enum: '', // Label. 소스에서 공통코드로 불러옴
			EnumKeys: '', // Value. 소스에서 공통코드로 불러옴
			Required: 1,
			RelWidth: 1
		},
		{
			Header: '본부장님차량사용구분',
			Name: 'bonbuUseYn',
			Type: 'Enum',
			Align: 'Center',
			DefaultValue: 'Y', // 초기값 (Value)
			Enum: '|사용|미사용', // Label
			EnumKeys: '|Y|N', // Value
			Required: 1,
			RelWidth: 1
		},
		{
			Header: '비고',
			Name: 'note',
			Type: 'Text',
			Align: 'Center',
			Required: 0,
			RelWidth: 1
		}
	]
};

export default options;
