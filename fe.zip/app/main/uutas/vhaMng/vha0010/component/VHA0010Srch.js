/*
 * VHA0010 화면 검색조건 컴포넌트의 파일
 */

import React, { useState, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Input } from '@material-ui/core';
import { UutasToolBar, UutasForm } from '@ktng/uutas';
import KtngUtils from '@ktng/utils';
import { showMessage } from 'app/store/fuse/messageSlice';
import { getVha0010MstList } from '../store/vha0010MstSlice';

const formSchema = [
	// row 1
	[
		// col 1
		{
			id: 'vhclDeptNm', // 폼 입력컨트롤 식별ID
			label: '부서명', // 폼 입력컨트롤의 라벨
			width: 150, // 너비
			align: 'center', // 정렬
			required: false // 필수여부 (validation check에서 검사할지 여부)
		}
	]
];

const VHA0010Srch = () => {
	const dispatch = useDispatch();

	// 입력된 값의 유효성검사를 하기위해 `useRef`로 폼입력컨트롤의 DOM에 접근한다
	const srchRef = useRef();

	const {
		uutasUser // 공통 Store에 저장된 배차관리사용자 정보
	} = useSelector(({ auth }) => ({
		uutasUser: auth.user.uutasUser || {}
	}));

	const [expanded, setExpanded] = useState(true); // 검색조건 폼 컴포넌트 보이기(true)/숨기기(false)

	// 폼 입력값
	const [vhclDeptNm, setVhclDeptNm] = useState(uutasUser.partNm || '');

	function onBtnSearchClick() {
		const validationComps = [
			// 입력값의 검증할 정보 추가
			{
				key: '부서명', //      [필수] 컬럼명
				value: vhclDeptNm, // [필수] 입력값
				type: 'text', //      [필수] 형식 'text'|'number'|'date'
				required: false, //    [선택] 필수입력 여부
				minLength: 2, //       [선택] 입력값 최소길이
				maxLength: 20 //       [선택] 입력값 최대길이
			}
		];

		if (KtngUtils.validationComps(validationComps, dispatch, srchRef)) {
			// 변경된 검색조건으로 조회
			dispatch(getVha0010MstList({ vhclDeptNm })).then(action => {
				const data = action.payload;
				if (data && data.list) {
					dispatch(showMessage({ message: `총 ${data.list.length}건이 조회되었습니다.` }));
				}
			});
		}
	}

	return (
		<>
			{/* 검색조건 툴바 */}
			<UutasToolBar
				/*
				 * onBtnSearchClick
				 * - `onBtnSearchClick` 속성에 콜백함수를 넘겨주면 ToolBar 컴포넌트에 `조회` 버튼이 생김
				 * - `조회` 버튼을 클릭하면 넘겨준 콜백함수가 실행됨.
				 */
				onBtnSearchClick={onBtnSearchClick}
				/*
				 * onBtnToggleClick
				 * - `onBtnToggleClick` 속성에 콜백함수를 넘겨주면 ToolBar 컴포넌트에 `토글 (아이콘)` 버튼이 생김
				 * - `토글 (아이콘)` 버튼을 클릭했을 때,
				 *   보이기 상태면 true, 숨기기 상태면 false를 콜백함수의 파라미터로 넘겨줌.
				 */
				onBtnToggleClick={setExpanded}
				expanded={expanded} // true -> 토글 버튼을 '보이기' 모양으로 표시, false -> 토글 버튼 '숨기기' 모양으로 표시
			/>

			{/* 검색조건 입력폼 */}
			<UutasForm
				/* 폼 입력값 validation 체크 시 DOM에 접근하기 위해 useRef 사용 */
				srchRef={srchRef}
				/* true -> 검색조건 보이기, false -> 검색조건 숨기기 */
				expanded={expanded}
				/* 폼 입력컨트롤의 배치 정보 */
				schema={formSchema}
				// ==== 여기부터 폼 입력컨트롤 정의 ================================
				/*
				 * Ex)
				 * formSchema에서 설정했던 id={
				 * 	   // id에 해당하는 폼 입력 컴포넌트
				 * 	   <... />
				 * }
				 */
				// 부서명
				vhclDeptNm={
					<Input
						className="flex flex-1 px-8"
						placeholder="부서명"
						fullWidth
						type="text"
						value={vhclDeptNm}
						inputProps={{ minLength: 2, maxLength: 20 }}
						onChange={e => setVhclDeptNm(e.target.value)}
						onKeyUp={e => {
							if (e.key === 'Enter') {
								onBtnSearchClick();
							}
						}}
					/>
				}
			/>
		</>
	);
};

export default VHA0010Srch;
