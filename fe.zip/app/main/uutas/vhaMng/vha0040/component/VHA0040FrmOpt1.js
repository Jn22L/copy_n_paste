const formSchema = [
	// row 1
	[
		{
			id: 'boardTitle', // 폼 입력컨트롤 식별ID
			label: '제목', // 폼 입력컨트롤의 라벨
			width: 150, // 너비
			align: 'center', // 정렬
			required: false, // 필수여부 (validation check에서 검사할지 여부)
			colSpan: 3
		},
		{ id: 'boardId', label: '번호', width: 150, align: 'center', requried: false }
	],
	// row 2
	[
		{ id: 'startDate', label: '시작일자', width: 150, align: 'center', requried: false },
		{ id: 'endDate', label: '종료일자', width: 150, align: 'center', requried: false },
		{ id: 'regDate', label: '등록일', width: 150, align: 'center', requried: false }
	],
	// row 3
	[{ id: 'boardContent', label: '내용', width: 150, align: 'center', requried: false, colSpan: 5 }]
];

export default formSchema;
