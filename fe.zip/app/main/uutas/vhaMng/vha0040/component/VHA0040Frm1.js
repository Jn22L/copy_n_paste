/*
 * VHA0040 화면 입력폼 컴포넌트의 파일
 */

import React, { useState, useRef, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Input, Typography } from '@material-ui/core';
import KtngTextarea from '@ktng/core/KtngTextarea';
import { KeyboardDatePicker } from '@material-ui/pickers';
import { UutasToolBar, UutasForm } from '@ktng/uutas';
import KtngUtils from '@ktng/utils';
import _ from '@lodash';
import { addMonths, format, isValid, parse } from 'date-fns';
import { showMessage } from 'app/store/fuse/messageSlice';
import {
	clearVha0040SubOne,
	deleteVha0040SubOne,
	getVha0040SubOne,
	insertVha0040SubOne,
	updateVha0040SubOne
} from '../store/vha0040SubSlice';
import { getVha0040MstList } from '../store/vha0040MstSlice';
import formSchema from './VHA0040FrmOpt1'; // 폼 입력컴포넌트 배치정보

// 사용자가 입력가능한 속성명 리스트
const userInputAttrNms = ['boardTitle', 'startDate', 'endDate', 'boardContent'];

const VHA0040Frm1 = () => {
	const dispatch = useDispatch();

	const { vha0040SubOne, vha0040MstParams } = useSelector(({ vha0040 }) => ({
		vha0040SubOne: vha0040.vha0040Sub.data,
		vha0040MstParams: vha0040.vha0040Mst.params
	}));

	// 입력된 값의 유효성검사를 하기위해 `useRef`로 폼입력컨트롤의 DOM에 접근한다
	const srchRef = useRef();

	const [form, setForm] = useState(); // 폼 입력값
	const [isNew, setIsNew] = useState();
	const [isChanged, setIsChanged] = useState();

	// 1. 입력컴포넌트 초기화
	useEffect(() => {
		if (!vha0040SubOne) return;

		// 폼 입력값 포맷으로 변환
		const { startDate, endDate, regDate } = vha0040SubOne;
		const _startDate = startDate ? parse(startDate, 'yyyyMMdd', new Date()) : new Date();
		const _endDate = endDate ? parse(endDate, 'yyyyMMdd', new Date()) : addMonths(new Date(), 1);
		const _regDate = regDate ? format(parse(regDate, 'yyyyMMdd', new Date()), 'yyyy.MM.dd') : '';

		setForm({
			boardId: vha0040SubOne.boardId || '',
			boardTitle: vha0040SubOne.boardTitle || '',
			startDate: _startDate,
			endDate: _endDate,
			regDate: _regDate,
			boardContent: vha0040SubOne.boardContent || ''
		});
	}, [vha0040SubOne]);

	// 2. 폼 상태 변경 (새 것 여부, 변경 여부)
	useEffect(() => {
		if (!vha0040SubOne || !form) return;

		const { startDate, endDate } = form;
		const vha0040 = {
			..._.pick(form, userInputAttrNms),
			// 변환해서 보내야할 폼 입력값
			startDate: isValid(startDate) ? format(startDate, 'yyyyMMdd') : null,
			endDate: isValid(endDate) ? format(endDate, 'yyyyMMdd') : null
		};

		setIsNew(!form.boardId);
		setIsChanged(
			// 폼 입력값이 비어있지 않고
			!_.isEmpty(form) &&
				// 사용자가 입력가능한 상태값으로 비교하여 변경사항이 있으면 저장 가능
				!_.isEqual(vha0040, _.pick(vha0040SubOne, userInputAttrNms))
		);
	}, [form, vha0040SubOne]);

	// 공통코드 리스트 불러오기 (이미 store에 있으면 요청안함)
	// useCmmCodeLoadEffect(() => {}, [reqCodes]);

	function onBtnDeleteClick() {
		dispatch(deleteVha0040SubOne({ boardId: form.boardId })).then(action => {
			const data = action.payload;
			if (data && data.success) {
				dispatch(showMessage({ message: '게시물이 삭제되었습니다.' }));

				dispatch(clearVha0040SubOne());
				// vha0040MstParams: 이전에 조회했던 파라미터로 조회
				dispatch(getVha0040MstList(vha0040MstParams)).then(_action => {
					const _data = _action.payload; // 비동기함수에서 반환한 데이터를 가져옴
					if (_data && _data.list) {
						if (_data.list.length > 0) {
							// 첫번째 항목으로 Sub 데이터 조회
							dispatch(getVha0040SubOne({ boardId: _data.list[0].boardId }));
						}
					}
				});
			}
		});
	}

	function onBtnSaveClick() {
		const { boardTitle, startDate, endDate, boardContent } = form;

		const validationComps = [
			// 입력값의 검증할 정보 추가
			{
				key: '제목', //      [필수] 컬럼명
				value: boardTitle, // [필수] 입력값
				type: 'text', //      [필수] 형식 'text'|'number'|'date'
				required: true, //    [선택] 필수입력 여부
				minByteLength: 2, //       [선택] 입력값 최소길이
				maxByteLength: 100 //       [선택] 입력값 최대길이
			},
			{ key: '시작일자', value: startDate, type: 'date', required: true },
			{ key: '종료일자', value: endDate, type: 'date', required: true },
			{ key: '내용', value: boardContent, type: 'text', required: true, minByteLength: 2, maxByteLength: 2000 }
		];

		if (!KtngUtils.validationComps(validationComps, dispatch, srchRef)) return;

		if (isValid(startDate) && isValid(endDate) && startDate.valueOf() > endDate.valueOf()) {
			dispatch(showMessage({ message: '시작일자는 종료일자 이전이어야 합니다.', variant: 'error' }));
			return;
		}

		const vha0040 = {
			...vha0040SubOne, // 기존 데이터
			..._.pick(form, userInputAttrNms), // 폼 입력값
			// 변환해서 보내야할 폼 입력값
			startDate: isValid(startDate) ? format(startDate, 'yyyyMMdd') : null,
			endDate: isValid(endDate) ? format(endDate, 'yyyyMMdd') : null
		};

		if (isNew) {
			// 새 게시물 저장
			dispatch(insertVha0040SubOne(vha0040)).then(action => {
				const data = action.payload;
				if (data && data.success) {
					dispatch(showMessage({ message: '게시물이 등록되었습니다.' }));

					dispatch(clearVha0040SubOne());
					// vha0040MstParams: 이전에 조회했던 파라미터로 조회
					dispatch(getVha0040MstList(vha0040MstParams)).then(_action => {
						const _data = _action.payload; // 비동기함수에서 반환한 데이터를 가져옴
						if (_data && _data.list) {
							if (_data.list.length > 0) {
								// 첫번째 항목으로 Sub 데이터 조회
								dispatch(getVha0040SubOne({ boardId: _data.list[0].boardId }));
							}
						}
					});
				}
			});
		} else {
			// 기존 게시물 수정
			dispatch(updateVha0040SubOne(vha0040)).then(action => {
				const data = action.payload;
				if (data && data.success) {
					dispatch(showMessage({ message: '변경사항이 반영되었습니다.' }));

					dispatch(clearVha0040SubOne());
					// vha0040MstParams: 이전에 조회했던 파라미터로 조회
					dispatch(getVha0040MstList(vha0040MstParams)).then(_action => {
						const _data = _action.payload; // 비동기함수에서 반환한 데이터를 가져옴
						if (_data && _data.list) {
							if (_data.list.length > 0) {
								// 첫번째 항목으로 Sub 데이터 조회
								dispatch(getVha0040SubOne({ boardId: _data.list[0].boardId }));
							}
						}
					});
				}
			});
		}
	}

	if (_.isEmpty(vha0040SubOne) || _.isEmpty(form)) {
		return null;
	}

	return (
		<>
			{/* 검색조건 툴바 */}
			<UutasToolBar
				title="상세화면"
				/*
				 * onBtnDeleteClick
				 * - `onBtnDeleteClick` 속성에 콜백함수를 넘겨주면 ToolBar 컴포넌트에 `삭제` 버튼이 생김
				 * - `삭제` 버튼을 클릭하면 넘겨준 콜백함수가 실행됨.
				 */
				onBtnDeleteClick={onBtnDeleteClick}
				btnDeleteDisabled={isNew}
				onBtnSaveClick={onBtnSaveClick}
				btnSaveDisabled={!isChanged}
				onBtnCancelClick={() => dispatch(clearVha0040SubOne())}
			/>

			{/* 게시물 입력폼 */}
			<UutasForm
				fullWidth // 너비 100%로 설정
				/* 폼 입력값 validation 체크 시 DOM에 접근하기 위해 useRef 사용 */
				srchRef={srchRef}
				/* 폼 입력컨트롤의 배치 정보 */
				schema={formSchema}
				// ==== 여기부터 폼 입력컨트롤 정의 ================================
				/*
				 * Ex)
				 * formSchema에서 설정했던 id={
				 * 	   // id에 해당하는 폼 입력 컴포넌트
				 * 	   <... />
				 * }
				 */
				// 제목
				boardTitle={
					<Input
						className="flex flex-1 px-8" // CSS 스타일 지정
						placeholder="제목"
						fullWidth
						type="text"
						value={form.boardTitle}
						onChange={e => {
							// 최대 Byte 길이 제한
							if (KtngUtils.getStrByteLength(e.target.value) <= 100) {
								setForm(state => ({ ...state, boardTitle: e.target.value }));
							}
						}}
					/>
				}
				// 번호
				boardId={<Typography className="flex flex-1 px-8">{form.boardId}</Typography>}
				// 시작일자
				startDate={
					<KeyboardDatePicker
						fullWidth
						format="yyyy.MM.dd"
						value={form.startDate}
						onChange={date => setForm(state => ({ ...state, startDate: date }))}
						error={false}
						helperText=""
					/>
				}
				// 종료일자
				endDate={
					<KeyboardDatePicker
						fullWidth
						format="yyyy.MM.dd"
						value={form.endDate}
						onChange={date => setForm(state => ({ ...state, endDate: date }))}
						error={false}
						helperText=""
					/>
				}
				// 등록일
				regDate={<Typography className="flex flex-1 px-8">{form.regDate}</Typography>}
				// 내용
				boardContent={
					<KtngTextarea
						placeholder="내용"
						value={form.boardContent}
						onChange={e => {
							// 최대 Byte 길이 제한
							if (KtngUtils.getStrByteLength(e.target.value) <= 2000) {
								setForm(state => ({ ...state, boardContent: e.target.value }));
							}
						}}
						inputProps={{ maxByteLength: 2000 }}
						rows={5}
					/>
				}
			/>
		</>
	);
};

export default VHA0040Frm1;
