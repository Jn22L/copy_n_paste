/*
 * 소메뉴 `차량등록관리`에 대한 메뉴경로 파일
 */

import VHA0020Page from './VHA0020Page';

// `메뉴경로` - `화면` 맵핑 정보를 가진 Config는 파일명 대문자로 시작
const VHA0020Config = {
	routes: [
		{
			path: '/vhaMng/vha0020', // 화면에 접근할 때 사용할 URL을 설정
			component: VHA0020Page // 접근할 화면의 컴포넌트를 설정
		}
	]
};

export default VHA0020Config;
