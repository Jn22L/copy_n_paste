/*
 * VHA0020 화면 검색조건 컴포넌트의 파일
 */

import React, { useState, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { MenuItem, Select } from '@material-ui/core';
import { UutasToolBar, UutasForm } from '@ktng/uutas';
import KtngUtils from '@ktng/utils';
import { useCmmCodeLoadEffect } from '@ktng/hooks';
import { showMessage } from 'app/store/fuse/messageSlice';
import { getVha0020MstList } from '../store/vha0020MstSlice';

const formSchema = [
	// row 1
	[
		// col 1
		{
			id: 'vhclDeptCd', // 폼 입력컨트롤 식별ID
			label: '부서코드', // 폼 입력컨트롤의 라벨
			width: 300, // 너비
			align: 'center', // 정렬
			required: false // 필수여부 (validation check에서 검사할지 여부)
		},
		// col 2
		{
			id: 'useYn',
			label: '사용여부',
			width: 150,
			align: 'center',
			requried: false
		}
	]
];

const VHA0020Srch = () => {
	const dispatch = useDispatch();

	// 입력된 값의 유효성검사를 하기위해 `useRef`로 폼입력컨트롤의 DOM에 접근한다
	const srchRef = useRef();

	const { vhDeptCode } = useSelector(({ ktng }) => ({
		vhDeptCode: ktng.code.VH_DEPT_ALL // 불러온 공통코드 리스트
	}));

	const [reqCodes] = useState([{ commCodeChk: 'VH_DEPT_ALL' }]); // 불러올 공통코드 리스트
	const [expanded, setExpanded] = useState(true); // 검색조건 폼 컴포넌트 보이기(true)/숨기기(false)

	// 폼 입력값
	const [vhclDeptCd, setVhclDeptCd] = useState('ALL');
	const [useYn, setUseYn] = useState('ALL');

	// 공통코드 리스트 불러오기 (이미 store에 있으면 요청안함)
	useCmmCodeLoadEffect(() => {}, [reqCodes]);

	function onBtnSearchClick() {
		const _vhclDeptCd = vhclDeptCd !== 'ALL' ? vhclDeptCd : '';
		const _useYn = useYn !== 'ALL' ? useYn : '';

		const validationComps = [
			// 입력값의 검증할 정보 추가
			{
				key: '부서코드', //      [필수] 컬럼명
				value: _vhclDeptCd, // [필수] 입력값
				type: 'text', //      [필수] 형식 'text'|'number'|'date'
				required: false, //    [선택] 필수입력 여부
				minLength: 2, //       [선택] 입력값 최소길이
				maxLength: 20 //       [선택] 입력값 최대길이
			},
			{
				key: '사용여부',
				value: _useYn,
				type: 'text',
				required: false,
				minLength: 1,
				maxLength: 1
			}
		];

		if (KtngUtils.validationComps(validationComps, dispatch, srchRef)) {
			// 변경된 검색조건으로 조회
			dispatch(
				getVha0020MstList({
					vhclDeptCd: _vhclDeptCd,
					useYn: _useYn
				})
			).then(action => {
				const data = action.payload;
				if (data && data.list) {
					dispatch(showMessage({ message: `총 ${data.list.length}건이 조회되었습니다.` }));
				}
			});
		}
	}

	return (
		<>
			{/* 검색조건 툴바 */}
			<UutasToolBar
				/*
				 * onBtnSearchClick
				 * - `onBtnSearchClick` 속성에 콜백함수를 넘겨주면 ToolBar 컴포넌트에 `조회` 버튼이 생김
				 * - `조회` 버튼을 클릭하면 넘겨준 콜백함수가 실행됨.
				 */
				onBtnSearchClick={onBtnSearchClick}
				/*
				 * onBtnToggleClick
				 * - `onBtnToggleClick` 속성에 콜백함수를 넘겨주면 ToolBar 컴포넌트에 `토글 (아이콘)` 버튼이 생김
				 * - `토글 (아이콘)` 버튼을 클릭했을 때,
				 *   보이기 상태면 true, 숨기기 상태면 false를 콜백함수의 파라미터로 넘겨줌.
				 */
				onBtnToggleClick={setExpanded}
				expanded={expanded} // true -> 토글 버튼을 '보이기' 모양으로 표시, false -> 토글 버튼 '숨기기' 모양으로 표시
			/>

			{/* 검색조건 입력폼 */}
			<UutasForm
				/* 폼 입력값 validation 체크 시 DOM에 접근하기 위해 useRef 사용 */
				srchRef={srchRef}
				/* true -> 검색조건 보이기, false -> 검색조건 숨기기 */
				expanded={expanded}
				/* 폼 입력컨트롤의 배치 정보 */
				schema={formSchema}
				// ==== 여기부터 폼 입력컨트롤 정의 ================================
				/*
				 * Ex)
				 * formSchema에서 설정했던 id={
				 * 	   // id에 해당하는 폼 입력 컴포넌트
				 * 	   <... />
				 * }
				 */
				// 부서코드
				vhclDeptCd={
					<Select
						className="flex flex-1 px-8 w-160"
						label="부서코드"
						fullWidth
						value={vhclDeptCd}
						onChange={e => setVhclDeptCd(e.target.value)}
						onKeyUp={e => {
							if (e.key === 'Enter') {
								onBtnSearchClick();
							}
						}}
					>
						<MenuItem value="ALL">전체</MenuItem>
						{vhDeptCode &&
							vhDeptCode.map((vhDept, key) => (
								<MenuItem key={key} value={vhDept.commCode}>
									{vhDept.commCodeName}
								</MenuItem>
							))}
					</Select>
				}
				useYn={
					<Select
						className="flex flex-1 px-8 w-96"
						label="사용여부"
						fullWidth
						value={useYn}
						onChange={e => setUseYn(e.target.value)}
						onKeyUp={e => {
							if (e.key === 'Enter') {
								onBtnSearchClick();
							}
						}}
					>
						<MenuItem value="ALL">전체</MenuItem>
						<MenuItem value="Y">사용</MenuItem>
						<MenuItem value="N">미사용</MenuItem>
					</Select>
				}
			/>
		</>
	);
};

export default VHA0020Srch;
