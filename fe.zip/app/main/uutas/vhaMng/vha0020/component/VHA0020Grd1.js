/*
 * VHA0020Grd 그리드 컴포넌트의 파일
 */

import KtngIbSheet from '@ktng/core/KtngIbSheet';
import KtngUtils, { KtngIbSheetUtils } from '@ktng/utils';
import { UutasToolBar } from '@ktng/uutas';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import _ from '@lodash';
import { showMessage } from 'app/store/fuse/messageSlice';
import { format } from 'date-fns';
import { Typography } from '@material-ui/core';
import { selectVha0020MstList, getVha0020MstList, saveGrid } from '../store/vha0020MstSlice';
import sheetOptions from './VHA0020GrdOpt1'; // 그리드 설정파일

const sheetId = KtngUtils.getUid('vha0020-grd1');

const VHA0020Grd1 = () => {
	const dispatch = useDispatch();

	/*
	 * ###################################################################################
	 * #### [Redux 설명 6 (끝)] Store에 저장된 데이터 가져오기2 (EntityAdapter) #############
	 * ###################################################################################
	 *
	 * > useSelector: Store에 저장된 데이터를 가져올 수 있다.
	 */
	// const vha0020MstList = useSelector(
	// 	/*
	// 	 * 직접 매핑함수를 작성하지 않고,
	// 	 * EntityAdapter를 사용하여 xxxxSlice.js 파일에 만들어둔 매핑함수를 사용하였다.
	// 	 *
	// 	 * > selectVha0020MstList: rootState객체로부터
	// 	 *   `vha0020MstList` (하위Store)에 저장된 데이터List를 꺼내주는 함수
	// 	 */
	// 	rootState => {
	// 		return selectVha0020MstList(rootState); // 리스트([...]) 형식으로 반환
	// 	}
	// );
	// ※ 간략히 재작성하면,
	const vha0020MstList = useSelector(selectVha0020MstList);

	const { ownTyCode, fuelTyCode, vhDeptCode, vhTypeCode, vha0020MstParams } = useSelector(({ ktng, vha0020 }) => ({
		ownTyCode: ktng.code.OWN_TY,
		fuelTyCode: ktng.code.FUEL_TY,
		vhDeptCode: ktng.code.VH_DEPT_ALL,
		vhTypeCode: ktng.code.VH_TYPE,
		vha0020MstParams: vha0020.vha0020Mst
	}));

	const [sheetObj, setSheetObj] = useState();
	const [grdData, setGrdData] = useState([]);

	// 1. 데이터 조회
	useEffect(() => {
		/*
		 * ###################################################################################
		 * #### [Redux 설명 4] Reducer 호출하기 ###############################################
		 * ###################################################################################
		 *
		 * > dispatch: Reducer를 호출한다.
		 */
		dispatch(
			/* 호출할 Reducer */
			getVha0020MstList({
				// Reducer에 필요한 파라미터를 key-value 객체로 전달함
			})
		).then(
			/*
			 * [필수아님]
			 * 호출한 Reducer가 createAsyncThunk로 생성한 비동기 Reducer인 경우,
			 * dispatch(...).then(...)
			 * 와 같이 `then()`을 붙여 `fulfilled`, `rejected` 시점의 Reducer들을 실행한 이후에 동작할
			 * 콜백함수를 작성할 수 있다.
			 */
			action => {
				const data = action.payload; // 비동기함수에서 반환한 데이터를 가져옴
				if (data && data.list) {
					// 반환된 데이터에 데이터List가 존재하는 경우, 몇 건 조회했는지 메시지를 띄움
					dispatch(showMessage({ message: `총 ${data.list.length}건이 조회되었습니다.` }));
				}
			}
		);
	}, [dispatch]);

	// 2. 데이터 필터
	useEffect(() => {
		setGrdData(vha0020MstList);
	}, [vha0020MstList]);

	/* KtngIbSheet 이벤트 콜백 */

	// 그리드 생성 콜백
	function onSheetLoad(sheet) {
		setSheetObj(sheet);

		// 그리드에 공통코드 설정
		if (ownTyCode) {
			const { enumKeys, enumVals } = KtngIbSheetUtils.cvtCodeToIbSheetEnumType(ownTyCode);
			sheet.setAttribute(null, 'ownTy', 'EnumKeys', enumKeys, true);
			sheet.setAttribute(null, 'ownTy', 'Enum', enumVals, true);
		}
		if (fuelTyCode) {
			const { enumKeys, enumVals } = KtngIbSheetUtils.cvtCodeToIbSheetEnumType(fuelTyCode);
			sheet.setAttribute(null, 'fuelTy', 'EnumKeys', enumKeys, true);
			sheet.setAttribute(null, 'fuelTy', 'Enum', enumVals, true);
		}
		if (vhDeptCode) {
			const { enumKeys, enumVals } = KtngIbSheetUtils.cvtCodeToIbSheetEnumType(vhDeptCode);
			sheet.setAttribute(null, 'vhclDeptCd', 'EnumKeys', enumKeys, true);
			sheet.setAttribute(null, 'vhclDeptCd', 'Enum', enumVals, true);
		}
		if (vhTypeCode) {
			const { enumKeys, enumVals } = KtngIbSheetUtils.cvtCodeToIbSheetEnumType(vhTypeCode);
			sheet.setAttribute(null, 'vhType', 'EnumKeys', enumKeys, true);
			sheet.setAttribute(null, 'vhType', 'Enum', enumVals, true);
		}

		// 이벤트 등록
		// onRowAdd, onAfterClick, onAfterChange 3개 이벤트는 `KtngIbSheet` 컴포넌트 속성에 콜백함수를 넣어 추가
		// 3개 이벤트를 제외한 이벤트를 등록할 때 이곳에 작성
		// sheet.bind('onIconClick', onSheetIconClick);
	}

	// 그리드에 행 추가
	function handleBtnAddClick() {
		return {
			productYm: new Date(), // `연식` 기본값: 오늘
			recordDt: new Date() // `운행시작일` 기본값: 오늘
		};
	}

	// 그리드 수정사항 일괄저장 (추가/수정/삭제)
	function handleBtnSaveClick() {
		const changesList = KtngIbSheetUtils.getRowsByStatus(sheetObj, ['I', 'U', 'D']).map(row => ({
			// 추가/수정할 속성이름/값 나열
			..._.pick(row, [
				'rowStatus',
				'vhclNo',
				'vhclNm',
				'ownTy',
				'fuelTy',
				// 'productYm', // 하단에서 {Date} -> {string} Type 변경
				'vhclDeptCd',
				// 'recordDt', // 하단에서 {Date} -> {string} Type 변경
				// 'expireDt', // 하단에서 {Date} -> {string} Type 변경
				'useYn',
				'vhType',
				'vhNote'
			]),
			productYm: format(row.productYm, 'yyyyMM'),
			recordDt: format(row.recordDt, 'yyyyMMdd'),
			expireDt: format(row.expireDt, 'yyyyMMdd')
		}));

		// 입력값 검증
		KtngUtils.validationSaveData(
			/* 추가/수정/삭제 리스트 */
			changesList,

			/* 필수 입력해야하는 속성이름/한글명 나열 */
			{
				vhclNo: '차량번호',
				vhclNm: '차종',
				vhclDeptCd: '배차부서',
				useYn: '사용여부'
			},

			dispatch, // 함수 내부에서 메시지 출력을 할 수 있도록 넘겨줌

			/* validation 성공 시 콜백 */
			() => {
				// 그리드 변경사항 저장
				dispatch(saveGrid({ changesList })).then(action => {
					const data = action.payload;
					if (data && data.success) {
						dispatch(showMessage({ message: '변경사항이 반영되었습니다.' }));
						// vha0020MstParams: 이전에 조회했던 파라미터로 조회
						dispatch(getVha0020MstList(vha0020MstParams));
					}
				});
			}
		);
	}

	// 그리드 엑셀 다운로드
	function handleBtnDownExcelClick() {
		return {
			/*
			 * Excel Config
			 */
			// fileName: '', // 엑셀파일명.......... 기본값: '{ToolBar title}_{오늘날짜 yyyyMMdd}.xlsx'
			// merge: 1, // 그리드 셀병합 유지여부... 기본값: 1(true)
			// ...
		};
	}

	return (
		<div className="flex flex-col w-full">
			{/* 그리드 툴바 */}
			<UutasToolBar
				title="차량등록관리" // ToolBar에 표시할 헤더 문자열
				variant="subtitle1" // `title` 문자열 스타일종류
				sheet={sheetObj} // IBSheet Object (onBtnAddClick, onBtnDownExcelClick 콜백을 사용하는 경우 필수)
				/*
				 * onBtnAddClick
				 * - `onBtnAddClick` 속성에 콜백함수를 넘겨주면 ToolBar 컴포넌트에 `추가` 버튼이 생김
				 * - `추가` 버튼을 클릭하면 넘겨준 콜백함수가 실행되고,
				 *   콜백함수에서 그리드에 추가할 행 데이터를 반환하면 그리드에 행이 추가됨.
				 */
				onBtnAddClick={handleBtnAddClick}
				/*
				 * onBtnSaveClick
				 * - `onBtnSaveClick` 속성에 콜백함수를 넘겨주면 ToolBar 컴포넌트에 `저장` 버튼이 생김
				 * - `저장` 버튼을 클릭하면 넘겨준 콜백함수가 실행됨.
				 */
				onBtnSaveClick={handleBtnSaveClick}
				/*
				 * onBtnDownExcelClick
				 * - `onBtnDownExcelClick` 속성에 콜백함수를 넘겨주면 ToolBar 컴포넌트에 `엑셀다운로드` 버튼이 생김
				 * - `엑셀다운로드` 버튼을 클릭하면 넘겨준 콜백함수가 실행되고,
				 *   콜백함수에서 엑셀 설정 key-value 객체를 넘겨주면, 설정을 반영하여 그리드 내용을 엑셀파일로 다운로드함.
				 */
				onBtnDownExcelClick={handleBtnDownExcelClick}
			/>

			{/* 그리드 */}
			<KtngIbSheet
				// [필수 속성]
				sheetId={sheetId} // 그리드를 식별할 수 있는 ID 문자열
				options={sheetOptions} // 그리드 설정
				data={grdData} // 데이터List
				// [선택 속성]
				// - 내부에서 그리드에 사용할 공통코드 로드
				codes={[
					{ commCodeChk: 'OWN_TY' }, // 차량소유구분
					{ commCodeChk: 'FUEL_TY' }, // 차량연료구분
					{ commCodeChk: 'VH_DEPT_ALL' }, // 배차부서 (배차+지정차량)
					{ commCodeChk: 'VH_TYPE' } // 차량용도구분
				]}
				// - 이벤트
				onLoad={onSheetLoad} // 생성된 sheet 객체 바인딩 및 배차부서 로드 수행
				//   ※ 아래 2개 외 필요한 이벤트는 `onSheetLoad`에서 직접 바인딩할 것
				// onAfterClick={onSheetClick} // 내부공통기능 수행 후 `onSheetClick` 콜백이 호출됨
				// onAfterChange={onSheetChange} // 내부공통기능 수행 후 `onSheetChange` 콜백이 호출됨
				// - 스타일 속성
				// className="" // tailwind 스타일 적용 가능
				style={{ height: '98%' }} // 그리드 초기 높이 설정시에는 style만 적용됨
			/>

			{/* 하단 안내문구 */}
			<div>
				<Typography className="text-red my-4">
					배차부서가 공란인 경우 기존 배차부서가 미사용중이거나 삭제된 부서이기 때문에 다른 배차부서로 선택해
					저장해주시기 바랍니다.
				</Typography>
			</div>
		</div>
	);
};

export default VHA0020Grd1;
