import { combineReducers } from 'redux';
import vhd0060Mst from './vhd0060MstSlice';
import vhd0060Dtl from './vhd0060DtlSlice';

const children = {
	vhd0060Mst,
	vhd0060Dtl
};

const reducer = combineReducers(children);

export default reducer;
