import { createSlice, createAsyncThunk, createEntityAdapter } from '@reduxjs/toolkit';
import KtngUtils from '@ktng/utils';
import vhd0060Service from 'app/services/vhd0060Service';

export const getVhd0060DtlList = createAsyncThunk(
	'vhd0060/vhd0060Dtl/getVhd0060DtlList',
	async ({ vhclNo, fromYmd, toYmd }, { dispatch, rejectWithValue }) => {
		try {
			const data = await vhd0060Service.selectGridDtl({ vhclNo, fromYmd, toYmd });
			return {
				list: data.list,
				params: {
					vhclNo,
					fromYmd,
					toYmd
				}
			};
		} catch (err) {
			throw KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

const vhd0060DtlAdapter = createEntityAdapter({
	selectId: vhd0060Dtl => `${vhd0060Dtl.runDt}.${vhd0060Dtl.userEmpNo}`
});

export const { selectAll: selectVhd0060DtlList, selectById: selectVhclDeptById } = vhd0060DtlAdapter.getSelectors(
	state => state.vhd0060.vhd0060Dtl
);

const initialState = {
	params: {
		vhclNo: '',
		fromYmd: '',
		toYmd: ''
	},
	loading: false
};

const vhd0060DtlSlice = createSlice({
	name: 'vhd0060/vhd0060Dtl',
	initialState: vhd0060DtlAdapter.getInitialState(initialState),
	reducers: {
		changeVhd0060DtlList: vhd0060DtlAdapter.updateOne,
		changeVhd0060DtlLists: vhd0060DtlAdapter.updateMany,
		clearVhd0060DtlList: vhd0060DtlAdapter.removeAll
	},

	extraReducers: {
		[getVhd0060DtlList.pending]: state => {
			state.loading = true;
		},

		[getVhd0060DtlList.fulfilled]: (state, action) => {
			const { list, params } = action.payload;
			vhd0060DtlAdapter.setAll(state, list);
			state.params = params;
			state.loading = false;
		},

		[getVhd0060DtlList.rejected]: state => {
			state.loading = false;
		}
	}
});

export const { changeVhd0060DtlList, changeVhd0060DtlLists, clearVhd0060DtlList } = vhd0060DtlSlice.actions;

export default vhd0060DtlSlice.reducer;
