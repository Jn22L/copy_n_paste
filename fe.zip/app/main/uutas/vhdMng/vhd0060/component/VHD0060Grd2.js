import KtngIbSheet from '@ktng/core/KtngIbSheet';
import KtngUtils from '@ktng/utils';
import { UutasToolBar } from '@ktng/uutas';
// import { showMessage } from 'app/store/fuse/messageSlice';
import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { selectVhd0060MstList } from '../store/vhd0060MstSlice';
import { selectVhd0060DtlList } from '../store/vhd0060DtlSlice';
import sheetOptions from './VHD0060GrdOpt2';

const sheetId = KtngUtils.getUid('vhd0060-grd2');

const VHD0060Grd2 = () => {
	const vhd0060MstList = useSelector(selectVhd0060MstList);
	const vhd0060DtlList = useSelector(selectVhd0060DtlList);
	const [sheetObj, setSheetObj] = useState();
	const [grdData, setGrdData] = useState([]);

	// 데이터 셋팅
	useEffect(() => {
		if (!sheetObj) return;

		if (vhd0060MstList?.length > 0) {
			setGrdData(vhd0060DtlList);
		} else {
			sheetObj.removeAll();
			// setGrdData([]);
		}
		// eslint-disable-next-line
	}, [sheetObj, vhd0060DtlList]);

	// 그리드 생성 콜백
	function onSheetLoad(sheet) {
		setSheetObj(sheet);
	}

	// 그리드 엑셀 다운로드
	function handleBtnDownExcelClick() {
		return {
			// Excel Config
			// down2Excel();
		};
	}

	return (
		<div className="flex flex-col w-full">
			<UutasToolBar
				title="운행기록부(업무용)"
				variant="subtitle1"
				sheet={sheetObj}
				onBtnDownExcelClick={handleBtnDownExcelClick} // Excel Config 반환
			/>

			<KtngIbSheet
				// [필수 속성]
				sheetId={sheetId}
				options={sheetOptions}
				data={grdData}
				onLoad={onSheetLoad}
				style={{ height: '430px' }} // 그리드 초기 높이 설정시에는 style만 적용됨
			/>
		</div>
	);
};

export default VHD0060Grd2;
