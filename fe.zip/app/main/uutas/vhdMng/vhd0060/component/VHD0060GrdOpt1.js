const options = {
	Cfg: {
		CanSelect: true,
		SelectingCells: 0,
		CanEdit: 0,
		HeaderMerge: 1,
		CustomScroll: 1
	},
	Def: {
		// Col: { RelWidth: 1 }
	},
	Cols: [
		{
			Header: ['차량번호'],
			Name: 'vhclNo',
			Type: 'Text',
			Align: 'Center',
			MinWidth: 150,
			CanEdit: 0
		},
		{
			Header: ['차종'],
			Name: 'vhclNm',
			Type: 'Text',
			Align: 'Center',
			MinWidth: 150,
			CanEdit: 0
		},
		{
			Header: ['차량용도'],
			Name: 'vhTypeNm',
			Type: 'Text',
			Align: 'Center',
			MinWidth: 150,
			CanEdit: 0
		},
		{
			Header: ['배차부서'],
			Name: 'vhclDeptNm',
			Type: 'Text',
			Align: 'Center',
			MinWidth: 150,
			CanEdit: 0,
			RelWidth: 1
		},
		{
			Header: ['운행시작일'],
			Name: 'recordDt',
			Type: 'Date',
			Format: 'yyyy.MM.dd',
			Align: 'Center',
			MinWidth: 150,
			CanEdit: 0,
			RelWidth: 1
		},
		{
			Header: ['운행종료일'],
			Name: 'expireDt',
			Type: 'Date',
			Format: 'yyyy.MM.dd',
			Align: 'Center',
			MinWidth: 150,
			CanEdit: 0,
			RelWidth: 1
		},
		{
			Header: ['운행종료사유'],
			Name: 'vhNote',
			Type: 'Text',
			Align: 'Left',
			MinWidth: 200,
			CanEdit: 0,
			RelWidth: 1
		}
	]
};

export default options;
