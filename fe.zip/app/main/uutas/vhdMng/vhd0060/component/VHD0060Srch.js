import React, { useEffect, useState, useRef } from 'react';
import { useDispatch } from 'react-redux';
import { useCmmCodeLoadEffect } from '@ktng/hooks';
import { UutasToolBar, UutasForm } from '@ktng/uutas';
import KtngUtils from '@ktng/utils';
import '@ktng/core/DateRangePicker/styles.css';
import 'react-date-range/dist/styles.css';
import 'react-date-range/dist/theme/default.css';
import { startOfToday, add, format, isValid } from 'date-fns';
import { KeyboardDatePicker } from '@material-ui/pickers';
import VehiclePicker from 'app/main/popup/VehiclePicker';
import { showMessage } from 'app/store/fuse/messageSlice';
import { getVhd0060MstList } from '../store/vhd0060MstSlice';

const reqCodes = [{ commCodeChk: 'VH_DEPT_ALL' }];

const formSchema = [
	// row 1
	[
		// col 1
		{
			id: 'vhclNo',
			label: '차량번호',
			width: 500,
			align: 'center',
			required: false
		},
		// col 2
		{
			id: 'fromToYmd',
			label: '출발기간',
			width: 350,
			align: 'center',
			required: true
		}
	]
];

const VHD0060Srch = props => {
	const dispatch = useDispatch();

	// 입력된 값의 유효성검사를 하기위해 `useRef`로 폼입력컨트롤의 DOM에 접근한다
	const srchRef = useRef();

	// const { uutasUser } = useSelector(({ auth }) => ({
	// 	uutasUser: auth.user.uutasUser
	// }));

	const [expanded, setExpanded] = useState(true);
	const [vehicle, setVehicle] = useState({});
	const _startDate = add(startOfToday(), { months: -1 });
	const [fromYmd, setFromYmd] = useState(_startDate);
	const [toYmd, setToYmd] = useState(startOfToday());

	// `배차부서` 공통코드 리스트 조회
	useCmmCodeLoadEffect(() => {}, [reqCodes]);

	// 회의실 목록 데이터 로드
	useEffect(() => {
		onBtnSearchClick();
		// eslint-disable-next-line
	}, []);

	// 조회버튼 클릭
	function onBtnSearchClick() {
		const _vhclNo = vehicle.vhclNo || '';
		const validationComps = [
			{ key: '차량번호', value: _vhclNo, type: 'text', required: false, minLength: 2, maxLength: 20 },
			{ key: '출발기간FROM', value: fromYmd, type: 'date', required: true },
			{ key: '출발기간TO', value: toYmd, type: 'date', required: true }
		];

		const _fromYmd = isValid(fromYmd) ? format(fromYmd, 'yyyyMMdd') : '';
		const _toYmd = isValid(toYmd) ? format(toYmd, 'yyyyMMdd') : '';

		if (KtngUtils.validationComps(validationComps, dispatch, srchRef)) {
			// Dtl 에 검색조건 전달
			const changes = {
				srchFromYmd: _fromYmd || undefined,
				srchToYmd: _toYmd || undefined
			};
			props.onFiltersChange(changes);

			// 변경된 검색조건으로 조회
			dispatch(
				getVhd0060MstList({
					vhclNo: _vhclNo,
					fromYmd: _fromYmd,
					toYmd: _toYmd
				})
			).then(action => {
				const data = action.payload;
				if (data && data.list) {
					dispatch(showMessage({ message: `총 ${data.list.length}건이 조회되었습니다.` }));
				}
			});
		}
	}

	return (
		<>
			{/* 검색조건 툴바 */}
			<UutasToolBar onBtnSearchClick={onBtnSearchClick} expanded={expanded} onBtnToggleClick={setExpanded} />

			{/* 검색조건 입력폼 */}
			<UutasForm
				srchRef={srchRef}
				expanded={expanded}
				schema={formSchema}
				// 차량번호
				vhclNo={
					<>
						<VehiclePicker
							onChange={data => setVehicle(data)}
							views={['vhclNo', 'vhclNm']}
							// disabledViews={['vhclNm']} // 리스트에 있는 입력뷰를 disabled 시킴
						/>
					</>
				}
				// 출발기간FROM TO
				fromToYmd={
					<>
						<KeyboardDatePicker
							className="w-136"
							format="yyyy.MM.dd"
							value={fromYmd}
							onChange={dateTime => setFromYmd(dateTime)}
						/>
						<div className="inline-block ml-16 mr-16">~</div>
						<KeyboardDatePicker
							className="w-136"
							format="yyyy.MM.dd"
							value={toYmd}
							onChange={dateTime => setToYmd(dateTime)}
						/>
					</>
				}
			/>
		</>
	);
};

export default VHD0060Srch;
