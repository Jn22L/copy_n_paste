const options = {
	Cfg: {
		CanSelect: true,
		SelectingCells: 0,
		CanEdit: 0,
		HeaderMerge: 3,
		CustomScroll: 1
	},
	Def: {
		// Col: { RelWidth: 1 }
	},
	Cols: [
		{
			Header: ['사용일자', '사용일자', '사용일자'],
			Name: 'runDt',
			Type: 'Date',
			Format: 'yyyy.MM.dd',
			Align: 'Center',
			MinWidth: 100,
			CanEdit: 0
		},
		{
			Header: ['사번', '사번', '사번'],
			Name: 'userEmpNo',
			Type: 'Text',
			Align: 'Center',
			MinWidth: 100,
			CanEdit: 0
		},
		{
			Header: ['성명', '성명', '성명'],
			Name: 'userEmpNm',
			Type: 'Text',
			Align: 'Center',
			MinWidth: 100,
			CanEdit: 0
		},
		{
			Header: ['소속', '소속', '소속'],
			Name: 'userPartNm',
			Type: 'Text',
			Align: 'Center',
			MinWidth: 100,
			CanEdit: 0,
			RelWidth: 1
		},
		{
			Header: ['직급', '직급', '직급'],
			Name: 'userPosGrdNm',
			Type: 'Text',
			Align: 'Center',
			MinWidth: 80,
			CanEdit: 0,
			RelWidth: 1
		},
		{
			Header: ['운행내역', '주행전 계기판의 \n 거리(km)', '주행전 계기판의 \n 거리(km)'],
			Name: 'beforeRunKm',
			Type: 'Int',
			Align: 'Right',
			MinWidth: 100,
			CanEdit: 0,
			RelWidth: 1
		},
		{
			Header: ['운행내역', '주행후 계기판의 \n 거리(km)', '주행후 계기판의 \n 거리(km)'],
			Name: 'alterRunKm',
			Type: 'Int',
			Align: 'Right',
			MinWidth: 100,
			CanEdit: 0,
			RelWidth: 1
		},
		{
			Header: ['운행내역', '주행거리(km)', '주행거리(km)'],
			Name: 'runKm',
			Type: 'Int',
			Align: 'Right',
			MinWidth: 100,
			CanEdit: 0,
			RelWidth: 1
		},
		{
			Header: ['운행내역', '사용거리(km)', '출퇴근용(km)'],
			Name: 'runKindKm1',
			Type: 'Int',
			Align: 'Right',
			MinWidth: 100,
			CanEdit: 0,
			RelWidth: 1
		},
		{
			Header: ['운행내역', '사용거리(km)', '일반업무용(km)'],
			Name: 'runKindKm2',
			Type: 'Int',
			Align: 'Right',
			MinWidth: 100,
			CanEdit: 0,
			RelWidth: 1
		},
		{
			Header: ['운행내역', '사용거리(km)', '개인용(km)'],
			Name: 'runKindKm3',
			Type: 'Int',
			Align: 'Right',
			MinWidth: 100,
			CanEdit: 0,
			RelWidth: 1
		},
		{
			Header: ['운행내역', '비고', '비고'],
			Name: 'reason',
			Type: 'Text',
			Align: 'Left',
			MinWidth: 150,
			CanEdit: 0,
			RelWidth: 1
		}
	]
};

export default options;
