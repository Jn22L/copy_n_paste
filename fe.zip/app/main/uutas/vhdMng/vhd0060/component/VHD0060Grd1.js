import KtngIbSheet from '@ktng/core/KtngIbSheet';
import KtngUtils from '@ktng/utils';
import { UutasToolBar } from '@ktng/uutas';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
// import { showMessage } from 'app/store/fuse/messageSlice';
import { selectVhd0060MstList } from '../store/vhd0060MstSlice';
import { getVhd0060DtlList } from '../store/vhd0060DtlSlice';
import sheetOptions from './VHD0060GrdOpt1';

const sheetId = KtngUtils.getUid('vhd0060-grd1');

const VHD0060Grd1 = ({ srchFilters }) => {
	const dispatch = useDispatch();
	const vhd0060MstList = useSelector(selectVhd0060MstList);

	const [sheetObj, setSheetObj] = useState();
	const [grdData, setGrdData] = useState([]);

	// 1. 데이터 셋팅, 조회
	useEffect(() => {
		if (!sheetObj) return;

		// Mst GrdData 를 채운다.
		setGrdData(vhd0060MstList);

		// Dtl 조회
		if (vhd0060MstList?.length > 0) {
			changeDtlList(vhd0060MstList[0].vhclNo);
		} else {
			changeDtlList('');
		}
		// eslint-disable-next-line
	}, [sheetObj, vhd0060MstList]);

	// 그리드 생성 콜백
	function onSheetLoad(sheet) {
		setSheetObj(sheet);
	}

	function onAfterClick(paramObject) {
		changeDtlList(paramObject.row.vhclNo);
		// eslint-disable-next-line
	}

	function changeDtlList(selectedVhclNo) {
		// 변경된 검색조건으로 Dtl을 조회
		dispatch(
			getVhd0060DtlList({
				vhclNo: selectedVhclNo,
				fromYmd: srchFilters.srchFromYmd,
				toYmd: srchFilters.srchToYmd
			})
		).then(action => {
			// const data = action.payload;
			// if (data && data.list) {
			// 	dispatch(showMessage({ message: `총 ${data.list.length}건이 조회되었습니다.` }));
			// }
		});
	}

	return (
		<div className="flex flex-col w-full">
			<UutasToolBar title="차량조회" variant="subtitle1" sheet={sheetObj} />

			<KtngIbSheet
				// [필수 속성]
				sheetId={sheetId}
				options={sheetOptions}
				data={grdData}
				onLoad={onSheetLoad}
				onAfterClick={onAfterClick}
				style={{ height: '125px' }} // 그리드 초기 높이 설정시에는 style만 적용됨
			/>
		</div>
	);
};

export default VHD0060Grd1;
