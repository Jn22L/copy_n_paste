import { combineReducers } from 'redux';
import vhd0050Mst from './vhd0050MstSlice';

const reducer = combineReducers({
	vhd0050Mst
});

export default reducer;
