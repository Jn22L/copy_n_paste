import { createSlice, createAsyncThunk, createEntityAdapter } from '@reduxjs/toolkit';
import KtngUtils from '@ktng/utils';
import vhd0050Service from 'app/services/vhd0050Service';
import { startOfToday, add } from 'date-fns';
import moment from 'moment';

export const getVhd0050MstList = createAsyncThunk(
	'vhd0050/vhd0050Mst/getVhd0050MstList',
	async ({ vhclDeptCd, driverNo, driverNm, fromYmd, toYmd }, { dispatch, rejectWithValue }) => {
		try {
			const data = await vhd0050Service.selectGrid({ vhclDeptCd, driverNo, driverNm, fromYmd, toYmd });
			return {
				list: data.list,
				params: {
					vhclDeptCd,
					driverNo,
					driverNm,
					fromYmd,
					toYmd
				}
			};
		} catch (err) {
			throw KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

const vhd0050MstAdapter = createEntityAdapter({
	selectId: vhclDept => vhclDept.empNo
});

export const { selectAll: selectVhd0050MstList, selectById: selectVhclDeptById } = vhd0050MstAdapter.getSelectors(
	state => state.vhd0050.vhd0050Mst
);

const initialState = {
	params: {
		vhclDeptCd: '',
		driverNo: '',
		driverNm: '',
		fromYmd: moment(add(startOfToday(), { months: -1 })).format('yyyyMMDD'),
		toYmd: moment(startOfToday()).format('yyyyMMDD')
	},
	loading: false
};

const vhd0050MstSlice = createSlice({
	name: 'vhd0050/vhd0050Mst',
	initialState: vhd0050MstAdapter.getInitialState(initialState),
	reducers: {
		changeVhd0050MstList: vhd0050MstAdapter.updateOne,
		changeVhd0050MstLists: vhd0050MstAdapter.updateMany,
		clearVhd0050MstList: vhd0050MstAdapter.removeAll
	},

	extraReducers: {
		[getVhd0050MstList.pending]: state => {
			state.loading = true;
		},

		[getVhd0050MstList.fulfilled]: (state, action) => {
			const { list, params } = action.payload;
			vhd0050MstAdapter.setAll(state, list);
			state.params = params;
			state.loading = false;
		},

		[getVhd0050MstList.rejected]: state => {
			state.loading = false;
		}
	}
});

export const { changeVhd0050MstList, changeVhd0050MstLists, clearVhd0050MstList } = vhd0050MstSlice.actions;

export default vhd0050MstSlice.reducer;
