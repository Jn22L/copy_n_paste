import React from 'react';
import { useSelector } from 'react-redux';
import withReducer from 'app/store/withReducer';
import { UutasPageSimple } from '@ktng/uutas';
import { VHD0050Srch, VHD0050Grd1 } from './component';
import reducer from './store';

// vhdMng/vhd0050/vhd0050
const VHD0050Page = () => {
	const { vhd0050MstLoading } = useSelector(({ vhd0050 }) => ({
		vhd0050MstLoading: vhd0050.vhd0050Mst.loading
	}));

	return (
		<UutasPageSimple title="운행기록통계" loading={vhd0050MstLoading}>
			{/* 검색조건 */}
			<VHD0050Srch />

			{/* 그리드 */}
			<div className="flex flex-1">
				<VHD0050Grd1 />
			</div>
		</UutasPageSimple>
	);
};

export default withReducer('vhd0050', reducer)(VHD0050Page);
