import React, { useEffect, useState, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { MenuItem, Select, IconButton, Input } from '@material-ui/core';
import { UutasToolBar, UutasForm } from '@ktng/uutas';
import KtngUtils from '@ktng/utils';
import { useCmmCodeLoadEffect } from '@ktng/hooks/index';
import { closeDialog, openDialog } from 'app/store/fuse/dialogSlice';
import DriverPopup from 'app/main/popup/DriverPopup';
import { Search } from '@material-ui/icons';
import { KeyboardDatePicker } from '@material-ui/pickers';
import { showMessage } from 'app/store/fuse/messageSlice';
import moment from 'moment';
import { getVhd0050MstList } from '../store/vhd0050MstSlice';

const formSchema = [
	// row 1
	[
		// col 1
		// {
		// 	id: 'vhclDeptCd',
		// 	label: '부서',
		// 	width: 300,
		// 	align: 'center',
		// 	required: false
		// },
		// col 2
		{
			id: 'fromToYmd',
			label: '기준기간',
			width: 420,
			align: 'center',
			required: false
		},
		{
			id: 'driverNo',
			label: '운전원',
			align: 'left',
			required: false
		}
		// col 3
	]
];

const VHD0050Srch = () => {
	const dispatch = useDispatch();

	// 입력된 값의 유효성검사를 하기위해 `useRef`로 폼입력컨트롤의 DOM에 접근한다
	const srchRef = useRef();

	const { uutasUser, vhDeptCode, vhd0050MstParams } = useSelector(({ auth, ktng, vhd0050 }) => ({
		uutasUser: auth.user.uutasUser || {},
		vhDeptCode: ktng.code.VH_DEPT_ALL || [],
		vhd0050MstParams: vhd0050.vhd0050Mst.params
	}));

	const [reqCodes] = useState([{ commCodeChk: 'VH_DEPT_ALL' }]);
	const [expanded, setExpanded] = useState(true);

	// 폼 입력값
	const [vhclDeptCd, setVhclDeptCd] = useState(vhd0050MstParams.vhclDeptCd || ''); // '부서'
	const [driverNo, setDriverNo] = useState(''); // `운전원`
	const [driverNm, setDriverNm] = useState(''); // `운전원`
	const [fromYmd, setFromYmd] = useState(moment(vhd0050MstParams.fromYmd).format('yyyy.MM.DD') || ''); // '기준기간'
	const [toYmd, setToYmd] = useState(moment(vhd0050MstParams.toYmd).format('yyyy.MM.DD') || ''); // '기준기간'

	useCmmCodeLoadEffect(() => {}, [reqCodes]);

	// VH_DEPT_ALL 공통코드에 사용자의 부서코드가 포함되어 있는지 확인 후 상태값 셋팅
	useEffect(() => {
		const isValidVhclDeptCd = KtngUtils.cmmCodeToName('VH_DEPT_ALL', uutasUser.partCd) !== null;
		if (isValidVhclDeptCd) {
			setVhclDeptCd(uutasUser.partCd);
		}
	}, [uutasUser.partCd, vhDeptCode]);

	function onBtnSearchClick() {
		const _vhclDeptCd = vhclDeptCd !== 'ALL' ? vhclDeptCd : '';
		const _driverNo = driverNo !== '' ? driverNo : '';
		const _fromYmd = fromYmd !== '' && fromYmd !== null ? moment(fromYmd).format('yyyyMMDD') : '';
		const _toYmd = toYmd !== '' && toYmd !== null ? moment(toYmd).format('yyyyMMDD') : '';

		const validationComps = [
			{ key: '부서', value: _vhclDeptCd, type: 'text', required: false, minLength: 2, maxLength: 20 },
			{ key: '운전원번호', value: _driverNo, type: 'text', required: false, minLength: 2, maxLength: 20 },
			{ key: '기준기간FROM', value: _fromYmd, type: 'text', required: false, maxLength: 8 },
			{ key: '기준기간TO', value: _toYmd, type: 'text', required: false, maxLength: 8 }
		];

		if (KtngUtils.validationComps(validationComps, dispatch, srchRef)) {
			// 변경된 검색조건으로 조회
			dispatch(
				getVhd0050MstList({
					vhclDeptCd: _vhclDeptCd,
					driverNo: _driverNo,
					driverNm,
					fromYmd: _fromYmd,
					toYmd: _toYmd
				})
			).then(action => {
				const data = action.payload;
				if (data && data.list) {
					dispatch(showMessage({ message: `총 ${data.list.length}건이 조회되었습니다.` }));
				}
			});
		}
	}

	// // 검사시작일자 변경 저장
	const onChangeFromYmd = date => {
		if (moment(date).isValid() && moment(toYmd).isValid() && moment(date).isAfter(toYmd)) {
			dispatch(showMessage({ message: '시작일자는 종료일자보다 클 수 없습니다.', variant: 'error' }));
			return;
		}

		setFromYmd(date);
	};

	// 검사종료일자 변경 저장
	const onChangeToYmd = date => {
		if (moment(fromYmd).isValid() && moment(date).isValid() && moment(fromYmd).isAfter(date)) {
			dispatch(showMessage({ message: '종료일자는 시작일자보다 작을 수 없습니다.', variant: 'error' }));
			return;
		}

		setToYmd(date);
	};

	// `운전원` 팝업 열기
	function openDriverPopup(museClick) {
		dispatch(
			openDialog({
				children: (
					<DriverPopup
						onSelect={selected => {
							setDriverNo(selected.driverNo);
							setDriverNm(selected.driverNm);
							dispatch(closeDialog());
						}}
						onClose={() => dispatch(closeDialog())}
						// 조회조건
						//vhclDeptCd={vhclDeptCd}
						useYn="ALL"
						driverNo={driverNo}
						driverNm={driverNm}
						// 옵션
						museClick={museClick}
					/>
				)
			})
		);
	}

	return (
		<>
			{/* 검색조건 툴바 */}
			<UutasToolBar onBtnSearchClick={onBtnSearchClick} expanded={expanded} onBtnToggleClick={setExpanded} />

			{/* 검색조건 입력폼 */}
			<UutasForm
				srchRef={srchRef}
				expanded={expanded}
				schema={formSchema}
				// 부서
				// vhclDeptCd={
				// 	<Select
				// 		className="flex flex-1 px-8 w-160"
				// 		label="부서코드"
				// 		fullWidth
				// 		value={vhclDeptCd}
				// 		onChange={e => setVhclDeptCd(e.target.value)}
				// 	>
				// 		<MenuItem value="ALL">전체</MenuItem>
				// 		{vhDeptCode &&
				// 			vhDeptCode.map((vhDept, key) => (
				// 				<MenuItem key={key} value={vhDept.commCode}>
				// 					{vhDept.commCodeName}
				// 				</MenuItem>
				// 			))}
				// 	</Select>
				// }
				// 기준기간
				fromToYmd={
					<div className="px-8">
						<KeyboardDatePicker
							className="w-136"
							format="yyyy.MM.dd"
							value={fromYmd}
							onChange={dateTime => onChangeFromYmd(dateTime)}
						/>
						<div className="inline ml-16 mr-16">~</div>
						<KeyboardDatePicker
							className="w-136"
							format="yyyy.MM.dd"
							value={toYmd}
							onChange={dateTime => onChangeToYmd(dateTime)}
						/>
					</div>
				}
				// 운전원
				driverNo={
					<>
						<Input
							className="w-96 mx-4"
							placeholder="운전원ID"
							value={driverNo}
							onChange={e => {
								setDriverNo(e.target.value);
								setDriverNm('');
							}}
							onKeyUp={e => {
								// 운전원ID 입력 후 `Enter` 입력 시 팝업 실행
								if (e.key === 'Enter') {
									openDriverPopup(false);
								}
							}}
						/>
						<Input
							className="w-160 mx-4"
							placeholder="운전원성명"
							value={driverNm}
							onChange={e => {
								setDriverNo('');
								setDriverNm(e.target.value);
							}}
							onKeyUp={e => {
								// 운전원성명 입력 후 `Enter` 입력 시 팝업 실행
								if (e.key === 'Enter') {
									openDriverPopup(false);
								}
							}}
						/>
						<IconButton
							size="small"
							onClick={e => openDriverPopup()} // 🔍 버튼 클릭 시 팝업 실행
						>
							<Search fontSize="small" />
						</IconButton>
					</>
				}
			/>
		</>
	);
};

export default VHD0050Srch;
