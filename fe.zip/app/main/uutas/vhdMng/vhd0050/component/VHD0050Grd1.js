import KtngIbSheet from '@ktng/core/KtngIbSheet';
import KtngUtils from '@ktng/utils';
import { UutasToolBar } from '@ktng/uutas';
import { showMessage } from 'app/store/fuse/messageSlice';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { startOfToday, add } from 'date-fns';
import moment from 'moment';
import sheetOptions from './VHD0050GrdOpt1';
import { selectVhd0050MstList, getVhd0050MstList } from '../store/vhd0050MstSlice';

const sheetId = KtngUtils.getUid('vhd0050-grd1');

const VHD0050Grd1 = () => {
	const dispatch = useDispatch();

	const vhd0050MstList = useSelector(selectVhd0050MstList);

	const { uutasUser, vhDeptCode } = useSelector(({ auth, ktng }) => ({
		uutasUser: auth.user.uutasUser || {},
		vhDeptCode: ktng.code.VH_DEPT_ALL // 불러온 공통코드 리스트
	}));

	const [sheetObj, setSheetObj] = useState();
	const [grdData, setGrdData] = useState([]);

	useEffect(() => {
		if (!vhDeptCode) return; // VH_DEPT_ALL 공통코드가 로드된 이후에 데이터 조회하도록 함

		let defaultVhclDeptCd = null;
		const isValidVhclDeptCd = KtngUtils.cmmCodeToName('VH_DEPT_ALL', uutasUser.partCd) !== null;

		if (isValidVhclDeptCd) {
			defaultVhclDeptCd = uutasUser.partCd;
		}

		const _startDate = add(startOfToday(), { months: -1 });
		const _vhclDeptCd = defaultVhclDeptCd !== 'ALL' ? defaultVhclDeptCd : '';

		dispatch(
			getVhd0050MstList({
				vhclDeptCd: _vhclDeptCd,
				driverNo: '',
				driverNm: '',
				fromYmd: moment(_startDate).format('yyyyMMDD'),
				toYmd: moment(startOfToday()).format('yyyyMMDD')
			})
		).then(action => {
			const data = action.payload;
			if (data && data.list) {
				dispatch(showMessage({ message: `총 ${data.list.length}건이 조회되었습니다.` }));
			}
		});
	}, [dispatch, uutasUser.partCd, vhDeptCode]);

	// 2. 데이터 필터
	useEffect(() => {
		setGrdData(vhd0050MstList);
	}, [vhd0050MstList]);

	// 그리드 생성 콜백
	function onSheetLoad(sheet) {
		setSheetObj(sheet);
	}

	// 그리드 엑셀 다운로드
	function handleBtnDownExcelClick() {
		return {
			/*
			 * Excel Config
			 */
		};
	}

	return (
		<div className="flex flex-col w-full">
			<UutasToolBar
				title="운행기록통계"
				variant="subtitle1"
				sheet={sheetObj}
				onBtnDownExcelClick={handleBtnDownExcelClick} // Excel Config 반환
			/>

			<KtngIbSheet
				// [필수 속성]
				sheetId={sheetId}
				options={sheetOptions}
				data={grdData}
				onLoad={onSheetLoad}
				style={{ height: '98%' }} // 그리드 초기 높이 설정시에는 style만 적용됨
			/>
		</div>
	);
};

export default VHD0050Grd1;
