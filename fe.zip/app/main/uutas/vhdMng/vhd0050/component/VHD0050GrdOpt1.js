const options = {
	Cfg: {
		CanSelect: true,
		SelectingCells: 0,
		CanEdit: 0,
		HeaderMerge: 2,
		CustomScroll: 1
	},
	Def: {
		// Col: { RelWidth: 1 }
	},
	Cols: [
		{
			Header: ['기본정보', '사번'],
			Name: 'empNo',
			Type: 'Text',
			Align: 'Center',
			MinWidth: 100,
			CanEdit: 0
		},
		{
			Header: ['기본정보', '소속기관'],
			Name: 'orgNm',
			Type: 'Text',
			Align: 'Center',
			MinWidth: 150,
			CanEdit: 0
		},
		{
			Header: ['기본정보', '성명'],
			Name: 'empNm',
			Type: 'Text',
			Align: 'Center',
			MinWidth: 150,
			CanEdit: 0
		},
		{
			Header: ['운행통계', '누적 총근무시간'],
			Name: 'workTm',
			Type: 'Text',
			Align: 'Center',
			MinWidth: 150,
			CanEdit: 0,
			RelWidth: 1
		},
		{
			Header: ['운행통계', '누적 실운행시간'],
			Name: 'realRunTm',
			Type: 'Text',
			Align: 'Center',
			MinWidth: 150,
			CanEdit: 0,
			RelWidth: 1
		},
		{
			Header: ['운행통계', '누적 실대기시간'],
			Name: 'standbyTm',
			Type: 'Text',
			Align: 'Center',
			MinWidth: 150,
			CanEdit: 0,
			RelWidth: 1
		},
		{
			Header: ['운행통계', '누적 주행거리(km)'],
			Name: 'totRunKm',
			Type: 'Text',
			Align: 'Center',
			MinWidth: 150,
			CanEdit: 0,
			RelWidth: 1
		},
		{
			Header: ['기타근무기록', '중식(구내식당) 이용일수'],
			Name: 'cafeteriaCnt',
			Type: 'Text',
			Align: 'Center',
			MinWidth: 150,
			CanEdit: 0,
			RelWidth: 1
		},
		{
			Header: ['기타근무기록', '외부숙박 이용일수'],
			Name: 'outlodgCnt',
			Type: 'Text',
			Align: 'Center',
			MinWidth: 150,
			CanEdit: 0,
			RelWidth: 1
		}
	]
};

export default options;
