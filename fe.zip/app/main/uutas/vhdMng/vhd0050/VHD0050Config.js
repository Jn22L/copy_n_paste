import VHD0050Page from './VHD0050Page';

const VHD0050Config = {
	routes: [
		{
			path: '/vhdMng/vhd0050',
			component: VHD0050Page
		}
	]
};

export default VHD0050Config;
