import VHD0020Page from './VHD0020Page';

// `메뉴경로` - `화면` 맵핑 정보를 가진 Config는 파일명 대문자로 시작
const VHD0020Config = {
	routes: [
		{
			path: '/vhdMng/vhd0020',
			component: VHD0020Page
		}
	]
};

export default VHD0020Config;
