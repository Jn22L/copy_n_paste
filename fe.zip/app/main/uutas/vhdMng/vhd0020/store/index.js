import { combineReducers } from 'redux';
import vhd0020Mst from './vhd0020MstSlice';

const reducer = combineReducers({
	vhd0020Mst
});

export default reducer;
