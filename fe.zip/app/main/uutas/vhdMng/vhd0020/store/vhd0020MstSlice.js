import { createSlice, createAsyncThunk, createEntityAdapter } from '@reduxjs/toolkit';
import KtngUtils from '@ktng/utils';
import vhd0020Service from 'app/services/vhd0020Service';
import moment from 'moment';

export const getVhd0020s = createAsyncThunk(
	'vhd0020/vhd0020Mst/getVhd0020s',
	async ({ vhclDeptCd, fromYmd, toYmd, chiefDeptCd, driverNo, vhclNo }, { dispatch, rejectWithValue }) => {
		try {
			const data = await vhd0020Service.selectVhd0020List(
				vhclDeptCd,
				fromYmd,
				toYmd,
				chiefDeptCd,
				driverNo,
				vhclNo
			);
			return {
				list: data.list,
				params: {
					vhclDeptCd,
					fromYmd,
					toYmd,
					chiefDeptCd,
					driverNo,
					vhclNo
				}
			};
		} catch (err) {
			throw KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

const vhd0020Adapter = createEntityAdapter({
	selectId: vhd0020 => vhd0020.assignNo
});

export const { selectAll: selectVhd0020s, selectById: selectVhd0020ById } = vhd0020Adapter.getSelectors(
	state => state.vhd0020.vhd0020Mst
);

const initialState = {
	params: {
		vhclDeptCd: '',
		fromYmd: moment().add(-1, 'month').format('yyyyMMDD'),
		toYmd: moment().format('yyyyMMDD'),
		chiefDeptCd: '',
		driverNo: '',
		vhclNo: ''
	},
	filters: {
		fromYmd: '',
		toYmd: ''
	},
	loading: false
};

const vhd0020MstSlice = createSlice({
	name: 'vhd0020/vhd0020Mst',
	initialState: vhd0020Adapter.getInitialState(initialState),
	reducers: {
		changeVhd0020Filter: (state, action) => {
			state.filters = {
				...state.filters,
				...action.payload
			};
		},
		clearVhd0020Filter: state => {
			state.filters = initialState.filters;
		}
	},
	extraReducers: {
		[getVhd0020s.pending]: state => {
			state.loading = true;
		},
		[getVhd0020s.fulfilled]: (state, action) => {
			const { list, params } = action.payload;
			vhd0020Adapter.setAll(state, list);
			state.params = params;
			state.loading = false;
		},
		[getVhd0020s.rejected]: state => {
			state.loading = false;
		}
	}
});

export const { changeVhd0020Filter, clearVhd0020Filter } = vhd0020MstSlice.actions;
export default vhd0020MstSlice.reducer;
