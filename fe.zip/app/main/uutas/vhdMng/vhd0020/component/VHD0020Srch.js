import { useCmmCodeLoadEffect } from '@ktng/hooks';
import React, { useState, useRef, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { MenuItem, Select } from '@material-ui/core';
import { KeyboardDatePicker } from '@material-ui/pickers';
import { UutasToolBar, UutasForm } from '@ktng/uutas';
import KtngUtils from '@ktng/utils';
import moment from 'moment';
import { showMessage } from 'app/store/fuse/messageSlice';
import { getVhd0020s } from '../store/vhd0020MstSlice';
import DeptPicker from 'app/main/popup/DeptPicker';
import DriverPicker from 'app/main/popup/DriverPicker';
import VehiclePicker from 'app/main/popup/VehiclePicker';

const formSchema = [
	// row 1
	[
		// col 1
		{
			id: 'vhclDeptCd',
			label: '부서코드',
			width: 400,
			align: 'center',
			required: false
		},
		// col 2
		{
			id: 'fromToYmd',
			label: '출발기간',
			width: 400,
			align: 'center',
			required: true
		},
		// col 3
		{
			id: 'dept',
			label: '사용부서',
			width: 400,
			align: 'center',
			required: false
		}
	],
	// row 2
	[
		// col 2
		{
			id: 'driver',
			label: '운전원',
			width: 400,
			align: 'center',
			required: false
		},
		{
			id: 'vhclNo',
			label: '차량번호',
			width: 400,
			align: 'center',
			required: false
		}
	]
];

const VHD0020Srch = () => {
	const dispatch = useDispatch();

	// 입력된 값의 유효성검사를 하기위해 `useRef`로 폼입력컨트롤의 DOM에 접근한다
	const srchRef = useRef();

	const { uutasUser, vhclDeptCode, vhd0020MstParams } = useSelector(({ auth, ktng, vhd0020 }) => ({
		uutasUser: auth.user.uutasUser || {},
		vhclDeptCode: ktng.code.VH_DEPT,
		vhd0020MstParams: vhd0020.vhd0020Mst.params
	}));

	const [expanded, setExpanded] = useState(true);

	// 폼 입력값
	const [reqCodes] = useState([{ commCodeChk: 'VH_DEPT' }]); // 불러올 공통코드 리스트
	const [vhclDeptCd, setVhclDeptCd] = useState(''); // 배차부서
	const [dept, setDept] = useState(''); // 사용부서
	const [fromYmd, setFromYmd] = useState(moment(vhd0020MstParams.fromYmd).format('yyyy.MM.DD')); // 출발 시작일
	const [toYmd, setToYmd] = useState(moment(vhd0020MstParams.toYmd).format('yyyy.MM.DD')); // 출발 종료일
	const [vehicle, setVehicle] = useState({});
	const [driver, setDriver] = useState({});

	// 공통코드 리스트 불러오기 (이미 store에 있으면 요청안함)
	useCmmCodeLoadEffect(() => {}, [reqCodes]);

	// VH_DEPT_ALL 공통코드에 사용자의 부서코드가 포함되어 있는지 확인 후 상태값 셋팅
	useEffect(() => {
		const isValidVhclDeptCd = KtngUtils.cmmCodeToName('VH_DEPT', uutasUser.partCd) !== null;
		if (isValidVhclDeptCd) {
			setVhclDeptCd(uutasUser.partCd);
		} else {
			if (vhclDeptCode && vhclDeptCode.length > 0) {
				setVhclDeptCd(vhclDeptCode[0].commCode);
			}
		}
	}, [uutasUser.partCd, vhclDeptCode]);

	function onBtnSearchClick() {
		const _vhclNo = vehicle.vhclNo || '';
		const _orgCd = dept.orgCd || '';
		const _driverNo = driver.driverNo || '';

		// 조회기간 필수값 체크
		if (!fromYmd || !toYmd) {
			dispatch(showMessage({ message: '출발기간을 입력해주세요.', variant: 'error' }));
			return false;
		}

		const _fromYmd = fromYmd !== '' ? moment(fromYmd).format('yyyyMMDD') : '';
		const _toYmd = toYmd !== '' ? moment(toYmd).format('yyyyMMDD') : '';

		const validationComps = [
			{ key: '조회시작', value: _fromYmd, type: 'text', required: false, maxLength: 8 },
			{ key: '조회종료', value: _toYmd, type: 'text', required: false, maxLength: 8 }
		];

		if (KtngUtils.validationComps(validationComps, dispatch, srchRef)) {
			// 변경된 검색조건 으로 조회
			dispatch(
				getVhd0020s({
					vhclDeptCd,
					fromYmd: _fromYmd,
					toYmd: _toYmd,
					chiefDeptCd: _orgCd,
					driverNo: _driverNo,
					vhclNo: _vhclNo
				})
			).then(action => {
				const data = action.payload;
				if (data && data.list) {
					dispatch(showMessage({ message: `총 ${data.list.length}건이 조회되었습니다.` }));
				}
			}); // DB 에서 조회
		}
	}

	// 검사시작일자 변경 저장
	const onChangeFromYmd = date => {
		if (moment(date).isValid() && moment(toYmd).isValid() && moment(date).isAfter(toYmd)) {
			dispatch(showMessage({ message: '시작일자는 종료일자보다 클 수 없습니다.', variant: 'error' }));
			return;
		}
		setFromYmd(date);
	};

	// 검사종료일자 변경 저장
	const onChangeToYmd = date => {
		if (moment(fromYmd).isValid() && moment(date).isValid() && moment(fromYmd).isAfter(date)) {
			dispatch(showMessage({ message: '종료일자는 시작일자보다 작을 수 없습니다.', variant: 'error' }));
			return;
		}
		setToYmd(date);
	};

	return (
		<>
			{/* 검색조건 툴바 */}
			<UutasToolBar onBtnSearchClick={onBtnSearchClick} expanded={expanded} onBtnToggleClick={setExpanded} />

			{/* 검색조건 입력폼 */}
			<UutasForm
				srchRef={srchRef}
				expanded={expanded}
				schema={formSchema}
				// 부서코드
				vhclDeptCd={
					<Select
						className="flex flex-1 px-8"
						label="배차부서"
						fullWidth
						value={vhclDeptCd}
						onChange={e => {
							setVhclDeptCd(e.target.value);
						}}
					>
						{/* <MenuItem value="ALL">전체</MenuItem> */}
						{vhclDeptCode &&
							vhclDeptCode.map((vhclDept, key) => (
								<MenuItem key={key} value={vhclDept.commCode}>
									{vhclDept.commCodeName}
								</MenuItem>
							))}
					</Select>
				}
				// 출발기간
				fromToYmd={
					<div className="px-8">
						<KeyboardDatePicker
							className="w-136"
							format="yyyy.MM.dd"
							value={fromYmd}
							onChange={dateTime => onChangeFromYmd(dateTime)}
						/>
						<div className="inline ml-16 mr-16">~</div>
						<KeyboardDatePicker
							className="w-136"
							format="yyyy.MM.dd"
							value={toYmd}
							onChange={dateTime => onChangeToYmd(dateTime)}
						/>
					</div>
				}
				//사용부서
				dept={
					<DeptPicker
						onChange={data => setDept(data)}
						views={['orgCd', 'orgNm']}
						disabledViews={['orgNm']} // 리스트에 있는 입력뷰를 disabled 시킴
					/>
				}
				//운전원
				driver={
					<DriverPicker
						onChange={data => setDriver(data)}
						views={['driverNo', 'driverNm']}
						disabledViews={['driverNm']} // 리스트에 있는 입력뷰를 disabled 시킴
					/>
				}
				// 차량번호
				vhclNo={
					<>
						<VehiclePicker
							onChange={data => setVehicle(data)}
							views={['vhclNo', 'vhclNm']}
							// disabledViews={['vhclNm']} // 리스트에 있는 입력뷰를 disabled 시킴
						/>
					</>
				}
			/>
		</>
	);
};

export default VHD0020Srch;
