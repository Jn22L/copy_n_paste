import VHB0040Page from './VHB0040Page';

// `메뉴경로` - `화면` 맵핑 정보를 가진 Config는 파일명 대문자로 시작
const VHB0040Config = {
	routes: [
		{
			path: '/vhbMng/vhb0040',
			component: VHB0040Page
		}
	]
};

export default VHB0040Config;
