import { createSlice, createAsyncThunk, createEntityAdapter } from '@reduxjs/toolkit';
import KtngUtils from '@ktng/utils';
import vhb0040Service from 'app/services/vhb0040Service';

export const getVhb0040MstList = createAsyncThunk(
	'vhb0040/vhb0040Mst/getVhb0040MstList',
	async ({ vhDeptCd, vhYyyymm }, { dispatch, rejectWithValue }) => {
		try {
			const data = await vhb0040Service.selectVhb0040MstList(vhDeptCd, vhYyyymm);
			return {
				list: data.list,
				params: {
					vhDeptCd,
					vhYyyymm
				}
			};
		} catch (err) {
			throw KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

const vhb0040MstAdapter = createEntityAdapter({
	selectId: vhb0040 => vhb0040.ymd
});

export const { selectAll: selectVhb0040Msts, selectById: selectVhb0040MstById } = vhb0040MstAdapter.getSelectors(
	state => state.vhb0040.vhb0040Mst
);

const initialState = {
	params: {
		vhDeptCd: '',
		vhYyyymm: ''
	},
	filters: {
		vhDeptCd: '',
		vhYyyymm: ''
	},
	loading: false
};

const vhb0040MstSlice = createSlice({
	name: 'vhb0040/vhb0040Mst',
	initialState: vhb0040MstAdapter.getInitialState(initialState),
	reducers: {
		changeVhb0040MstsFilter: (state, action) => {
			state.filters = {
				...state.filters,
				...action.payload
			};
		},
		clearVhb0040MstsFilter: state => {
			state.filters = initialState.filters;
		}
	},
	extraReducers: {
		[getVhb0040MstList.pending]: state => {
			state.loading = true;
		},
		[getVhb0040MstList.fulfilled]: (state, action) => {
			const { list, params } = action.payload;
			vhb0040MstAdapter.setAll(state, list);
			state.params = params;
			state.loading = false;
		},
		[getVhb0040MstList.rejected]: state => {
			state.loading = false;
		}
	}
});

export const { changeVhb0040MstsFilter, clearVhb0040MstsFilter } = vhb0040MstSlice.actions;

export default vhb0040MstSlice.reducer;
