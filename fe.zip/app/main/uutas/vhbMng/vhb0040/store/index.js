import { combineReducers } from 'redux';
import vhb0040Mst from './vhb0040MstSlice';

const reducer = combineReducers({
	vhb0040Mst
});

export default reducer;
