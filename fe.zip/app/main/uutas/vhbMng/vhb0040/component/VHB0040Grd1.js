import KtngIbSheet from '@ktng/core/KtngIbSheet';
import KtngUtils from '@ktng/utils';
import { UutasToolBar } from '@ktng/uutas';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { selectVhb0040Msts } from '../store/vhb0040MstSlice';
import sheetOptions from './VHB0040GrdOpt1';

const sheetId = KtngUtils.getUid('vhb0040-grd1');

const VHB0040Grd1 = () => {
	const dispatch = useDispatch();
	const vhb0040MstList = useSelector(selectVhb0040Msts);

	const [sheetObj, setSheetObj] = useState();
	const [grdData, setGrdData] = useState([]);

	useEffect(() => {
		setGrdData(vhb0040MstList);
		// 첫번째 항목으로, 하단 grid 조회
		// if (vhb0040MstList?.length > 0) {
		// 	dispatch(getVhb0040SubList({ applyNo: vhb0040MstList[0].applyNo }));
		// } else {
		// 	dispatch(getVhb0040SubList({ applyNo: '' }));
		// }
		// eslint-disable-next-line
	}, [vhb0040MstList]);

	// 그리드 생성 콜백
	function onSheetLoad(sheet) {
		setSheetObj(sheet);
	}

	// 그리드 행 선택
	function onSheetClick({ sheet, row, col }) {
		//if (row.rowStatus !== 'N') return;
		// const applyNo = sheet.getValue(row, 'applyNo');
		// dispatch(getVhb0030SubList({ applyNo })).then(action => {
		// 	const data = action.payload;
		// 	if (data && data.list) {
		// 		//dispatch(showMessage({ message: `총 ${data.list.length}건이 조회되었습니다.` }));
		// 	}
		// });
	}

	return (
		<div className="flex flex-col w-full">
			<UutasToolBar title="배차현황캘린더" variant="subtitle1" sheet={sheetObj} />

			<KtngIbSheet
				// [필수 속성]
				sheetId={sheetId}
				options={sheetOptions}
				data={grdData}
				// [선택 속성]
				onLoad={onSheetLoad} // 생성된 sheet 객체 바인딩 및 공통코드 로드 수행
				onAfterClick={onSheetClick} // 내부공통기능 수행 후 `onSheetClick` 콜백이 호출됨
				style={{ height: '98%' }} // 그리드 초기 높이 설정시에는 style만 적용됨
			/>
		</div>
	);
};

export default VHB0040Grd1;
