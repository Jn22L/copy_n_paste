import React, { useState, useRef, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { UutasToolBar, UutasForm } from '@ktng/uutas';
import KtngUtils from '@ktng/utils';
import { getVhb0040MstList } from '../store/vhb0040MstSlice';
import { MenuItem, Select } from '@material-ui/core';
import { KeyboardDatePicker } from '@material-ui/pickers';
import { format, isValid } from 'date-fns';
import { useCmmCodeLoadEffect } from '@ktng/hooks';

const formSchema = [
	// row 1
	[
		// col 1
		{
			id: 'vhclDeptCd',
			label: '배차부서',
			width: 400,
			align: 'center',
			required: false
		},
		// col 2
		{
			id: 'vhYyyymm',
			label: '차량출발년월',
			width: 150,
			align: 'center',
			required: true
		}
	]
];

const VHZ3030Srch = () => {
	const dispatch = useDispatch();

	// 입력된 값의 유효성검사를 하기위해 `useRef`로 폼입력컨트롤의 DOM에 접근한다
	const srchRef = useRef();

	const { uutasUser, vhclDeptCode, vhb0040MstParams } = useSelector(({ auth, ktng, vhb0040 }) => ({
		uutasUser: auth.user.uutasUser || {},
		vhclDeptCode: ktng.code.VH_DEPT,
		vhb0040MstParams: vhb0040.vhb0040Mst.params
	}));

	const [expanded, setExpanded] = useState(true);

	// 폼 입력값
	const [reqCodes] = useState([{ commCodeChk: 'VH_DEPT' }]); // 불러올 공통코드 리스트
	const [vhclDeptCd, setVhclDeptCd] = useState(uutasUser.partCd); // 배차부서
	const [vhYyyymm, setVhYyyymm] = useState(new Date());

	// 공통코드 리스트 불러오기 (이미 store에 있으면 요청안함)
	useCmmCodeLoadEffect(() => {}, [reqCodes]);

	// VH_DEPT_ALL 공통코드에 사용자의 부서코드가 포함되어 있는지 확인 후 상태값 셋팅
	useEffect(() => {
		const isValidVhclDeptCd = KtngUtils.cmmCodeToName('VH_DEPT', uutasUser.partCd) !== null;
		if (isValidVhclDeptCd) {
			setVhclDeptCd(uutasUser.partCd);
		} else {
			if (vhclDeptCode && vhclDeptCode.length > 0) {
				setVhclDeptCd(vhclDeptCode[0].commCode);
			}
		}
	}, [uutasUser.partCd, vhclDeptCode]);

	// 데이터 로드
	useEffect(() => {
		onBtnSearchClick();
		// eslint-disable-next-line
	}, []);

	function onBtnSearchClick() {
		const _vhYyyymm = isValid(vhYyyymm) ? format(vhYyyymm, 'yyyyMM') : '';

		const validationComps = [
			{ key: '차량출발년월', value: _vhYyyymm, type: 'text', required: true, minLength: 6, maxLength: 6 }
		];

		if (KtngUtils.validationComps(validationComps, dispatch, srchRef)) {
			// 변경된 검색조건 으로 조회
			dispatch(getVhb0040MstList({ vhDeptCd: vhclDeptCd, vhYyyymm: _vhYyyymm })).then(action => {
				//const data = action.payload;
			}); // DB 에서 조회
		}
	}

	return (
		<>
			{/* 검색조건 툴바 */}
			<UutasToolBar onBtnSearchClick={onBtnSearchClick} expanded={expanded} onBtnToggleClick={setExpanded} />

			{/* 검색조건 입력폼 */}
			<UutasForm
				srchRef={srchRef}
				expanded={expanded}
				schema={formSchema}
				// 배차부서
				vhclDeptCd={
					<Select
						className="flex flex-1 px-8"
						label="배차부서"
						fullWidth
						value={vhclDeptCd}
						onChange={e => {
							setVhclDeptCd(e.target.value);
						}}
					>
						{/* <MenuItem value="ALL">전체</MenuItem> */}
						{vhclDeptCode &&
							vhclDeptCode.map((vhclDept, key) => (
								<MenuItem key={key} value={vhclDept.commCode}>
									{vhclDept.commCodeName}
								</MenuItem>
							))}
					</Select>
				}
				// 차량출발년월
				vhYyyymm={
					<KeyboardDatePicker
						className="w-128"
						views={['year', 'month']}
						format="yyyy.MM"
						value={vhYyyymm}
						onChange={date => setVhYyyymm(date)}
						onKeyUp={e => {
							if (e.key === 'Enter') {
								onBtnSearchClick();
							}
						}}
						error={false}
						helperText=""
					/>
				}
			/>
		</>
	);
};

export default VHZ3030Srch;
