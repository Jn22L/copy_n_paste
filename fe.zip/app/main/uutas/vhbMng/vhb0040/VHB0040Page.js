// **************************************************************************
// 파    일    명   : VHB0040Page.js
// 업무      분류   :
// 업    무    명   : 배차현황캘린더
// 프로그램   내용   :
// 기          타   :
// ==========================================================================
// 작    성    자   :
// 작    성    일   : 2022.01.07
// 최종    수정일   :
// 변 경    이 력   :
// **************************************************************************

import React from 'react';
import { useSelector } from 'react-redux';
import withReducer from 'app/store/withReducer';
import { UutasPageSimple } from '@ktng/uutas';
import { VHB0040Srch, VHB0040Grd1 } from './component';
import reducer from './store';

// /vhbMng/vhb0040
const VHB0040Page = () => {
	const { dataLoading } = useSelector(({ vhb0040 }) => ({
		dataLoading: vhb0040.vhb0040Mst.loading
	}));

	return (
		<UutasPageSimple title="배차현황캘린더" loading={dataLoading}>
			{/* 검색조건 */}
			<VHB0040Srch />

			{/* 상단 grid */}
			<div className="flex flex-1">
				<VHB0040Grd1 />
			</div>
		</UutasPageSimple>
	);
};

export default withReducer('vhb0040', reducer)(VHB0040Page);
