/*
 * 대메뉴 `기준정보`에 대한 메뉴경로 파일
 */

import VHB0010Config from './vhb0010/VHB0010Config';
import VHB0020Config from './vhb0020/VHB0020Config';
import VHB0030Config from './vhb0030/VHB0030Config';
import VHB0040Config from './vhb0040/VHB0040Config';

// 리스트로 된 Config는 파일명 소문자로 시작
const vhbMngConfig = [
	VHB0010Config, // 게시판
	VHB0020Config, // 배차신청등록
	VHB0030Config, // 배차신청현황
	VHB0040Config // 배차현황캘린더
];

export default vhbMngConfig;
