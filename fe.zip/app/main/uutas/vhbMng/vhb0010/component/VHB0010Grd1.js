/*
 * VHA0040Grd 그리드 컴포넌트의 파일
 */

import KtngIbSheet from '@ktng/core/KtngIbSheet';
import KtngUtils from '@ktng/utils';
import { UutasToolBar } from '@ktng/uutas';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { format } from 'date-fns';
import _ from '@lodash';
import { showMessage } from 'app/store/fuse/messageSlice';
import { selectVhb0010MstList, getVhb0010MstList } from '../store/vhb0010MstSlice';
import { createVhb0010SubOne, getVhb0010SubOne } from '../store/vhb0010SubSlice';
import sheetOptions from './VHB0010GrdOpt1'; // 그리드 설정파일

const sheetId = KtngUtils.getUid('vhb0010-grd1');

const initialForm = {
	boardId: '',
	boardContent: '',
	regDate: format(new Date(), 'yyyyMMdd')
	// boardTitle: '',
	// startDate: format(new Date(), 'yyyyMMdd'),
	// endDate: format(addMonths(new Date(), 1), 'yyyyMMdd'),
	// viewNum: '0',
};

const VHB0010Grd1 = () => {
	const dispatch = useDispatch();

	/*
	 * ###################################################################################
	 * #### [Redux 설명 6 (끝)] Store에 저장된 데이터 가져오기2 (EntityAdapter) #############
	 * ###################################################################################
	 *
	 * > useSelector: Store에 저장된 데이터를 가져올 수 있다.
	 */
	// const vha0040MstList = useSelector(
	// 	/*
	// 	 * 직접 매핑함수를 작성하지 않고,
	// 	 * EntityAdapter를 사용하여 xxxxSlice.js 파일에 만들어둔 매핑함수를 사용하였다.
	// 	 *
	// 	 * > selectVha0040MstList: rootState객체로부터
	// 	 *   `vha0040MstList` (하위Store)에 저장된 데이터List를 꺼내주는 함수
	// 	 */
	// 	rootState => {
	// 		return selectVha0040MstList(rootState); // 리스트([...]) 형식으로 반환
	// 	}
	// );
	// ※ 간략히 재작성하면,
	const vhb0010MstList = useSelector(selectVhb0010MstList);

	const { vhb0010SubOne, uutasUser, vhDeptCode } = useSelector(({ vhb0010, auth, ktng }) => ({
		vhb0010SubOne: vhb0010.vhb0010Sub.data,
		uutasUser: auth.user.uutasUser || {},
		vhDeptCode: ktng.code.VH_DEPT_ALL // 불러온 공통코드 리스트
	}));

	const [sheetObj, setSheetObj] = useState();
	const [grdData, setGrdData] = useState([]);

	// 1. 데이터 조회
	useEffect(() => {
		let defaultVhclDeptCd = null;
		const isValidVhclDeptCd = KtngUtils.cmmCodeToName('VH_DEPT_ALL', uutasUser.partCd) !== null;
		if (isValidVhclDeptCd) {
			defaultVhclDeptCd = uutasUser.partCd;
		}

		/*
		 * ###################################################################################
		 * #### [Redux 설명 4] Reducer 호출하기 ###############################################
		 * ###################################################################################
		 *
		 * > dispatch: Reducer를 호출한다.
		 */
		dispatch(
			/* 호출할 Reducer */
			getVhb0010MstList({
				// Reducer에 필요한 파라미터를 key-value 객체로 전달함
				vhclDeptCd: defaultVhclDeptCd,
				sregYear: format(new Date(), 'yyyy')
			})
		).then(
			/*
			 * [필수아님]
			 * 호출한 Reducer가 createAsyncThunk로 생성한 비동기 Reducer인 경우,
			 * dispatch(...).then(...)
			 * 와 같이 `then()`을 붙여 `fulfilled`, `rejected` 시점의 Reducer들을 실행한 이후에 동작할
			 * 콜백함수를 작성할 수 있다.
			 */
			action => {
				const data = action.payload; // 비동기함수에서 반환한 데이터를 가져옴
				if (data && data.list) {
					if (data.list.length > 0) {
						// 첫번째 항목으로 Sub 데이터 조회
						dispatch(getVhb0010SubOne({ boardId: data.list[0].boardId }));
					}
					// 반환된 데이터에 데이터List가 존재하는 경우, 몇 건 조회했는지 메시지를 띄움
					dispatch(showMessage({ message: `총 ${data.list.length}건이 조회되었습니다.` }));
				}
			}
		);
	}, [dispatch, uutasUser.partCd, vhDeptCode]);

	// 2. 데이터 필터
	useEffect(() => {
		setGrdData(vhb0010MstList);
	}, [vhb0010MstList]);

	/* KtngIbSheet 이벤트 콜백 */

	// 그리드 생성 콜백
	function onSheetLoad(sheet) {
		setSheetObj(sheet);

		// 그리드에 공통코드 설정
		// if (driverTyCode) {
		// 	const { enumKeys, enumVals } = KtngIbSheetUtils.cvtCodeToIbSheetEnumType(driverTyCode);
		// 	sheet.setAttribute(null, 'driverTy', 'EnumKeys', enumKeys, true);
		// 	sheet.setAttribute(null, 'driverTy', 'Enum', enumVals, true);
		// }

		// 이벤트 등록
		// onRowAdd, onAfterClick, onAfterChange 3개 이벤트는 `KtngIbSheet` 컴포넌트 속성에 콜백함수를 넣어 추가
		// 3개 이벤트를 제외한 이벤트를 등록할 때 이곳에 작성
		// sheet.bind('onDataLoad', onSheetDataLoad);
	}

	function onSheetClick({ sheet, row, col }) {
		const boardId = sheet.getValue(row, 'boardId');
		if (boardId) {
			if (boardId !== vhb0010SubOne.boardId) {
				// id가 존재하는 행
				dispatch(getVhb0010SubOne({ boardId })).then(action => {
					const data = action.payload;
					if (data && data.data) {
						const { viewNum } = data.data;
						sheet.setValue(row, 'viewNum', viewNum);
					}
				});
			}
		} else {
			// id가 없는 새로운 행
			dispatch(
				createVhb0010SubOne({
					// 기본값
					...initialForm,
					// 사용자 폼 입력값
					..._.pick(row, ['boardTitle', 'viewNum']),
					startDate: format(row.startDate, 'yyyyMMdd'),
					endDate: format(row.endDate, 'yyyyMMdd')
				})
			);
		}
	}

	return (
		<div className="flex flex-col w-full">
			{/* 그리드 툴바 */}
			<UutasToolBar
				title="게시물 조회" // ToolBar에 표시할 헤더 문자열
				variant="subtitle1" // `title` 문자열 스타일종류
				sheet={sheetObj} // IBSheet Object (onBtnAddClick, onBtnDownExcelClick 콜백을 사용하는 경우 필수)
				/*
				 * onBtnAddClick
				 * - `onBtnAddClick` 속성에 콜백함수를 넘겨주면 ToolBar 컴포넌트에 `추가` 버튼이 생김
				 * - `추가` 버튼을 클릭하면 넘겨준 콜백함수가 실행되고,
				 *   콜백함수에서 그리드에 추가할 행 데이터를 반환하면 그리드에 행이 추가됨.
				 */
				// onBtnAddClick={handleBtnAddClick}
				/*
				 * onBtnDownExcelClick
				 * - `onBtnDownExcelClick` 속성에 콜백함수를 넘겨주면 ToolBar 컴포넌트에 `엑셀다운로드` 버튼이 생김
				 * - `엑셀다운로드` 버튼을 클릭하면 넘겨준 콜백함수가 실행되고,
				 *   콜백함수에서 엑셀 설정 key-value 객체를 넘겨주면, 설정을 반영하여 그리드 내용을 엑셀파일로 다운로드함.
				 */
				//onBtnDownExcelClick={handleBtnDownExcelClick}
			/>

			{/* 그리드 */}
			<KtngIbSheet
				// [필수 속성]
				sheetId={sheetId} // 그리드를 식별할 수 있는 ID 문자열
				options={sheetOptions} // 그리드 설정
				data={grdData} // 데이터List
				// [선택 속성]
				// - 내부에서 그리드에 사용할 공통코드 로드
				// codes={[
				// 	{ commCodeChk: 'VH_DEPT_ALL' } // 배차부서 (배차+지정차량)
				// ]}
				// - 이벤트
				onLoad={onSheetLoad} // 생성된 sheet 객체 바인딩 및 배차부서 로드 수행
				//   ※ 아래 2개 외 필요한 이벤트는 `onSheetLoad`에서 직접 바인딩할 것
				onAfterClick={onSheetClick} // 내부공통기능 수행 후 `onSheetClick` 콜백이 호출됨
				// onAfterChange={onSheetChange} // 내부공통기능 수행 후 `onSheetChange` 콜백이 호출됨
				// - 스타일 속성
				// className="" // tailwind 스타일 적용 가능
				style={{ height: '98%' }} // 그리드 초기 높이 설정시에는 style만 적용됨
			/>
		</div>
	);
};

export default VHB0010Grd1;
