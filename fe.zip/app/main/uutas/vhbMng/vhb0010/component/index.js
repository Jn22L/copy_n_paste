/*
 * component 폴더 내의 컴포넌트들을 import하여 한번에 export하는 index 파일
 * (컴포넌트들을 indexing 해주는 파일)
 *
 * 장점)
 * 1. 한번에 여러 컴포넌트 import 시 한 줄로 작성할 수 있어 소스 라인 수를 줄일 수 있다.
 *    Ex) import { VHA0040Srch, VHA0040Grd1 } from './component';
 *
 * 2. 다른 파일에서 1번과 같이 index.js를 통해 import한 경우,
 *    import한 컴포넌트를 `Ctrl + 클릭`하면 해당 컴포넌트의 소스파일로 바로 이동가능하다.
 */

import VHB0010Srch from './VHB0010Srch';
import VHB0010Grd1 from './VHB0010Grd1';
import VHB0010Frm1 from './VHB0010Frm1';

export { VHB0010Srch, VHB0010Grd1, VHB0010Frm1 };
