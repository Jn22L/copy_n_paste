/*
 * VHA0040 화면 입력폼 컴포넌트의 파일
 */

import React, { useState, useRef, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { Input, Typography } from '@material-ui/core';
import { KeyboardDatePicker } from '@material-ui/pickers';
import { UutasToolBar, UutasForm } from '@ktng/uutas';
import _ from '@lodash';
import { addMonths, format, parse } from 'date-fns';
import KtngUtils from '@ktng/utils';
import KtngTextarea from '@ktng/core/KtngTextarea';

const formSchema = [
	// row 1
	[
		// col 1
		{
			id: 'boardTitle', // 폼 입력컨트롤 식별ID
			label: '제목', // 폼 입력컨트롤의 라벨
			width: 150, // 너비
			align: 'center', // 정렬
			required: false, // 필수여부 (validation check에서 검사할지 여부)
			colSpan: 3
		},
		// col 2
		{
			id: 'boardId',
			label: '번호',
			width: 150,
			align: 'center',
			requried: false
		}
	],
	// row 2
	[
		// col 1
		{
			id: 'startDate',
			label: '시작일자',
			width: 150,
			align: 'center',
			requried: false
		},
		// col 2
		{
			id: 'endDate',
			label: '종료일자',
			width: 150,
			align: 'center',
			requried: false
		},
		// col 3
		{
			id: 'regDate',
			label: '등록일',
			width: 150,
			align: 'center',
			requried: false
		}
	],
	// row 3
	[
		// col 1
		{
			id: 'boardContent',
			label: '내용',
			width: 150,
			align: 'center',
			requried: false,
			colSpan: 5
		}
	]
];

const VHB0010Frm1 = () => {
	const { vhb0010SubOne } = useSelector(({ vhb0010 }) => ({
		vhb0010SubOne: vhb0010.vhb0010Sub.data,
		vhb0010MstParams: vhb0010.vhb0010Mst.params
	}));

	// 입력된 값의 유효성검사를 하기위해 `useRef`로 폼입력컨트롤의 DOM에 접근한다
	const srchRef = useRef();

	// 폼 입력값
	const [boardTitle, setBoardTitle] = useState('');
	const [startDate, setStartDate] = useState(new Date());
	const [endDate, setEndDate] = useState(addMonths(new Date(), 1));
	const [boardContent, setBoardContent] = useState('');

	const boardId = vhb0010SubOne.boardId || '';
	const regDate = vhb0010SubOne.regDate
		? format(parse(vhb0010SubOne.regDate, 'yyyyMMdd', new Date()), 'yyyy.MM.dd')
		: '';

	// const isChanged =
	// 	// 폼 입력값이 비어있지 않고
	// 	!_.isEmpty(form) &&
	// 	// 사용자가 입력가능한 상태값으로 비교하여 변경사항이 있으면 저장 가능
	// 	!_.isEqual(form, _.pick(vhb0010SubOne, ['boardTitle', 'startDate', 'endDate', 'boardContent']));

	useEffect(() => {
		const { startDate: _startDate, endDate: _endDate } = vhb0010SubOne;
		setBoardTitle(vhb0010SubOne.boardTitle || '');
		setStartDate(_startDate ? parse(_startDate, 'yyyyMMdd', new Date()) : new Date());
		setEndDate(_endDate ? parse(_endDate, 'yyyyMMdd', new Date()) : new Date());
		setBoardContent(vhb0010SubOne.boardContent || '');
	}, [vhb0010SubOne]);

	if (_.isEmpty(vhb0010SubOne)) {
		return null;
	}

	return (
		<>
			{/* 검색조건 툴바 */}
			<UutasToolBar
				title="상세화면"
				/*
				 * onBtnDeleteClick
				 * - `onBtnDeleteClick` 속성에 콜백함수를 넘겨주면 ToolBar 컴포넌트에 `삭제` 버튼이 생김
				 * - `삭제` 버튼을 클릭하면 넘겨준 콜백함수가 실행됨.
				 */
				//onBtnDeleteClick={onBtnDeleteClick}
				//btnDeleteDisabled={isNew}
				//onBtnSaveClick={onBtnSaveClick}
				//btnSaveDisabled={!isChanged}
				//onBtnCancelClick={() => dispatch(clearVhb0010SubOne())}
			/>

			{/* 게시물 입력폼 */}
			<UutasForm
				fullWidth
				/* 폼 입력값 validation 체크 시 DOM에 접근하기 위해 useRef 사용 */
				srchRef={srchRef}
				/* 폼 입력컨트롤의 배치 정보 */
				schema={formSchema}
				// ==== 여기부터 폼 입력컨트롤 정의 ================================
				/*
				 * Ex)
				 * formSchema에서 설정했던 id={
				 * 	   // id에 해당하는 폼 입력 컴포넌트
				 * 	   <... />
				 * }
				 */
				// 제목
				boardTitle={
					<Input
						className="flex flex-1 px-8" // CSS 스타일 지정
						placeholder="제목"
						fullWidth
						type="text"
						value={boardTitle}
						inputProps={{ minLength: 2, maxLength: 100 }} // 컴포넌트 내부의 실제 input 태그에 적용할 속성 정의
						onChange={e => setBoardTitle(e.target.value)}
						readOnly
					/>
				}
				// 번호
				boardId={<Typography className="flex flex-1 px-8">{boardId}</Typography>}
				// 시작일자
				startDate={
					<KeyboardDatePicker
						fullWidth
						format="yyyy.MM.dd"
						value={startDate}
						onChange={date => setEndDate(date)}
						inputProps={{ readOnly: true }}
						readOnly
					/>
				}
				// 종료일자
				endDate={
					<KeyboardDatePicker
						fullWidth
						format="yyyy.MM.dd"
						value={endDate}
						onChange={date => setEndDate(date)}
						inputProps={{ readOnly: true }}
						readOnly
					/>
				}
				// 등록일
				regDate={<Typography className="flex flex-1 px-8">{regDate}</Typography>}
				// 내용
				boardContent={
					<KtngTextarea
						placeholder="내용"
						value={boardContent}
						onChange={e => {
							// 최대 Byte 길이 제한
							if (KtngUtils.getStrByteLength(e.target.value) <= 2000) {
								setBoardContent(e.target.value);
							}
						}}
						inputProps={{ maxLength: 2000, readOnly: true }}
						rows={5}
					/>
				}
			/>
		</>
	);
};

export default VHB0010Frm1;
