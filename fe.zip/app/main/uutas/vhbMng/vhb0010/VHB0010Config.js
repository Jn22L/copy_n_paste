/*
 * 소메뉴 `게시판관리`에 대한 메뉴경로 파일
 */

import VHB0010Page from './VHB0010Page';

// `메뉴경로` - `화면` 맵핑 정보를 가진 Config는 파일명 대문자로 시작
const VHB0010Config = {
	routes: [
		{
			path: '/vhbMng/vhb0010', // 화면에 접근할 때 사용할 URL을 설정
			component: VHB0010Page // 접근할 화면의 컴포넌트를 설정
		}
	]
};

export default VHB0010Config;
