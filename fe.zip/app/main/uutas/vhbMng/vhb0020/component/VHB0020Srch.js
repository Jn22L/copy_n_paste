/*
 * VHB0020 화면 검색조건 컴포넌트의 파일
 */

import React, { useState, useRef } from 'react';
import { useDispatch } from 'react-redux';
import { KeyboardDatePicker } from '@material-ui/pickers';
import { isValid, format } from 'date-fns';
import { UutasToolBar, UutasForm } from '@ktng/uutas';
import KtngUtils from '@ktng/utils';
import { showMessage } from 'app/store/fuse/messageSlice';
import DeptPicker from 'app/main/popup/DeptPicker';
import { getVhb0020MstList } from '../store/vhb0020MstSlice';
import { clearVhb0020SubOne, getVhb0020SubOne } from '../store/vhb0020SubSlice';

const formSchema = [
	// row 1
	[
		// col 1
		{
			id: 'vhYyyymm',
			label: '차량출발년월',
			align: 'center',
			requried: false
		},
		// col 2
		{
			id: 'partCd',
			label: '신청부서',
			align: 'center',
			required: true
		}
	]
];

const VHB0020Srch = () => {
	const dispatch = useDispatch();

	// 입력된 값의 유효성검사를 하기위해 `useRef`로 폼입력컨트롤의 DOM에 접근한다
	const srchRef = useRef();

	const [expanded, setExpanded] = useState(true); // 검색조건 폼 컴포넌트 보이기(true)/숨기기(false)

	// 폼 입력값
	const [vhYyyymm, setVhYyyymm] = useState(new Date());
	const [partCd, setPartCd] = useState();

	function onBtnSearchClick() {
		const validationComps = [
			// 입력값의 검증할 정보 추가
			{
				key: '차량출발년월', //      [필수] 컬럼명
				value: vhYyyymm, // [필수] 입력값
				type: 'date', //      [필수] 형식 'text'|'number'|'date'
				required: false //    [선택] 필수입력 여부
			},
			{
				key: '신청부서',
				value: partCd,
				type: 'text',
				required: true
			}
		];

		if (KtngUtils.validationComps(validationComps, dispatch, srchRef)) {
			// 변경된 검색조건으로 조회
			dispatch(
				getVhb0020MstList({
					vhYyyymm: isValid(vhYyyymm) ? format(vhYyyymm, 'yyyyMM') : null,
					partCd
				})
			).then(action => {
				const data = action.payload;
				if (data && data.list) {
					if (data.list.length > 0) {
						// 첫번째 항목으로 Sub 데이터 조회
						dispatch(getVhb0020SubOne({ applyNo: data.list[0].applyNo }));
					} else {
						dispatch(clearVhb0020SubOne()); // 0건이면 하단 입력폼 닫기
					}
					dispatch(showMessage({ message: `총 ${data.list.length}건이 조회되었습니다.` }));
				}
			});
		}
	}

	return (
		<>
			{/* 검색조건 툴바 */}
			<UutasToolBar
				/*
				 * onBtnSearchClick
				 * - `onBtnSearchClick` 속성에 콜백함수를 넘겨주면 ToolBar 컴포넌트에 `조회` 버튼이 생김
				 * - `조회` 버튼을 클릭하면 넘겨준 콜백함수가 실행됨.
				 */
				onBtnSearchClick={onBtnSearchClick}
				/*
				 * onBtnToggleClick
				 * - `onBtnToggleClick` 속성에 콜백함수를 넘겨주면 ToolBar 컴포넌트에 `토글 (아이콘)` 버튼이 생김
				 * - `토글 (아이콘)` 버튼을 클릭했을 때,
				 *   보이기 상태면 true, 숨기기 상태면 false를 콜백함수의 파라미터로 넘겨줌.
				 */
				onBtnToggleClick={setExpanded}
				expanded={expanded} // true -> 토글 버튼을 '보이기' 모양으로 표시, false -> 토글 버튼 '숨기기' 모양으로 표시
			/>

			{/* 검색조건 입력폼 */}
			<UutasForm
				/* 폼 입력값 validation 체크 시 DOM에 접근하기 위해 useRef 사용 */
				srchRef={srchRef}
				/* true -> 검색조건 보이기, false -> 검색조건 숨기기 */
				expanded={expanded}
				/* 폼 입력컨트롤의 배치 정보 */
				schema={formSchema}
				// ==== 여기부터 폼 입력컨트롤 정의 ================================
				/*
				 * Ex)
				 * formSchema에서 설정했던 id={
				 * 	   // id에 해당하는 폼 입력 컴포넌트
				 * 	   <... />
				 * }
				 */
				// 차량출발년월
				vhYyyymm={
					<KeyboardDatePicker
						className="w-128"
						views={['year', 'month']}
						format="yyyy.MM"
						value={vhYyyymm}
						onChange={date => setVhYyyymm(date)}
						onKeyUp={e => {
							if (e.key === 'Enter') {
								onBtnSearchClick();
							}
						}}
						error={false}
						helperText=""
					/>
				}
				// 부서코드
				partCd={
					<DeptPicker
						symd={new Date()} // 초기값: 오늘 날짜
						orgCd={partCd}
						onChange={selected => setPartCd(selected.orgCd)}
						views={['orgCd', 'orgNm']}
					/>
				}
			/>
		</>
	);
};

export default VHB0020Srch;
