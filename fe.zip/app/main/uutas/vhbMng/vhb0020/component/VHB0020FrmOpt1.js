// prettier-ignore
const formSchema = [
	// row 1
	[
		{ id: 'vhclDeptCd', label: '배차부서', align: 'left',   required: true              },
		{ id: 'applyEmpNo', label: '신청자',   align: 'left',   required: false             },
		{ id: 'vhType',     label: '용도',     align: 'left',   required: false             }
    ],
    // row 2
	[
		{ id: 'depatureDt', label: '출발일자', align: 'center', required: true              },
		{ id: 'depatureTm', label: '출발시간', align: 'center', required: true              },
		{ id: 'usePurpose', label: '사용목적', align: 'left',   required: true              }
    ],
    // row 3
	[
		{ id: 'arrivalDt',  label: '도착일자', align: 'center', required: true               },
		{ id: 'arrivalTm',  label: '도착시간', align: 'center', required: true               },
		{ id: 'boardNo',    label: '승차인원', align: 'left',   required: true               }
    ],
    // row 4
	[
		{ id: 'chiefEmpNo', label: '사용자',   align: 'left',   required: true               },
		{ id: 'chiefParNm', label: '기관',     align: 'left',   required: false               },
		{ id: 'chiefDeptNm', label: '부서',    align: 'left',   required: false               }
    ],
    // row 5
	[
		{ id: 'chiefJobNm',  label: '직무',     align: 'left',  required: false              },
		{ id: 'chiefCellPn', label: '휴대전화', align: 'left',  required: true,  colSpan: 3  }
    ],
    // row 6
	[
		{ id: 'destination', label: '행선지',   align: 'left',  required: true               },
		{ id: 'departure',   label: '출발지',   align: 'left',  required: false               },
		{ id: 'passstop',    label: '경유지',   align: 'left',  required: false               }
    ],
    // row 7
	[   { id: 'vhEtc',       label: '비고',      align: 'left', required: false,  colSpan: 5  }      ],
    // row 8
	[   { id: 'fileTitle',   label: '일정표첨부', align: 'left',      required: false,  colSpan: 5  } ]
];

export default formSchema;
