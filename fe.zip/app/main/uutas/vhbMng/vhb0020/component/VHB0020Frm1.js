/*
 * VHB0020 화면 입력폼 컴포넌트의 파일
 */

import React, { useState, useRef, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { IconButton, Input, MenuItem, Select, Typography } from '@material-ui/core';
import KtngTextarea from '@ktng/core/KtngTextarea';
import { KeyboardDatePicker, KeyboardDateTimePicker } from '@material-ui/pickers';
import { UutasToolBar, UutasForm, UutasFileInput } from '@ktng/uutas';
import KtngUtils from '@ktng/utils';
import _ from '@lodash';
import { addHours, format, isValid, parse } from 'date-fns';
import { showMessage } from 'app/store/fuse/messageSlice';
import { useCmmCodeLoadEffect } from '@ktng/hooks';
import EmpPicker from 'app/main/popup/EmpPicker';
import { Search } from '@material-ui/icons';
import { closeDialog, openDialog } from 'app/store/fuse/dialogSlice';
import EmpPopup from 'app/main/popup/EmpPopup';
import vhb0020Service from 'app/services/vhb0020Service';
import {
	clearVhb0020SubOne,
	deleteVhb0020SubOne,
	getVhb0020SubOne,
	insertVhb0020SubOne,
	updateVhb0020SubOne
} from '../store/vhb0020SubSlice';
import { clearVhb0020MstList, getVhb0020MstList } from '../store/vhb0020MstSlice';
import formSchema from './VHB0020FrmOpt1';

// 사용자가 입력가능한 속성명 리스트
// prettier-ignore
const userInputAttrNms = ['vhclDeptCd', 'applyEmpNo', 'vhType', 'depatureDt', 'depatureTm', 'usePurpose', 'arrivalDt', 'arrivalTm', 'boardNo', 'chiefEmpNo', 'chiefParCd', 'chiefDeptCd', 'chiefJobNm', 'chiefCellPn', 'destination', 'departure', 'passstop', 'vhEtc', 'file', 'deletedFile'];

const reqCodes = [{ commCodeChk: 'VH_DEPT' }, { commCodeChk: 'VH_TYPE' }];

const VHB0020Frm1 = () => {
	const dispatch = useDispatch();

	const { vhb0020SubOne, vhb0020MstParams, vhDeptCodes, vhTypeCodes, user } = useSelector(
		({ vhb0020, ktng, auth }) => ({
			vhb0020SubOne: vhb0020.vhb0020Sub.data,
			vhb0020MstParams: vhb0020.vhb0020Mst.params,
			vhDeptCodes: ktng.code.VH_DEPT,
			vhTypeCodes: ktng.code.VH_TYPE,
			user: auth.user
		})
	);

	const srchRef = useRef(); // 입력된 값의 유효성검사를 하기위해 `useRef`로 폼입력컨트롤의 DOM에 접근한다

	const [form, setForm] = useState(); // 폼 입력값
	const [isNew, setIsNew] = useState();
	const [isChanged, setIsChanged] = useState();
	const [hasMngAuth, setHasMngAuth] = useState(); // 수정권한 보유여부

	// 1. 입력컴포넌트 초기화
	useEffect(() => {
		if (!vhb0020SubOne || !vhDeptCodes || !vhTypeCodes) return;

		// prettier-ignore
		const { applyCellPhnNo, depatureDt, depatureTm, arrivalDt, arrivalTm, chiefCellPn } = vhb0020SubOne;

		// 폼 입력값 포맷으로 변환
		const _applyCellPhnNo = applyCellPhnNo ? KtngUtils.formatTelNo(applyCellPhnNo) : '';
		const _depatureDt = depatureDt ? parse(depatureDt, 'yyyyMMdd', new Date()) : new Date();
		const _depatureTm =
			depatureDt && depatureTm ? parse(`${depatureDt}${depatureTm}`, 'yyyyMMddHHmm', new Date()) : new Date();
		const _arrivalDt = arrivalDt ? parse(arrivalDt, 'yyyyMMdd', new Date()) : new Date();
		const _arrivalTm =
			arrivalDt && arrivalTm
				? parse(`${arrivalDt}${arrivalTm}`, 'yyyyMMddHHmm', new Date())
				: addHours(new Date(), 2);
		const _chiefCellPn = chiefCellPn ? KtngUtils.formatTelNo(chiefCellPn) : '';

		setForm({
			...vhb0020SubOne,
			applyCellPhnNo: _applyCellPhnNo,
			depatureDt: _depatureDt,
			depatureTm: _depatureTm,
			arrivalDt: _arrivalDt,
			arrivalTm: _arrivalTm,
			chiefCellPn: _chiefCellPn
		});
	}, [vhb0020SubOne, vhDeptCodes, vhTypeCodes]);

	// 2. 폼 상태 변경 (새 것 여부, 변경 여부)
	useEffect(() => {
		if (!vhb0020SubOne || !form || !user.uutasUser) return;

		const { depatureDt, depatureTm, arrivalDt, arrivalTm, chiefCellPn } = form;
		const vhb0020 = {
			..._.pick(form, userInputAttrNms),
			// 변환해서 보내야할 폼 입력값
			depatureDt: isValid(depatureDt) ? format(depatureDt, 'yyyyMMdd') : null,
			depatureTm: isValid(depatureTm) ? format(depatureTm, 'HHmm') : null,
			arrivalDt: isValid(arrivalDt) ? format(arrivalDt, 'yyyyMMdd') : null,
			arrivalTm: isValid(arrivalTm) ? format(arrivalTm, 'HHmm') : null,
			chiefCellPn: chiefCellPn ? chiefCellPn.replace(/[^0-9]/g, '') : null
		};

		const _isNew = !form.applyNo;
		setIsNew(_isNew);
		setIsChanged(
			// 폼 입력값이 비어있지 않고
			!_.isEmpty(form) &&
				// 사용자가 입력가능한 상태값으로 비교하여 변경사항이 있으면 저장 가능
				userInputAttrNms.some(attrNm => {
					return (vhb0020[attrNm] || vhb0020SubOne[attrNm]) && vhb0020[attrNm] !== vhb0020SubOne[attrNm];
				})
		);

		setHasMngAuth(state => {
			if (state !== undefined) return state;

			const { applyEmpNo } = vhb0020SubOne;
			const { role = [], uutasUser = {} } = user;
			return (
				_isNew || // 1. 새로운 신청서이거나,
				!role.find(_role => _role === 'ROLE_ADMIN' || _role === 'ROLE_MNG') || // 2. 관리자나 배차담당자
				(!_.isEmpty(applyEmpNo) && applyEmpNo === uutasUser.empNo) // 3. 신청자 본인
			);
		});
	}, [form, vhb0020SubOne, user]);

	// 공통코드 리스트 불러오기 (이미 store에 있으면 요청안함)
	useCmmCodeLoadEffect(() => {}, [reqCodes]);

	function onBtnDeleteClick() {
		dispatch(deleteVhb0020SubOne({ applyNo: form.applyNo })).then(action => {
			const data = action.payload;
			if (data && data.success) {
				dispatch(showMessage({ message: '배차신청이 취소되었습니다.' }));

				dispatch(clearVhb0020SubOne());
				if (vhb0020MstParams.partCd) {
					// vhb0020MstParams: 이전에 조회했던 파라미터로 조회
					dispatch(getVhb0020MstList(vhb0020MstParams)).then(_action => {
						const _data = _action.payload; // 비동기함수에서 반환한 데이터를 가져옴
						if (_data && _data.list) {
							if (_data.list.length > 0) {
								// 첫번째 항목으로 Sub 데이터 조회
								dispatch(getVhb0020SubOne({ applyNo: _data.list[0].applyNo }));
							}
						}
					});
				} else {
					dispatch(clearVhb0020MstList());
				}
			}
		});
	}

	function onBtnSaveClick() {
		// prettier-ignore
		const {
			vhclDeptCd, applyEmpNo, vhType, depatureDt, depatureTm, usePurpose, arrivalDt, arrivalTm, boardNo, chiefEmpNo, chiefCellPn, destination, departure, passstop, vhEtc
		} = form;

		const _chiefCellPn = chiefCellPn ? chiefCellPn.replace(/[^0-9]/g, '') : '';

		// prettier-ignore
		const validationComps = [
			// 입력값의 검증할 정보 추가
			{ key: '배차부서',   value: vhclDeptCd,  type: 'text', required: true,  minByteLength: 2, maxByteLength: 6    },
			{ key: '신청자',     value: applyEmpNo,  type: 'text', required: false, minByteLength: 2, maxByteLength: 8    },
			{ key: '용도',       value: vhType,      type: 'text', required: false, maxByteLength: 8                      },
			{ key: '출발일자',   value: depatureDt,  type: 'date', required: true                                         },
			{ key: '출발시간',   value: depatureTm,  type: 'date', required: true                                         },
			{ key: '사용목적',   value: usePurpose,  type: 'text', required: true,  minByteLength: 2, maxByteLength: 50   },
			{ key: '도착일자',   value: arrivalDt,   type: 'date', required: true                                         },
			{ key: '도착시간',   value: arrivalTm,   type: 'date', required: true                                         },
			{ key: '승차인원',   value: boardNo,     type: 'text', required: true,  maxByteLength: 22                     },
			{ key: '사용자',     value: chiefEmpNo,  type: 'text', required: true,  minByteLength: 2, maxByteLength: 8    },
			{ key: '휴대전화',   value: _chiefCellPn, type: 'text', required: true,  minByteLength: 2, maxByteLength: 11   },
			{ key: '행선지',     value: destination, type: 'text', required: true,  minByteLength: 2, maxByteLength: 30   },
			{ key: '출발지',     value: departure,   type: 'text', required: false, minByteLength: 2, maxByteLength: 30   },
			{ key: '경유지',     value: passstop,    type: 'text', required: false, minByteLength: 2, maxByteLength: 30   },
			{ key: '비고',       value: vhEtc,       type: 'text', required: false, minByteLength: 2, maxByteLength: 2000 },
			// 일정표첨부: 검증필요없음
		];

		if (!KtngUtils.validationComps(validationComps, dispatch, srchRef)) return;

		if (isValid(depatureTm) && isValid(arrivalTm) && depatureTm.valueOf() > arrivalTm.valueOf()) {
			dispatch(showMessage({ message: '출발일시는 종료일시 이전이어야 합니다.', variant: 'error' }));
			return;
		}

		if (boardNo === '0') {
			dispatch(showMessage({ message: '승차인원은 1명 이상이어야 합니다.', variant: 'error' }));
			return;
		}

		const vhb0020 = {
			...vhb0020SubOne, // 기존 데이터
			..._.pick(form, userInputAttrNms), // 폼 입력값
			// 변환해서 보내야할 폼 입력값
			depatureDt: isValid(depatureDt) ? format(depatureDt, 'yyyyMMdd') : null,
			depatureTm: isValid(depatureTm) ? format(depatureTm, 'HHmm') : null,
			arrivalDt: isValid(arrivalDt) ? format(arrivalDt, 'yyyyMMdd') : null,
			arrivalTm: isValid(arrivalTm) ? format(arrivalTm, 'HHmm') : null,
			chiefCellPn: _chiefCellPn
		};

		if (isNew) {
			// 새 배차신청 저장
			dispatch(insertVhb0020SubOne(vhb0020)).then(async action => {
				const data = action.payload;
				if (data && data.success) {
					if (vhb0020.file) {
						const { applyNo } = data.data; // 새로 생성된 신청번호

						// 첨부파일 업로드
						try {
							await vhb0020Service.uploadFile(vhb0020.file, applyNo);
						} catch (e) {
							console.error(e);
						}
					}

					dispatch(showMessage({ message: '배차신청이 등록되었습니다.' }));

					dispatch(clearVhb0020SubOne());
					if (vhb0020MstParams.partCd) {
						// vhb0020MstParams: 이전에 조회했던 파라미터로 조회
						dispatch(getVhb0020MstList(vhb0020MstParams)).then(_action => {
							const _data = _action.payload; // 비동기함수에서 반환한 데이터를 가져옴
							if (_data && _data.list) {
								if (_data.list.length > 0) {
									// 첫번째 항목으로 Sub 데이터 조회
									dispatch(getVhb0020SubOne({ applyNo: _data.list[0].applyNo }));
								}
							}
						});
					} else {
						dispatch(clearVhb0020MstList());
					}
				}
			});
		} else {
			// 기존 배차신청 수정
			dispatch(updateVhb0020SubOne(vhb0020)).then(async action => {
				const data = action.payload;
				if (data && data.success) {
					if (vhb0020.deletedFile) {
						// 첨부파일 삭제
						try {
							await vhb0020Service.deleteFile(vhb0020.applyNo);
						} catch (e) {
							console.error(e);
						}
					}
					if (vhb0020.file) {
						// 첨부파일 업로드
						try {
							await vhb0020Service.uploadFile(vhb0020.file, vhb0020.applyNo);
						} catch (e) {
							console.error(e);
						}
					}

					dispatch(showMessage({ message: '변경사항이 반영되었습니다.' }));

					dispatch(clearVhb0020SubOne());
					if (vhb0020MstParams.partCd) {
						// vhb0020MstParams: 이전에 조회했던 파라미터로 조회
						dispatch(getVhb0020MstList(vhb0020MstParams)).then(_action => {
							const _data = _action.payload; // 비동기함수에서 반환한 데이터를 가져옴
							if (_data && _data.list) {
								if (_data.list.length > 0) {
									// 첫번째 항목으로 Sub 데이터 조회
									dispatch(getVhb0020SubOne({ applyNo: _data.list[0].applyNo }));
								}
							}
						});
					} else {
						dispatch(clearVhb0020MstList());
					}
				}
			});
		}
	}

	// `사원` 팝업 열기
	function openEmpPopup(museClick) {
		dispatch(
			openDialog({
				children: (
					<EmpPopup
						onSelect={selected => {
							setForm(state => ({
								...state,
								applyEmpNo: selected.empNo,
								applyEmpNm: selected.empNm,
								applyCellPhnNo: selected.cellPhnNo
							}));
							dispatch(closeDialog());
						}}
						onClose={() => dispatch(closeDialog())}
						// 조회조건
						empNo={form.applyEmpNo} // 팝업 열자마자 입력한 사번으로 검색
						// 옵션
						museClick={museClick} // false면, 조회결과 1건인 경우 자동선택하고 팝업을 닫음
					/>
				)
			})
		);
	}

	if (_.isEmpty(vhb0020SubOne) || _.isEmpty(form)) {
		return null;
	}

	return (
		<>
			{/* 검색조건 툴바 */}
			{/* prettier-ignore */}
			<UutasToolBar title="배차신청등록" onBtnDeleteClick={onBtnDeleteClick} btnDeleteDisabled={isNew || !hasMngAuth} onBtnSaveClick={onBtnSaveClick} btnSaveDisabled={!isChanged || !hasMngAuth} onBtnCancelClick={() => dispatch(clearVhb0020SubOne())} />

			{/* 배차신청 입력폼 */}
			<UutasForm
				fullWidth // 너비 100%로 설정
				srchRef={srchRef} // 폼 입력값 validation 체크 시 DOM에 접근하기 위해 useRef 사용
				schema={formSchema} // 폼 입력컨트롤의 배치 정보
				// ==== 여기부터 폼 입력컨트롤 정의 ================================
				// 배차부서
				vhclDeptCd={
					// prettier-ignore
					<Select label="배차부서" fullWidth value={form.vhclDeptCd || ''} onChange={e => setForm(state => ({ ...state, vhclDeptCd: e.target.value }))} readOnly={!hasMngAuth}>
						{/* 서버 등에서 가져온 데이터로 option 추가 */}
						{vhDeptCodes &&
							vhDeptCodes.map((codeObj, key) => (
								<MenuItem key={key} value={codeObj.commCode}>
									{codeObj.commCodeName}
								</MenuItem>
							))}
					</Select>
				}
				// 신청자
				applyEmpNo={
					<div className="flex items-center">
						<Input
							className="w-96 mx-4"
							placeholder="사번"
							value={form.applyEmpNo || ''}
							onChange={e => {
								setForm(state => ({
									...state,
									applyEmpNo: e.target.value,
									applyEmpNm: '',
									applyCellPhnNo: ''
								}));
							}}
							onKeyUp={e => {
								// 사번 입력 후 `Enter` 입력 시 팝업 실행
								if (e.key === 'Enter') {
									openEmpPopup(false);
								}
							}}
							readOnly={!hasMngAuth}
						/>
						<Input
							className="w-160 mx-4"
							placeholder="성명"
							value={
								form.applyEmpNm && form.applyCellPhnNo
									? `${form.applyEmpNm} (${form.applyCellPhnNo})`
									: ''
							}
							disabled
						/>
						<IconButton
							size="small"
							onClick={e => openEmpPopup()} // 🔍 버튼 클릭 시 팝업 실행
							disabled={!hasMngAuth}
						>
							<Search fontSize="small" />
						</IconButton>
					</div>
				}
				// 용도
				vhType={
					// prettier-ignore
					<Select label="용도" fullWidth value={form.vhType || ''} onChange={e => setForm(state => ({ ...state, vhType: e.target.value }))} readOnly={!hasMngAuth}>
						{/* 서버 등에서 가져온 데이터로 option 추가 */}
						{vhTypeCodes &&
							vhTypeCodes.map((codeObj, key) => (
								<MenuItem key={key} value={codeObj.commCode}>
									{codeObj.commCodeName}
								</MenuItem>
							))}
					</Select>
				}
				// 출발일자
				depatureDt={
					// prettier-ignore
					<KeyboardDatePicker fullWidth format="yyyy.MM.dd" value={form.depatureDt} onChange={date => setForm(state => ({ ...state, depatureDt: date }))} readOnly={!hasMngAuth} error={false} helperText="" />
				}
				// 출발시간
				depatureTm={
					<KeyboardDateTimePicker
						fullWidth
						views={['hours', 'minutes']}
						disableToolbar // Date 선택 못하도록 막기 위함
						format="HH:mm"
						value={form.depatureTm}
						onChange={date => setForm(state => ({ ...state, depatureTm: date }))}
						readOnly={!hasMngAuth}
						error={false}
						helperText=""
					/>
				}
				// 사용목적
				usePurpose={
					<Input
						placeholder="사용목적"
						fullWidth
						type="text"
						value={form.usePurpose || ''}
						onChange={e => {
							// 최대 Byte 길이 제한
							if (KtngUtils.getStrByteLength(e.target.value) <= 50) {
								setForm(state => ({ ...state, usePurpose: e.target.value }));
							}
						}}
						readOnly={!hasMngAuth}
					/>
				}
				// 도착일자
				arrivalDt={
					// prettier-ignore
					<KeyboardDatePicker fullWidth format="yyyy.MM.dd" value={form.arrivalDt} onChange={date => setForm(state => ({ ...state, arrivalDt: date }))} readOnly={!hasMngAuth} error={false} helperText="" />
				}
				// 도착시간
				arrivalTm={
					<KeyboardDateTimePicker
						fullWidth
						views={['hours', 'minutes']}
						disableToolbar // Date 선택 못하도록 막기 위함
						format="HH:mm"
						value={form.arrivalTm}
						onChange={date => setForm(state => ({ ...state, arrivalTm: date }))}
						readOnly={!hasMngAuth}
						error={false}
						helperText=""
					/>
				}
				// 승차인원
				boardNo={
					<Input
						placeholder="승차인원"
						fullWidth
						type="text"
						value={form.boardNo || ''}
						onChange={e => {
							if (
								!/[^0-9\b]/g.test(e.target.value) && // . 등 문자입력불가
								KtngUtils.getStrByteLength(String(e.target.value)) <= 22 // 최대 Byte 길이 제한
							) {
								setForm(state => ({ ...state, boardNo: e.target.value }));
							}
						}}
						readOnly={!hasMngAuth}
					/>
				}
				// 사용자
				chiefEmpNo={
					<EmpPicker
						empNo={form.chiefEmpNo || ''}
						empNm={form.chiefEmpNm || ''}
						onChange={selected => {
							setForm(state => ({
								...state,
								chiefEmpNo: selected.empNo,
								chiefEmpNm: selected.empNm,
								chiefParCd: selected.parCd,
								chiefParNm: selected.parNm,
								chiefDeptCd: selected.partCd,
								chiefDeptNm: selected.partNm,
								chiefJobCd: selected.jobCd,
								chiefJobNm: selected.jobNm,
								chiefCellPn: selected.cellPhnNo ? KtngUtils.formatTelNo(selected.cellPhnNo) : ''
							}));
						}}
						readOnly={!hasMngAuth}
						disabledViews={!hasMngAuth ? ['empNo', 'empNm'] : []}
					/>
				}
				// 기관
				chiefParNm={<Typography>{form.chiefParNm}</Typography>}
				// 부서
				chiefDeptNm={<Typography>{form.chiefDeptNm}</Typography>}
				// 직무
				chiefJobNm={<Typography>{form.chiefJobNm}</Typography>}
				// 휴대전화
				chiefCellPn={
					<Input
						placeholder="휴대전화"
						fullWidth
						type="text"
						value={form.chiefCellPn || ''}
						onChange={e => {
							// 최대 Byte 길이 제한
							if (KtngUtils.getStrByteLength(e.target.value) <= 11) {
								setForm(state => ({ ...state, chiefCellPn: e.target.value }));
							}
						}}
						onFocus={e => {
							// 포커스가 오면, 전화번호 포맷('-') 지움
							setForm(state => ({ ...state, chiefCellPn: e.target.value.replace(/[^0-9]/g, '') }));
						}}
						onBlur={e => {
							// 포커스를 잃으면, 전화번호 포맷으로 변환
							setForm(state => ({ ...state, chiefCellPn: KtngUtils.formatTelNo(e.target.value) }));
						}}
						readOnly={!hasMngAuth}
					/>
				}
				// 행선지
				destination={
					<Input
						placeholder="행선지"
						fullWidth
						type="text"
						value={form.destination || ''}
						onChange={e => {
							// 최대 Byte 길이 제한
							if (KtngUtils.getStrByteLength(e.target.value) <= 30) {
								setForm(state => ({ ...state, destination: e.target.value }));
							}
						}}
						readOnly={!hasMngAuth}
					/>
				}
				// 출발지
				departure={
					<Input
						placeholder="출발지"
						fullWidth
						type="text"
						value={form.departure || ''}
						onChange={e => {
							// 최대 Byte 길이 제한
							if (KtngUtils.getStrByteLength(e.target.value) <= 30) {
								setForm(state => ({ ...state, departure: e.target.value }));
							}
						}}
						readOnly={!hasMngAuth}
					/>
				}
				// 경유지
				passstop={
					<Input
						placeholder="경유지"
						fullWidth
						type="text"
						value={form.passstop || ''}
						onChange={e => {
							// 최대 Byte 길이 제한
							if (KtngUtils.getStrByteLength(e.target.value) <= 30) {
								setForm(state => ({ ...state, passstop: e.target.value }));
							}
						}}
						readOnly={!hasMngAuth}
					/>
				}
				// 비고
				vhEtc={
					<KtngTextarea
						placeholder="비고"
						value={form.vhEtc || ''}
						onChange={e => {
							// 최대 Byte 길이 제한
							if (KtngUtils.getStrByteLength(e.target.value) <= 2000) {
								setForm(state => ({ ...state, vhEtc: e.target.value }));
							}
						}}
						inputProps={{ maxByteLength: 2000, readOnly: !hasMngAuth }}
						rows={1}
					/>
				}
				// 일정표첨부
				fileTitle={
					<UutasFileInput
						newFile={form.file} // 새로 첨부할 파일객체
						prevAttachNo={
							// 이전에 첨부된 파일번호
							form.fileTitle && // 기존 파일명(fileTitle)이 존재하고
							!form.deletedFile && // deletedFile이 없는 경우,
							form.applyNo // 기존 파일번호 전달 (파일다운로드 가능)
						}
						// [콜백함수]
						// 파일이 새로 첨부된 경우 콜백
						onChange={e => setForm(state => ({ ...state, file: e.target.files[0] }))}
						// 파일 첨부 취소
						onCancelNewFile={() => setForm(state => ({ ...state, file: undefined }))}
						// 이전에 첨부된 파일 삭제
						onRemovePrevFile={({ attachNo }) => setForm(state => ({ ...state, deletedFile: attachNo }))}
						// [옵션]
						readOnly={!hasMngAuth} // true일 때만 파일첨부/삭제 가능
					/>
				}
			/>
		</>
	);
};

export default VHB0020Frm1;
