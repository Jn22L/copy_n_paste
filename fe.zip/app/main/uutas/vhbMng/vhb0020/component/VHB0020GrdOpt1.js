/*
 * VHB0020Grd 그리드의 설정 파일
 *
 * 더 많은 설정값은 IBSheet8 manual에서 확인 가능
 *
 * - IBSheet8 manual 다운로드 경로
 *   http://gitlab.ktng.com:8880/t0210023/dev-env/raw/master/install/ibsheet8-manual-v20201229.zip?inline=false
 */

const options = {
	/* 1. Cfg: 그리드 스타일 관련 설정 */
	Cfg: {
		CanSelect: true, // 시트 선택 가능
		SelectingCells: 1, // 개별 셀 선택 가능
		CanEdit: 0, // 수정 불가능
		CustomScroll: 1 // 그리드와 스크롤 겹침 이슈 처리
	},

	/* 2. Def: 그리드 값 관련 설정 */
	Def: {
		// 2.1. Col: 그리드의 전체 열에 일괄적으로 적용할 설정
		// Col: {
		// 	RelWidth: 1 // 열 너비를 특정값으로 고정하지 않고 그리드 전체너비의 비율로 조정되도록 함
		// },
		// 2.2. Row: 그리드의 전체 행에 일괄적으로 적용할 설정
		// Row: {
		// 	CanFormula: 1, // {attribute}Formula 사용설정 Ex) `CanEditFormula`: 셀 수정가능 여부를 동적으로 결정할 수 있음
		// 	CalcOrder: 'driverNoCanEdit' // Formula 계산순서 설정
		// }
	},

	/* 3. Col: 그리드 컬럼 List */
	Cols: [
		/*
		 * `순번` 컬럼
		 * - Name을 'SEQ'로 설정 시 IBSheet에서 알아서 순번을 넣어줌
		 */
		// {
		// 	Header: '순번',
		// 	Name: 'SEQ',
		// 	Type: 'Int',
		// 	Align: 'center',
		// 	MinWidth: 80
		// },
		/*
		 * `삭제` 컬럼. 편집가능한 그리드에 공통적으로 들어가는 컬럼
		 * - 조회만하는 그리드에서는 `삭제` 컬럼 주석처리할 것
		 * - 체크박스 체크 시 `삭제(D)` 상태로 변경
		 */
		// {
		// 	Header: {
		// 		Value: '삭제',
		// 		HeaderCheck: 1
		// 	},
		// 	Type: 'Bool',
		// 	Name: 'delYn',
		// 	Align: 'center',
		// 	DefaultValue: false,
		// 	NoChanged: true
		// },
		/*
		 * `상태` 컬럼. 편집가능한 그리드에 공통적으로 넣어주는 컬럼
		 * - 조회만하는 그리드에서는 `상태` 컬럼 주석처리할 것
		 * - `상태` 셀은 직접 편집 불가능하고,
		 * - 행의 상태에 따라 자동으로 값이 변경됨.
		 */
		// {
		// 	Header: '상태',
		// 	Name: 'rowStatus',
		// 	Type: 'Enum',
		// 	Align: 'center',
		// 	DefaultValue: 'N',
		// 	Enum: '||추가|수정|삭제',
		// 	EnumKeys: '|N|I|U|D',
		// 	CanEdit: 0,
		// 	NoChanged: true
		// },
		// ==== 여기부터 필요한 컬럼을 정의 =========================================================
		{
			Header: '신청일자',
			Name: 'applyDt',
			Type: 'Date',
			Align: 'Center',
			RelWidth: 1
		},
		{
			Header: '사용자',
			Name: 'chiefEmpNm',
			Type: 'Text',
			Align: 'Center',
			RelWidth: 1
		},
		{
			Header: '출발일자',
			Name: 'depatureDt',
			Type: 'Date',
			Format: 'yyyy.MM.dd',
			Align: 'Center',
			RelWidth: 1
		},
		{
			Header: '출발시간',
			Name: 'depatureTm',
			Type: 'Date',
			Format: 'HH:mm',
			Align: 'Center',
			RelWidth: 1
		},
		{
			Header: '도착일자',
			Name: 'arrivalDt',
			Type: 'Date',
			Format: 'yyyy.MM.dd',
			Align: 'Center',
			RelWidth: 1
		},
		{
			Header: '도착시간',
			Name: 'arrivalTm',
			Type: 'Date',
			Format: 'HH:mm',
			Align: 'Center',
			RelWidth: 1
		},
		{
			Header: '행선지',
			Name: 'destination',
			Type: 'Text',
			Align: 'Center',
			RelWidth: 1
		},
		{
			Header: '사용목적',
			Name: 'usePurpose',
			Type: 'Text',
			Align: 'Center',
			RelWidth: 1
		},
		{
			Header: '용도',
			Name: 'vhTypeNm',
			Type: 'Text',
			Align: 'Center',
			RelWidth: 1
		},
		// 숨긴 열
		{
			Header: '신청번호',
			Name: 'applyNo',
			Type: 'Text',
			Align: 'Center',
			Visible: 0 // 숨김
		}
	]
};

export default options;
