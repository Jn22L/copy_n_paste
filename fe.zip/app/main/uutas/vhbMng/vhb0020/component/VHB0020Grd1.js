/*
 * VHB0020Grd 그리드 컴포넌트의 파일
 */

import KtngIbSheet from '@ktng/core/KtngIbSheet';
import KtngUtils from '@ktng/utils';
import { UutasToolBar } from '@ktng/uutas';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { format, addHours } from 'date-fns';
import _ from '@lodash';
import { selectVhb0020MstList } from '../store/vhb0020MstSlice';
import { createVhb0020SubOne, getVhb0020SubOne } from '../store/vhb0020SubSlice';
import sheetOptions from './VHB0020GrdOpt1'; // 그리드 설정파일

const sheetId = KtngUtils.getUid('vhb0020-grd1');

const initialForm = {
	vhType: 'A',
	usePurpose: '',
	boardNo: '1'
};

const VHB0020Grd1 = () => {
	const dispatch = useDispatch();

	/*
	 * ###################################################################################
	 * #### [Redux 설명 6 (끝)] Store에 저장된 데이터 가져오기2 (EntityAdapter) #############
	 * ###################################################################################
	 *
	 * > useSelector: Store에 저장된 데이터를 가져올 수 있다.
	 */
	// const vhb0020MstList = useSelector(
	// 	/*
	// 	 * 직접 매핑함수를 작성하지 않고,
	// 	 * EntityAdapter를 사용하여 xxxxSlice.js 파일에 만들어둔 매핑함수를 사용하였다.
	// 	 *
	// 	 * > selectVhb0020MstList: rootState객체로부터
	// 	 *   `vhb0020MstList` (하위Store)에 저장된 데이터List를 꺼내주는 함수
	// 	 */
	// 	rootState => {
	// 		return selectVhb0020MstList(rootState); // 리스트([...]) 형식으로 반환
	// 	}
	// );
	// ※ 간략히 재작성하면,
	const vhb0020MstList = useSelector(selectVhb0020MstList);

	const { vhb0020SubOne, uutasUser } = useSelector(({ vhb0020, auth }) => ({
		vhb0020SubOne: vhb0020.vhb0020Sub.data,
		uutasUser: auth.user.uutasUser || {}
	}));

	const [sheetObj, setSheetObj] = useState();
	const [grdData, setGrdData] = useState([]);

	// 1. 데이터 필터
	useEffect(() => {
		if (!vhb0020MstList) return;
		setGrdData(vhb0020MstList);
	}, [vhb0020MstList]);

	/* KtngIbSheet 이벤트 콜백 */

	// 그리드 생성 콜백
	function onSheetLoad(sheet) {
		setSheetObj(sheet);

		// 그리드에 공통코드 설정
		// if (driverTyCode) {
		// 	const { enumKeys, enumVals } = KtngIbSheetUtils.cvtCodeToIbSheetEnumType(driverTyCode);
		// 	sheet.setAttribute(null, 'driverTy', 'EnumKeys', enumKeys, true);
		// 	sheet.setAttribute(null, 'driverTy', 'Enum', enumVals, true);
		// }

		// 이벤트 등록
		// onRowAdd, onAfterClick, onAfterChange 3개 이벤트는 `KtngIbSheet` 컴포넌트 속성에 콜백함수를 넣어 추가
		// 3개 이벤트를 제외한 이벤트를 등록할 때 이곳에 작성
		// sheet.bind('onDataLoad', onSheetDataLoad);
	}

	// 그리드에 행 추가
	function handleBtnAddClick() {
		const depatureDt = new Date();
		const depatureTm = format(new Date(), 'HHmm');
		const arrivalDt = addHours(new Date(), 2);
		const arrivalTm = format(addHours(new Date(), 2), 'HHmm');

		// 빈 게시물 추가
		dispatch(
			// 게시물 상세에 필요한 초기값 셋팅
			createVhb0020SubOne({
				// 기본값
				...initialForm,
				// 사용자 폼 입력값
				applyEmpNo: uutasUser.empNo || '',
				applyEmpNm: uutasUser.empNm || '',
				applyCellPhnNo: uutasUser.cellPhnNo ? KtngUtils.formatTelNo(uutasUser.cellPhnNo) : '',
				depatureDt: format(depatureDt, 'yyyyMMdd'),
				depatureTm,
				arrivalDt: format(arrivalDt, 'yyyyMMdd'),
				arrivalTm
			})
		);

		// 게시물 리스트의 행에 필요한 초기값 셋팅
		return { applyDt: new Date(), depatureDt, depatureTm, arrivalDt, arrivalTm };
	}

	// 그리드 엑셀 다운로드
	function handleBtnDownExcelClick() {
		return {
			/*
			 * Excel Config
			 */
			// fileName: '', // 엑셀파일명.......... 기본값: '{ToolBar title}_{오늘날짜 yyyyMMdd}.xlsx'
			// merge: 1, // 그리드 셀병합 유지여부... 기본값: 1(true)
			// ...
		};
	}

	function onSheetClick({ sheet, row, col }) {
		const applyNo = sheet.getValue(row, 'applyNo');
		if (applyNo) {
			if (!vhb0020SubOne || applyNo !== vhb0020SubOne.applyNo) {
				// id가 존재하는 행
				dispatch(getVhb0020SubOne({ applyNo }));
			}
		} else {
			// id가 없는 새로운 행
			dispatch(
				createVhb0020SubOne({
					// 기본값
					...initialForm,
					// 사용자 폼 입력값
					..._.pick(row, ['depatureTm', 'arrivalTm']),
					applyEmpNo: uutasUser.empNo || '',
					applyEmpNm: uutasUser.empNm || '',
					depatureDt: format(row.depatureDt, 'yyyyMMdd'),
					arrivalDt: format(row.arrivalDt, 'yyyyMMdd')
				})
			);
		}
	}

	return (
		<div className="flex flex-col w-full">
			{/* 그리드 툴바 */}
			<UutasToolBar
				title="배차신청등록" // ToolBar에 표시할 헤더 문자열
				variant="subtitle1" // `title` 문자열 스타일종류
				sheet={sheetObj} // IBSheet Object (onBtnAddClick, onBtnDownExcelClick 콜백을 사용하는 경우 필수)
				/*
				 * onBtnAddClick
				 * - `onBtnAddClick` 속성에 콜백함수를 넘겨주면 ToolBar 컴포넌트에 `추가` 버튼이 생김
				 * - `추가` 버튼을 클릭하면 넘겨준 콜백함수가 실행되고,
				 *   콜백함수에서 그리드에 추가할 행 데이터를 반환하면 그리드에 행이 추가됨.
				 */
				onBtnAddClick={handleBtnAddClick}
				/*
				 * onBtnDownExcelClick
				 * - `onBtnDownExcelClick` 속성에 콜백함수를 넘겨주면 ToolBar 컴포넌트에 `엑셀다운로드` 버튼이 생김
				 * - `엑셀다운로드` 버튼을 클릭하면 넘겨준 콜백함수가 실행되고,
				 *   콜백함수에서 엑셀 설정 key-value 객체를 넘겨주면, 설정을 반영하여 그리드 내용을 엑셀파일로 다운로드함.
				 */
				onBtnDownExcelClick={handleBtnDownExcelClick}
			/>

			{/* 그리드 */}
			<KtngIbSheet
				// [필수 속성]
				sheetId={sheetId} // 그리드를 식별할 수 있는 ID 문자열
				options={sheetOptions} // 그리드 설정
				data={grdData} // 데이터List
				// [선택 속성]
				// - 내부에서 그리드에 사용할 공통코드 로드
				// codes={[
				// 	{ commCodeChk: 'VH_DEPT_ALL' } // 배차부서 (배차+지정차량)
				// ]}
				// - 이벤트
				onLoad={onSheetLoad} // 생성된 sheet 객체 바인딩 및 배차부서 로드 수행
				//   ※ 아래 2개 외 필요한 이벤트는 `onSheetLoad`에서 직접 바인딩할 것
				onAfterClick={onSheetClick} // 내부공통기능 수행 후 `onSheetClick` 콜백이 호출됨
				// onAfterChange={onSheetChange} // 내부공통기능 수행 후 `onSheetChange` 콜백이 호출됨
				// - 스타일 속성
				// className="" // tailwind 스타일 적용 가능
				style={{ height: '98%' }} // 그리드 초기 높이 설정시에는 style만 적용됨
			/>
		</div>
	);
};

export default VHB0020Grd1;
