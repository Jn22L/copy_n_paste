/*
 * VHB0020 업무화면 마스터그리드의 데이터를
 * 관리하는 Slice(Action + Reducer)파일
 *
 * > Reducer : store의 변경사항을 반영하는 함수 역할
 * > Action  : Reducer를 식별할 수 있는 문자열
 */

import { createSlice, createAsyncThunk, createEntityAdapter } from '@reduxjs/toolkit';
import KtngUtils from '@ktng/utils';
import vhb0020Service from 'app/services/vhb0020Service';

/*
 * ###################################################################################
 * #### [Redux 설명 3] store/xxxxSlice.js 파일 작성 ###################################
 * ###################################################################################
 */

// ==== 1. 비동기 함수 작성 ========================================================

/*
 * 비동기로 동작하는 Reducer를 사용하고 싶은 경우, createAsyncThunk로 Action/Reducer를 생성한다.
 *
 * > createAsyncThunk: 비동기로 동작하는 Reducer와 Reducer에 대한 Action을 한번에 생성한다.
 */
export const getVhb0020MstList = createAsyncThunk(
	'vhb0020/vhb0020Mst/getVhb0020MstList', // Action이름.. 주로 `{Store집합명}/{하위Store명}/{함수명}`으로 설정한다
	async (
		{ vhYyyymm, partCd }, // 함수 호출 시 전달할 파라미터 key-value 객체
		{ dispatch, rejectWithValue } // redux-toolkit 라이브러리에서 제공해주는 기능 중에 필요한 것들만 불러옴
	) => {
		// 비동기 동작 작성...
		try {
			const data = await vhb0020Service.selectMstGrid({ vhYyyymm, partCd });
			return {
				// 서버로부터 넘겨받은 데이터List 저장
				list: data.list,
				params: {
					// [필수아님] 서버에 요청할 때 사용했던 파라미터 저장
					vhYyyymm,
					partCd
				}
			};
		} catch (err) {
			// 비동기 Reducer 함수 안에서 에러 발생 시, 공통함수로 처리
			throw KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

// ==== 2. EntityAdapter 생성 ========================================================

/*
 * 저장된 데이터List를 관리하는 EntityAdapter를 생성한다.
 *
 * > EntityAdapter: 생성할 때, 데이터List의 유일한 값를 반환하는 콜백함수를 작성해주면
 *   `addMany, addOne, updateMany, updateOne, removeAll, removeMany, removeOne` 등
 *   데이터List를 관리할 수 있는 함수들을 자동생성해준다.
 *
 * > createEntityAdapter: 데이터List에 대한 EntityAdapter를 생성한다.
 */
const vhb0020MstAdapter = createEntityAdapter({
	selectId: vhb0020Mst => vhb0020Mst.applyNo // 데이터List의 유일한 값을 반환하는 콜백함수 작성
	// 만약 정보가 A컬럼, B컬럼 두 컬럼으로 유일한 값이 정해지는 경우, A값 + B값을 반환하는 것도 가능
	// Ex) selectId: data => data.A + data.B
});

/*
 * EntityAdapter를 사용하여 데이터List를 조회
 */
export const { selectAll: selectVhb0020MstList, selectById: selectVhclDeptById } = vhb0020MstAdapter.getSelectors(
	state => state.vhb0020.vhb0020Mst
);

// ==== 3. Slice(Action + Reducer) 생성 ================================================

/* Store의 기본값 설정 */
const initialState = {
	params: {
		vhYyyymm: '',
		partCd: ''
	},
	loading: false
};

/*
 * Store를 관리하는 Action, Reducer를 포함한 Slice를 생성한다.
 *
 * > createSlice: Slice 생성한다.
 */
const vhb0020MstSlice = createSlice({
	/*
	 * 3.1. Slice 이름 설정
	 * Reducer의 Action이름의 접두어로 사용.. 주로 `{Store집합명}/{하위Store명}`으로 설정한다
	 */
	name: 'vhb0020/vhb0020Mst',

	/*
	 * 3.2. Store 기본값 설정
	 * > EntityAdapter.getInitialState: 파라미터로 받은 State key-value 객체에
	 *   { ids: [], entities: [] }를 추가한다.
	 */
	initialState: vhb0020MstAdapter.getInitialState(initialState),

	/*
	 * 3.3. Reducer 작성
	 * Store데이터를 변경하는 함수.
	 * 직접 작성하거나, EntityAdapter로 자동생성된 함수를 활용하여 작성
	 *
	 * > EntityAdapter.updateOne: 데이터List의 데이터 한 개의 내용을 변경
	 * > EntityAdapter.updateMany: 데이터List의 데이터 여러 개의 내용을 변경
	 * > EntityAdapter.removeAll: 저장된 데이터List를 비움
	 */
	reducers: {
		changeVhb0020MstOne: (state, action) => {
			return vhb0020MstAdapter.updateOne(state, action);
		},
		changeVhb0020MstList: (state, action) => {
			return vhb0020MstAdapter.updateMany(state, action);
		},
		clearVhb0020MstList: (state, action) => {
			return vhb0020MstAdapter.removeAll(state, action);
		}
	},

	/*
	 * 3.4. extraReducer 작성
	 * 위에서 생성한 비동기 함수의 3가지 시점에서 동작할 Reducer를 각각 작성한다.
	 * - [pending]   : 실행 직전
	 * - [fulfilled] : 성공 직후
	 * - [rejected]  : 실패 직후
	 */
	extraReducers: {
		/*
		 * 3.4.1. [pending]
		 * - 주로 로딩여부를 true로 바꿔주거나,
		 * - 이전에 받아왔던 데이터를 clear해준다.
		 */
		[getVhb0020MstList.pending]: state => {
			state.loading = true; // [필수아님] 로딩여부 true
		},

		/*
		 * 3.4.2. [fulfilled]
		 * - 성공적으로 서버로부터 넘겨받은 데이터를 Store에 넣어준다.
		 * - 비동기함수에서 반환(return)한 객체는 action.payload에 들어있다.
		 */
		[getVhb0020MstList.fulfilled]: (state, action) => {
			const { list, params } = action.payload; // 비동기함수 반환값

			vhb0020MstAdapter.setAll(state, list); // EntityAdapter에 데이터List 저장
			state.params = params; // [필수아님] 데이터List 조회 시 사용했던 파라미터 저장
			state.loading = false; // [필수아님] 로딩여부 false
		},

		/*
		 * 3.4.3. [rejected]
		 * - 비동기함수 내에서 에러가 발생한 경우 동작한다.
		 */
		[getVhb0020MstList.rejected]: state => {
			state.loading = false; // [필수아님] 로딩여부 false
		}
	}
});

// Slice 내부에서 작성/생성한 Reducer들을 다른 파일에서 사용할 수 있도록 export한다.
export const { changeVhb0020MstOne, changeVhb0020MstList, clearVhb0020MstList } = vhb0020MstSlice.actions;

// Slice의 Store를 다른 파일에서 사용할 수 있도록 export한다.
export default vhb0020MstSlice.reducer;
