// **************************************************************************
// 파    일    명   : VHB0020Page.js
// 업무      분류  : 배차신청등록
// 업    무    명   : 배차신청등록
// 프로그램   내용   : 배차신청을 조회/입력/수정/삭제하는 화면
// 기          타   :
// ==========================================================================
// 작    성    자   : 김 민 우
// 작    성    일   : 2022.01.04
// 최종    수정일   :
// 변 경    이 력   :
// **************************************************************************

import React from 'react';
import { useSelector } from 'react-redux';
import withReducer from 'app/store/withReducer';
import { UutasPageSimple } from '@ktng/uutas';
import _ from '@lodash';
import { Divider } from '@material-ui/core';
import { VHB0020Srch, VHB0020Grd1, VHB0020Frm1 } from './component';
import reducer from './store';

// vhbMng/vhb0020/vhb0020
const VHB0020Page = () => {
	/*
	 * ###################################################################################
	 * #### [Redux 설명 5] Store에 저장된 데이터 가져오기1 ##################################
	 * ###################################################################################
	 *
	 * > useSelector: Store에 저장된 데이터를 가져올 수 있다.
	 */
	const { vhb0020MstLoading, vhb0020SubLoading, vhb0020SubOne } = useSelector(
		/*
		 * rootState 객체로부터 현재 컴포넌트에서 사용할 데이터만 선택하여
		 * key-value 객체를 반환해주는 함수를 작성한다.
		 */
		(
			/* rootState 객체로부터 현재 컴포넌트에서 사용할 `Store집합`들만 선택 */
			{
				vhb0020 // `Store집합`의 별명
			}
		) =>
			/*
			 * 파라미터로 받은 `Store집합`을 활용하여,
			 * `useSelector` 함수가 반환할 key-value 객체를 생성하여 반환한다.
			 */
			({
				vhb0020MstLoading: vhb0020.vhb0020Mst.loading, // 서버로부터 데이터로드 중이면 true, 아니면 false
				vhb0020SubLoading: vhb0020.vhb0020Sub.loading,
				vhb0020SubOne: vhb0020.vhb0020Sub.data
			})
	);

	return (
		<UutasPageSimple
			title="배차신청등록" // 헤더에 표시할 페이지 이름
			loading={vhb0020MstLoading || vhb0020SubLoading} // 로딩 발생 시마다 화면에 로딩바를 표시해줌
		>
			{/* 검색조건 */}
			<VHB0020Srch />

			{/* 배차신청등록 그리드 */}
			<div className="flex flex-1">
				<VHB0020Grd1 />
			</div>

			{/* 게시판 입력폼 */}
			{!_.isEmpty(vhb0020SubOne) && (
				<div className="flex flex-col flex-1">
					<Divider className="my-16" />

					<VHB0020Frm1 />
				</div>
			)}
		</UutasPageSimple>
	);
};

/*
 * #############################################################################
 * #### [Redux 설명 1] 화면에 Redux 추가 ########################################
 * #############################################################################
 *
 * 화면을 여러 컴포넌트로 쪼갤 경우, 쪼갠 컴포넌트에서 공유하고 싶은 데이터를
 * Redux를 통해 관리할 수 있다.
 *
 * 먼저, VHB0020Page(Store를 함께 공유하고 싶은 하위 컴포넌트들을 가진 컴포넌트)에 Store를 추가한다.
 *
 * > withReducer: 컴포넌트에 사용할 Store를 추가해주는 함수
 */
export default withReducer(
	'vhb0020', // {string} `useSelector`로 `Store집합`을 불러올 때 사용할 별명
	reducer //    {object} 컴포넌트에서 사용할 `Store집합`
)(VHB0020Page);
