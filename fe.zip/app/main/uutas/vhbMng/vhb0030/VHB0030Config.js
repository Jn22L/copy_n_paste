import VHB0030Page from './VHB0030Page';

// `메뉴경로` - `화면` 맵핑 정보를 가진 Config는 파일명 대문자로 시작
const VHB0030Config = {
	routes: [
		{
			path: '/vhbMng/vhb0030',
			component: VHB0030Page
		}
	]
};

export default VHB0030Config;
