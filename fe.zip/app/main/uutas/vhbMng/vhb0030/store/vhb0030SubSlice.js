import { createSlice, createAsyncThunk, createEntityAdapter } from '@reduxjs/toolkit';
import KtngUtils from '@ktng/utils';
import vhb0030Service from 'app/services/vhb0030Service';

export const getVhb0030SubList = createAsyncThunk(
	'vhb0030/vhb0030Sub/getVhb0030SubList',
	async ({ applyNo }, { dispatch, rejectWithValue }) => {
		try {
			const data = await vhb0030Service.selectVhb0030SubList(applyNo);
			return {
				list: data.list,
				params: {
					applyNo
				}
			};
		} catch (err) {
			throw KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

const vhb0030SubAdapter = createEntityAdapter({
	selectId: sub => sub.assignNo
});

export const { selectAll: selectVhb0030Subs, selectById: selectVhb0030SubById } = vhb0030SubAdapter.getSelectors(
	state => state.vhb0030.vhb0030Sub
);

const initialState = {
	params: {
		applyNo: ''
	},
	filters: {
		applyNo: ''
	},
	loading: false
};

const vhb0030SubSlice = createSlice({
	name: 'vhb0030/vhb0030Sub',
	initialState: vhb0030SubAdapter.getInitialState(initialState),
	reducers: {
		changeVhb0030SubsFilter: (state, action) => {
			state.filters = {
				...state.filters,
				...action.payload
			};
		},
		clearVhb0030SubsFilter: state => {
			state.filters = initialState.filters;
		}
	},
	extraReducers: {
		[getVhb0030SubList.pending]: state => {
			state.loading = true;
		},
		[getVhb0030SubList.fulfilled]: (state, action) => {
			const { list, params } = action.payload;
			vhb0030SubAdapter.setAll(state, list);
			state.params = params;
			state.loading = false;
		},
		[getVhb0030SubList.rejected]: state => {
			state.loading = false;
		}
	}
});

export const { changeVhb0030SubsFilter, clearVhb0030SubsFilter } = vhb0030SubSlice.actions;

export default vhb0030SubSlice.reducer;
