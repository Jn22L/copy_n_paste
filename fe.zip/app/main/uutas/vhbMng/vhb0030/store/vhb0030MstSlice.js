import { createSlice, createAsyncThunk, createEntityAdapter } from '@reduxjs/toolkit';
import KtngUtils from '@ktng/utils';
import vhb0030Service from 'app/services/vhb0030Service';

export const getVhb0030MstList = createAsyncThunk(
	'vhb0030/vhb0030Mst/getVhb0030MstList',
	async ({ vhYyyymm, partCd }, { dispatch, rejectWithValue }) => {
		try {
			const data = await vhb0030Service.selectVhb0030MstList(vhYyyymm, partCd);
			return {
				list: data.list,
				params: {
					vhYyyymm,
					partCd
				}
			};
		} catch (err) {
			throw KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

const vhb0030MstAdapter = createEntityAdapter({
	selectId: mst => mst.applyNo
});

export const { selectAll: selectVhb0030Msts, selectById: selectVhb0030MstById } = vhb0030MstAdapter.getSelectors(
	state => state.vhb0030.vhb0030Mst
);

const initialState = {
	params: {
		vhYyyymm: '',
		partCd: ''
	},
	filters: {
		vhYyyymm: '',
		partCd: ''
	},
	loading: false
};

const vhb0030MstSlice = createSlice({
	name: 'vhb0030/vhb0030Mst',
	initialState: vhb0030MstAdapter.getInitialState(initialState),
	reducers: {
		changeVhb0030MstsFilter: (state, action) => {
			state.filters = {
				...state.filters,
				...action.payload
			};
		},
		clearVhb0030MstsFilter: state => {
			state.filters = initialState.filters;
		}
	},
	extraReducers: {
		[getVhb0030MstList.pending]: state => {
			state.loading = true;
		},
		[getVhb0030MstList.fulfilled]: (state, action) => {
			const { list, params } = action.payload;
			vhb0030MstAdapter.setAll(state, list);
			state.params = params;
			state.loading = false;
		},
		[getVhb0030MstList.rejected]: state => {
			state.loading = false;
		}
	}
});

export const { changeVhb0030MstsFilter, clearVhb0030MstsFilter } = vhb0030MstSlice.actions;

export default vhb0030MstSlice.reducer;
