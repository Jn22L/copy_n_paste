import { combineReducers } from 'redux';
import vhb0030Mst from './vhb0030MstSlice';
import vhb0030Sub from './vhb0030SubSlice';

const reducer = combineReducers({
	vhb0030Mst,
	vhb0030Sub
});

export default reducer;
