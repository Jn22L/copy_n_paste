// **************************************************************************
// 파    일    명   : VHB0030Page.js
// 업무      분류   :
// 업    무    명   : 배차신청현황
// 프로그램   내용   :
// 기          타   :
// ==========================================================================
// 작    성    자   :
// 작    성    일   : 2022.01.06
// 최종    수정일   :
// 변 경    이 력   :
// **************************************************************************

import React from 'react';
import { useSelector } from 'react-redux';
import withReducer from 'app/store/withReducer';
import { UutasPageSimple } from '@ktng/uutas';
import { VHB0030Srch, VHB0030Grd1, VHB0030Grd2 } from './component';
import reducer from './store';

// /vhbMng/vhb0030
const VHB0030Page = () => {
	const { dataLoading } = useSelector(({ vhb0030 }) => ({
		dataLoading: vhb0030.vhb0030Mst.loading
	}));

	return (
		<UutasPageSimple title="배차신청현황" loading={dataLoading}>
			{/* 검색조건 */}
			<VHB0030Srch />

			{/* 상단 grid */}
			<div className="flex flex-1">
				<VHB0030Grd1 />
			</div>

			{/* 하단 grid */}
			<div className="flex flex-1">
				<VHB0030Grd2 />
			</div>
		</UutasPageSimple>
	);
};

export default withReducer('vhb0030', reducer)(VHB0030Page);
