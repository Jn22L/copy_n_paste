const options = {
	Cfg: {
		CanSelect: true, // 시트 선택 가능
		SelectingCells: 1, // 개별 셀 선택 가능
		CanEdit: 0, // 수정 가능
		CustomScroll: 1 // 그리드와 스크롤 겹침 이슈 처리
	},
	/* 2. Def: 그리드 값 관련 설정 */
	Def: {
		// 2.1. Col: 그리드의 전체 열에 일괄적으로 적용할 설정
		// Col: {
		// 	RelWidth: 1 // 열 너비를 특정값으로 고정하지 않고 그리드 전체너비의 비율로 조정되도록 함
		// },
		// 2.2. Row: 그리드의 전체 행에 일괄적으로 적용할 설정
		// Row: {
		// 	CanFormula: 1, // {attribute}Formula 사용설정 Ex) `CanEditFormula`: 셀 수정가능 여부를 동적으로 결정할 수 있음
		// 	CalcOrder: 'empNoCanEdit' // Formula 계산순서 설정
		// }
	},
	Cols: [
		{
			Header: '출발일자',
			Name: 'depatureDt',
			Type: 'Date',
			Format: 'yyyy.MM.dd',
			Align: 'Center',
			Required: 0,
			RelWidth: 1,
			CanEdit: 0
		},
		{
			Header: '시간',
			Name: 'depatureTm',
			Type: 'Date',
			Format: 'HH:mm',
			Align: 'Center',
			Required: 0,
			RelWidth: 0.5,
			CanEdit: 0
		},
		{
			Header: '도착일자',
			Name: 'arrivalDt',
			Type: 'Date',
			Format: 'yyyy.MM.dd',
			Align: 'Center',
			Required: 0,
			RelWidth: 1,
			CanEdit: 0
		},
		{
			Header: '시간',
			Name: 'arrivalTm',
			Type: 'Date',
			Format: 'HH:mm',
			Align: 'Center',
			Required: 0,
			RelWidth: 0.5,
			CanEdit: 0
		},
		{
			Header: '행선지',
			Name: 'destination',
			Type: 'Text',
			Align: 'left',
			Required: 0,
			RelWidth: 1,
			CanEdit: 0
		},
		{
			Header: '차량번호',
			Name: 'vhclNo',
			Type: 'Text',
			Align: 'Center',
			Required: 0,
			RelWidth: 1,
			CanEdit: 0
		},
		{
			Header: '운전자',
			Name: 'driverNm',
			Type: 'Text',
			Align: 'center',
			Required: 0,
			RelWidth: 1,
			CanEdit: 0
		},
		{
			Header: '운전자전화번호',
			Name: 'cellPn',
			Type: 'Text',
			Align: 'Center',
			Required: 0,
			RelWidth: 1,
			CanEdit: 0,
			CustomFormat: 'PhoneNo'
		}
	]
};

export default options;
