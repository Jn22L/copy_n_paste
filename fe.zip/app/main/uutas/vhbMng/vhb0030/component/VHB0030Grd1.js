import KtngIbSheet from '@ktng/core/KtngIbSheet';
import KtngUtils from '@ktng/utils';
import { UutasToolBar } from '@ktng/uutas';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { selectVhb0030Msts } from '../store/vhb0030MstSlice';
import { getVhb0030SubList } from '../store/vhb0030SubSlice';
import sheetOptions from './VHB0030GrdOpt1';

const sheetId = KtngUtils.getUid('vhb0030-grd1');

const VHB0030Grd1 = () => {
	const dispatch = useDispatch();
	const vhb0030MstList = useSelector(selectVhb0030Msts);

	const [sheetObj, setSheetObj] = useState();
	const [grdData, setGrdData] = useState([]);

	useEffect(() => {
		setGrdData(vhb0030MstList);
		// 첫번째 항목으로, 하단 grid 조회
		if (vhb0030MstList?.length > 0) {
			dispatch(getVhb0030SubList({ applyNo: vhb0030MstList[0].applyNo }));
		} else {
			dispatch(getVhb0030SubList({ applyNo: '' }));
		}
		// eslint-disable-next-line
	}, [vhb0030MstList]);

	// 그리드 생성 콜백
	function onSheetLoad(sheet) {
		setSheetObj(sheet);
	}

	// 그리드 행 선택
	function onSheetClick({ sheet, row, col }) {
		//if (row.rowStatus !== 'N') return;
		const applyNo = sheet.getValue(row, 'applyNo');
		dispatch(getVhb0030SubList({ applyNo })).then(action => {
			const data = action.payload;
			if (data && data.list) {
				//dispatch(showMessage({ message: `총 ${data.list.length}건이 조회되었습니다.` }));
			}
		});
	}

	return (
		<div className="flex flex-col w-full">
			<UutasToolBar title="신청사항조회" variant="subtitle1" sheet={sheetObj} />

			<KtngIbSheet
				// [필수 속성]
				sheetId={sheetId}
				options={sheetOptions}
				data={grdData}
				// [선택 속성]
				onLoad={onSheetLoad} // 생성된 sheet 객체 바인딩 및 공통코드 로드 수행
				onAfterClick={onSheetClick} // 내부공통기능 수행 후 `onSheetClick` 콜백이 호출됨
				style={{ height: '98%' }} // 그리드 초기 높이 설정시에는 style만 적용됨
			/>
		</div>
	);
};

export default VHB0030Grd1;
