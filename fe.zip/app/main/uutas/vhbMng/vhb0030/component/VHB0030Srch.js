import React, { useState, useRef, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { UutasToolBar, UutasForm } from '@ktng/uutas';
import KtngUtils from '@ktng/utils';
import { getVhb0030MstList } from '../store/vhb0030MstSlice';
import DeptPicker from 'app/main/popup/DeptPicker';
import { KeyboardDatePicker } from '@material-ui/pickers';
import { format, isValid } from 'date-fns';

const formSchema = [
	// row 1
	[
		// col 1
		{
			id: 'vhYyyymm',
			label: '차량출발년월',
			width: 150,
			align: 'center',
			required: true
		},
		// col 2
		{
			id: 'deptPicker',
			label: '신청부서',
			width: 400,
			align: 'center',
			required: true
		}
	]
];

const VHZ3030Srch = () => {
	const dispatch = useDispatch();

	// 입력된 값의 유효성검사를 하기위해 `useRef`로 폼입력컨트롤의 DOM에 접근한다
	const srchRef = useRef();

	const { uutasUser } = useSelector(({ auth }) => ({
		uutasUser: auth.user.uutasUser || {}
	}));

	const [expanded, setExpanded] = useState(true);

	// 폼 입력값
	const [vhYyyymm, setVhYyyymm] = useState(new Date());
	const [deptPicker, setDeptPicker] = useState({ orgCd: uutasUser.partCd, orgNm: uutasUser.partNm });

	// 데이터 로드
	useEffect(() => {
		onBtnSearchClick();
		// eslint-disable-next-line
	}, []);

	function onBtnSearchClick() {
		const _partCd = deptPicker.orgCd || '';
		const _vhYyyymm = isValid(vhYyyymm) ? format(vhYyyymm, 'yyyyMM') : '';

		const validationComps = [
			{ key: '차량출발년월', value: _vhYyyymm, type: 'text', required: true, minLength: 6, maxLength: 6 },
			{ key: '신청부서', value: _partCd, type: 'text', required: true, minLength: 6, maxLength: 6 }
		];

		if (KtngUtils.validationComps(validationComps, dispatch, srchRef)) {
			// 변경된 검색조건 으로 조회
			dispatch(getVhb0030MstList({ vhYyyymm: _vhYyyymm, partCd: _partCd })).then(action => {
				//const data = action.payload;
			}); // DB 에서 조회
		}
	}

	return (
		<>
			{/* 검색조건 툴바 */}
			<UutasToolBar onBtnSearchClick={onBtnSearchClick} expanded={expanded} onBtnToggleClick={setExpanded} />

			{/* 검색조건 입력폼 */}
			<UutasForm
				srchRef={srchRef}
				expanded={expanded}
				schema={formSchema}
				// 차량출발년월
				vhYyyymm={
					<KeyboardDatePicker
						className="w-128"
						views={['year', 'month']}
						format="yyyy.MM"
						value={vhYyyymm}
						onChange={date => setVhYyyymm(date)}
						onKeyUp={e => {
							if (e.key === 'Enter') {
								onBtnSearchClick();
							}
						}}
						error={false}
						helperText=""
					/>
				}
				// 신청부서
				deptPicker={
					<DeptPicker
						orgCd={uutasUser.partCd} // 부서코드 초기값
						orgNm={uutasUser.partNm} // 부서명 초기값
						onChange={data => setDeptPicker(data)}
						views={['orgCd', 'orgNm']} // 리스트에 있는 입력뷰만 보임 (undefined면 모두 보임)
					/>
				}
			/>
		</>
	);
};

export default VHZ3030Srch;
