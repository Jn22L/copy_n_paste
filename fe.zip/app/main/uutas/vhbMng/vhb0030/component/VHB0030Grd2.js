import KtngIbSheet from '@ktng/core/KtngIbSheet';
import KtngUtils from '@ktng/utils';
import { UutasToolBar } from '@ktng/uutas';
import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { selectVhb0030Subs } from '../store/vhb0030SubSlice';
import sheetOptions from './VHB0030GrdOpt2';

const sheetId = KtngUtils.getUid('vhb0030-grd2');

const VHB0030Grd2 = () => {
	const gridResult = useSelector(selectVhb0030Subs);
	const [sheetObj, setSheetObj] = useState();
	const [grdData, setGrdData] = useState([]);

	// 2. 데이터 필터
	useEffect(() => {
		setGrdData(gridResult);
	}, [gridResult]);

	// 그리드 생성 콜백
	function onSheetLoad(sheet) {
		setSheetObj(sheet);
	}

	return (
		<div className="flex flex-col w-full">
			<UutasToolBar title="배차결과조회" variant="subtitle1" sheet={sheetObj} />

			<KtngIbSheet
				// [필수 속성]
				sheetId={sheetId}
				options={sheetOptions}
				data={grdData}
				// [선택 속성]
				onLoad={onSheetLoad}
				style={{ height: '98%' }} // 그리드 초기 높이 설정시에는 style만 적용됨
			/>
		</div>
	);
};

export default VHB0030Grd2;
