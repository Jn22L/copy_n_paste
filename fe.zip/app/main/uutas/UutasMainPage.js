import React from 'react';
import { makeStyles, Typography } from '@material-ui/core';
import clsx from 'clsx';

const useStyles = makeStyles(theme => ({
	root: {
		'& .logo-icon': {
			width: 256,
			transition: theme.transitions.create(['width', 'height'], {
				duration: theme.transitions.duration.shortest,
				easing: theme.transitions.easing.easeInOut
			})
		},
		'& .react-badge, & .logo-text': {
			transition: theme.transitions.create('opacity', {
				duration: theme.transitions.duration.shortest,
				easing: theme.transitions.easing.easeInOut
			}),
			color: '#767779'
		}
	}
}));

function UutasMainPage() {
	const classes = useStyles();

	return (
		<div className="flex justify-center" style={{ height: '100%' }}>
			<div className={clsx(classes.root, 'flex flex-col justify-center')}>
				<div>
					<img className="logo-icon" src="assets/images/logos/ktng_logo.png" alt="logo" />
				</div>
				<div className="flex justify-center">
					<Typography className="text-32 mx-12 font-extrabold logo-text" color="inherit">
						배차관리시스템 메인
					</Typography>
				</div>
			</div>
		</div>
	);
}

export default UutasMainPage;
