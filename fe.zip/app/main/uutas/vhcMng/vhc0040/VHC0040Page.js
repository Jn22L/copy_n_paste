// **************************************************************************
// 파    일    명   : VHC0040Page.js
// 업  무   분  류  : 배차관리
// 업    무    명   : 결재관리
// 프로그램   내용   : 결재요청된 배차내역을 '승인/반려/취소'하는 화면
// 기          타   :
// ==========================================================================
// 작    성    자   : 심주용
// 작    성    일   : 2021.12.29
// 최종    수정일   :
// 변 경    이 력   :
// **************************************************************************

import React from 'react';
import { useSelector } from 'react-redux';
import withReducer from 'app/store/withReducer';
import { UutasPageSimple } from '@ktng/uutas';
import { VHC0040Srch, VHC0040Grd1 } from './component';
import reducer from './store';

// vhcMng/vhc0040/vhc0040
const VHC0040Page = () => {
	const { vhc0040MstLoading } = useSelector(({ vhc0040 }) => ({
		vhc0040MstLoading: vhc0040.vhc0040Mst.loading
	}));

	return (
		<UutasPageSimple title="결재상신" loading={vhc0040MstLoading}>
			{/* 검색조건 */}
			<VHC0040Srch />

			{/* 결재내역 목록 그리드 */}
			<div className="flex flex-1">
				<VHC0040Grd1 />
			</div>
		</UutasPageSimple>
	);
};

export default withReducer('vhc0040', reducer)(VHC0040Page);
