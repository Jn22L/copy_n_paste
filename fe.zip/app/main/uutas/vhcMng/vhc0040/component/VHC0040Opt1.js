const options = {
	Cfg: {
		CanSelect: true, // 시트 선택 가능
		SelectingCells: 1, // 개별 셀 선택 불가능
		CanEdit: 1, // 수정 가능
		IgnoreFocused: true,
		CustomScroll: 1, // 그리드와 스크롤 겹침 이슈 처리
		MultiRecord: true,
		InEditMode: 1,
		Size: 'Normal',
		Alternate: 2 // 짝수행에 하이라이트 표시
	},
	Def: {
		Row: {
			CanFormula: 1, // {attribute}Formula 사용설정 Ex) `CanEditFormula`: 셀 수정가능 여부를 동적으로 결정할 수 있음
			CalcOrder: 'rejectCauseCanEdit', // Formula 계산순서 설정
			AlternateColor: "#F1F1F1" // 짝수행 색상
		},
		Col: {
			Spanned: 1 // RecordRowSpan -> col에 Spanned:1 이 설정되어 있어야 사용할 수 있습니다.
		}
	},
	Cols: [
		// 첫번째 단위 데이터(DataRow) 행
		[
			{
				Header: {
					Value: '선택',
					HeaderCheck: 1
				},
				Type: 'Bool',
				Name: 'ckBox',
				Align: 'center',
				DefaultValue: false,
				NoChanged: true,
				CanEdit: 1,
				RecordRowSpan: 2 // 멀티레코드 기능(MultiRecord)을 사용하는 시트에서 특정 행을 기준으로 아래쪽으로 합쳐질 행의 개수를 설정합니다.
			},
			// ==== 여기부터 필요한 컬럼을 정의 =========================================================
			{
				Header: '결재상태',
				Name: 'approveTyNm',
				Type: 'Text',
				Align: 'Center',
				Required: 0,
				RelWidth: 1,
				CanEdit: 0
			},
			{
				Header: '출발일자',
				Name: 'depatureDt',
				Type: 'Date',
				Format: 'yyyy.MM.dd',
				Align: 'Center',
				Required: 0,
				RelWidth: 1,
				CanEdit: 0
			},
			{
				Header: '출발시간',
				Name: 'depatureTm',
				Type: 'Date',
				Format: 'HH:mm',
				Align: 'Center',
				Required: 0,
				RelWidth: 1,
				CanEdit: 0
			},
			{
				Header: '도착일자',
				Name: 'arrivalDt',
				Type: 'Date',
				Format: 'yyyy.MM.dd',
				Align: 'Center',
				Required: 0,
				RelWidth: 1,
				CanEdit: 0
			},
			{
				Header: '도착시간',
				Name: 'arrivalTm',
				Type: 'Date',
				Format: 'HH:mm',
				Align: 'Center',
				Required: 0,
				RelWidth: 1,
				CanEdit: 0
			},
			{
				Header: '행선지',
				Name: 'destination',
				Type: 'Text',
				Align: 'Center',
				Required: 0,
				RelWidth: 1,
				CanEdit: 0
			}
		],
		// 두번째 단위 데이터(DataRow) 행
		[
			{
				Header: '선택'
			},
			// ==== 여기부터 필요한 컬럼을 정의 =========================================================
			{
				Header: '차량번호',
				Name: 'vhclNo',
				Type: 'Text',
				Align: 'Center',
				Required: 0,
				// RelWidth: 1,
				CanEdit: 0
			},
			{
				Header: '차종',
				Name: 'vhclNm',
				Type: 'Text',
				Align: 'Center',
				Required: 0,
				// RelWidth: 1,
				CanEdit: 0
			},
			{
				Header: '운전자',
				Name: 'driverNm',
				Type: 'Text',
				Align: 'Center',
				Required: 0,
				// RelWidth: 1,
				CanEdit: 0
			},
			{
				Header: '사용자',
				Name: 'chiefEmpNm',
				Type: 'Text',
				Align: 'Center',
				Required: 0,
				// RelWidth: 1,
				CanEdit: 0
			},
			{
				Header: '사용목적',
				Name: 'usePurpose',
				Type: 'Text',
				Align: 'Center',
				Required: 0,
				// RelWidth: 1,
				CanEdit: 0
			},
			{
				Header: '반려/취소사유',
				Name: 'rejectCause',
				Type: 'Text',
				Align: 'Center',
				Required: 1,
				// RelWidth: 1,
				// CanEdit: 1,
				CanEditFormula: param => {
					const { approveTy } = param.Row;
					// `승인/미결` 상태에서만 수정가능
					return approveTy === 'Y' || approveTy === 'R';
				}
			}
		]
	]
};

export default options;
