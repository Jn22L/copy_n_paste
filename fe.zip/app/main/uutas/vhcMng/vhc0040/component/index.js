import VHC0040Srch from './VHC0040Srch';
import VHC0040Grd1 from './VHC0040Grd1';

export { VHC0040Srch, VHC0040Grd1 };
