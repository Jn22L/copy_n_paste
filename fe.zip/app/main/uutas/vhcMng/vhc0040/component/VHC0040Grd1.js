import { KtngConfirmDialog4 } from '@ktng/core/KtngConfirmDialog';
import KtngIbSheet from '@ktng/core/KtngIbSheet';
import KtngUtils from '@ktng/utils';
import { UutasToolBar } from '@ktng/uutas';
import _ from '@lodash';
import { Button } from '@material-ui/core';
import { Add, Remove } from '@material-ui/icons';
import { closeDialog, openDialog } from 'app/store/fuse/dialogSlice';
import { showMessage } from 'app/store/fuse/messageSlice';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
// import { getCodes, saveCodes } from '../store/codesSlice';
import { changeApproveTy, getVhc0040MstList, selectVhc0040MstList } from '../store/vhc0040MstSlice';
import sheetOptions from './VHC0040Opt1';

const sheetId = KtngUtils.getUid('vhc0040-grd1');

const VHC0040Grd1 = () => {
	const dispatch = useDispatch();
	// const classes = useStyles();

	const vhc0040MstList = useSelector(selectVhc0040MstList);

	const { uutasUser, vhc0040MstParams } = useSelector(({ auth, vhc0040 }) => ({
		uutasUser: auth.user.uutasUser || {},
		vhc0040MstParams: vhc0040.vhc0040Mst.params
	}));

	const [sheetObj, setSheetObj] = useState();
	const [grdData, setGrdData] = useState([]);

	// 1. 데이터 조회
	useEffect(() => {
		const { partCd } = uutasUser;
		const { fromYmd, toYmd, approveTy } = vhc0040MstParams;
		dispatch(getVhc0040MstList({ vhclDeptCd: partCd, fromYmd, toYmd, approveTy })).then(action => {
			const data = action.payload;
			if (data && data.list) {
				dispatch(showMessage({ message: `총 ${data.list.length}건이 조회되었습니다.` }));
			}
		});
	}, [dispatch]);

	// 2. 데이터 필터
	useEffect(() => {
		setGrdData(vhc0040MstList);
	}, [vhc0040MstList]);

	// 그리드 생성 콜백
	function onSheetLoad(sheet) {
		setSheetObj(sheet);
	}

	// 승인
	function handleBtnApprovalClick() {
		const selectedRows = sheetObj.getRowsByChecked('ckBox').map(row => ({
			// 추가/수정할 속성이름/값 나열
			..._.pick(row, ['approveTy', 'assignNo']),
			status: 'approval'
		}));

		if (selectedRows && selectedRows.length === 0) {
			dispatch(showMessage({ message: '저장할 내역이 없습니다.' }));
		} else {
			let message = '승인요청하시겠습니까?';
			for (let i = 0; i < selectedRows.length; i++) {
				// 승인
				if (selectedRows[i].approveTy === 'Y') {
					dispatch(showMessage({ message: '기승인건으로 취소처리만 가능합니다.' }));
					return;
				}
				if (selectedRows[i].approveTy === 'X' || selectedRows[i].approveTy === 'C') {
					message = `승인시에는 반려/취소 사유를 입력하실 수 없습니다.\n
						입력한 반려/취소 사유를 제거하고 승인하시겠습니까?`;
				}
			}

			dispatch(
				openDialog({
					children: (
						<KtngConfirmDialog4
							title="승인 확인"
							okClick={() => {
								dispatch(closeDialog());
								changeApproveType(selectedRows);
								// onValidationSuccessCallback();
							}}
							cancelClick={() => dispatch(closeDialog())}
						>
							{message}
						</KtngConfirmDialog4>
					)
				})
			);
		}
	}

	// 반려
	function handleBtnRejectClick() {
		const selectedRows = sheetObj.getRowsByChecked('ckBox').map(row => ({
			// 추가/수정할 속성이름/값 나열
			..._.pick(row, ['approveTy', 'assignNo', 'rejectCause']),
			status: 'reject'
		}));

		if (selectedRows && selectedRows.length === 0) {
			dispatch(showMessage({ message: '저장할 내역이 없습니다.' }));
		} else {
			for (let i = 0; i < selectedRows.length; i++) {
				// 승인
				if (selectedRows[i].approveTy === 'Y') {
					dispatch(showMessage({ message: '기승인건으로 취소처리만 가능합니다.' }));
					return;
				}
				// 반려
				if (selectedRows[i].approveTy === 'X') {
					dispatch(showMessage({ message: '기반려건으로 승인처리만 가능합니다.' }));
					return;
				}
				// 취소
				if (selectedRows[i].approveTy === 'X') {
					dispatch(showMessage({ message: '취소건으로 승인처리만 가능합니다.' }));
					return;
				}
			}

			// 미결
			// 입력값 검증
			KtngUtils.validationSaveData(
				/* 추가/수정/삭제 리스트 */
				selectedRows,

				/* 필수 입력해야하는 속성이름/한글명 나열 */
				{
					rejectCause: '반려/취소사유'
				},

				dispatch, // 함수 내부에서 메시지 출력을 할 수 있도록 넘겨줌

				/* validation 성공 시 콜백 */
				() => {
					changeApproveType(selectedRows);
				}
			);
		}
	}

	// 취소
	function handleBtnCancleClick() {
		const selectedRows = sheetObj.getRowsByChecked('ckBox').map(row => ({
			// 추가/수정할 속성이름/값 나열
			..._.pick(row, ['approveTy', 'assignNo', 'rejectCause']),
			status: 'cancle'
		}));

		if (selectedRows && selectedRows.length === 0) {
			dispatch(showMessage({ message: '저장할 내역이 없습니다.' }));
		} else {
			for (let i = 0; i < selectedRows.length; i++) {
				// 미결
				if (selectedRows[i].approveTy === 'R') {
					dispatch(showMessage({ message: '미결재건으로 승인 또는 반려처리만 가능합니다.' }));
					return;
				}
				// 반려
				if (selectedRows[i].approveTy === 'X') {
					dispatch(showMessage({ message: '반려건으로 승인처리만 가능합니다.' }));
					return;
				}
				// 취소
				if (selectedRows[i].approveTy === 'C') {
					dispatch(showMessage({ message: '기취소건으로 승인처리만 가능합니다.' }));
					return;
				}
			}

			// 승인
			// 입력값 검증
			KtngUtils.validationSaveData(
				/* 추가/수정/삭제 리스트 */
				selectedRows,

				/* 필수 입력해야하는 속성이름/한글명 나열 */
				{
					rejectCause: '반려/취소사유'
				},

				dispatch, // 함수 내부에서 메시지 출력을 할 수 있도록 넘겨줌

				/* validation 성공 시 콜백 */
				() => {
					changeApproveType(selectedRows);
				}
			);
		}
	}

	function changeApproveType(selectedRows) {
		dispatch(changeApproveTy({ selectedRows })).then(action => {
			const data = action.payload;
			if (data && data.success) {
				dispatch(showMessage({ message: '변경사항이 반영되었습니다.' }));
				// vha0010MstParams: 이전에 조회했던 파라미터로 조회
				dispatch(getVhc0040MstList(vhc0040MstParams));
			}
		});
	}

	return (
		<div className="flex flex-col w-full">
			<UutasToolBar title="그룹코드 목록" variant="subtitle1" sheet={sheetObj}>
				<Button aria-label="add" color="primary" onClick={handleBtnApprovalClick}>
					<Add />
					<span>승인</span>
				</Button>
				<Button aria-label="add" color="primary" onClick={handleBtnRejectClick}>
					<Remove />
					<span>반려</span>
				</Button>
				<Button aria-label="add" color="primary" onClick={handleBtnCancleClick}>
					<Remove />
					<span>취소</span>
				</Button>
			</UutasToolBar>

			<KtngIbSheet
				// [필수 속성]
				sheetId={sheetId}
				options={sheetOptions}
				data={grdData}
				// [선택 속성]
				// - 이벤트
				onLoad={onSheetLoad} // 생성된 sheet 객체 바인딩 및 공통코드 로드 수행
				//   ※ 아래 2개 외 필요한 이벤트는 `onSheetLoad`에서 직접 바인딩할 것
				// onAfterClick={onSheetClick} // 내부공통기능 수행 후 `onSheetClick` 콜백이 호출됨
				// onAfterChange={onSheetChange} // 내부공통기능 수행 후 `onSheetChange` 콜백이 호출됨
				// - 스타일 속성
				// className="" // tailwind 스타일 적용 가능
				style={{ height: '98%' }} // 그리드 초기 높이 설정시에는 style만 적용됨
			/>
		</div>
	);
};

export default VHC0040Grd1;
