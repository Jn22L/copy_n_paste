import { useCmmCodeLoadEffect } from '@ktng/hooks';
import KtngUtils from '@ktng/utils';
import { UutasForm, UutasToolBar } from '@ktng/uutas';
import { TextField, Input, MenuItem, Select } from '@material-ui/core';
import { KeyboardDatePicker } from '@material-ui/pickers';
import { showMessage } from 'app/store/fuse/messageSlice';
import moment from 'moment';
import React, { useRef, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getVhc0040MstList } from '../store/vhc0040MstSlice';

const formSchema = [
	// row 1
	[
		// col 1
		{
			id: 'applyEmp',
			label: '결재자',
			width: 200,
			align: 'center',
			required: false
		},
		// col 2
		{
			id: 'fromToYmd',
			label: '출발기간',
			width: 400,
			align: 'center',
			required: true
		},
		// col 3
		{
			id: 'approveTy',
			label: '구분',
			width: 150,
			align: 'center',
			required: true
		}
	]
];

const VHC0040Srch = () => {
	const dispatch = useDispatch();

	// 입력된 값의 유효성검사를 하기위해 `useRef`로 폼입력컨트롤의 DOM에 접근한다
	const srchRef = useRef();

	const { uutasUser, vhc0040MstParams } = useSelector(({ auth, vhc0040 }) => ({
		uutasUser: auth.user.uutasUser || {},
		vhc0040MstParams: vhc0040.vhc0040Mst.params
	}));

	const [reqCodes] = useState([{ commCodeChk: 'VHCL_DEPT_CD' }]); // 불러올 공통코드 리스트
	const [expanded, setExpanded] = useState(true);

	// 폼 입력값
	const [applyEmpNo, setApplyEmpNo] = useState(uutasUser.empNo || ''); // 결재자 사번
	const [applyEmpNm, setApplyEmpNm] = useState(uutasUser.empNm || ''); // 결재자 이름
	const [vhclDeptCd, setVhclDeptCd] = useState(uutasUser.partCd || ''); // 결재자 부서코드
	const [fromYmd, setFromYmd] = useState(moment(vhc0040MstParams.fromYmd).format('yyyy.MM.DD')); // 출발 시작일
	const [toYmd, setToYmd] = useState(moment(vhc0040MstParams.toYmd).format('yyyy.MM.DD')); // 출발 종료일
	const [approveTy, setApproveTy] = useState(vhc0040MstParams.approveTy); // 구분

	// 공통코드 리스트 불러오기 (이미 store에 있으면 요청안함)
	useCmmCodeLoadEffect(() => {}, [reqCodes]);

	function onBtnSearchClick() {
		const validationComps = [
			// { key: '그룹코드명', value: commCodeName, type: 'text', required: false, maxLength: 20 }
		];

		if (KtngUtils.validationComps(validationComps, dispatch, srchRef)) {
			dispatch(
				getVhc0040MstList({
					vhclDeptCd,
					fromYmd: moment(fromYmd).format('yyyyMMDD'),
					toYmd: moment(toYmd).format('yyyyMMDD'),
					approveTy
				})
			);
		}
	}

	// // 검사시작일자 변경 저장
	const onChangeFromYmd = date => {
		if (moment(date).isValid() && moment(toYmd).isValid() && moment(date).isAfter(toYmd)) {
			dispatch(showMessage({ message: '시작일자는 종료일자보다 클 수 없습니다.', variant: 'error' }));
			return;
		}
		setFromYmd(date);
	};

	// 검사종료일자 변경 저장
	const onChangeToYmd = date => {
		if (moment(fromYmd).isValid() && moment(date).isValid() && moment(fromYmd).isAfter(date)) {
			dispatch(showMessage({ message: '종료일자는 시작일자보다 작을 수 없습니다.', variant: 'error' }));
			return;
		}
		setToYmd(date);
	};

	return (
		<>
			{/* 검색조건 툴바 */}
			<UutasToolBar onBtnSearchClick={onBtnSearchClick} expanded={expanded} onBtnToggleClick={setExpanded} />

			{/* 검색조건 입력폼 */}
			<UutasForm
				srchRef={srchRef}
				expanded={expanded}
				schema={formSchema}
				// 결재자
				applyEmp={
					<div className="flex flex-1 px-8">
						<Input
							className="w-96 mx-4"
							placeholder="사번"
							fullWidth
							type="text"
							value={applyEmpNo}
							inputProps={{ readOnly: true, minLength: 2, maxLength: 10 }}
						/>
						<Input
							className="w-64 mx-4"
							placeholder="이름"
							fullWidth
							type="text"
							value={applyEmpNm}
							inputProps={{ readOnly: true, minLength: 2, maxLength: 10 }}
						/>
					</div>
				}
				// 출발기간
				fromToYmd={
					<>
						<KeyboardDatePicker
							className="w-136"
							format="yyyy.MM.dd"
							value={fromYmd}
							onChange={dateTime => onChangeFromYmd(dateTime)}
						/>
						<div className="inline ml-16 mr-16">~</div>
						<KeyboardDatePicker
							className="w-136"
							format="yyyy.MM.dd"
							value={toYmd}
							onChange={dateTime => onChangeToYmd(dateTime)}
						/>
					</>
				}
				// 구분
				approveTy={
					<Select
						labelId="search-type"
						id="search-type"
						className="min-w-80"
						disableUnderline
						value={approveTy}
						onChange={e => {
							setApproveTy(e.target.value);
						}}
					>
						<MenuItem value="R">미결</MenuItem>
						<MenuItem value="Y">승인</MenuItem>
						<MenuItem value="X">반려</MenuItem>
						<MenuItem value="C">취소</MenuItem>
					</Select>
				}
			/>
		</>
	);
};

export default VHC0040Srch;
