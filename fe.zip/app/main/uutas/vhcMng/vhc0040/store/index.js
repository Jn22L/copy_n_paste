import { combineReducers } from 'redux';
import vhc0040Mst from './vhc0040MstSlice';

const reducer = combineReducers({
	vhc0040Mst
});

export default reducer;
