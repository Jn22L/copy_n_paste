import KtngUtils from '@ktng/utils';
import { createAsyncThunk, createEntityAdapter, createSlice } from '@reduxjs/toolkit';
import vhc0040Service from 'app/services/vhc0040Service';
import moment from 'moment';
import { format } from 'date-fns';

export const getVhc0040MstList = createAsyncThunk(
	'vhc0040/vhc0040Mst/getVhc0040MstList',
	async ({ vhclDeptCd, fromYmd, toYmd, approveTy }, { dispatch, rejectWithValue }) => {
		try {
			const data = await vhc0040Service.selectApprovalMngList({ vhclDeptCd, fromYmd, toYmd, approveTy });
			return {
				list: data.list,
				params: {
					// [필수아님] 서버에 요청할 때 사용했던 파라미터 저장
					vhclDeptCd,
					fromYmd,
					toYmd,
					approveTy
				}
			};
		} catch (err) {
			throw KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

export const changeApproveTy = createAsyncThunk(
	'vhc0040/vhc0040Mst/changeApproveTy',
	async ({ selectedRows }, { dispatch, rejectWithValue }) => {
		try {
			const data = await vhc0040Service.changeApproveTy(selectedRows);
			return data;
		} catch (err) {
			throw KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

const vhc0040MstAdapter = createEntityAdapter({
	selectId: vhc0040Mst => vhc0040Mst.assignNo
});

export const { selectAll: selectVhc0040MstList, selectById: selectAssignNoById } = vhc0040MstAdapter.getSelectors(
	state => state.vhc0040.vhc0040Mst
);

const initialState = {
	params: {
		applyEmpNo: '',
		applyEmpNm: '',
		fromYmd: moment().format('yyyyMMDD'),
		toYmd: moment().add(1, 'month').format('yyyyMMDD'),
		approveTy: 'R'
	},
	filters: {
		commCodeName: ''
	},
	loading: false
};

const vhc0040MstSlice = createSlice({
	name: 'vhc0040/vhc0040Mst',
	initialState: vhc0040MstAdapter.getInitialState(initialState),
	reducers: {
		changeGrpCodesFilter: (state, action) => {
			state.filters = {
				...state.filters,
				...action.payload
			};
		},
		clearGrpCodesFilter: state => {
			state.filters = initialState.filters;
		},
		changeGrpCode: vhc0040MstAdapter.updateOne,
		changeGrpCodes: vhc0040MstAdapter.updateMany,
		clearGrpCodes: vhc0040MstAdapter.removeAll
	},
	extraReducers: {
		[getVhc0040MstList.pending]: state => {
			state.loading = true;
		},
		[getVhc0040MstList.fulfilled]: (state, action) => {
			const { list, params } = action.payload;

			vhc0040MstAdapter.setAll(state, list);
			state.params = params;
			state.loading = false;
		},
		[getVhc0040MstList.rejected]: state => {
			state.loading = false;
		}
	}
});

export const {
	changeGrpCodesFilter,
	clearGrpCodesFilter,
	changeGrpCode,
	changeGrpCodes,
	clearGrpCodes
} = vhc0040MstSlice.actions;

export default vhc0040MstSlice.reducer;
