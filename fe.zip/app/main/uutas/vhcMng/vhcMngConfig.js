import VHC0030Config from './vhc0030/VHC0030Config';
import VHC0040Config from './vhc0040/VHC0040Config';

// 리스트로 된 Config는 파일명 소문자로 시작
const vhcMngConfig = [
	// TODO: VHC0010 신청건 배차
	// TODO: VHC0020 배차관리
	VHC0030Config, // 결재 상신
	VHC0040Config // 결재 관리
];

export default vhcMngConfig;
