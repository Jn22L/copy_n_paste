import VHC0030Page from './VHC0030Page';

// `메뉴경로` - `화면` 맵핑 정보를 가진 Config는 파일명 대문자로 시작
const VHC0030Config = {
	routes: [
		{
			path: '/vhcMng/vhc0030', // 화면에 접근할 때 사용할 URL을 설정
			component: VHC0030Page // 접근할 화면의 컴포넌트를 설정
		}
	]
};

export default VHC0030Config;
