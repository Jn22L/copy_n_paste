import KtngUtils from '@ktng/utils';
import { createAsyncThunk, createEntityAdapter, createSlice } from '@reduxjs/toolkit';
import vhc0030Service from 'app/services/vhc0030Service';
import moment from 'moment';

export const getVhc0030MstList = createAsyncThunk(
	'vhc0030/vhc0030Mst/getVhc0030MstList',
	async ({ vhclDeptCd, fromYmd, toYmd, approveTy }, { dispatch, rejectWithValue }) => {
		
		console.log("vhclDeptCd : "+vhclDeptCd);
		console.log("fromYmd : "+fromYmd);
		console.log("toYmd : "+toYmd);
		console.log("approveTy : "+approveTy);

		try {
			const data = await vhc0030Service.selectApprovalList({ vhclDeptCd, fromYmd, toYmd, approveTy });
			return {
				list: data.list,
				params: {
					// [필수아님] 서버에 요청할 때 사용했던 파라미터 저장
					vhclDeptCd,
					fromYmd,
					toYmd,
					approveTy
				}
			};
		} catch (err) {
			throw KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

export const changeApproveTy = createAsyncThunk(
	'vhc0030/vhc0030Mst/changeApproveTy',
	async ({ selectedRows }, { dispatch, rejectWithValue }) => {
		try {
			const data = await vhc0030Service.changeApproveTy(selectedRows);
			return data;
		} catch (err) {
			throw KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

const vhc0030MstAdapter = createEntityAdapter({
	selectId: vhc0030Mst => vhc0030Mst.assignNo
});

export const { selectAll: selectVhc0030MstList, selectById: selectAssignNoById } = vhc0030MstAdapter.getSelectors(
	state => state.vhc0030.vhc0030Mst
);

const initialState = {
	params: {
		vhclDeptCd: '',
		fromYmd: moment().format('yyyyMMDD'),
		toYmd: moment().add(1, 'month').format('yyyyMMDD'),
		approveTy: 'N'
	},
	filters: {
		commCodeName: ''
	},
	loading: false
};

const vhc0030MstSlice = createSlice({
	name: 'vhc0030/vhc0030Mst',
	initialState: vhc0030MstAdapter.getInitialState(initialState),
	reducers: {
		changeGrpCodesFilter: (state, action) => {
			state.filters = {
				...state.filters,
				...action.payload
			};
		},
		clearGrpCodesFilter: state => {
			state.filters = initialState.filters;
		},
		changeGrpCode: vhc0030MstAdapter.updateOne,
		changeGrpCodes: vhc0030MstAdapter.updateMany,
		clearGrpCodes: vhc0030MstAdapter.removeAll
	},
	extraReducers: {
		[getVhc0030MstList.pending]: state => {
			state.loading = true;
		},
		[getVhc0030MstList.fulfilled]: (state, action) => {
			const { list, params } = action.payload;

			vhc0030MstAdapter.setAll(state, list);
			state.params = params;
			state.loading = false;
		},
		[getVhc0030MstList.rejected]: state => {
			state.loading = false;
		}
	}
});

export const {
	changeGrpCodesFilter,
	clearGrpCodesFilter,
	changeGrpCode,
	changeGrpCodes,
	clearGrpCodes
} = vhc0030MstSlice.actions;

export default vhc0030MstSlice.reducer;
