import { combineReducers } from 'redux';
import vhc0030Mst from './vhc0030MstSlice';

const reducer = combineReducers({
	vhc0030Mst
});

export default reducer;
