// **************************************************************************
// 파    일    명   : VHC0030Page.js
// 업  무   분  류  : 배차관리
// 업    무    명   : 결재상신
// 프로그램   내용   : 배차신청된 데이터를 '결재요청/상신취소'하는 화면
// 기          타   :
// ==========================================================================
// 작    성    자   : 심주용
// 작    성    일   : 2021.12.21
// 최종    수정일   :
// 변 경    이 력   :
// **************************************************************************

import React from 'react';
import { useSelector } from 'react-redux';
import withReducer from 'app/store/withReducer';
import { UutasPageSimple } from '@ktng/uutas';
import { VHC0030Srch, VHC0030Grd1 } from './component';
import reducer from './store';

// vhcMng/vhc0030/vhc0030
const VHC0030Page = () => {
	const { vhc0030MstLoading } = useSelector(({ vhc0030 }) => ({
		vhc0030MstLoading: vhc0030.vhc0030Mst.loading
	}));

	return (
		<UutasPageSimple title="결재상신" loading={vhc0030MstLoading}>
			{/* 검색조건 */}
			<VHC0030Srch />

			{/* 결재내역 목록 그리드 */}
			<div className="flex flex-1">
				<VHC0030Grd1 />
			</div>
		</UutasPageSimple>
	);
};

export default withReducer('vhc0030', reducer)(VHC0030Page);
