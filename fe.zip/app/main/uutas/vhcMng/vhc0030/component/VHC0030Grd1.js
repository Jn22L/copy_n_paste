import KtngIbSheet from '@ktng/core/KtngIbSheet';
import KtngUtils from '@ktng/utils';
import { UutasToolBar } from '@ktng/uutas';
import _ from '@lodash';
import { Button } from '@material-ui/core';
import { Add, Remove } from '@material-ui/icons';
import { showMessage } from 'app/store/fuse/messageSlice';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
// import { getCodes, saveCodes } from '../store/codesSlice';
import { getVhc0030MstList, changeApproveTy, selectVhc0030MstList } from '../store/vhc0030MstSlice';
import sheetOptions from './VHC0030Opt1';

const sheetId = KtngUtils.getUid('vhc0030-grd1');

const VHC0030Grd1 = () => {
	const dispatch = useDispatch();
	// const classes = useStyles();

	const vhc0030MstList = useSelector(selectVhc0030MstList);

	const { vhc0030MstParams } = useSelector(({ vhc0030 }) => ({
		vhc0030MstParams: vhc0030.vhc0030Mst.params
	}));

	const [sheetObj, setSheetObj] = useState();
	const [grdData, setGrdData] = useState([]);

	// 1. 데이터 조회
	useEffect(() => {
		const { vhclDeptCd, fromYmd, toYmd, approveTy } = vhc0030MstParams;
		dispatch(getVhc0030MstList({ vhclDeptCd, fromYmd, toYmd, approveTy })).then(action => {
			const data = action.payload;
			if (data && data.list) {
				dispatch(showMessage({ message: `총 ${data.list.length}건이 조회되었습니다.` }));
			}
		});
		// eslint-disable-next-line
	}, [dispatch]);

	// 2. 데이터 필터
	useEffect(() => {
		setGrdData(vhc0030MstList);
	}, [vhc0030MstList]);

	// 그리드 생성 콜백
	function onSheetLoad(sheet) {
		setSheetObj(sheet);
	}

	// 결재상신
	function handleBtnApprovalClick() {
		const selectedRows = sheetObj.getRowsByChecked('ckBox').map(row => ({
			// 추가/수정할 속성이름/값 나열
			..._.pick(row, ['approveTy', 'assignNo']),
			status: 'approval'
		}));

		if (selectedRows && selectedRows.length === 0) {
			dispatch(showMessage({ message: '저장할 내역이 없습니다.' }));
		} else {
			for (let i = 0; i < selectedRows.length; i++) {
				// 결재전
				if (selectedRows[i].approveTy === 'R') {
					dispatch(showMessage({ message: '기상신건으로 상신취소처리만 가능합니다.' }));
					return;
				}
				// 승인
				if (selectedRows[i].approveTy === 'Y') {
					dispatch(showMessage({ message: '기승인건으로 재요청 할 수 없습니다.' }));
					return;
				}
			}
			changeApproveType(selectedRows);
		}
	}

	// 상신취소
	function handleBtnCancleClick() {
		const selectedRows = sheetObj.getRowsByChecked('ckBox').map(row => ({
			// 추가/수정할 속성이름/값 나열
			..._.pick(row, ['approveTy', 'assignNo']),
			status: 'cancle'
		}));

		if (selectedRows && selectedRows.length === 0) {
			dispatch(showMessage({ message: '저장할 내역이 없습니다.' }));
		} else {
			for (let i = 0; i < selectedRows.length; i++) {
				// 미상신
				if (selectedRows[i].approveTy === 'N') {
					dispatch(showMessage({ message: '미상신건으로 결재요청처리만 가능합니다.' }));
					return;
				}
				// 승인
				if (selectedRows[i].approveTy === 'Y') {
					dispatch(showMessage({ message: '기승인건으로 상신취소 할 수 없습니다.' }));
					return;
				}
				// 반려
				if (selectedRows[i].approveTy === 'X') {
					dispatch(showMessage({ message: '반려건으로 결재요청처리만 가능합니다.' }));
					return;
				}
				// 취소
				if (selectedRows[i].approveTy === 'C') {
					dispatch(showMessage({ message: '취소건으로 결재요청처리만 가능합니다.' }));
					return;
				}
			}
			changeApproveType(selectedRows);
		}
	}

	function changeApproveType(selectedRows) {
		dispatch(changeApproveTy({ selectedRows })).then(action => {
			const data = action.payload;
			if (data && data.success) {
				dispatch(showMessage({ message: '변경사항이 반영되었습니다.' }));
				// vha0010MstParams: 이전에 조회했던 파라미터로 조회
				dispatch(getVhc0030MstList(vhc0030MstParams));
			}
		});
	}

	return (
		<div className="flex flex-col w-full">
			<UutasToolBar title="그룹코드 목록" variant="subtitle1" sheet={sheetObj}>
				<Button aria-label="add" color="primary" onClick={handleBtnApprovalClick}>
					<Add />
					<span>결재상신</span>
				</Button>
				<Button aria-label="add" color="primary" onClick={handleBtnCancleClick}>
					<Remove />
					<span>상신취소</span>
				</Button>
			</UutasToolBar>

			<KtngIbSheet
				// [필수 속성]
				sheetId={sheetId}
				options={sheetOptions}
				data={grdData}
				// [선택 속성]
				// - 이벤트
				onLoad={onSheetLoad} // 생성된 sheet 객체 바인딩 및 공통코드 로드 수행
				//   ※ 아래 2개 외 필요한 이벤트는 `onSheetLoad`에서 직접 바인딩할 것
				// onAfterClick={onSheetClick} // 내부공통기능 수행 후 `onSheetClick` 콜백이 호출됨
				// onAfterChange={onSheetChange} // 내부공통기능 수행 후 `onSheetChange` 콜백이 호출됨
				// - 스타일 속성
				// className="" // tailwind 스타일 적용 가능
				style={{ height: '98%' }} // 그리드 초기 높이 설정시에는 style만 적용됨
			/>
		</div>
	);
};

export default VHC0030Grd1;
