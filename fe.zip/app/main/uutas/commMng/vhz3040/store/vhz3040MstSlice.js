import { createSlice, createAsyncThunk, createEntityAdapter } from '@reduxjs/toolkit';
import KtngUtils from '@ktng/utils';
import vhz3040Service from 'app/services/vhz3040Service';

export const getAdmIps = createAsyncThunk(
	'vhz3040/vhz3040Mst/getAdmIps',
	async ({ empNo, ipAddr }, { dispatch, rejectWithValue }) => {
		try {
			const data = await vhz3040Service.selectAdmIpList(empNo, ipAddr);
			return {
				list: data.list,
				params: {
					empNo,
					ipAddr
				}
			};
		} catch (err) {
			throw KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

export const saveAdmIps = createAsyncThunk(
	'vhz3040/vhz3040Mst/saveAdmIps',
	async ({ admIpList }, { dispatch, rejectWithValue }) => {
		try {
			const data = await vhz3040Service.save(admIpList);
			return data;
		} catch (err) {
			throw KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

const admIpsAdapter = createEntityAdapter({
	selectId: adm => `${adm.empNo}.${adm.ipAddr}`
});

export const { selectAll: selectAdmIps, selectById: selectAdmIpById } = admIpsAdapter.getSelectors(
	state => state.vhz3040.vhz3040Mst
);

const initialState = {
	params: {
		empNo: '',
		ipAddr: ''
	},
	loading: false
};

const vhz3040MstSlice = createSlice({
	name: 'vhz3040/vhz3040Mst',
	initialState: admIpsAdapter.getInitialState(initialState),
	reducers: {
		changeAdmIpsFilter: (state, action) => {
			state.filters = {
				...state.filters,
				...action.payload
			};
		},
		clearAdmIpsFilter: state => {
			state.filters = initialState.filters;
		},
		changeAdmIp: admIpsAdapter.updateOne,
		changeAdmIps: admIpsAdapter.updateMany,
		clearAdmIps: admIpsAdapter.removeAll
	},
	extraReducers: {
		[getAdmIps.pending]: state => {
			state.loading = true;
		},
		[getAdmIps.fulfilled]: (state, action) => {
			const { list, params } = action.payload;
			admIpsAdapter.setAll(state, list);
			state.params = params;
			state.loading = false;
		},
		[getAdmIps.rejected]: state => {
			state.loading = false;
		},
		[saveAdmIps.pending]: state => {
			state.loading = true;
		},
		[saveAdmIps.fulfilled]: state => {
			state.loading = false;
		},
		[saveAdmIps.rejected]: state => {
			state.loading = false;
		}
	}
});

export const {
	changeAdmIpsFilter,
	clearAdmIpsFilter,
	changeAdmIp,
	changeAdmIps,
	clearAdmIps
} = vhz3040MstSlice.actions;

export default vhz3040MstSlice.reducer;
