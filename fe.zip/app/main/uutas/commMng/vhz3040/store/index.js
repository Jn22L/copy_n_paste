import { combineReducers } from 'redux';
import vhz3040Mst from './vhz3040MstSlice';

const reducer = combineReducers({
	vhz3040Mst
});

export default reducer;
