// **************************************************************************
// 파    일    명   : VHZ3040Page.js
// 업무      분류   :
// 업    무    명   : 관리자IP등록
// 프로그램   내용   :
// 기          타   :
// ==========================================================================
// 작    성    자   :
// 작    성    일   : 2021.12.23
// 최종    수정일   :
// 변 경    이 력   :
// **************************************************************************

import React from 'react';
import { useSelector } from 'react-redux';
import withReducer from 'app/store/withReducer';
import { UutasPageSimple } from '@ktng/uutas';
import { VHZ3040Srch, VHZ3040Grd1 } from './component';
import reducer from './store';

// /cmmnMng/authMng/vhz3040
const VHZ3040Page = () => {
	const { dataLoading } = useSelector(({ vhz3040 }) => ({
		dataLoading: vhz3040.vhz3040Mst.loading
	}));

	return (
		<UutasPageSimple title="관리자IP등록" loading={dataLoading}>
			{/* 검색조건 */}
			<VHZ3040Srch />

			{/* 프로그램 목록 */}
			<div className="flex flex-1">
				<VHZ3040Grd1 />
			</div>
		</UutasPageSimple>
	);
};

export default withReducer('vhz3040', reducer)(VHZ3040Page);
