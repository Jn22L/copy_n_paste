import React, { useState, useRef } from 'react';
import { useDispatch } from 'react-redux';
import { Input } from '@material-ui/core';
import { UutasToolBar, UutasForm } from '@ktng/uutas';
import KtngUtils from '@ktng/utils';
import { showMessage } from 'app/store/fuse/messageSlice';
import { getAdmIps } from '../store/vhz3040MstSlice';

const formSchema = [
	// row 1
	[
		// col 1
		{
			id: 'empNo',
			label: '사번',
			width: 150,
			align: 'center',
			required: false
		},
		// col 2
		{
			id: 'ipAddr',
			label: 'IP주소',
			width: 150,
			align: 'center',
			required: false
		}
	]
];

const VHZ3040Srch = () => {
	const dispatch = useDispatch();

	// 입력된 값의 유효성검사를 하기위해 `useRef`로 폼입력컨트롤의 DOM에 접근한다
	const srchRef = useRef();

	const [expanded, setExpanded] = useState(true);

	// 폼 입력값
	const [empNo, setEmpNo] = useState('');
	const [ipAddr, setIpAddr] = useState('');

	function onBtnSearchClick() {
		const validationComps = [
			{ key: '사번', value: empNo, type: 'text', required: false, maxLength: 20 },
			{ key: 'IP주소', value: ipAddr, type: 'text', required: false, maxLength: 20 }
		];

		if (KtngUtils.validationComps(validationComps, dispatch, srchRef)) {
			// 변경된 검색조건 으로 조회
			dispatch(getAdmIps({ empNo, ipAddr })).then(action => {
				const data = action.payload;
				if (data && data.list) {
					dispatch(showMessage({ message: `총 ${data.list.length}건이 조회되었습니다.` }));
				}
			}); // DB 에서 조회
		}
	}

	return (
		<>
			{/* 검색조건 툴바 */}
			<UutasToolBar onBtnSearchClick={onBtnSearchClick} expanded={expanded} onBtnToggleClick={setExpanded} />

			{/* 검색조건 입력폼 */}
			<UutasForm
				srchRef={srchRef}
				expanded={expanded}
				schema={formSchema}
				// 사번
				empNo={
					<Input
						className="flex flex-1 px-8"
						placeholder="사번"
						fullWidth
						type="text"
						value={empNo}
						inputProps={{ maxLength: 20 }}
						onChange={e => setEmpNo(e.target.value)}
						onKeyUp={e => {
							if (e.key === 'Enter') {
								onBtnSearchClick();
							}
						}}
					/>
				}
				// IP주소
				ipAddr={
					<Input
						className="flex flex-1 px-8"
						placeholder="IP주소"
						fullWidth
						type="text"
						value={ipAddr}
						inputProps={{ maxLength: 20 }}
						onChange={e => setIpAddr(e.target.value)}
						onKeyUp={e => {
							if (e.key === 'Enter') {
								onBtnSearchClick();
							}
						}}
					/>
				}
			/>
		</>
	);
};

export default VHZ3040Srch;
