import VHZ3040Page from './VHZ3040Page';

// `메뉴경로` - `화면` 맵핑 정보를 가진 Config는 파일명 대문자로 시작
const VHZ3040Config = {
	routes: [
		{
			path: '/cmmnMng/authMng/vhz3040',
			component: VHZ3040Page
		}
	]
};

export default VHZ3040Config;
