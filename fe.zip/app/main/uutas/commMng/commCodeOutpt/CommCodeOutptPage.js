// **************************************************************************
// 파    일    명   : CommCodeOutptPage.js
// 업무      분류  : 공통코드출력
// 업    무    명   : 공통코드출력
// 프로그램   내용   : 공통코드를 조회하는 화면
// 기          타   :
// ==========================================================================
// 작    성    자   : 김 민 우
// 작    성    일   : 2021.12.16
// 최종    수정일   :
// 변 경    이 력   :
// **************************************************************************

import React from 'react';
import { useSelector } from 'react-redux';
import withReducer from 'app/store/withReducer';
import { UutasPageSimple } from '@ktng/uutas';
import { CommCodeOutptSrch, CommCodeOutptGrd1 } from './component';
import reducer from './store';

// cmmnMng/cmmnCdMng/cmmnCdOutpt
const CommCodeOutptPage = () => {
	const { codesLoading, grpCodesLoading } = useSelector(({ commCodeOutpt }) => ({
		codesLoading: commCodeOutpt.codes.loading,
		grpCodesLoading: commCodeOutpt.grpCodes.loading
	}));

	return (
		<UutasPageSimple title="공통코드관리" loading={codesLoading || grpCodesLoading}>
			{/* 검색조건 */}
			<CommCodeOutptSrch />

			{/* 그룹코드 목록 */}
			<div className="flex flex-1">
				<CommCodeOutptGrd1 />
			</div>
		</UutasPageSimple>
	);
};

export default withReducer('commCodeOutpt', reducer)(CommCodeOutptPage);
