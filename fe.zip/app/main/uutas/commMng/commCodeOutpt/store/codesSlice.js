import { createSlice, createAsyncThunk, createEntityAdapter } from '@reduxjs/toolkit';
import KtngUtils from '@ktng/utils';
import codeService from 'app/services/codeService';

export const getCodes = createAsyncThunk(
	'commCodeOutpt/codes/getCodes',
	async ({ commCodeChk, commCode }, { dispatch, rejectWithValue }) => {
		try {
			const data = await codeService.list(commCodeChk, commCode);
			return {
				list: data.list,
				params: {
					commCodeChk,
					commCode
				}
			};
		} catch (err) {
			throw KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

const codesAdapter = createEntityAdapter({
	selectId: code => `${code.commCodeChk}.${code.commCode}`
});

export const { selectAll: selectCodes, selectById: selectCodeById } = codesAdapter.getSelectors(
	state => state.commCodeOutpt.codes
);

const initialState = {
	params: {
		commCodeChk: '',
		commCode: ''
	},
	loading: false
};

const codesSlice = createSlice({
	name: 'commCodeOutpt/codes',
	initialState: codesAdapter.getInitialState(initialState),
	reducers: {
		changeCode: codesAdapter.updateOne,
		changeCodes: codesAdapter.updateMany,
		clearCodes: codesAdapter.removeAll
	},
	extraReducers: {
		[getCodes.pending]: state => {
			state.loading = true;
		},
		[getCodes.fulfilled]: (state, action) => {
			const { list, params } = action.payload;
			codesAdapter.setAll(state, list);
			state.params = params;
			state.loading = false;
		},
		[getCodes.rejected]: state => {
			state.loading = false;
		}
	}
});

export const { changeCode, changeCodes, clearCodes } = codesSlice.actions;

export default codesSlice.reducer;
