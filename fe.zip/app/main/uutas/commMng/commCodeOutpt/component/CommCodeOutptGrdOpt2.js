const options = {
	Cfg: {
		CanSelect: true, // 시트 선택 가능
		SelectingCells: 0, // 개별 셀 선택 불가능
		CanEdit: 0, // 수정 불가능
		CustomScroll: 1 // 그리드와 스크롤 겹침 이슈 처리
	},
	Def: {
		// Col: { RelWidth: 1 }
	},
	Cols: [
		{
			Header: '공통코드',
			Name: 'commCode',
			Type: 'Text',
			Align: 'Center',
			Required: 1,
			RelWidth: 1
		},
		{
			Header: '공통코드명',
			Name: 'commCodeName',
			Type: 'Text',
			Align: 'Center',
			Required: 1,
			RelWidth: 1
		},
		{
			Header: '정렬순서',
			Name: 'seq',
			Type: 'Text',
			Align: 'Center',
			Required: 1,
			RelWidth: 1
		}
	]
};

export default options;
