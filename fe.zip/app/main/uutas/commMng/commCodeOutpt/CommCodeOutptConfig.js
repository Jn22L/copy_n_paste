import CommCodeOutptPage from './CommCodeOutptPage';

// `메뉴경로` - `화면` 맵핑 정보를 가진 Config는 파일명 대문자로 시작
const CommCodeOutptConfig = {
	routes: [
		{
			path: '/cmmnMng/cmmnCdMng/cmmnCdOutpt',
			component: CommCodeOutptPage
		}
	]
};

export default CommCodeOutptConfig;
