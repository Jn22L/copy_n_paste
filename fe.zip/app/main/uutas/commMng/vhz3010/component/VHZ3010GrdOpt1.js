const options = {
	Cfg: {
		CanSelect: true, // 시트 선택 가능
		SelectingCells: 1, // 개별 셀 선택 가능
		CanEdit: 1, // 수정 가능
		CustomScroll: 1 // 그리드와 스크롤 겹침 이슈 처리
	},
	Def: {
		// 2.2. Row: 그리드의 전체 행에 일괄적으로 적용할 설정
		Row: {
			CanFormula: 1, // {attribute}Formula 사용설정 Ex) `CanEditFormula`: 셀 수정가능 여부를 동적으로 결정할 수 있음
			CalcOrder: 'roleCdCanEdit' // Formula 계산순서 설정
		}
	},
	Cols: [
		{
			Header: {
				Value: '삭제',
				HeaderCheck: 1
			},
			Type: 'Bool',
			Name: 'delYn',
			Align: 'center',
			DefaultValue: false,
			NoChanged: true
		},
		{
			Header: '상태',
			Name: 'rowStatus',
			Type: 'Enum',
			Align: 'center',
			DefaultValue: 'N',
			Enum: '||추가|수정|삭제',
			EnumKeys: '|N|I|U|D',
			CanEdit: 0,
			NoChanged: true
		},
		{
			Header: '권한코드',
			Name: 'roleCd',
			Type: 'Text',
			Align: 'center',
			CanEditFormula: param => {
				const { rowStatus } = param.Row;
				// `추가` 상태에서만 수정가능
				return rowStatus === 'I';
			},
			Required: 1,
			RelWidth: 1
		},
		{
			Header: '권한명',
			Name: 'roleNm',
			Type: 'Text',
			Align: 'center',
			CanEdit: 1,
			Required: 1,
			RelWidth: 1
		},
		{
			Header: '권한설명',
			Name: 'rmk',
			Type: 'Text',
			Align: 'left',
			CanEdit: 1,
			RelWidth: 2
		}
	]
};

export default options;
