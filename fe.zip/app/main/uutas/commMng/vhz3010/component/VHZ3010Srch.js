import React, { useState, useRef } from 'react';
import { useDispatch } from 'react-redux';
import { Input } from '@material-ui/core';
import { UutasToolBar, UutasForm } from '@ktng/uutas';
import KtngUtils from '@ktng/utils';
import { showMessage } from 'app/store/fuse/messageSlice';
import { getRoles } from '../store/vhz3010MstSlice';

const formSchema = [
	// row 1
	[
		// col 1
		{
			id: 'roleCd',
			label: '권한ID',
			width: 150,
			align: 'center',
			required: false
		},
		// col 2
		{
			id: 'roleNm',
			label: '권한명',
			width: 150,
			align: 'center',
			required: false
		}
	]
];

const VHZ3010Srch = () => {
	const dispatch = useDispatch();

	// 입력된 값의 유효성검사를 하기위해 `useRef`로 폼입력컨트롤의 DOM에 접근한다
	const srchRef = useRef();

	const [expanded, setExpanded] = useState(true);

	// 폼 입력값
	const [roleCd, setRoleCd] = useState('');
	const [roleNm, setRoleNm] = useState('');

	function onBtnSearchClick() {
		const validationComps = [
			{ key: '권한ID', value: roleCd, type: 'text', required: false, maxLength: 20 },
			{ key: '권한명', value: roleNm, type: 'text', required: false, maxLength: 20 }
		];

		if (KtngUtils.validationComps(validationComps, dispatch, srchRef)) {
			// 변경된 검색조건 으로 조회
			dispatch(getRoles({ roleCd, roleNm })).then(action => {
				const data = action.payload;
				if (data && data.list) {
					dispatch(showMessage({ message: `총 ${data.list.length}건이 조회되었습니다.` }));
				}
			}); // DB 에서 조회
		}
	}

	return (
		<>
			{/* 검색조건 툴바 */}
			<UutasToolBar onBtnSearchClick={onBtnSearchClick} expanded={expanded} onBtnToggleClick={setExpanded} />

			{/* 검색조건 입력폼 */}
			<UutasForm
				srchRef={srchRef}
				expanded={expanded}
				schema={formSchema}
				// 권한ID
				roleCd={
					<Input
						className="flex flex-1 px-8"
						placeholder="권한ID"
						fullWidth
						type="text"
						value={roleCd}
						inputProps={{ maxLength: 20 }}
						onChange={e => setRoleCd(e.target.value)}
						onKeyUp={e => {
							if (e.key === 'Enter') {
								onBtnSearchClick();
							}
						}}
					/>
				}
				// 권한명
				roleNm={
					<Input
						className="flex flex-1 px-8"
						placeholder="권한명"
						fullWidth
						type="text"
						value={roleNm}
						inputProps={{ maxLength: 20 }}
						onChange={e => setRoleNm(e.target.value)}
						onKeyUp={e => {
							if (e.key === 'Enter') {
								onBtnSearchClick();
							}
						}}
					/>
				}
			/>
		</>
	);
};

export default VHZ3010Srch;
