import { createSlice, createAsyncThunk, createEntityAdapter } from '@reduxjs/toolkit';
import KtngUtils from '@ktng/utils';
import vhz3010Service from 'app/services/vhz3010Service';

export const getRoles = createAsyncThunk(
	'vhz3010/vhz3010Mst/getRoles',
	async ({ roleCd, roleNm }, { dispatch, rejectWithValue }) => {
		try {
			const data = await vhz3010Service.selectRoleListByRolcd(roleCd, roleNm);
			return {
				list: data.list,
				params: {
					roleCd,
					roleNm
				}
			};
		} catch (err) {
			throw KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

export const saveRoles = createAsyncThunk(
	'vhz3010/vhz3010Mst/saveRoles',
	async ({ roleList }, { dispatch, rejectWithValue }) => {
		try {
			const data = await vhz3010Service.save(roleList);
			return data;
		} catch (err) {
			throw KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

const rolesAdapter = createEntityAdapter({
	selectId: role => role.roleCd
});

export const { selectAll: selectRoles, selectById: selectRoleById } = rolesAdapter.getSelectors(
	state => state.vhz3010.vhz3010Mst
);

const initialState = {
	params: {
		roleCd: '',
		roleNm: ''
	},
	loading: false
};

const vhz3010MstSlice = createSlice({
	name: 'vhz3010/vhz3010Mst',
	initialState: rolesAdapter.getInitialState(initialState),
	reducers: {
		changeRolesFilter: (state, action) => {
			state.filters = {
				...state.filters,
				...action.payload
			};
		},
		clearRolesFilter: state => {
			state.filters = initialState.filters;
		},
		changeRole: rolesAdapter.updateOne,
		changeRoles: rolesAdapter.updateMany,
		clearRoles: rolesAdapter.removeAll
	},
	extraReducers: {
		[getRoles.pending]: state => {
			state.loading = true;
		},
		[getRoles.fulfilled]: (state, action) => {
			const { list, params } = action.payload;
			rolesAdapter.setAll(state, list);
			state.params = params;
			state.loading = false;
		},
		[getRoles.rejected]: state => {
			state.loading = false;
		},
		[saveRoles.pending]: state => {
			state.loading = true;
		},
		[saveRoles.fulfilled]: state => {
			state.loading = false;
		},
		[saveRoles.rejected]: state => {
			state.loading = false;
		}
	}
});

export const { changeRolesFilter, clearRolesFilter, changeRole, changeRoles, clearRoles } = vhz3010MstSlice.actions;

export default vhz3010MstSlice.reducer;
