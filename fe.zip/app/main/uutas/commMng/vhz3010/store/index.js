import { combineReducers } from 'redux';
import vhz3010Mst from './vhz3010MstSlice';

const reducer = combineReducers({
	vhz3010Mst
});

export default reducer;
