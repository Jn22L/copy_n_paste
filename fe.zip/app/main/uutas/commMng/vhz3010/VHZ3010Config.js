import VHZ3010Page from './VHZ3010Page';

// `메뉴경로` - `화면` 맵핑 정보를 가진 Config는 파일명 대문자로 시작
const VHZ3010Config = {
	routes: [
		{
			path: '/cmmnMng/authMng/vhz3010',
			component: VHZ3010Page
		}
	]
};

export default VHZ3010Config;
