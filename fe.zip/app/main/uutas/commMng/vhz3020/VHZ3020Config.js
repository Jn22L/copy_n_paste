import VHZ3020Page from './VHZ3020Page';

// `메뉴경로` - `화면` 맵핑 정보를 가진 Config는 파일명 대문자로 시작
const VHZ3020Config = {
	routes: [
		{
			path: '/cmmnMng/authMng/vhz3020',
			component: VHZ3020Page
		}
	]
};

export default VHZ3020Config;
