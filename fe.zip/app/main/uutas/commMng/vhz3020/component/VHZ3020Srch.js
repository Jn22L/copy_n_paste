import React, { useState, useRef } from 'react';
import { useDispatch } from 'react-redux';
import { Input } from '@material-ui/core';
import { UutasToolBar, UutasForm } from '@ktng/uutas';
import KtngUtils from '@ktng/utils';
import { showMessage } from 'app/store/fuse/messageSlice';
import { getRoles } from '../store/vhz3020MstSlice';

const formSchema = [
	// row 1
	[
		// col 1
		{
			id: 'roleCd',
			label: '권한코드',
			width: 150,
			align: 'center',
			required: false
		},
		// col 2
		{
			id: 'menuCd',
			label: '메뉴코드',
			width: 150,
			align: 'center',
			required: false
		}
	]
];

const VHZ3020Srch = () => {
	const dispatch = useDispatch();

	// 입력된 값의 유효성검사를 하기위해 `useRef`로 폼입력컨트롤의 DOM에 접근한다
	const srchRef = useRef();

	const [expanded, setExpanded] = useState(true);

	// 폼 입력값
	const [roleCd, setRoleCd] = useState('');
	const [menuCd, setMenuCd] = useState('');

	function onBtnSearchClick() {
		const validationComps = [
			{ key: '권한코드', value: roleCd, type: 'text', required: false, maxLength: 20 },
			{ key: '메뉴코드', value: menuCd, type: 'text', required: false, maxLength: 20 }
		];

		if (KtngUtils.validationComps(validationComps, dispatch, srchRef)) {
			// 변경된 검색조건 으로 조회
			dispatch(getRoles({ roleCd, menuCd })).then(action => {
				const data = action.payload;
				if (data && data.list) {
					dispatch(showMessage({ message: `총 ${data.list.length}건이 조회되었습니다.` }));
				}
			}); // DB 에서 조회
		}
	}

	return (
		<>
			{/* 검색조건 툴바 */}
			<UutasToolBar onBtnSearchClick={onBtnSearchClick} expanded={expanded} onBtnToggleClick={setExpanded} />

			{/* 검색조건 입력폼 */}
			<UutasForm
				srchRef={srchRef}
				expanded={expanded}
				schema={formSchema}
				// 권한ID
				roleCd={
					<Input
						className="flex flex-1 px-8"
						placeholder="권한코드"
						fullWidth
						type="text"
						value={roleCd}
						inputProps={{ maxLength: 20 }}
						onChange={e => setRoleCd(e.target.value)}
						onKeyUp={e => {
							if (e.key === 'Enter') {
								onBtnSearchClick();
							}
						}}
					/>
				}
				// 권한명
				menuCd={
					<Input
						className="flex flex-1 px-8"
						placeholder="메뉴코드"
						fullWidth
						type="text"
						value={menuCd}
						inputProps={{ maxLength: 20 }}
						onChange={e => setMenuCd(e.target.value)}
						onKeyUp={e => {
							if (e.key === 'Enter') {
								onBtnSearchClick();
							}
						}}
					/>
				}
			/>
		</>
	);
};

export default VHZ3020Srch;
