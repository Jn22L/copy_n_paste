import { createSlice, createAsyncThunk, createEntityAdapter } from '@reduxjs/toolkit';
import KtngUtils from '@ktng/utils';
import vhz3020Service from 'app/services/vhz3020Service';

export const getRoles = createAsyncThunk(
	'vhz3020/vhz3020Mst/getRoles',
	async ({ roleCd, menuCd }, { dispatch, rejectWithValue }) => {
		try {
			const data = await vhz3020Service.selectRoleMenuList(roleCd, menuCd);
			return {
				list: data.list,
				params: {
					roleCd,
					menuCd
				}
			};
		} catch (err) {
			throw KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

export const saveRoles = createAsyncThunk(
	'vhz3020/vhz3020Mst/saveRoles',
	async ({ roleList }, { dispatch, rejectWithValue }) => {
		try {
			const data = await vhz3020Service.save(roleList);
			return data;
		} catch (err) {
			throw KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

const rolesAdapter = createEntityAdapter({
	selectId: roleMenu => `${roleMenu.roleCd}.${roleMenu.menuCd}`
});

export const { selectAll: selectRoles, selectById: selectRoleById } = rolesAdapter.getSelectors(
	state => state.vhz3020.vhz3020Mst
);

const initialState = {
	params: {
		roleCd: '',
		menuCd: ''
	},
	loading: false
};

const vhz3020MstSlice = createSlice({
	name: 'vhz3020/vhz3020Mst',
	initialState: rolesAdapter.getInitialState(initialState),
	reducers: {
		changeRolesFilter: (state, action) => {
			state.filters = {
				...state.filters,
				...action.payload
			};
		},
		clearRolesFilter: state => {
			state.filters = initialState.filters;
		},
		changeRole: rolesAdapter.updateOne,
		changeRoles: rolesAdapter.updateMany,
		clearRoles: rolesAdapter.removeAll
	},
	extraReducers: {
		[getRoles.pending]: state => {
			state.loading = true;
		},
		[getRoles.fulfilled]: (state, action) => {
			const { list, params } = action.payload;
			rolesAdapter.setAll(state, list);
			state.params = params;
			state.loading = false;
		},
		[getRoles.rejected]: state => {
			state.loading = false;
		},
		[saveRoles.pending]: state => {
			state.loading = true;
		},
		[saveRoles.fulfilled]: state => {
			state.loading = false;
		},
		[saveRoles.rejected]: state => {
			state.loading = false;
		}
	}
});

export const { changeRolesFilter, clearRolesFilter, changeRole, changeRoles, clearRoles } = vhz3020MstSlice.actions;

export default vhz3020MstSlice.reducer;
