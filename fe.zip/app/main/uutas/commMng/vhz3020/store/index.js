import { combineReducers } from 'redux';
import vhz3020Mst from './vhz3020MstSlice';

const reducer = combineReducers({
	vhz3020Mst
});

export default reducer;
