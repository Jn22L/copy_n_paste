// **************************************************************************
// 파    일    명   : MenuMngPage.js
// 업무      분류  : 메뉴관리
// 업    무    명   : 메뉴관리
// 프로그램   내용   : 메뉴를 조회하는 화면
// 기          타   :
// ==========================================================================
// 작    성    자   : 김 민 우
// 작    성    일   : 2021.12.17
// 최종    수정일   :
// 변 경    이 력   :
// **************************************************************************

import React from 'react';
import { useSelector } from 'react-redux';
import withReducer from 'app/store/withReducer';
import { UutasPageSimple } from '@ktng/uutas';
import { MenuMngSrch, MenuMngGrd1 } from './component';
import reducer from './store';

// cmmnMng/prgMenuMng/menuMng
const MenuMngPage = () => {
	const { menusLoading } = useSelector(({ menuMng }) => ({
		menusLoading: menuMng.menus.loading
	}));

	return (
		<UutasPageSimple title="메뉴관리" loading={menusLoading}>
			{/* 검색조건 */}
			<MenuMngSrch />

			{/* 메뉴 목록 */}
			<div className="flex flex-1">
				<MenuMngGrd1 />
			</div>
		</UutasPageSimple>
	);
};

export default withReducer('menuMng', reducer)(MenuMngPage);
