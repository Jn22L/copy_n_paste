import MenuMngSrch from './MenuMngSrch';
import MenuMngGrd1 from './MenuMngGrd1';

export { MenuMngSrch, MenuMngGrd1 };
