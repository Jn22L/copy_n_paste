const options = {
	Cfg: {
		CanSelect: true, // 시트 선택 가능
		SelectingCells: 0, // 개별 셀 선택 불가능
		CanEdit: 0, // 수정 불가능
		CustomScroll: 1, // 그리드와 스크롤 겹침 이슈 처리
		IgnoreFocused: true,
		InEditMode: 1,
		MainCol: 'name',
		NoTreeLines: true
	},
	Def: {
		// Col: { RelWidth: 1 }
	},
	Cols: [
		{
			Header: '메뉴',
			Name: 'name',
			Type: 'Text',
			Align: 'left',
			CanEdit: 0
		},
		{
			Header: '메뉴ID',
			Name: 'objCd',
			Type: 'Text',
			Align: 'center',
			CanEdit: 0,
			MinWidth: 120,
			RelWidth: 1
		},
		{
			Header: '메뉴구분',
			Name: 'menuGb',
			Type: 'Text',
			Align: 'center',
			CanEdit: 0,
			MinWidth: 100,
			RelWidth: 1
		},
		{
			Header: '등록일자',
			Name: 'createDate',
			Type: 'Date',
			Align: 'center',
			CanEdit: 0,
			MinWidth: 120,
			RelWidth: 1
		},
		{
			Header: '수정일자',
			Name: 'modifyDate',
			Type: 'Date',
			Align: 'center',
			CanEdit: 0,
			MinWidth: 120,
			RelWidth: 1
		},
		{
			Header: '사용여부',
			Name: 'useYn',
			Type: 'Enum',
			Enum: '|Y|N',
			Align: 'center',
			EnumKeys: '|0|1',
			ColMerge: false,
			CanEdit: 0,
			MinWidth: 50
		},
		{
			Header: '아이콘',
			Name: 'iconInfo',
			Type: 'Text',
			Align: 'center',
			CanEdit: 0,
			MinWidth: 150
		}
	]
};

export default options;
