import { combineReducers } from 'redux';
import menus from './menusSlice';

const reducer = combineReducers({
	menus
});

export default reducer;
