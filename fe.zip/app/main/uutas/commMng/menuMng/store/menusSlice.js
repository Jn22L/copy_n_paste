import { createSlice, createAsyncThunk, createEntityAdapter } from '@reduxjs/toolkit';
import KtngUtils from '@ktng/utils';
import menuService from 'app/services/menuService';

export const getMenus = createAsyncThunk('menuMng/menus/getMenus', async (_, { dispatch, rejectWithValue }) => {
	try {
		const data = await menuService.getMenuList();
		return {
			list: data.list
		};
	} catch (err) {
		throw KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
	}
});

const menusAdapter = createEntityAdapter({
	selectId: menu => menu.objCd
});

export const { selectAll: selectMenus, selectById: selectMenuById } = menusAdapter.getSelectors(
	state => state.menuMng.menus
);

const initialState = {
	filters: {
		objCd: '',
		name: ''
	},
	loading: false
};

const menusSlice = createSlice({
	name: 'menuMng/menus',
	initialState: menusAdapter.getInitialState(initialState),
	reducers: {
		changeMenusFilter: (state, action) => {
			state.filters = {
				...state.filters,
				...action.payload
			};
		},
		clearMenusFilter: state => {
			state.filters = initialState.filters;
		},
		changeMenu: menusAdapter.updateOne,
		changeMenus: menusAdapter.updateMany,
		clearMenus: menusAdapter.removeAll
	},
	extraReducers: {
		[getMenus.pending]: state => {
			state.loading = true;
		},
		[getMenus.fulfilled]: (state, action) => {
			const { list } = action.payload;
			menusAdapter.setAll(state, list);
			state.loading = false;
		},
		[getMenus.rejected]: state => {
			state.loading = false;
		}
	}
});

export const { changeMenusFilter, clearMenusFilter, changeMenu, changeMenus, clearMenus } = menusSlice.actions;

export default menusSlice.reducer;
