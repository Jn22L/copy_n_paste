const options = {
	Cfg: {
		CanSelect: true, // 시트 선택 가능
		SelectingCells: 1, // 개별 셀 선택 가능
		CanEdit: 1, // 수정 가능
		CustomScroll: 1 // 그리드와 스크롤 겹침 이슈 처리
	},
	/* 2. Def: 그리드 값 관련 설정 */
	Def: {
		// 2.1. Col: 그리드의 전체 열에 일괄적으로 적용할 설정
		// Col: {
		// 	RelWidth: 1 // 열 너비를 특정값으로 고정하지 않고 그리드 전체너비의 비율로 조정되도록 함
		// },

		// 2.2. Row: 그리드의 전체 행에 일괄적으로 적용할 설정
		Row: {
			CanFormula: 1, // {attribute}Formula 사용설정 Ex) `CanEditFormula`: 셀 수정가능 여부를 동적으로 결정할 수 있음
			CalcOrder: 'empNoCanEdit' // Formula 계산순서 설정
		}
	},
	Cols: [
		{
			Header: {
				Value: '삭제',
				HeaderCheck: 1
			},
			Type: 'Bool',
			Name: 'delYn',
			Align: 'center',
			DefaultValue: false,
			NoChanged: true
		},
		{
			Header: '상태',
			Name: 'rowStatus',
			Type: 'Enum',
			Align: 'center',
			DefaultValue: 'N',
			Enum: '||추가|수정|삭제',
			EnumKeys: '|N|I|U|D',
			CanEdit: 0,
			NoChanged: true
		},
		{
			Header: '사번',
			Name: 'empNo',
			Type: 'Text',
			Align: 'center',
			Required: 1,
			RelWidth: 1,
			CanEditFormula: param => {
				const { rowStatus } = param.Row;
				// `추가` 상태에서만 수정가능
				return rowStatus === 'I';
			}
		},
		{
			Header: '이름',
			Name: 'empNm',
			Type: 'Text',
			Align: 'center',
			CanEdit: 1,
			Required: 1,
			RelWidth: 1
		},
		{
			Header: '핸드폰번호',
			Name: 'cellPhnNo',
			Type: 'Text',
			Align: 'center',
			CanEdit: 1,
			Required: 1,
			RelWidth: 1
		},
		{
			Header: '기관코드',
			Name: 'parCd',
			Type: 'Text',
			Align: 'center',
			CanEdit: 1,
			Required: 1,
			RelWidth: 1
		},
		{
			Header: '기관명',
			Name: 'parNm',
			Type: 'Text',
			Align: 'center',
			CanEdit: 1,
			Required: 1,
			RelWidth: 1
		},
		{
			Header: '관리부서코드',
			Name: 'depCd',
			Type: 'Text',
			Align: 'center',
			CanEdit: 1,
			Required: 1,
			RelWidth: 1
		},
		{
			Header: '관리부서명',
			Name: 'depNm',
			Type: 'Text',
			Align: 'center',
			CanEdit: 1,
			Required: 1,
			RelWidth: 1
		},
		{
			Header: '근무부서코드',
			Name: 'partCd',
			Type: 'Text',
			Align: 'center',
			CanEdit: 1,
			Required: 1,
			RelWidth: 1
		},
		{
			Header: '근무부서명',
			Name: 'partNm',
			Type: 'Text',
			Align: 'center',
			CanEdit: 1,
			Required: 1,
			RelWidth: 1
		},
		{
			Header: '로그인권한',
			Name: 'roleCd',
			Type: 'Enum',
			Align: 'center',
			DefaultValue: 'ROLE_ADMIN',
			Enum: '|ROLE_ADMIN_COMM|ROLE_ADMIN|ROLE_MGR|ROLE_DGN|ROLE_USR',
			EnumKeys: '|ROLE_ADMIN_COMM|ROLE_ADMIN|ROLE_MGR|ROLE_DGN|ROLE_USR',
			CanEdit: 1,
			Required: 1,
			RelWidth: 2
		},
		{
			Header: '배차부서',
			Name: 'vhclDeptCd',
			Type: 'Text',
			Align: 'center',
			CanEdit: 1,
			Required: 1,
			RelWidth: 1
		},
		{
			Header: '로그인유저구분',
			Name: 'loginUserGubun',
			Type: 'Enum',
			Align: 'center',
			DefaultValue: 'USER',
			Enum: '|일반사용자|운전원',
			EnumKeys: '|USER|DRIVER',
			CanEdit: 1,
			Required: 1,
			RelWidth: 1
		}
	]
};

export default options;
