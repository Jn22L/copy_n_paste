import React, { useState, useRef } from 'react';
import { useDispatch } from 'react-redux';
import { Input } from '@material-ui/core';
import { UutasToolBar, UutasForm } from '@ktng/uutas';
import KtngUtils from '@ktng/utils';
import { showMessage } from 'app/store/fuse/messageSlice';
import { getTempUsers } from '../store/vhz3030MstSlice';

const formSchema = [
	// row 1
	[
		// col 1
		{
			id: 'empNo',
			label: '사번',
			width: 150,
			align: 'center',
			required: false
		},
		// col 2
		{
			id: 'empNm',
			label: '이름',
			width: 150,
			align: 'center',
			required: false
		}
	]
];

const VHZ3030Srch = () => {
	const dispatch = useDispatch();

	// 입력된 값의 유효성검사를 하기위해 `useRef`로 폼입력컨트롤의 DOM에 접근한다
	const srchRef = useRef();

	const [expanded, setExpanded] = useState(true);

	// 폼 입력값
	const [empNo, setEmpNo] = useState('');
	const [empNm, setEmpNm] = useState('');

	function onBtnSearchClick() {
		const validationComps = [
			{ key: '사번', value: empNo, type: 'text', required: false, maxLength: 20 },
			{ key: '이름', value: empNm, type: 'text', required: false, maxLength: 20 }
		];

		if (KtngUtils.validationComps(validationComps, dispatch, srchRef)) {
			// 변경된 검색조건 으로 조회
			dispatch(getTempUsers({ empNo, empNm })).then(action => {
				const data = action.payload;
				if (data && data.list) {
					dispatch(showMessage({ message: `총 ${data.list.length}건이 조회되었습니다.` }));
				}
			}); // DB 에서 조회
		}
	}

	return (
		<>
			{/* 검색조건 툴바 */}
			<UutasToolBar onBtnSearchClick={onBtnSearchClick} expanded={expanded} onBtnToggleClick={setExpanded} />

			{/* 검색조건 입력폼 */}
			<UutasForm
				srchRef={srchRef}
				expanded={expanded}
				schema={formSchema}
				// 사번
				empNo={
					<Input
						className="flex flex-1 px-8"
						placeholder="사번"
						fullWidth
						type="text"
						value={empNo}
						inputProps={{ maxLength: 20 }}
						onChange={e => setEmpNo(e.target.value)}
						onKeyUp={e => {
							if (e.key === 'Enter') {
								onBtnSearchClick();
							}
						}}
					/>
				}
				// 이름
				empNm={
					<Input
						className="flex flex-1 px-8"
						placeholder="이름"
						fullWidth
						type="text"
						value={empNm}
						inputProps={{ maxLength: 20 }}
						onChange={e => setEmpNm(e.target.value)}
						onKeyUp={e => {
							if (e.key === 'Enter') {
								onBtnSearchClick();
							}
						}}
					/>
				}
			/>
		</>
	);
};

export default VHZ3030Srch;
