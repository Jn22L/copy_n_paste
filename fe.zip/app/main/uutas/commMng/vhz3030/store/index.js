import { combineReducers } from 'redux';
import vhz3030Mst from './vhz3030MstSlice';

const reducer = combineReducers({
	vhz3030Mst
});

export default reducer;
