import { createSlice, createAsyncThunk, createEntityAdapter } from '@reduxjs/toolkit';
import KtngUtils from '@ktng/utils';
import vhz3030Service from 'app/services/vhz3030Service';

export const getTempUsers = createAsyncThunk(
	'vhz3030/vhz3030Mst/getTempUsers',
	async ({ empNo, empNm }, { dispatch, rejectWithValue }) => {
		try {
			const data = await vhz3030Service.selectTempUserList(empNo, empNm);
			return {
				list: data.list,
				params: {
					empNo,
					empNm
				}
			};
		} catch (err) {
			throw KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

////

export const saveTempUsers = createAsyncThunk(
	'vhz3030/vhz3030Mst/saveTempUsers',
	async ({ tempUserList }, { dispatch, rejectWithValue }) => {
		try {
			const data = await vhz3030Service.save(tempUserList);
			return data;
		} catch (err) {
			throw KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

const tempUsersAdapter = createEntityAdapter({
	selectId: tempUser => tempUser.empNo
});

export const { selectAll: selectTempUsers, selectById: selectTempUserById } = tempUsersAdapter.getSelectors(
	state => state.vhz3030.vhz3030Mst
);

const initialState = {
	filters: {
		empNo: '',
		empNm: ''
	},
	loading: false
};

const vhz3030MstSlice = createSlice({
	name: 'vhz3030/vhz3030Mst',
	initialState: tempUsersAdapter.getInitialState(initialState),
	reducers: {
		changeTempUsersFilter: (state, action) => {
			state.filters = {
				...state.filters,
				...action.payload
			};
		},
		clearTempUsersFilter: state => {
			state.filters = initialState.filters;
		},
		changeTempUser: tempUsersAdapter.updateOne,
		changeTempUsers: tempUsersAdapter.updateMany,
		clearTempUsers: tempUsersAdapter.removeAll
	},
	extraReducers: {
		[getTempUsers.pending]: state => {
			state.loading = true;
		},
		[getTempUsers.fulfilled]: (state, action) => {
			const { list, params } = action.payload;
			tempUsersAdapter.setAll(state, list);
			state.params = params;
			state.loading = false;
		},
		[getTempUsers.rejected]: state => {
			state.loading = false;
		},
		[saveTempUsers.pending]: state => {
			state.loading = true;
		},
		[saveTempUsers.fulfilled]: state => {
			state.loading = false;
		},
		[saveTempUsers.rejected]: state => {
			state.loading = false;
		}
	}
});

export const {
	changeTempUsersFilter,
	clearTempUsersFilter,
	changeTempUser,
	changeTempUsers,
	clearTempUsers
} = vhz3030MstSlice.actions;

export default vhz3030MstSlice.reducer;
