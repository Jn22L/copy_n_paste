import CommCodeMngConfig from './commCodeMng/CommCodeMngConfig';
import CommCodeOutptConfig from './commCodeOutpt/CommCodeOutptConfig';
import PrgMngConfig from './prgMng/PrgMngConfig';
import MenuMngConfig from './menuMng/MenuMngConfig';
import VHZ1020Config from './vhz1020/VHZ1020Config';
import VHZ2030Config from './vhz2030/VHZ2030Config';
import VHZ3010Config from './vhz3010/VHZ3010Config';
import VHZ3020Config from './vhz3020/VHZ3020Config';
import VHZ3030Config from './vhz3030/VHZ3030Config';
import VHZ3040Config from './vhz3040/VHZ3040Config';

// 리스트로 된 Config는 파일명 소문자로 시작
const commCodeMngConfig = [
	//
	CommCodeMngConfig,
	CommCodeOutptConfig,
	PrgMngConfig,
	MenuMngConfig,
	VHZ1020Config,
	VHZ2030Config,
	VHZ3010Config,
	VHZ3020Config,
	VHZ3030Config,
	VHZ3040Config
];

export default commCodeMngConfig;
