const options = {
	Cfg: {
		CanSelect: true, // 시트 선택 가능
		SelectingCells: 1, // 개별 셀 선택 가능
		CanEdit: 1, // 수정 가능
		CustomScroll: 1 // 그리드와 스크롤 겹침 이슈 처리
	},
	Def: {
		// Col: { RelWidth: 1 }
	},
	Cols: [
		{
			Header: {
				Value: '삭제',
				HeaderCheck: 1
			},
			Type: 'Bool',
			Name: 'delYn',
			Align: 'center',
			DefaultValue: false,
			NoChanged: true
		},
		{
			Header: '상태',
			Name: 'rowStatus',
			Type: 'Enum',
			Align: 'center',
			DefaultValue: 'N',
			Enum: '||추가|수정|삭제',
			EnumKeys: '|N|I|U|D',
			CanEdit: 0,
			NoChanged: true
		},
		{
			Header: '그룹코드',
			Name: 'commCode',
			Type: 'Text',
			Align: 'Center',
			Required: 1,
			RelWidth: 1
		},
		{
			Header: '그룹코드명',
			Name: 'commCodeName',
			Type: 'Text',
			Align: 'Center',
			Required: 1,
			RelWidth: 1
		}
	]
};

export default options;
