import KtngIbSheet from '@ktng/core/KtngIbSheet';
import KtngUtils, { KtngIbSheetUtils } from '@ktng/utils';
import { UutasToolBar } from '@ktng/uutas';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import _ from '@lodash';
import { showMessage } from 'app/store/fuse/messageSlice';
import { getCodes, saveCodes } from '../store/codesSlice';
import { selectGrpCodes, getGrpCodes } from '../store/grpCodesSlice';
import sheetOptions from './CommCodeMngGrdOpt1';

const sheetId = KtngUtils.getUid('commCodeMng-grd1');

const CommCodeMngGrd1 = () => {
	const dispatch = useDispatch();

	const grpCodes = useSelector(selectGrpCodes);
	const { grpCodesFilters, grpCodesParams } = useSelector(({ commCodeMng }) => ({
		grpCodesFilters: commCodeMng.grpCodes.filters,
		grpCodesParams: commCodeMng.grpCodes.params
	}));

	const [sheetObj, setSheetObj] = useState();
	const [grdData, setGrdData] = useState([]);

	// 1. 데이터 조회
	useEffect(() => {
		dispatch(getGrpCodes({})).then(action => {
			const data = action.payload;
			if (data && data.list) {
				dispatch(showMessage({ message: `총 ${data.list.length}건이 조회되었습니다.` }));
			}
		});
	}, [dispatch]);

	// 2. 데이터 필터
	useEffect(() => {
		if (!grpCodes || !grpCodesFilters) return;

		const { commCodeName } = grpCodesFilters;
		setGrdData(
			grpCodes.filter(
				// 검색 공통코드명이 비었거나 그룹코드명에 포함된 문자열인 경우 true, 아니면 false
				grpCode => !commCodeName || grpCode.commCodeName.indexOf(commCodeName) > -1
			)
		);
	}, [grpCodes, grpCodesFilters]);

	// 그리드 생성 콜백
	function onSheetLoad(sheet) {
		setSheetObj(sheet);

		// 이벤트 등록
		// onRowAdd, onAfterClick, onAfterChange 3개 이벤트는 `KtngIbSheet` 컴포넌트 속성에 콜백함수를 넣어 추가
		// 3개 이벤트를 제외한 이벤트를 등록할 때 이곳에 작성
		// sheet.bind('onBeforeClick', onSheetBeforeClick);
	}

	// 그리드 행 선택
	function onSheetClick({ sheet, row, col }) {
		if (row.rowStatus !== 'N') return;
		const commCode = sheet.getValue(row, 'commCode');
		dispatch(getCodes({ commCodeChk: commCode })).then(action => {
			const data = action.payload;
			if (data && data.list) {
				dispatch(showMessage({ message: `총 ${data.list.length}건이 조회되었습니다.` }));
			}
		});
	}

	// 그리드에 행 추가
	function handleBtnAddClick() {
		return {
			commCodeChk: 'GRP',
			commCode: '',
			commCodeName: ''
		};
	}

	// 그리드 수정사항 일괄저장 (추가/수정/삭제)
	function handleBtnSaveClick() {
		const codeList = KtngIbSheetUtils.getRowsByStatus(sheetObj, ['I', 'U', 'D']).map(row =>
			_.pick(row, ['rowStatus', 'commCodeChk', 'commCode', 'commCodeName'])
		);
		KtngUtils.validationSaveData(codeList, { commCode: '그룹코드', commCodeName: '그룹코드명' }, dispatch, () => {
			dispatch(saveCodes({ commCodeChk: 'GRP', codeList })).then(action => {
				const data = action.payload;
				if (data && data.success) {
					dispatch(showMessage({ message: '변경사항이 반영되었습니다.' }));
					// grpCodesParams: 이전에 조회했던 파라미터로 조회
					dispatch(getGrpCodes(grpCodesParams));
				}
			});
		});
	}

	// 그리드 엑셀 다운로드
	function handleBtnDownExcelClick() {
		return {
			/* Excel Config */
		};
	}

	return (
		<div className="flex flex-col w-full">
			<UutasToolBar
				title="그룹코드 목록"
				variant="subtitle1"
				sheet={sheetObj}
				onBtnAddClick={handleBtnAddClick} // 추가할 데이터 반환
				onBtnSaveClick={handleBtnSaveClick}
				onBtnDownExcelClick={handleBtnDownExcelClick} // Excel Config 반환
			/>

			<KtngIbSheet
				// [필수 속성]
				sheetId={sheetId}
				options={sheetOptions}
				data={grdData}
				// [선택 속성]
				// - 이벤트
				onLoad={onSheetLoad} // 생성된 sheet 객체 바인딩 및 공통코드 로드 수행
				//   ※ 아래 2개 외 필요한 이벤트는 `onSheetLoad`에서 직접 바인딩할 것
				onAfterClick={onSheetClick} // 내부공통기능 수행 후 `onSheetClick` 콜백이 호출됨
				// onAfterChange={onSheetChange} // 내부공통기능 수행 후 `onSheetChange` 콜백이 호출됨
				// - 스타일 속성
				// className="" // tailwind 스타일 적용 가능
				style={{ height: '98%' }} // 그리드 초기 높이 설정시에는 style만 적용됨
			/>
		</div>
	);
};

export default CommCodeMngGrd1;
