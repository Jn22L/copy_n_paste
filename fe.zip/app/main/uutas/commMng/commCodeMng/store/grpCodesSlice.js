import { createSlice, createAsyncThunk, createEntityAdapter } from '@reduxjs/toolkit';
import KtngUtils from '@ktng/utils';
import codeService from 'app/services/codeService';

export const getGrpCodes = createAsyncThunk(
	'commCodeMng/grpCodes/getGrpCodes',
	async ({ commCode }, { dispatch, rejectWithValue }) => {
		try {
			const data = await codeService.list('GRP', commCode);
			return {
				list: data.list,
				params: {
					commCode
				}
			};
		} catch (err) {
			throw KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

const grpCodesAdapter = createEntityAdapter({
	selectId: grpCode => `${grpCode.commCodeChk}.${grpCode.commCode}`
});

export const { selectAll: selectGrpCodes, selectById: selectGrpCodeById } = grpCodesAdapter.getSelectors(
	state => state.commCodeMng.grpCodes
);

const initialState = {
	params: {
		commCode: ''
	},
	filters: {
		commCodeName: ''
	},
	loading: false
};

const grpCodesSlice = createSlice({
	name: 'commCodeMng/grpCodes',
	initialState: grpCodesAdapter.getInitialState(initialState),
	reducers: {
		changeGrpCodesFilter: (state, action) => {
			state.filters = {
				...state.filters,
				...action.payload
			};
		},
		clearGrpCodesFilter: state => {
			state.filters = initialState.filters;
		},
		changeGrpCode: grpCodesAdapter.updateOne,
		changeGrpCodes: grpCodesAdapter.updateMany,
		clearGrpCodes: grpCodesAdapter.removeAll
	},
	extraReducers: {
		[getGrpCodes.pending]: state => {
			state.loading = true;
		},
		[getGrpCodes.fulfilled]: (state, action) => {
			const { list, params } = action.payload;
			grpCodesAdapter.setAll(state, list);
			state.params = params;
			state.loading = false;
		},
		[getGrpCodes.rejected]: state => {
			state.loading = false;
		}
	}
});

export const {
	changeGrpCodesFilter,
	clearGrpCodesFilter,
	changeGrpCode,
	changeGrpCodes,
	clearGrpCodes
} = grpCodesSlice.actions;

export default grpCodesSlice.reducer;
