import { combineReducers } from 'redux';
import grpCodes from './grpCodesSlice';
import codes from './codesSlice';

const reducer = combineReducers({
	grpCodes,
	codes
});

export default reducer;
