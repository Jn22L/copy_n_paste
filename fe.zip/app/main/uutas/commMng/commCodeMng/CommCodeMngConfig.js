import CommCodeMngPage from './CommCodeMngPage';

// `메뉴경로` - `화면` 맵핑 정보를 가진 Config는 파일명 대문자로 시작
const CommCodeMngConfig = {
	routes: [
		{
			path: '/cmmnMng/cmmnCdMng/cmmnCdMng',
			component: CommCodeMngPage
		}
	]
};

export default CommCodeMngConfig;
