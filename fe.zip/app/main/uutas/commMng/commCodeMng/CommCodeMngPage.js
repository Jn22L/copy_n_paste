// **************************************************************************
// 파    일    명   : CommCodeMngPage.js
// 업무      분류  : 공통코드관리
// 업    무    명   : 공통코드관리
// 프로그램   내용   : 공통코드를 조회/입력/수정/삭제하는 화면
// 기          타   :
// ==========================================================================
// 작    성    자   : 김 민 우
// 작    성    일   : 2021.12.14
// 최종    수정일   :
// 변 경    이 력   :
// **************************************************************************

import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import withReducer from 'app/store/withReducer';
import { IconButton, makeStyles } from '@material-ui/core';
import { ExpandLess, ExpandMore } from '@material-ui/icons';
import { UutasPageSimple } from '@ktng/uutas';
import clsx from 'clsx';
import { CommCodeMngSrch, CommCodeMngGrd1, CommCodeMngGrd2 } from './component';
import reducer from './store';
import { selectCodes } from './store/codesSlice';

const useStyles = makeStyles(theme => ({
	mstGrd: {
		display: 'flex',
		flexDirection: 'row', // 'row'를 사용해야 그리드에 스크롤이 생김
		flex: 1 // 그리드가 차지하는 높이 비율 (값에 비례)
	},
	subGrd: {
		display: 'flex',
		flexDirection: 'row',
		flex: 2
	}
}));

// commMng/commCodeMng/commCodeMng
const CommCodeMngPage = () => {
	const classes = useStyles();

	const codes = useSelector(selectCodes);

	const { grpCodesLoading, codesLoading } = useSelector(({ commCodeMng }) => ({
		grpCodesLoading: commCodeMng.grpCodes.loading,
		codesLoading: commCodeMng.codes.loading
	}));

	const [showSubGrd, setShowSubGrd] = useState(true); // 서브그리드 보이기/숨김

	// 서브그리드의 데이터가 새로 조회되면 서브그리드 보이기
	useEffect(() => {
		setShowSubGrd(!!codes);
	}, [codes]);

	return (
		<UutasPageSimple title="공통코드관리" loading={grpCodesLoading || codesLoading}>
			{/* 검색조건 */}
			<CommCodeMngSrch />

			{/* 그룹코드 목록 */}
			<div className={classes.mstGrd}>
				<CommCodeMngGrd1 />
			</div>

			{/* 서브그리드 보이기/숨김 버튼 */}
			<div className="flex justify-center">
				<IconButton onClick={() => setShowSubGrd(!showSubGrd)}>
					{showSubGrd ? <ExpandMore /> : <ExpandLess />}
				</IconButton>
			</div>

			{/* 공통코드 목록 */}
			<div className={clsx(classes.subGrd, !showSubGrd && 'hidden')}>
				<CommCodeMngGrd2 />
			</div>
		</UutasPageSimple>
	);
};

export default withReducer('commCodeMng', reducer)(CommCodeMngPage);
