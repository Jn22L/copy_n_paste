import { combineReducers } from 'redux';
import vhz2030Mst from './vhz2030MstSlice';

const reducer = combineReducers({
	vhz2030Mst
});

export default reducer;
