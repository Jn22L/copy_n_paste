import { createSlice, createAsyncThunk, createEntityAdapter } from '@reduxjs/toolkit';
import KtngUtils from '@ktng/utils';
import vhz2030Service from 'app/services/vhz2030Service';

export const getMenus = createAsyncThunk(
	'vhz2030/vhz2030Mst/getMenus',
	async ({ menuCd, menuNm }, { dispatch, rejectWithValue }) => {
		try {
			const data = await vhz2030Service.selectMenuList(menuCd, menuNm);
			return {
				list: data.list,
				params: {
					menuCd,
					menuNm
				}
			};
		} catch (err) {
			throw KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

////

export const saveMenus = createAsyncThunk(
	'vhz2030/vhz2030Mst/saveMenus',
	async ({ menuList }, { dispatch, rejectWithValue }) => {
		try {
			const data = await vhz2030Service.save(menuList);
			return data;
		} catch (err) {
			throw KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

const menusAdapter = createEntityAdapter({
	selectId: menu => menu.menuCd
});

export const { selectAll: selectMenus, selectById: selectMenuById } = menusAdapter.getSelectors(
	state => state.vhz2030.vhz2030Mst
);

const initialState = {
	filters: {
		menuCd: '',
		menuNm: ''
	},
	loading: false
};

const vhz2030MstSlice = createSlice({
	name: 'vhz2030/vhz2030Mst',
	initialState: menusAdapter.getInitialState(initialState),
	reducers: {
		changeMenusFilter: (state, action) => {
			state.filters = {
				...state.filters,
				...action.payload
			};
		},
		clearMenusFilter: state => {
			state.filters = initialState.filters;
		},
		changeMenu: menusAdapter.updateOne,
		changeMenus: menusAdapter.updateMany,
		clearMenus: menusAdapter.removeAll
	},
	extraReducers: {
		[getMenus.pending]: state => {
			state.loading = true;
		},
		[getMenus.fulfilled]: (state, action) => {
			const { list, params } = action.payload;
			menusAdapter.setAll(state, list);
			state.params = params;
			state.loading = false;
		},
		[getMenus.rejected]: state => {
			state.loading = false;
		},
		[saveMenus.pending]: state => {
			state.loading = true;
		},
		[saveMenus.fulfilled]: state => {
			state.loading = false;
		},
		[saveMenus.rejected]: state => {
			state.loading = false;
		}
	}
});

export const { changeMenusFilter, clearMenusFilter, changeMenu, changeMenus, clearMenus } = vhz2030MstSlice.actions;

export default vhz2030MstSlice.reducer;
