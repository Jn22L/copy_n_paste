// **************************************************************************
// 파    일    명   : VHZ2030Page.js
// 업무      분류   :
// 업    무    명   : 메뉴관리
// 프로그램   내용   :
// 기          타   :
// ==========================================================================
// 작    성    자   :
// 작    성    일   : 2021.12.27
// 최종    수정일   :
// 변 경    이 력   :
// **************************************************************************

import React from 'react';
import { useSelector } from 'react-redux';
import withReducer from 'app/store/withReducer';
import { UutasPageSimple } from '@ktng/uutas';
import { VHZ2030Srch, VHZ2030Grd1 } from './component';
import reducer from './store';

// cmmnMng/prgMenuMng/vhz2030
const VHZ2030Page = () => {
	const { dataLoading } = useSelector(({ vhz2030 }) => ({
		dataLoading: vhz2030.vhz2030Mst.loading
	}));

	return (
		<UutasPageSimple title="메뉴관리" loading={dataLoading}>
			{/* 검색조건 */}
			<VHZ2030Srch />

			{/* 프로그램 목록 */}
			<div className="flex flex-1">
				<VHZ2030Grd1 />
			</div>
		</UutasPageSimple>
	);
};

export default withReducer('vhz2030', reducer)(VHZ2030Page);
