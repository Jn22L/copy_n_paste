import VHZ2030Page from './VHZ2030Page';

// `메뉴경로` - `화면` 맵핑 정보를 가진 Config는 파일명 대문자로 시작
const VHZ2030Config = {
	routes: [
		{
			path: '/cmmnMng/prgMenuMng/vhz2030',
			component: VHZ2030Page
		}
	]
};

export default VHZ2030Config;
