const options = {
	Cfg: {
		CanSelect: true, // 시트 선택 가능
		SelectingCells: 1, // 개별 셀 선택 가능
		CanEdit: 1, // 수정 가능
		CustomScroll: 1 // 그리드와 스크롤 겹침 이슈 처리
	},
	/* 2. Def: 그리드 값 관련 설정 */
	Def: {
		// 2.1. Col: 그리드의 전체 열에 일괄적으로 적용할 설정
		// Col: {
		// 	RelWidth: 1 // 열 너비를 특정값으로 고정하지 않고 그리드 전체너비의 비율로 조정되도록 함
		// },

		// 2.2. Row: 그리드의 전체 행에 일괄적으로 적용할 설정
		Row: {
			CanFormula: 1, // {attribute}Formula 사용설정 Ex) `CanEditFormula`: 셀 수정가능 여부를 동적으로 결정할 수 있음
			CalcOrder: 'menuCdCanEdit' // Formula 계산순서 설정
		}
	},
	Cols: [
		{
			Header: {
				Value: '삭제',
				HeaderCheck: 1
			},
			Type: 'Bool',
			Name: 'delYn',
			Align: 'center',
			DefaultValue: false,
			NoChanged: true
		},
		{
			Header: '상태',
			Name: 'rowStatus',
			Type: 'Enum',
			Align: 'center',
			DefaultValue: 'N',
			Enum: '||추가|수정|삭제',
			EnumKeys: '|N|I|U|D',
			CanEdit: 0,
			NoChanged: true
		},
		{
			Header: '메뉴',
			Name: 'menuCd',
			Type: 'Text',
			Align: 'center',
			Required: 1,
			RelWidth: 1,
			CanEditFormula: param => {
				const { rowStatus } = param.Row;
				// `추가` 상태에서만 수정가능
				return rowStatus === 'I';
			}
		},
		{
			Header: '메뉴명',
			Name: 'menuNm',
			Type: 'Text',
			Align: 'left',
			CanEdit: 1,
			Required: 1,
			RelWidth: 1
		},
		{
			Header: '상위메뉴',
			Name: 'upprMenuCd',
			Type: 'Text',
			Align: 'center',
			CanEdit: 1,
			Required: 1,
			RelWidth: 1
		},
		{
			Header: '출력순서',
			Name: 'orderNo',
			Type: 'Text',
			Align: 'center',
			CanEdit: 1,
			Required: 1,
			RelWidth: 1
		},
		{
			Header: '메뉴레벨',
			Name: 'menuLvl',
			Type: 'Text',
			Align: 'center',
			CanEdit: 1,
			Required: 1,
			RelWidth: 1
		},
		{
			Header: '메뉴URL',
			Name: 'menuUrl',
			Type: 'Text',
			Align: 'left',
			CanEdit: 1,
			Required: 1,
			RelWidth: 2
		}
	]
};

export default options;
