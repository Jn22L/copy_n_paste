import React, { useState, useRef } from 'react';
import { useDispatch } from 'react-redux';
import { Input } from '@material-ui/core';
import { UutasToolBar, UutasForm } from '@ktng/uutas';
import KtngUtils from '@ktng/utils';
import { showMessage } from 'app/store/fuse/messageSlice';
import { getMenus } from '../store/vhz2030MstSlice';

const formSchema = [
	// row 1
	[
		// col 1
		{
			id: 'menuCd',
			label: '메뉴',
			width: 150,
			align: 'center',
			required: false
		},
		// col 2
		{
			id: 'menuNm',
			label: '메뉴명',
			width: 150,
			align: 'center',
			required: false
		}
	]
];

const VHZ2030Srch = () => {
	const dispatch = useDispatch();

	// 입력된 값의 유효성검사를 하기위해 `useRef`로 폼입력컨트롤의 DOM에 접근한다
	const srchRef = useRef();

	const [expanded, setExpanded] = useState(true);

	// 폼 입력값
	const [menuCd, setMenuCd] = useState('');
	const [menuNm, setMenuNm] = useState('');

	function onBtnSearchClick() {
		const validationComps = [
			{ key: '메뉴', value: menuCd, type: 'text', required: false, maxLength: 20 },
			{ key: '메뉴명', value: menuNm, type: 'text', required: false, maxLength: 20 }
		];

		if (KtngUtils.validationComps(validationComps, dispatch, srchRef)) {
			// 변경된 검색조건 으로 조회
			dispatch(getMenus({ menuCd, menuNm })).then(action => {
				const data = action.payload;
				if (data && data.list) {
					dispatch(showMessage({ message: `총 ${data.list.length}건이 조회되었습니다.` }));
				}
			}); // DB 에서 조회
		}
	}

	return (
		<>
			{/* 검색조건 툴바 */}
			<UutasToolBar onBtnSearchClick={onBtnSearchClick} expanded={expanded} onBtnToggleClick={setExpanded} />

			{/* 검색조건 입력폼 */}
			<UutasForm
				srchRef={srchRef}
				expanded={expanded}
				schema={formSchema}
				// 메뉴
				menuCd={
					<Input
						className="flex flex-1 px-8"
						placeholder="메뉴"
						fullWidth
						type="text"
						value={menuCd}
						inputProps={{ maxLength: 20 }}
						onChange={e => setMenuCd(e.target.value)}
						onKeyUp={e => {
							if (e.key === 'Enter') {
								onBtnSearchClick();
							}
						}}
					/>
				}
				// 메뉴명
				menuNm={
					<Input
						className="flex flex-1 px-8"
						placeholder="메뉴명"
						fullWidth
						type="text"
						value={menuNm}
						inputProps={{ maxLength: 20 }}
						onChange={e => setMenuNm(e.target.value)}
						onKeyUp={e => {
							if (e.key === 'Enter') {
								onBtnSearchClick();
							}
						}}
					/>
				}
			/>
		</>
	);
};

export default VHZ2030Srch;
