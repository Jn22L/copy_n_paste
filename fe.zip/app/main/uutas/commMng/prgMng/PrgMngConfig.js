import PrgMngPage from './PrgMngPage';

// `메뉴경로` - `화면` 맵핑 정보를 가진 Config는 파일명 대문자로 시작
const PrgMngConfig = {
	routes: [
		{
			path: '/cmmnMng/prgMenuMng/prgMng',
			component: PrgMngPage
		}
	]
};

export default PrgMngConfig;
