import { createSlice, createAsyncThunk, createEntityAdapter } from '@reduxjs/toolkit';
import KtngUtils from '@ktng/utils';
import menuService from 'app/services/menuService';

export const getPrograms = createAsyncThunk('prgMng/programs/getPrograms', async (_, { dispatch, rejectWithValue }) => {
	try {
		const data = await menuService.getPrgList();
		return {
			list: data.list
		};
	} catch (err) {
		throw KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
	}
});

const programsAdapter = createEntityAdapter({
	selectId: program => program.objCd
});

export const { selectAll: selectPrograms, selectById: selectProgramById } = programsAdapter.getSelectors(
	state => state.prgMng.programs
);

const initialState = {
	filters: {
		objCd: '',
		name: ''
	},
	loading: false
};

const programsSlice = createSlice({
	name: 'prgMng/programs',
	initialState: programsAdapter.getInitialState(initialState),
	reducers: {
		changeProgramsFilter: (state, action) => {
			state.filters = {
				...state.filters,
				...action.payload
			};
		},
		clearProgramsFilter: state => {
			state.filters = initialState.filters;
		},
		changeProgram: programsAdapter.updateOne,
		changePrograms: programsAdapter.updateMany,
		clearPrograms: programsAdapter.removeAll
	},
	extraReducers: {
		[getPrograms.pending]: state => {
			state.loading = true;
		},
		[getPrograms.fulfilled]: (state, action) => {
			const { list } = action.payload;
			programsAdapter.setAll(state, list);
			state.loading = false;
		},
		[getPrograms.rejected]: state => {
			state.loading = false;
		}
	}
});

export const {
	changeProgramsFilter,
	clearProgramsFilter,
	changeProgram,
	changePrograms,
	clearPrograms
} = programsSlice.actions;

export default programsSlice.reducer;
