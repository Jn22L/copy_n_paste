import { combineReducers } from 'redux';
import programs from './programsSlice';

const reducer = combineReducers({
	programs
});

export default reducer;
