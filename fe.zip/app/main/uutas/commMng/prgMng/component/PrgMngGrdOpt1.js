const options = {
	Cfg: {
		CanSelect: true, // 시트 선택 가능
		SelectingCells: 0, // 개별 셀 선택 불가능
		CanEdit: 0, // 수정 불가능
		CustomScroll: 1, // 그리드와 스크롤 겹침 이슈 처리
		IgnoreFocused: true,
		DataMerge: 1
	},
	Def: {
		// Col: { RelWidth: 1 }
	},
	Cols: [
		{
			Header: '대분류명',
			Name: 'lvl2Name',
			Type: 'Text',
			Align: 'center',
			CanEdit: 0,
			MinWitdh: 150
		},
		{
			Header: '중분류명',
			Name: 'lvl3Name',
			Type: 'Text',
			Align: 'center',
			CanEdit: 0,
			MinWitdh: 150
		},
		{
			Header: '프로그램ID',
			Name: 'objCd',
			Type: 'Text',
			Align: 'center',
			CanEdit: 0,
			MinWidth: 100
		},
		{
			Header: '프로그램명',
			Name: 'name',
			Type: 'Text',
			Align: 'center',
			CanEdit: 0,
			MinWidth: 200
		},
		{
			Header: 'URL',
			Name: 'url',
			Type: 'Text',
			Align: 'left',
			CanEdit: 0,
			MinWidth: 200,
			RelWidth: 1
		},
		{
			Header: '사용여부',
			Name: 'useYn',
			Type: 'Enum',
			Enum: '|Y|N',
			Align: 'center',
			EnumKeys: '|0|1',
			ColMerge: false,
			CanEdit: 0,
			MinWidth: 50
		}
	]
};

export default options;
