import React, { useState, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Input } from '@material-ui/core';
import { UutasToolBar, UutasForm } from '@ktng/uutas';
import KtngUtils from '@ktng/utils';
import { changeProgramsFilter } from '../store/programsSlice';

const formSchema = [
	// row 1
	[
		// col 1
		{
			id: 'objCd',
			label: '프로그램ID',
			width: 150,
			align: 'center',
			required: false
		},
		// col 2
		{
			id: 'name',
			label: '프로그램명',
			width: 150,
			align: 'center',
			required: false
		}
	]
];

const PrgMngSrch = () => {
	const dispatch = useDispatch();

	// 입력된 값의 유효성검사를 하기위해 `useRef`로 폼입력컨트롤의 DOM에 접근한다
	const srchRef = useRef();

	const { programsFilter } = useSelector(({ prgMng }) => ({
		programsFilter: prgMng.programs.filters
	}));

	const [expanded, setExpanded] = useState(true);

	// 폼 입력값
	const [name, setName] = useState(programsFilter.name);
	const [objCd, setObjCd] = useState(programsFilter.objCd);

	function onBtnSearchClick() {
		const validationComps = [
			{ key: '프로그램ID', value: objCd, type: 'text', required: false, maxLength: 20 },
			{ key: '프로그램명', value: name, type: 'text', required: false, maxLength: 20 }
		];

		if (KtngUtils.validationComps(validationComps, dispatch, srchRef)) {
			// 변경된 검색조건 으로 조회
			dispatch(changeProgramsFilter({ objCd, name }));
		}
	}

	return (
		<>
			{/* 검색조건 툴바 */}
			<UutasToolBar onBtnSearchClick={onBtnSearchClick} expanded={expanded} onBtnToggleClick={setExpanded} />

			{/* 검색조건 입력폼 */}
			<UutasForm
				srchRef={srchRef}
				expanded={expanded}
				schema={formSchema}
				// 프로그램ID
				objCd={
					<Input
						className="flex flex-1 px-8"
						placeholder="프로그램ID"
						fullWidth
						type="text"
						value={objCd}
						inputProps={{ maxLength: 20 }}
						onChange={e => setObjCd(e.target.value)}
						onKeyUp={e => {
							if (e.key === 'Enter') {
								onBtnSearchClick();
							}
						}}
					/>
				}
				// 프로그램명
				name={
					<Input
						className="flex flex-1 px-8"
						placeholder="프로그램명"
						fullWidth
						type="text"
						value={name}
						inputProps={{ maxLength: 20 }}
						onChange={e => setName(e.target.value)}
						onKeyUp={e => {
							if (e.key === 'Enter') {
								onBtnSearchClick();
							}
						}}
					/>
				}
			/>
		</>
	);
};

export default PrgMngSrch;
