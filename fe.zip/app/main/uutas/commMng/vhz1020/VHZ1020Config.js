import VHZ1020Page from './VHZ1020Page';

// `메뉴경로` - `화면` 맵핑 정보를 가진 Config는 파일명 대문자로 시작
const VHZ1020Config = {
	routes: [
		{
			path: '/cmmnMng/cmmnCdMng/vhz1020',
			component: VHZ1020Page
		}
	]
};

export default VHZ1020Config;
