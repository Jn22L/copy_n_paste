import React, { useState, useRef } from 'react';
import { useDispatch } from 'react-redux';
import { Input } from '@material-ui/core';
import { UutasToolBar, UutasForm } from '@ktng/uutas';
import KtngUtils from '@ktng/utils';
import { showMessage } from 'app/store/fuse/messageSlice';
import { getCmCodes } from '../store/vhz1020MstSlice';

const formSchema = [
	// row 1
	[
		// col 1
		{
			id: 'grpCode',
			label: '그룹코드',
			width: 150,
			align: 'center',
			required: false
		},
		// col 2
		{
			id: 'grpName',
			label: '그룹명',
			width: 150,
			align: 'center',
			required: false
		}
	]
];

const VHZ1020Srch = () => {
	const dispatch = useDispatch();

	// 입력된 값의 유효성검사를 하기위해 `useRef`로 폼입력컨트롤의 DOM에 접근한다
	const srchRef = useRef();

	const [expanded, setExpanded] = useState(true);

	// 폼 입력값
	const [grpCode, setGrpCode] = useState('');
	const [grpName, setGrpName] = useState('');

	function onBtnSearchClick() {
		const validationComps = [
			{ key: '그룹코드', value: grpCode, type: 'text', required: false, maxLength: 20 },
			{ key: '그룹명', value: grpName, type: 'text', required: false, maxLength: 20 }
		];

		if (KtngUtils.validationComps(validationComps, dispatch, srchRef)) {
			// 변경된 검색조건 으로 조회
			dispatch(getCmCodes({ grpCode, grpName })).then(action => {
				const data = action.payload;
				if (data && data.list) {
					dispatch(showMessage({ message: `총 ${data.list.length}건이 조회되었습니다.` }));
				}
			}); // DB 에서 조회
		}
	}

	return (
		<>
			{/* 검색조건 툴바 */}
			<UutasToolBar onBtnSearchClick={onBtnSearchClick} expanded={expanded} onBtnToggleClick={setExpanded} />

			{/* 검색조건 입력폼 */}
			<UutasForm
				srchRef={srchRef}
				expanded={expanded}
				schema={formSchema}
				// 권한ID
				grpCode={
					<Input
						className="flex flex-1 px-8"
						placeholder="그룹코드"
						fullWidth
						type="text"
						value={grpCode}
						inputProps={{ maxLength: 20 }}
						onChange={e => setGrpCode(e.target.value)}
						onKeyUp={e => {
							if (e.key === 'Enter') {
								onBtnSearchClick();
							}
						}}
					/>
				}
				// 권한명
				grpName={
					<Input
						className="flex flex-1 px-8"
						placeholder="그룹명"
						fullWidth
						type="text"
						value={grpName}
						inputProps={{ maxLength: 20 }}
						onChange={e => setGrpName(e.target.value)}
						onKeyUp={e => {
							if (e.key === 'Enter') {
								onBtnSearchClick();
							}
						}}
					/>
				}
			/>
		</>
	);
};

export default VHZ1020Srch;
