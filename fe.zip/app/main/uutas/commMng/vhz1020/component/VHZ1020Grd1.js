import KtngIbSheet from '@ktng/core/KtngIbSheet';
import KtngUtils from '@ktng/utils';
import { UutasToolBar } from '@ktng/uutas';
import { showMessage } from 'app/store/fuse/messageSlice';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { selectCmCodes, getCmCodes } from '../store/vhz1020MstSlice';
import sheetOptions from './VHZ1020GrdOpt1';

const sheetId = KtngUtils.getUid('vhz1020-grd1');

const VHZ1020Grd1 = () => {
	const dispatch = useDispatch();

	const gridResult = useSelector(selectCmCodes);

	const [sheetObj, setSheetObj] = useState();
	const [grdData, setGrdData] = useState([]);

	// 1. 데이터 조회
	useEffect(() => {
		dispatch(getCmCodes({})).then(action => {
			const data = action.payload;
			if (data && data.list) {
				dispatch(showMessage({ message: `총 ${data.list.length}건이 조회되었습니다.` }));
			}
		});
	}, [dispatch]);

	// 2. 데이터 필터
	useEffect(() => {
		setGrdData(gridResult);
	}, [gridResult]);

	// 그리드 생성 콜백
	function onSheetLoad(sheet) {
		setSheetObj(sheet);

		// 이벤트 등록
		// sheet.bind('onAfterClick', onSheetClick);
	}

	// 그리드 엑셀 다운로드
	function handleBtnDownExcelClick() {
		return {
			/* Excel Config */
		};
	}

	return (
		<div className="flex flex-col w-full">
			<UutasToolBar
				title="공통코드 목록"
				variant="subtitle1"
				sheet={sheetObj}
				onBtnDownExcelClick={handleBtnDownExcelClick} // Excel Config 반환
			/>

			<KtngIbSheet
				// [필수 속성]
				sheetId={sheetId}
				options={sheetOptions}
				data={grdData}
				// [선택 속성]
				// - 이벤트
				onLoad={onSheetLoad} // 생성된 sheet 객체 바인딩 및 공통코드 로드 수행
				//   ※ 아래 2개 외 필요한 이벤트는 `onSheetLoad`에서 직접 바인딩할 것
				// onAfterClick={onSheetClick} // 내부공통기능 수행 후 `onSheetClick` 콜백이 호출됨
				// onAfterChange={onSheetChange} // 내부공통기능 수행 후 `onSheetChange` 콜백이 호출됨
				// - 스타일 속성
				// className="" // tailwind 스타일 적용 가능
				style={{ height: '98%' }} // 그리드 초기 높이 설정시에는 style만 적용됨
			/>
		</div>
	);
};

export default VHZ1020Grd1;
