const options = {
	Cfg: {
		CanSelect: false, // 시트 선택 가능
		SelectingCells: 1, // 개별 셀 선택 가능
		CustomScroll: 1, // 그리드와 스크롤 겹침 이슈 처리
		CanEdit: 0 // 수정 불가능
	},
	Def: {},
	Cols: [
		{
			Header: '그룹코드',
			Name: 'grpCode',
			Type: 'Text',
			Align: 'Left',
			RelWidth: 1
		},
		{
			Header: '그룹명',
			Name: 'grpName',
			Type: 'Text',
			Align: 'Left',
			RelWidth: 1
		},
		{
			Header: '공통코드',
			Name: 'commCode',
			Type: 'Text',
			Align: 'Left',
			RelWidth: 1
		},
		{
			Header: '공통코드명',
			Name: 'commName',
			Type: 'Text',
			Align: 'Left',
			RelWidth: 1
		}
	]
};

export default options;
