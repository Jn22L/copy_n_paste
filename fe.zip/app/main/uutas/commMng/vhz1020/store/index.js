import { combineReducers } from 'redux';
import vhz1020Mst from './vhz1020MstSlice';

const reducer = combineReducers({
	vhz1020Mst
});

export default reducer;
