import { createSlice, createAsyncThunk, createEntityAdapter } from '@reduxjs/toolkit';
import KtngUtils from '@ktng/utils';
import vhz1020Service from 'app/services/vhz1020Service';

export const getCmCodes = createAsyncThunk(
	'vhz1020/vhz1020Mst/getCmCodes',
	async ({ grpCode, grpName }, { dispatch, rejectWithValue }) => {
		try {
			const data = await vhz1020Service.selectCommCodeList(grpCode, grpName);
			return {
				list: data.list,
				params: {
					grpCode,
					grpName
				}
			};
		} catch (err) {
			throw KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

const cmCodesAdapter = createEntityAdapter({
	selectId: cmCode => `${cmCode.grpCode}.${cmCode.commCode}`
});

export const { selectAll: selectCmCodes, selectById: selectCmCodeById } = cmCodesAdapter.getSelectors(
	state => state.vhz1020.vhz1020Mst
);

const initialState = {
	params: {
		grpCode: '',
		grpName: ''
	},
	loading: false
};

const vhz1020MstSlice = createSlice({
	name: 'vhz1020/vhz1020Mst',
	initialState: cmCodesAdapter.getInitialState(initialState),
	reducers: {
		changeCmCodesFilter: (state, action) => {
			state.filters = {
				...state.filters,
				...action.payload
			};
		},
		clearCmCodesFilter: state => {
			state.filters = initialState.filters;
		},
		changeCmCode: cmCodesAdapter.updateOne,
		changeCmCodes: cmCodesAdapter.updateMany,
		clearCmCodes: cmCodesAdapter.removeAll
	},
	extraReducers: {
		[getCmCodes.pending]: state => {
			state.loading = true;
		},
		[getCmCodes.fulfilled]: (state, action) => {
			const { list, params } = action.payload;
			cmCodesAdapter.setAll(state, list);
			state.params = params;
			state.loading = false;
		},
		[getCmCodes.rejected]: state => {
			state.loading = false;
		}
	}
});

export const { changeRolesFilter, clearRolesFilter, changeRole, changeRoles, clearRoles } = vhz1020MstSlice.actions;

export default vhz1020MstSlice.reducer;
