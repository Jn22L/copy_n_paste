/*
 * `배차관리시스템` 업무 화면에 대한 메뉴경로 파일
 */

import vhaMngConfig from './vhaMng/vhaMngConfig';
import vhbMngConfig from './vhbMng/vhbMngConfig';
import vhcMngConfig from './vhcMng/vhcMngConfig';
import vhdMngConfig from './vhdMng/vhdMngConfig';
import commMngConfig from './commMng/commMngConfig';
import UutasMainPage from './UutasMainPage';

// 리스트로 된 Config는 파일명 소문자로 시작
const uutasConfig = [
	...vhaMngConfig, // `기준정보` 하위 메뉴 추가
	...vhbMngConfig, // `배차신청관리` 하위 메뉴 추가
	...vhcMngConfig, // `배차관리` 하위 메뉴 추가
	...vhdMngConfig, // `실적관리` 하위 메뉴 추가
	...commMngConfig, // `공통관리` 하위 메뉴 추가
	{
		routes: [
			{
				path: '/main',
				component: UutasMainPage
			}
		]
	}
];

export default uutasConfig;
