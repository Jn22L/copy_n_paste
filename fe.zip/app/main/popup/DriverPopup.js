// **************************************************************************
// 파    일    명   : DriverPopup.js
// 업무    대분류   : 공통팝업
// 업무    중분류   : 운전자 팝업
// 업    무    명   : 운전자 팝업
// 프로그램 내용     : 운전자를 선택할 수 있는 공통팝업
// 기          타   :
// ==========================================================================
// 작성자          : 김 민 우
// 작성일          : 2021.12.27
// 최종 수정일     :
// 변경이력        :
// **************************************************************************

import _ from '@lodash';
import {
	Button,
	DialogActions,
	DialogContent,
	DialogTitle,
	FormControl,
	InputLabel,
	makeStyles,
	MenuItem,
	Select,
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableRow,
	TextField
} from '@material-ui/core';
import { showMessage } from 'app/store/fuse/messageSlice';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import UutasBackdrop from '@ktng/uutas/UutasPageSimple/UutasBackdrop';
import commonService from 'app/services/commonService';
import KtngUtils from '@ktng/utils';
import { useCmmCodeLoadEffect } from '@ktng/hooks';

const useStyles = makeStyles(() => ({
	left: {
		overflow: 'scroll',
		padding: 5,
		borderRightWidth: '1px',
		borderColor: 'rgba(0, 0, 0, 0.12)'
	},
	root: {
		width: '100%',
		minHeight: 380,
		maxHeight: 380,
		'&&.MuiDialogContent-root': {
			padding: 5,
			borderBottomWidth: '1px',
			borderColor: 'rgba(0, 0, 0, 0.12)'
		}
	}
}));

const reqCodes = [{ commCodeChk: 'VH_DEPT_ALL' }]; // 불러올 공통코드 리스트

const DriverPopup = props => {
	const classes = useStyles();
	const dispatch = useDispatch();

	const { vhDeptCodes } = useSelector(({ ktng }) => ({
		vhDeptCodes: ktng.code.VH_DEPT_ALL // 불러온 공통코드 리스트
	}));

	const [vhclDeptCd, setVhclDeptCd] = useState('ALL'); // 전체
	const [useYn, setUseYn] = useState('ALL'); // 전체
	const [driverNo, setDriverNo] = useState('');
	const [driverNm, setDriverNm] = useState('');

	const [selectedItem, setSelectedItem] = useState();
	const [list, setList] = useState();
	const [driverListLoading, setDriverListLoading] = useState(false);

	// 공통코드 리스트 불러오기 (이미 store에 있으면 요청안함)
	useCmmCodeLoadEffect(() => {}, [reqCodes]);

	/**
	 * 화면 로드 시 작동
	 */
	useEffect(() => {
		if (!vhDeptCodes) return;

		setVhclDeptCd(props.vhclDeptCd || 'ALL');
		setUseYn(props.useYn || 'ALL');
		setDriverNo(props.driverNo || '');
		setDriverNm(props.driverNm || '');

		if (!validateSearchParams(props.driverNo, props.driverNm)) return;

		let _vhclDeptCd = props.vhclDeptCd;
		if (_vhclDeptCd === 'ALL') {
			_vhclDeptCd = null;
		}
		let _useYn = props.useYn;
		if (_useYn === 'ALL') {
			_useYn = null;
		}

		setDriverListLoading(true);
		commonService
			.getDriverList({
				vhclDeptCd: _vhclDeptCd,
				useYn: _useYn,
				driverNo: props.driverNo,
				driverNm: props.driverNm
			})
			.then(data => {
				setDriverListLoading(false);
				if (data && data.list) {
					setList(data.list);

					// 조회결과가 1건 이상인 경우
					if (data.list.length > 0) {
						setSelectedItem(data.list[0]);

						// 조회결과가 1건이고 `museClick`이 false인 경우, 즉시 선택
						if (data.list.length === 1 && props.museClick === false) {
							if (props.onSelect) {
								props.onSelect(data.list[0]);
							}
						} else {
							dispatch(showMessage({ message: `${data.list.length}건이 조회되었습니다.` }));
						}
					} else {
						dispatch(showMessage({ message: '0건이 조회되었습니다.' }));
					}
				}
			})
			.catch(err => {
				setDriverListLoading(false);
				if (props.onClose) {
					props.onClose();
				}
			});
		// eslint-disable-next-line
	}, [dispatch, vhDeptCodes, props]);

	//	클릭시 Row 색상 이벤트
	const isSelected = item => {
		const temp1 = _.pick(selectedItem, ['driverNo']);
		const temp2 = _.pick(item, ['driverNo']);

		return _.isEqual(temp1, temp2);
	};

	// 엔터 이벤트
	const handleKeyPress = event => {
		if (event.key === 'Enter') {
			search();
		}
	};

	//	검색 이벤트
	const search = () => {
		if (!validateSearchParams(driverNo, driverNm)) return;

		let _vhclDeptCd = vhclDeptCd;
		if (_vhclDeptCd === 'ALL') {
			_vhclDeptCd = null;
		}

		let _useYn = useYn;
		if (_useYn === 'ALL') {
			_useYn = null;
		}

		setDriverListLoading(true);
		commonService
			.getDriverList({ vhclDeptCd: _vhclDeptCd, useYn: _useYn, driverNo, driverNm })
			.then(data => {
				setDriverListLoading(false);
				if (data && data.list) {
					setList(data.list);
					dispatch(showMessage({ message: `${data.list.length}건이 조회되었습니다.` }));
				}
			})
			.catch(err => {
				setDriverListLoading(false);
				if (props.onClose) {
					props.onClose();
				}
			});
	};

	// 클릭 이벤트
	const handleRowClick = (event, item) => {
		setSelectedItem(item);
	};

	// 더블클릭 이벤트
	const handleRowDoubleClick = (event, item) => {
		setSelectedItem(item);
		handleOKBtnClick();
	};

	//	취소버튼 클릭 이벤트
	const handleClose = () => {
		if (props.onClose) {
			props.onClose();
		}
	};

	//	선택버튼 클릭 이벤트
	const handleOKBtnClick = () => {
		if (props.onSelect) {
			props.onSelect(selectedItem);
		}
	};

	// 검색어 검증
	const validateSearchParams = (_driverNo, _driverNm) => {
		const validationComps = [
			{ key: '운전원ID', value: _driverNo, type: 'text', required: false, minLength: 2 },
			{ key: '운전원성명', value: _driverNm, type: 'text', required: false, minLength: 2 }
		];
		if (!KtngUtils.validationComps(validationComps, dispatch)) return false;

		return true;
	};

	return (
		<>
			<DialogTitle>운전원 선택</DialogTitle>
			<div className="p-10 border-t border-b flex flex-row">
				<FormControl className="w-160 mx-4" variant="outlined" size="small">
					<InputLabel>부서코드</InputLabel>
					<Select
						label="부서코드"
						value={vhclDeptCd}
						onChange={e => setVhclDeptCd(e.target.value)}
						onKeyUp={handleKeyPress}
						disabled={props.readOnly}
					>
						<MenuItem value="ALL">전체</MenuItem>
						{vhDeptCodes &&
							vhDeptCodes.map((vhDept, key) => (
								<MenuItem key={key} value={vhDept.commCode}>
									{vhDept.commCodeName}
								</MenuItem>
							))}
					</Select>
				</FormControl>
				<FormControl className="w-96 mx-4" variant="outlined" size="small">
					<InputLabel>근무여부</InputLabel>
					<Select
						label="근무여부"
						value={useYn}
						onChange={e => setUseYn(e.target.value)}
						onKeyUp={handleKeyPress}
						disabled={props.readOnly}
					>
						<MenuItem value="ALL">전체</MenuItem>
						<MenuItem value="Y">근무</MenuItem>
						<MenuItem value="N">미근무</MenuItem>
					</Select>
				</FormControl>
				<TextField
					className="w-128 mx-4"
					label="운전원ID"
					name="driverNo"
					size="small"
					variant="outlined"
					inputProps={{ maxLength: 10 }}
					onChange={e => setDriverNo(e.target.value)}
					onKeyPress={handleKeyPress}
					value={driverNo}
					disabled={props.readOnly}
				/>
				<TextField
					className="w-160 mx-4"
					label="운전원성명"
					name="driverNm"
					size="small"
					variant="outlined"
					onChange={e => setDriverNm(e.target.value)}
					onKeyPress={handleKeyPress}
					fullWidth
					value={driverNm}
					disabled={props.readOnly}
				/>
				<Button variant="contained" color="primary" onClick={() => search()} disabled={props.readOnly}>
					검색
				</Button>
			</div>
			<DialogContent className={classes.root}>
				<Table className="table5" size="small">
					<colgroup>
						<col style={{ width: '10rem' }} />
						<col style={{ width: '12rem' }} />
						<col style={{ width: '12rem' }} />
					</colgroup>
					<TableHead>
						<TableRow>
							<TableCell align="center">운전원ID</TableCell>
							<TableCell align="center">성명</TableCell>
							<TableCell align="center">휴대전화</TableCell>
						</TableRow>
					</TableHead>
					<TableBody>
						{list &&
							list.map((item, index) => {
								const isItemSelected = isSelected(item);
								return (
									<TableRow
										key={index}
										className="cursor-pointer"
										hover
										selected={isItemSelected}
										onClick={event => handleRowClick(event, item)}
										onDoubleClick={event => handleRowDoubleClick(event, item)}
									>
										<TableCell align="center">{item.driverNo}</TableCell>
										<TableCell align="center">{item.driverNm}</TableCell>
										<TableCell align="center">{KtngUtils.formatTelNo(item.cellPn)}</TableCell>
									</TableRow>
								);
							})}
					</TableBody>
				</Table>
				<UutasBackdrop open={driverListLoading} />
			</DialogContent>
			<DialogActions>
				<Button onClick={handleOKBtnClick} color="primary" disabled={!selectedItem} autoFocus>
					OK
				</Button>
				<Button onClick={handleClose} color="primary">
					CANCEL
				</Button>
			</DialogActions>
		</>
	);
};

export default DriverPopup;
