import { IconButton, Input, MenuItem, Select } from '@material-ui/core';
import { Search } from '@material-ui/icons';
import { closeDialog, openDialog } from 'app/store/fuse/dialogSlice';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { string, func, object, array, bool } from 'prop-types';
import { useCmmCodeLoadEffect } from '@ktng/hooks';
import VehiclePopup from './VehiclePopup';

const reqCodes = [{ commCodeChk: 'VH_DEPT_ALL' }];

const VehiclePicker = props => {
	const dispatch = useDispatch();

	const { vhDeptCodes } = useSelector(({ ktng }) => ({
		vhDeptCodes: ktng.code.VH_DEPT_ALL
	}));

	// `차량` 선택결과
	const [vhclDeptCd, setVhclDeptCd] = useState(props.vhclDeptCd || 'ALL'); // `차량` 팝업 배차부서코드
	const [vhclNo, setVhclNo] = useState(props.vhclNo || '');
	const [vhclNm, setVhclNm] = useState(props.vhclNm || '');

	const [views, setViews] = useState();
	const [disabledViews, setDisabledViews] = useState();

	useEffect(() => {
		setVhclDeptCd(state => props.vhclDeptCd || state);
		// null/undefined이면 기존 state값 사용, 문자열(빈 문자열 포함)인 경우 props값 사용
		setVhclNo(state => (props.vhclNo || props.vhclNo === '' ? props.vhclNo : state));
		setVhclNm(state => (props.vhclNm || props.vhclNm === '' ? props.vhclNm : state));
	}, [props.vhclDeptCd, props.vhclNo, props.vhclNm]);

	useEffect(() => {
		if (props.views) {
			const _views = {};
			props.views.forEach(view => {
				_views[view] = true;
			});
			setViews(_views);
		}
		if (props.disabledViews) {
			const _views = {};
			props.disabledViews.forEach(view => {
				_views[view] = true;
			});
			setDisabledViews(_views);
		}
	}, [props.views, props.disabledViews]);

	// `배차부서` 공통코드 리스트 조회
	useCmmCodeLoadEffect(() => {}, [reqCodes]);

	// `차량` 팝업 열기
	function openVehiclePopup(museClick) {
		dispatch(
			openDialog({
				children: (
					<VehiclePopup
						onSelect={selected => {
							setVhclNo(selected.vhclNo);
							setVhclNm(selected.vhclNm);
							props.onChange(selected);
							dispatch(closeDialog());
						}}
						onClose={() => dispatch(closeDialog())}
						// 조회조건
						vhclDeptCd={vhclDeptCd} // 팝업 열자마자 입력한 배차부서코드로 검색
						vhclNo={vhclNo} // 팝업 열자마자 입력한 차량번호로 검색
						vhclNm={vhclNm} // 팝업 열자마자 입력한 차량명으로 검색
						// 옵션
						museClick={museClick} // false면, 조회결과 1건인 경우 자동선택하고 팝업을 닫음
						readOnly={props.readOnly} // true면 팝업 내에서 조회조건 수정불가
					/>
				)
			})
		);
	}

	return (
		<div className={props.className}>
			{(!views || views.vhclDeptCd) && (
				<Select
					className="w-160 text-center mx-4"
					placeholder="배차부서코드"
					value={vhclDeptCd}
					onChange={e => {
						setVhclDeptCd(e.target.value);
						props.onChange({ vhclDeptCd: e.target.value, vhclNo, vhclNm });
					}}
					disabled={disabledViews && disabledViews.vhclDeptCd}
				>
					<MenuItem value="ALL">전체</MenuItem>
					{vhDeptCodes &&
						vhDeptCodes.map((code, key) => (
							<MenuItem key={key} value={code.commCode}>
								{code.commCodeName}
							</MenuItem>
						))}
				</Select>
			)}
			{(!views || views.vhclNo) && (
				<Input
					className="w-96 mx-4"
					placeholder="차량번호"
					value={vhclNo}
					onChange={e => {
						setVhclNo(e.target.value);
						setVhclNm(''); // 차량번호, 차량명 둘 중 하나 입력 시 다른 하나 clear
						props.onChange({ vhclDeptCd, vhclNo: e.target.value, vhclNm: '' });
					}}
					onKeyUp={e => {
						// 차량번호 입력 후 `Enter` 입력 시 팝업 실행
						if (e.key === 'Enter') {
							openVehiclePopup(false);
						}
					}}
					disabled={disabledViews && disabledViews.vhclNo}
				/>
			)}
			{(!views || views.vhclNm) && (
				<Input
					className="w-160 mx-4"
					placeholder="차종"
					value={vhclNm}
					onChange={e => {
						setVhclNo(''); // 차량번호, 차량명 둘 중 하나 입력 시 다른 하나 clear
						setVhclNm(e.target.value);
						props.onChange({ vhclDeptCd, vhclNo: '', vhclNm: e.target.value });
					}}
					onKeyUp={e => {
						// 차종 입력 후 `Enter` 입력 시 팝업 실행
						if (e.key === 'Enter') {
							openVehiclePopup(false);
						}
					}}
					disabled={disabledViews && disabledViews.vhclNm}
				/>
			)}
			<IconButton
				size="small"
				onClick={e => openVehiclePopup()} // 🔍 버튼 클릭 시 팝업 실행
			>
				<Search fontSize="small" />
			</IconButton>
		</div>
	);
};

VehiclePicker.propTypes = {
	className: string || object,
	vhclDeptCd: string,
	vhclNo: string,
	vhclNm: string,
	views: array,
	disabledViews: array,
	onChange: func,
	readOnly: bool
};

VehiclePicker.defaultProps = {
	views: null,
	disabledViews: [],
	onChange: () => {},
	readOnly: false
};

export default VehiclePicker;
