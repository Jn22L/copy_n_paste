import { IconButton, Input, MenuItem, Select } from '@material-ui/core';
import { Search } from '@material-ui/icons';
import { closeDialog, openDialog } from 'app/store/fuse/dialogSlice';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { string, func, object, array, bool } from 'prop-types';
import { useCmmCodeLoadEffect } from '@ktng/hooks';
import DriverPopup from './DriverPopup';

const reqCodes = [{ commCodeChk: 'VH_DEPT_ALL' }];

const DriverPicker = props => {
	const dispatch = useDispatch();

	const { vhDeptCodes } = useSelector(({ ktng }) => ({
		vhDeptCodes: ktng.code.VH_DEPT_ALL
	}));

	// `운전원` 선택결과
	const [vhclDeptCd, setVhclDeptCd] = useState(props.vhclDeptCd || 'ALL'); // `운전원` 팝업 배차부서코드
	const [useYn, setUseYn] = useState(props.useYn || 'ALL'); // `운전원` 팝업 근무여부
	const [driverNo, setDriverNo] = useState(props.driverNo || '');
	const [driverNm, setDriverNm] = useState(props.driverNm || '');

	const [views, setViews] = useState();
	const [disabledViews, setDisabledViews] = useState();

	useEffect(() => {
		setVhclDeptCd(state => props.vhclDeptCd || state);
		setUseYn(state => props.useYn || state);
		// null/undefined이면 기존 state값 사용, 문자열(빈 문자열 포함)인 경우 props값 사용
		setDriverNo(state => (props.driverNo || props.driverNo === '' ? props.driverNo : state));
		setDriverNm(state => (props.driverNm || props.driverNm === '' ? props.driverNm : state));
	}, [props.vhclDeptCd, props.useYn, props.driverNo, props.driverNm]);

	useEffect(() => {
		if (props.views) {
			const _views = {};
			props.views.forEach(view => {
				_views[view] = true;
			});
			setViews(_views);
		}
		if (props.disabledViews) {
			const _views = {};
			props.disabledViews.forEach(view => {
				_views[view] = true;
			});
			setDisabledViews(_views);
		}
	}, [props.views, props.disabledViews]);

	// `배차부서` 공통코드 리스트 조회
	useCmmCodeLoadEffect(() => {}, [reqCodes]);

	// `운전원` 팝업 열기
	function openDriverPopup(museClick) {
		dispatch(
			openDialog({
				children: (
					<DriverPopup
						onSelect={selected => {
							setDriverNo(selected.driverNo);
							setDriverNm(selected.driverNm);
							props.onChange(selected);
							dispatch(closeDialog());
						}}
						onClose={() => dispatch(closeDialog())}
						// 조회조건
						vhclDeptCd={vhclDeptCd} // 팝업 열자마자 입력한 배차부서코드로 검색
						useYn={useYn} // 팝업 열자마자 입력한 근무여부로 검색
						driverNo={driverNo} // 팝업 열자마자 입력한 운전원ID로 검색
						driverNm={driverNm} // 팝업 열자마자 입력한 운전원성명으로 검색
						// 옵션
						museClick={museClick} // false면, 조회결과 1건인 경우 자동선택하고 팝업을 닫음
						readOnly={props.readOnly} // true면 팝업 내에서 조회조건 수정불가
					/>
				)
			})
		);
	}

	return (
		<div className={props.className}>
			{(!views || views.vhclDeptCd) && (
				<Select
					className="w-160 text-center mx-4"
					placeholder="배차부서코드"
					value={vhclDeptCd}
					onChange={e => {
						setVhclDeptCd(e.target.value);
						props.onChange({ vhclDeptCd: e.target.value, useYn, driverNo, driverNm });
					}}
					disabled={disabledViews && disabledViews.vhclDeptCd}
				>
					<MenuItem value="ALL">전체</MenuItem>
					{vhDeptCodes &&
						vhDeptCodes.map((code, key) => (
							<MenuItem key={key} value={code.commCode}>
								{code.commCodeName}
							</MenuItem>
						))}
				</Select>
			)}
			{(!views || views.useYn) && (
				<Select
					className="w-84 text-center mx-4"
					placeholder="근무여부"
					value={useYn}
					onChange={e => {
						setUseYn(e.target.value);
						props.onChange({ vhclDeptCd, useYn: e.target.value, driverNo, driverNm });
					}}
					disabled={disabledViews && disabledViews.useYn}
				>
					<MenuItem value="ALL">전체</MenuItem>
					<MenuItem value="Y">근무</MenuItem>
					<MenuItem value="N">미근무</MenuItem>
				</Select>
			)}
			{(!views || views.driverNo) && (
				<Input
					className="w-96 mx-4"
					placeholder="운전원ID"
					value={driverNo}
					onChange={e => {
						setDriverNo(e.target.value);
						setDriverNm(''); // 운전원ID, 운전원성명 둘 중 하나 입력 시 다른 하나 clear
						props.onChange({ vhclDeptCd, useYn, driverNo: e.target.value, driverNm: '' });
					}}
					onKeyUp={e => {
						// 운전원ID 입력 후 `Enter` 입력 시 팝업 실행
						if (e.key === 'Enter') {
							openDriverPopup(false);
						}
					}}
					disabled={disabledViews && disabledViews.driverNo}
				/>
			)}
			{(!views || views.driverNm) && (
				<Input
					className="w-160 mx-4"
					placeholder="운전원성명"
					value={driverNm}
					onChange={e => {
						setDriverNo(''); // 운전원ID, 운전원성명 둘 중 하나 입력 시 다른 하나 clear
						setDriverNm(e.target.value);
						props.onChange({ vhclDeptCd, useYn, driverNo: '', driverNm: e.target.value });
					}}
					onKeyUp={e => {
						// 운전원성명 입력 후 `Enter` 입력 시 팝업 실행
						if (e.key === 'Enter') {
							openDriverPopup(false);
						}
					}}
					disabled={disabledViews && disabledViews.driverNm}
				/>
			)}
			<IconButton
				size="small"
				onClick={e => openDriverPopup()} // 🔍 버튼 클릭 시 팝업 실행
			>
				<Search fontSize="small" />
			</IconButton>
		</div>
	);
};

DriverPicker.propTypes = {
	className: string || object,
	vhclDeptCd: string,
	useYn: string,
	driverNo: string,
	driverNm: string,
	views: array,
	disabledViews: array,
	onChange: func,
	readOnly: bool
};

DriverPicker.defaultProps = {
	views: null,
	disabledViews: [],
	onChange: () => {},
	readOnly: false
};

export default DriverPicker;
