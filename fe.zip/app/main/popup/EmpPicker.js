import { IconButton, Input } from '@material-ui/core';
import { Search } from '@material-ui/icons';
import { closeDialog, openDialog } from 'app/store/fuse/dialogSlice';
import React, { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { string, func, object, array, bool } from 'prop-types';
import EmpPopup from './EmpPopup';

const EmpPicker = props => {
	const dispatch = useDispatch();

	// `사원` 선택결과
	const [empNo, setEmpNo] = useState(props.empNo || '');
	const [empNm, setEmpNm] = useState(props.empNm || '');

	const [views, setViews] = useState();
	const [disabledViews, setDisabledViews] = useState();

	useEffect(() => {
		// null/undefined이면 기존 state값 사용, 문자열(빈 문자열 포함)인 경우 props값 사용
		setEmpNo(state => (props.empNo || props.empNo === '' ? props.empNo : state));
		setEmpNm(state => (props.empNm || props.empNm === '' ? props.empNm : state));
	}, [props.empNo, props.empNm]);

	useEffect(() => {
		if (props.views) {
			const _views = {};
			props.views.forEach(view => {
				_views[view] = true;
			});
			setViews(_views);
		}
		if (props.disabledViews) {
			const _views = {};
			props.disabledViews.forEach(view => {
				_views[view] = true;
			});
			setDisabledViews(_views);
		}
	}, [props.views, props.disabledViews]);

	// `사원` 팝업 열기
	function openEmpPopup(museClick) {
		dispatch(
			openDialog({
				children: (
					<EmpPopup
						onSelect={selected => {
							setEmpNo(selected.empNo);
							setEmpNm(selected.empNm);
							props.onChange(selected);
							dispatch(closeDialog());
						}}
						onClose={() => dispatch(closeDialog())}
						// 조회조건
						empNo={empNo} // 팝업 열자마자 입력한 사번으로 검색
						empNm={empNm} // 팝업 열자마자 입력한 성명으로 검색
						// 옵션
						museClick={museClick} // false면, 조회결과 1건인 경우 자동선택하고 팝업을 닫음
						readOnly={props.readOnly} // true면 팝업 내에서 조회조건 수정불가
					/>
				)
			})
		);
	}

	return (
		<div className={props.className}>
			{(!views || views.empNo) && (
				<Input
					className="w-96 mx-4"
					placeholder="사번"
					value={empNo}
					onChange={e => {
						setEmpNo(e.target.value);
						setEmpNm('');
						props.onChange({ empNo: e.target.value, empNm: '' });
					}}
					onKeyUp={e => {
						// 사번 입력 후 `Enter` 입력 시 팝업 실행
						if (e.key === 'Enter') {
							openEmpPopup(false);
						}
					}}
					disabled={disabledViews && disabledViews.empNo}
				/>
			)}
			{(!views || views.empNm) && (
				<Input
					className="w-160 mx-4"
					placeholder="성명"
					value={empNm}
					onChange={e => {
						setEmpNo('');
						setEmpNm(e.target.value);
						props.onChange({ empNo: '', empNm: e.target.value });
					}}
					onKeyUp={e => {
						// 성명 입력 후 `Enter` 입력 시 팝업 실행
						if (e.key === 'Enter') {
							openEmpPopup(false);
						}
					}}
					disabled={disabledViews && disabledViews.empNm}
				/>
			)}
			<IconButton
				size="small"
				onClick={e => openEmpPopup()} // 🔍 버튼 클릭 시 팝업 실행
			>
				<Search fontSize="small" />
			</IconButton>
		</div>
	);
};

EmpPicker.propTypes = {
	className: string || object,
	empNo: string,
	empNm: string,
	views: array,
	disabledViews: array,
	onChange: func,
	readOnly: bool
};

EmpPicker.defaultProps = {
	views: null,
	disabledViews: [],
	onChange: () => {},
	readOnly: false
};

export default EmpPicker;
