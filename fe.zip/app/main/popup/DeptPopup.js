// **************************************************************************
// 파    일    명   : DeptPopup.js
// 업무    대분류   : 공통팝업
// 업무    중분류   : 부서코드 팝업
// 업    무    명   : 부서코드 팝업
// 프로그램 내용     : 부서코드를 선택할 수 있는 공통팝업
// 기          타   :
// ==========================================================================
// 작성자          : 김 민 우
// 작성일          : 2021.12.21
// 최종 수정일     :
// 변경이력        :
// **************************************************************************

import _ from '@lodash';
import {
	Button,
	DialogActions,
	DialogContent,
	DialogTitle,
	makeStyles,
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableRow,
	TextField
} from '@material-ui/core';
import { showMessage } from 'app/store/fuse/messageSlice';
import React, { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { KeyboardDatePicker } from '@material-ui/pickers';
import UutasBackdrop from '@ktng/uutas/UutasPageSimple/UutasBackdrop';
import { format } from 'date-fns';
import commonService from 'app/services/commonService';
import KtngUtils from '@ktng/utils';

const useStyles = makeStyles(() => ({
	left: {
		overflow: 'scroll',
		padding: 5,
		borderRightWidth: '1px',
		borderColor: 'rgba(0, 0, 0, 0.12)'
	},
	root: {
		width: '100%',
		minHeight: 380,
		maxHeight: 380,
		'&&.MuiDialogContent-root': {
			padding: 5,
			borderBottomWidth: '1px',
			borderColor: 'rgba(0, 0, 0, 0.12)'
		}
	}
}));

const DeptPopup = props => {
	const classes = useStyles();
	const dispatch = useDispatch();

	const [symd, setSymd] = useState(new Date());
	const [orgCd, setOrgCd] = useState('');
	const [orgFullNm, setOrgFullNm] = useState('');

	const [selectedItem, setSelectedItem] = useState();
	const [list, setList] = useState();
	const [deptListLoading, setDeptListLoading] = useState(false);

	/**
	 * 화면 로드 시 작동
	 */
	useEffect(() => {
		if (!props.orgCd && !props.orgFullNm) return; // 초기 검색어가 없는 경우 조회안함

		setSymd(props.symd || new Date());
		setOrgCd(props.orgCd || '');
		setOrgFullNm(props.orgFullNm || '');

		if (!validateSearchParams(props.symd, props.orgCd, props.orgFullNm)) return;

		setDeptListLoading(true);
		commonService
			.getDeptList({ symd: format(props.symd, 'yyyyMMdd'), orgCd: props.orgCd, orgFullNm: props.orgFullNm })
			.then(data => {
				setDeptListLoading(false);
				if (data && data.list) {
					setList(data.list);

					// 조회결과가 1건 이상인 경우
					if (data.list.length > 0) {
						setSelectedItem(data.list[0]);

						// 조회결과가 1건이고 `museClick`이 false인 경우, 즉시 선택
						if (data.list.length === 1 && props.museClick === false) {
							if (props.onSelect) {
								props.onSelect(data.list[0]);
							}
						} else {
							dispatch(showMessage({ message: `${data.list.length}건이 조회되었습니다.` }));
						}
					} else {
						dispatch(showMessage({ message: '0건이 조회되었습니다.' }));
					}
				}
			})
			.catch(err => {
				setDeptListLoading(false);
				if (props.onClose) {
					props.onClose();
				}
			});

		// eslint-disable-next-line
	}, [dispatch, props]);

	//	클릭시 Row 색상 이벤트
	const isSelected = item => {
		const temp1 = _.pick(selectedItem, ['orgCd']);
		const temp2 = _.pick(item, ['orgCd']);

		return _.isEqual(temp1, temp2);
	};

	// 엔터 이벤트
	const handleKeyPress = event => {
		if (event.key === 'Enter') {
			search();
		}
	};

	//	검색 이벤트
	const search = () => {
		if (!validateSearchParams(symd, orgCd, orgFullNm)) return;

		setDeptListLoading(true);
		commonService
			.getDeptList({ symd: format(symd, 'yyyyMMdd'), orgCd, orgFullNm })
			.then(data => {
				setDeptListLoading(false);
				if (data && data.list) {
					setList(data.list);
					dispatch(showMessage({ message: `${data.list.length}건이 조회되었습니다.` }));
				}
			})
			.catch(err => {
				setDeptListLoading(false);
				if (props.onClose) {
					props.onClose();
				}
			});
	};

	// 클릭 이벤트
	const handleRowClick = (event, item) => {
		setSelectedItem(item);
	};

	// 더블클릭 이벤트
	const handleRowDoubleClick = (event, item) => {
		setSelectedItem(item);
		handleOKBtnClick();
	};

	// 취소버튼 클릭 이벤트
	const handleClose = () => {
		if (props.onClose) {
			props.onClose();
		}
	};

	// 선택버튼 클릭 이벤트
	const handleOKBtnClick = () => {
		if (props.onSelect) {
			props.onSelect(selectedItem);
		}
	};

	// 검색어 검증
	const validateSearchParams = (_symd, _orgCd, _orgFullNm) => {
		const validationComps = [
			{ key: '기준일자', value: _symd, type: 'date', required: true, minLength: 8 },
			{ key: '부서코드', value: _orgCd, type: 'text', required: false, minLength: 2 },
			{ key: '부서명', value: _orgFullNm, type: 'text', required: false, minLength: 2 }
		];
		if (!KtngUtils.validationComps(validationComps, dispatch)) return false;

		// 부서코드, 부서명 둘 중 하나는 입력
		if (!_orgCd && !_orgFullNm) {
			dispatch(showMessage({ message: '부서코드, 부서명 둘 중 하나는 입력해주세요.', variant: 'error' }));
			return false;
		}

		return true;
	};

	return (
		<>
			<DialogTitle>부서 선택</DialogTitle>
			<div className="p-10 border-t border-b flex flex-row">
				<KeyboardDatePicker
					className="w-160 mx-4"
					size="small"
					inputVariant="outlined"
					label="기준일자"
					value={symd}
					format="yyyy.MM.dd"
					onChange={date => setSymd(date)}
					onKeyPress={handleKeyPress}
					disabled={props.readOnly}
				/>
				<TextField
					className="w-96 mx-4"
					label="부서코드"
					name="orgCd"
					size="small"
					variant="outlined"
					inputProps={{ maxLength: 10 }}
					onChange={e => setOrgCd(e.target.value)}
					onKeyPress={handleKeyPress}
					value={orgCd}
					disabled={props.readOnly}
				/>
				<TextField
					className="w-160 mx-4"
					label="부서명"
					name="orgFullNm"
					size="small"
					variant="outlined"
					onChange={e => setOrgFullNm(e.target.value)}
					onKeyPress={handleKeyPress}
					fullWidth
					value={orgFullNm}
					disabled={props.readOnly}
				/>
				<Button variant="contained" color="primary" onClick={() => search()} disabled={props.readOnly}>
					검색
				</Button>
			</div>
			<DialogContent className={classes.root}>
				<Table className="table5" size="small">
					<colgroup>
						<col style={{ width: '10rem' }} />
						<col style={{ width: '24rem' }} />
					</colgroup>
					<TableHead>
						<TableRow>
							<TableCell align="center">부서코드</TableCell>
							<TableCell align="center">부서명</TableCell>
						</TableRow>
					</TableHead>
					<TableBody>
						{list &&
							list.map((item, index) => {
								const isItemSelected = isSelected(item);
								return (
									<TableRow
										key={index}
										className="cursor-pointer"
										hover
										selected={isItemSelected}
										onClick={event => handleRowClick(event, item)}
										onDoubleClick={event => handleRowDoubleClick(event, item)}
									>
										<TableCell align="center">{item.orgCd}</TableCell>
										<TableCell align="left" style={{ height: '5.2rem', wordBreak: 'keep-all' }}>
											{item.orgFullNm}
										</TableCell>
									</TableRow>
								);
							})}
					</TableBody>
				</Table>
				<UutasBackdrop open={deptListLoading} />
			</DialogContent>
			<DialogActions>
				<Button onClick={handleOKBtnClick} color="primary" disabled={!selectedItem} autoFocus>
					OK
				</Button>
				<Button onClick={handleClose} color="primary">
					CANCEL
				</Button>
			</DialogActions>
		</>
	);
};

export default DeptPopup;
