// **************************************************************************
// 파    일    명   : EmpPopup.js
// 업무    대분류   : 공통팝업
// 업무    중분류   : 사원 팝업
// 업    무    명   : 사원 팝업
// 프로그램 내용     : 사원을 선택할 수 있는 공통팝업
// 기          타   :
// ==========================================================================
// 작성자          : 김 민 우
// 작성일          : 2021.12.27
// 최종 수정일     :
// 변경이력        :
// **************************************************************************

import _ from '@lodash';
import {
	Button,
	DialogActions,
	DialogContent,
	DialogTitle,
	makeStyles,
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableRow,
	TextField
} from '@material-ui/core';
import { showMessage } from 'app/store/fuse/messageSlice';
import React, { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { format, parse } from 'date-fns';
import UutasBackdrop from '@ktng/uutas/UutasPageSimple/UutasBackdrop';
import commonService from 'app/services/commonService';
import KtngUtils from '@ktng/utils';

const useStyles = makeStyles(() => ({
	left: {
		overflow: 'scroll',
		padding: 5,
		borderRightWidth: '1px',
		borderColor: 'rgba(0, 0, 0, 0.12)'
	},
	root: {
		width: '100%',
		minHeight: 380,
		maxHeight: 380,
		'&&.MuiDialogContent-root': {
			padding: 5,
			borderBottomWidth: '1px',
			borderColor: 'rgba(0, 0, 0, 0.12)'
		}
	}
}));

const EmpPopup = props => {
	const classes = useStyles();
	const dispatch = useDispatch();

	const [empNo, setEmpNo] = useState('');
	const [empNm, setEmpNm] = useState('');

	const [selectedItem, setSelectedItem] = useState();
	const [list, setList] = useState();
	const [empListLoading, setEmpListLoading] = useState(false);

	/**
	 * 화면 로드 시 작동
	 */
	useEffect(() => {
		if (!props.empNo && !props.empNm) return; // 초기 검색어가 없는 경우 조회안함

		setEmpNo(props.empNo || '');
		setEmpNm(props.empNm || '');

		if (!validateSearchParams(props.empNo, props.empNm)) return;

		setEmpListLoading(true);
		commonService
			.getEmpList({ empNo: props.empNo, empNm: props.empNm })
			.then(data => {
				setEmpListLoading(false);
				if (data && data.list) {
					setList(data.list);

					// 조회결과가 1건 이상인 경우
					if (data.list.length > 0) {
						setSelectedItem(data.list[0]);

						// 조회결과가 1건이고 `museClick`이 false인 경우, 즉시 선택
						if (data.list.length === 1 && props.museClick === false) {
							if (props.onSelect) {
								props.onSelect(data.list[0]);
							}
						} else {
							dispatch(showMessage({ message: `${data.list.length}건이 조회되었습니다.` }));
						}
					} else {
						dispatch(showMessage({ message: '0건이 조회되었습니다.' }));
					}
				}
			})
			.catch(err => {
				setEmpListLoading(false);
				if (props.onClose) {
					props.onClose();
				}
			});

		// eslint-disable-next-line
	}, [dispatch, props]);

	//	클릭시 Row 색상 이벤트
	const isSelected = item => {
		const temp1 = _.pick(selectedItem, ['empNo']);
		const temp2 = _.pick(item, ['empNo']);

		return _.isEqual(temp1, temp2);
	};

	// 엔터 이벤트
	const handleKeyPress = event => {
		if (event.key === 'Enter') {
			search();
		}
	};

	//	검색 이벤트
	const search = () => {
		if (!validateSearchParams(empNo, empNm)) return;

		setEmpListLoading(true);
		commonService
			.getEmpList({ empNo, empNm })
			.then(data => {
				setEmpListLoading(false);
				if (data && data.list) {
					setList(data.list);
					dispatch(showMessage({ message: `${data.list.length}건이 조회되었습니다.` }));
				}
			})
			.catch(err => {
				setEmpListLoading(false);
				if (props.onClose) {
					props.onClose();
				}
			});
	};

	// 클릭 이벤트
	const handleRowClick = (event, item) => {
		setSelectedItem(item);
	};

	// 더블클릭 이벤트
	const handleRowDoubleClick = (event, item) => {
		setSelectedItem(item);
		handleOKBtnClick();
	};

	//	취소버튼 클릭 이벤트
	const handleClose = () => {
		if (props.onClose) {
			props.onClose();
		}
	};

	//	선택버튼 클릭 이벤트
	const handleOKBtnClick = () => {
		if (props.onSelect) {
			props.onSelect(selectedItem);
		}
	};

	// 검색어 검증
	const validateSearchParams = (_empNo, _empNm) => {
		const validationComps = [
			{ key: '사번', value: _empNo, type: 'text', required: false, minLength: 2 },
			{ key: '성명', value: _empNm, type: 'text', required: false, minLength: 2 }
		];
		if (!KtngUtils.validationComps(validationComps, dispatch)) return false;

		// 사번, 성명 둘 중 하나는 입력
		if (!_empNo && !_empNm) {
			dispatch(showMessage({ message: '사번, 성명 둘 중 하나는 입력해주세요.', variant: 'error' }));
			return false;
		}

		return true;
	};

	return (
		<>
			<DialogTitle>사원 찾기</DialogTitle>
			<div className="p-10 border-t border-b flex flex-row">
				<TextField
					className="w-96 mx-4"
					label="사번"
					name="empNo"
					size="small"
					variant="outlined"
					inputProps={{ maxLength: 20 }}
					onChange={e => setEmpNo(e.target.value)}
					onKeyPress={handleKeyPress}
					value={empNo}
					disabled={props.readOnly}
				/>
				<TextField
					className="w-160 mx-4"
					label="성명"
					name="empNm"
					size="small"
					variant="outlined"
					inputProps={{ maxLength: 20 }}
					onChange={e => setEmpNm(e.target.value)}
					onKeyPress={handleKeyPress}
					fullWidth
					value={empNm}
					disabled={props.readOnly}
				/>
				<Button variant="contained" color="primary" onClick={() => search()} disabled={props.readOnly}>
					검색
				</Button>
			</div>
			<DialogContent className={classes.root}>
				<Table className="table5" size="small">
					<colgroup>
						<col style={{ width: '10rem' }} />
						<col style={{ width: '10rem' }} />
						<col style={{ width: '6rem' }} />
						<col style={{ width: '12rem' }} />
						<col style={{ width: '10rem' }} />
						<col style={{ width: '4rem' }} />
						<col style={{ width: '4rem' }} />
					</colgroup>
					<TableHead>
						<TableRow>
							<TableCell align="center">사번</TableCell>
							<TableCell align="center">성명</TableCell>
							<TableCell align="center">직급</TableCell>
							<TableCell align="center">소속</TableCell>
							<TableCell align="center">입사일</TableCell>
							<TableCell align="center">재직여부</TableCell>
							<TableCell align="center">사원구분</TableCell>
						</TableRow>
					</TableHead>
					<TableBody>
						{list &&
							list.map((item, index) => {
								const isItemSelected = isSelected(item);
								return (
									<TableRow
										key={index}
										className="cursor-pointer"
										hover
										selected={isItemSelected}
										onClick={event => handleRowClick(event, item)}
										onDoubleClick={event => handleRowDoubleClick(event, item)}
									>
										<TableCell align="center">{item.empNo}</TableCell>
										<TableCell align="center">{item.empNm}</TableCell>
										<TableCell align="center">{item.posGrdNm}</TableCell>
										<TableCell align="center" style={{ height: '5.2rem', wordBreak: 'keep-all' }}>
											{item.parDepNm}
										</TableCell>
										<TableCell align="center">
											{item.firstHireYmd &&
												format(parse(item.firstHireYmd, 'yyyyMMdd', new Date()), 'yyyy.MM.dd')}
										</TableCell>
										<TableCell align="center">{item.inOffiYnNm}</TableCell>
										<TableCell align="center">{item.empGubun}</TableCell>
									</TableRow>
								);
							})}
					</TableBody>
				</Table>
				<UutasBackdrop open={empListLoading} />
			</DialogContent>
			<DialogActions>
				<Button onClick={handleOKBtnClick} color="primary" disabled={!selectedItem} autoFocus>
					OK
				</Button>
				<Button onClick={handleClose} color="primary">
					CANCEL
				</Button>
			</DialogActions>
		</>
	);
};

export default EmpPopup;
