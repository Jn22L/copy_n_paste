// **************************************************************************
// 파    일    명   : VehiclePopup.js
// 업무    대분류   : 공통팝업
// 업무    중분류   : 차량선택 팝업
// 업    무    명   : 차량선택 팝업
// 프로그램 내용     : 등록된 차량을 선택할 수 있는 공통팝업
// 기          타   :
// ==========================================================================
// 작성자          : 김 민 우
// 작성일          : 2021.12.27
// 최종 수정일     :
// 변경이력        :
// **************************************************************************

import _ from '@lodash';
import {
	Button,
	DialogActions,
	DialogContent,
	DialogTitle,
	FormControl,
	InputLabel,
	makeStyles,
	MenuItem,
	Select,
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableRow,
	TextField
} from '@material-ui/core';
import { showMessage } from 'app/store/fuse/messageSlice';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import KtngUtils from '@ktng/utils';
import UutasBackdrop from '@ktng/uutas/UutasPageSimple/UutasBackdrop';
import commonService from 'app/services/commonService';
import { useCmmCodeLoadEffect } from '@ktng/hooks';

const useStyles = makeStyles(() => ({
	left: {
		overflow: 'scroll',
		padding: 5,
		borderRightWidth: '1px',
		borderColor: 'rgba(0, 0, 0, 0.12)'
	},
	root: {
		width: '100%',
		minHeight: 380,
		maxHeight: 380,
		'&&.MuiDialogContent-root': {
			padding: 5,
			borderBottomWidth: '1px',
			borderColor: 'rgba(0, 0, 0, 0.12)'
		}
	}
}));

const reqCodes = [{ commCodeChk: 'VH_DEPT_ALL' }, { commCodeChk: 'VH_TYPE' }]; // 불러올 공통코드 리스트

const VehiclePopup = props => {
	const classes = useStyles();
	const dispatch = useDispatch();

	const { vhDeptCodes } = useSelector(({ ktng }) => ({
		vhDeptCodes: ktng.code.VH_DEPT_ALL // 불러온 공통코드 리스트
	}));

	const [vhclDeptCd, setVhclDeptCd] = useState('ALL'); // 전체
	const [vhclNo, setVhclNo] = useState('');
	const [vhclNm, setVhclNm] = useState('');

	const [selectedItem, setSelectedItem] = useState();
	const [list, setList] = useState();
	const [vehicleListLoading, setVehicleListLoading] = useState(false);

	// 공통코드 리스트 불러오기 (이미 store에 있으면 요청안함)
	useCmmCodeLoadEffect(() => {}, [reqCodes]);

	/**
	 * 화면 로드 시 작동
	 */
	useEffect(() => {
		if (!vhDeptCodes) return;

		setVhclDeptCd(props.vhclDeptCd || 'ALL');
		setVhclNo(props.vhclNo || '');
		setVhclNm(props.vhclNm || '');

		if (!validateSearchParams(props.vhclNo, props.vhclNm)) return;

		let _vhclDeptCd = props.vhclDeptCd;
		if (_vhclDeptCd === 'ALL') {
			_vhclDeptCd = null;
		}

		setVehicleListLoading(true);
		commonService
			.getVehicleList({ vhclDeptCd: _vhclDeptCd, vhclNo: props.vhclNo, vhclNm: props.vhclNm })
			.then(data => {
				setVehicleListLoading(false);
				if (data && data.list) {
					setList(data.list);

					// 조회결과가 1건 이상인 경우
					if (data.list.length > 0) {
						setSelectedItem(data.list[0]);

						// 조회결과가 1건이고 `museClick`이 false인 경우, 즉시 선택
						if (data.list.length === 1 && props.museClick === false) {
							if (props.onSelect) {
								props.onSelect(data.list[0]);
							}
						} else {
							dispatch(showMessage({ message: `${data.list.length}건이 조회되었습니다.` }));
						}
					} else {
						dispatch(showMessage({ message: '0건이 조회되었습니다.' }));
					}
				}
			})
			.catch(err => {
				setVehicleListLoading(false);
				if (props.onClose) {
					props.onClose();
				}
			});
		// eslint-disable-next-line
	}, [dispatch, vhDeptCodes, props]);

	//	클릭시 Row 색상 이벤트
	const isSelected = item => {
		const temp1 = _.pick(selectedItem, ['vhclNo']);
		const temp2 = _.pick(item, ['vhclNo']);

		return _.isEqual(temp1, temp2);
	};

	// 엔터 이벤트
	const handleKeyPress = event => {
		if (event.key === 'Enter') {
			search();
		}
	};

	//	검색 이벤트
	const search = () => {
		if (!validateSearchParams(vhclNo, vhclNm)) return;

		let _vhclDeptCd = vhclDeptCd;
		if (_vhclDeptCd === 'ALL') {
			_vhclDeptCd = null;
		}

		setVehicleListLoading(true);
		commonService
			.getVehicleList({ vhclDeptCd: _vhclDeptCd, vhclNo, vhclNm })
			.then(data => {
				setVehicleListLoading(false);
				if (data && data.list) {
					setList(data.list);
					dispatch(showMessage({ message: `${data.list.length}건이 조회되었습니다.` }));
				}
			})
			.catch(err => {
				setVehicleListLoading(false);
				if (props.onClose) {
					props.onClose();
				}
			});
	};

	// 클릭 이벤트
	const handleRowClick = (e, item) => {
		setSelectedItem(item);
	};

	// 더블클릭 이벤트
	const handleRowDoubleClick = (e, item) => {
		setSelectedItem(item);
		handleOKBtnClick();
	};

	//	취소버튼 클릭 이벤트
	const handleClose = () => {
		if (props.onClose) {
			props.onClose();
		}
	};

	//	선택버튼 클릭 이벤트
	const handleOKBtnClick = () => {
		if (props.onSelect) {
			props.onSelect(selectedItem);
		}
	};

	// 검색어 검증
	const validateSearchParams = (_vhclNo, _vhclNm) => {
		const validationComps = [
			{ key: '차량번호', value: _vhclNo, type: 'text', required: false, minLength: 2 },
			{ key: '차량명', value: _vhclNm, type: 'text', required: false, minLength: 2 }
		];
		if (!KtngUtils.validationComps(validationComps, dispatch)) return false;

		return true;
	};

	return (
		<>
			<DialogTitle>차량 선택</DialogTitle>
			<div className="p-10 border-t border-b flex flex-row">
				<FormControl className="w-160 mx-4" variant="outlined" size="small">
					<InputLabel>부서코드</InputLabel>
					<Select
						label="부서코드"
						value={vhclDeptCd}
						onChange={e => setVhclDeptCd(e.target.value)}
						onKeyUp={handleKeyPress}
						disabled={props.readOnly}
					>
						<MenuItem value="ALL">전체</MenuItem>
						{vhDeptCodes &&
							vhDeptCodes.map((vhDept, key) => (
								<MenuItem key={key} value={vhDept.commCode}>
									{vhDept.commCodeName}
								</MenuItem>
							))}
					</Select>
				</FormControl>
				<TextField
					className="w-96 mx-4"
					label="차량번호"
					name="vhclNo"
					size="small"
					variant="outlined"
					inputProps={{ maxLength: 10 }}
					onChange={e => setVhclNo(e.target.value)}
					onKeyPress={handleKeyPress}
					value={vhclNo}
					disabled={props.readOnly}
				/>
				<TextField
					className="w-160 mx-4"
					label="차량명"
					name="vhclNm"
					size="small"
					variant="outlined"
					onChange={e => setVhclNm(e.target.value)}
					onKeyPress={handleKeyPress}
					fullWidth
					value={vhclNm}
					disabled={props.readOnly}
				/>
				<Button variant="contained" color="primary" onClick={() => search()} disabled={props.readOnly}>
					검색
				</Button>
			</div>
			<DialogContent className={classes.root}>
				<Table className="table5" size="small">
					<colgroup>
						<col style={{ width: '10rem' }} />
						<col style={{ width: '16rem' }} />
						<col style={{ width: '12rem' }} />
					</colgroup>
					<TableHead>
						<TableRow>
							<TableCell align="center">차량번호</TableCell>
							<TableCell align="center">차종</TableCell>
							<TableCell align="center">용도</TableCell>
						</TableRow>
					</TableHead>
					<TableBody>
						{list &&
							list.map((item, index) => {
								const isItemSelected = isSelected(item);
								return (
									<TableRow
										key={index}
										className="cursor-pointer"
										hover
										selected={isItemSelected}
										onClick={event => handleRowClick(event, item)}
										onDoubleClick={event => handleRowDoubleClick(event, item)}
									>
										<TableCell align="center">{item.vhclNo}</TableCell>
										<TableCell align="left">{item.vhclNm}</TableCell>
										<TableCell align="left">
											{KtngUtils.cmmCodeToName('VH_TYPE', item.vhType)}
										</TableCell>
									</TableRow>
								);
							})}
					</TableBody>
				</Table>
				<UutasBackdrop open={vehicleListLoading} />
			</DialogContent>
			<DialogActions>
				<Button onClick={handleOKBtnClick} color="primary" disabled={!selectedItem} autoFocus>
					OK
				</Button>
				<Button onClick={handleClose} color="primary">
					CANCEL
				</Button>
			</DialogActions>
		</>
	);
};

export default VehiclePopup;
