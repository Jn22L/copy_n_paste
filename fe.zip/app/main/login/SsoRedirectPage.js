import React, { useEffect } from 'react';
import qs from 'qs';
import NssoService from 'app/services/nssoService';
import OidcService from 'app/services/oidcService';
import { setUserData } from 'app/auth/store/userSlice';
import { useDispatch } from 'react-redux';
import { showMessage } from 'app/store/fuse/messageSlice';
import KtngSplashScreen from '@ktng/core/KtngSplashScreen';

function SsoRedirectPage({ location, history }) {
	const dispatch = useDispatch();
	const query = qs.parse(location.search, { ignoreQueryPrefix: true });

	useEffect(() => {
		if (query && query.code && query.state) {
			// 엑세스토큰요청
			NssoService.getAuthorizationCode(query)
				.then(tokenResult => {
					// console.info('엑세스토큰요청 성공', tokenResult);
					OidcService.loginSuccess(tokenResult)
						.then(user => {
							dispatch(setUserData(user));
							history.push('/');
						})
						.catch(errDesc => {
							// 실패 시 토큰 REVOKE
							OidcService.revoke().then(() => {
								dispatch(showMessage({ message: errDesc, variant: 'error' }));
								history.push('/login');
							});
						});
				})
				.catch(errDesc => {
					dispatch(showMessage({ message: errDesc, variant: 'error' }));
				});
		} else {
			// 실패 시 처리
			const { error, error_description: errorDesc } = query;
			const message = `${error}::${errorDesc}`;
			dispatch(showMessage({ message, variant: 'error' }));
			history.push('/');
		}
		// eslint-disable-next-line
	}, [dispatch, history]);

	return <KtngSplashScreen />;
}

export default SsoRedirectPage;
