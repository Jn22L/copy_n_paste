import { removeUserData } from 'app/auth/store/userSlice';
import { MenuItem, ListItemIcon, Icon } from '@material-ui/core';
import oidcService from 'app/services/oidcService';
import { useDispatch, useSelector } from 'react-redux';
import crypto from 'crypto';
import React from 'react';

const SSO_CONFIG = {
	logout_url: process.env.REACT_APP_SSO_LOGOUT_URL,
	redirect_uri: process.env.REACT_APP_SSO_LOGOUT_REDIRECT_URI
};

// prettier-ignore
const generateToken = length => 
    crypto
        .randomBytes(length)
        .toString('base64')
        .replace(/\+/g, '-')
        .replace(/\//g, '_')
        .replace(/=/g, '');

function NssoLogoutForm() {
	const dispatch = useDispatch();
	const user = useSelector(({ auth }) => auth.user);

	const form = {
		idtokenhint: oidcService.getIdToken(),
		returnurl: SSO_CONFIG.redirect_uri,
		logouturl: SSO_CONFIG.logout_url,
		state: generateToken(8)
	};

	const handleLogout = () => {
		dispatch(removeUserData());
		oidcService.setSession(null);
		if (user.from === 'NSSO') {
			document.getElementById('formEl').submit();
		}
	};

	return (
		<>
			<form id="formEl" action={form.logouturl} method="POST">
				<input type="hidden" name="id_token_hint" value={form.idtokenhint} />
				<input type="hidden" name="post_logout_redirect_uri" value={form.returnurl} />
				<input type="hidden" name="logout_uri" value={form.logouturl} />
				<input type="hidden" name="state" value={form.state} />
			</form>
			<MenuItem className="h-64" onClick={handleLogout}>
				<ListItemIcon className="min-w-24">
					<Icon>exit_to_app</Icon>
				</ListItemIcon>
			</MenuItem>
		</>
	);
}

export default NssoLogoutForm;
