import { useForm } from '@fuse/hooks';
import { Button, Icon, IconButton, InputAdornment, TextField } from '@material-ui/core';
import { setUserData } from 'app/auth/store/userSlice';
import oidcService from 'app/services/oidcService';
import React, { useState } from 'react';
import { useDispatch } from 'react-redux';

export default function SelfLoginForm() {
	const dispatch = useDispatch();
	const { form, handleChange } = useForm({ empNo: '', password: '' });
	const [showPassword, setShowPassword] = useState(false);

	function keyPress(e) {
		if (e.keyCode === 13) {
			handleSubmit();
		}
	}

	function handleSubmit() {
		const { empNo, password } = form;
		oidcService.staticSignIn(empNo, password).then(user => {
			dispatch(setUserData(user));
		});
	}

	return (
		<div className="w-full h-320">
			<form className="flex flex-col justify-center w-full">
				<TextField
					variant="outlined"
					required
					className="my-16"
					type="text"
					label="사번"
					name="empNo"
					value={form.empNo}
					onChange={handleChange}
					InputProps={{
						endAdornment: (
							<InputAdornment position="end">
								<Icon className="text-20" color="action">
									user
								</Icon>
							</InputAdornment>
						)
					}}
				/>
				<TextField
					variant="outlined"
					required
					className="mb-16"
					label="비밀번호"
					type="password"
					name="password"
					value={form.password}
					onChange={handleChange}
					onKeyDown={keyPress}
					InputProps={{
						className: 'pr-2',
						type: showPassword ? 'text' : 'password',
						endAdornment: (
							<InputAdornment position="end">
								<IconButton onClick={() => setShowPassword(!showPassword)}>
									<Icon className="text-20" color="action">
										{showPassword ? 'visibility' : 'visibility_off'}
									</Icon>
								</IconButton>
							</InputAdornment>
						)
					}}
				/>

				<Button
					variant="contained"
					color="primary"
					className="w-full mx-auto mt-16"
					aria-label="LOG IN"
					value="legacy"
					onClick={handleSubmit}
				>
					Login
				</Button>
			</form>
		</div>
	);
}
