import LoginPage from './LoginPage';
import SsoRedirectPage from './SsoRedirectPage';

const LoginConfig = {
	settings: {
		layout: {
			config: {
				navbar: {
					display: false
				},
				toolbar: {
					display: false
				},
				footer: {
					display: false
				},
				leftSidePanel: {
					display: false
				},
				rightSidePanel: {
					display: false
				}
			}
		}
	},
	routes: [
		{
			path: '/login',
			component: LoginPage,
			auth: { check: false }
		},
		{
			path: '/nsso/redirect',
			component: SsoRedirectPage,
			auth: { check: false }
		}
	]
};

export default LoginConfig;
