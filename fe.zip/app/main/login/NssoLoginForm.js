import Button from '@material-ui/core/Button';
import React, { useState } from 'react';
import { useForm } from '@fuse/hooks';
import NssoService from 'app/services/nssoService';
import { CircularProgress } from '@material-ui/core';

function LoginForm(props) {
	const { form } = useForm(NssoService.getCodeFormObj);
	const [loading, setLoading] = useState(false);

	function submitGetCode() {
		setLoading(true);
		// AuthStatus.SSOUnAvailable
		document.getElementById('formEl').submit();
	}

	return (
		<div className="w-full h-320 ">
			<form id="formEl" action={form.authorize_url} method="POST">
				<input type="hidden" name="client_id" value={form.client_id} />
				<input type="hidden" name="redirect_uri" value={form.redirect_uri} />
				<input type="hidden" name="response_type" value={form.response_type} />
				<input type="hidden" name="scope" value={form.scope} />
				<input type="hidden" name="state" value={form.state} />
				<input type="hidden" name="nonce" value={form.nonce} />
			</form>
			<Button
				variant="contained"
				color="primary"
				className="w-full p-4 normal-case rounded-full mt-52"
				aria-label="LOG IN"
				value="legacy"
				disabled={loading}
				onClick={submitGetCode}
			>
				{!loading ? 'IAM SSO 로그인' : <CircularProgress size="2.4rem" />}
			</Button>
		</div>
	);
}

export default LoginForm;
