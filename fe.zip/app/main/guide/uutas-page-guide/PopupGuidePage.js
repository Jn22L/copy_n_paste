import React, { useState } from 'react';
import { Checkbox, Divider, FormControlLabel } from '@material-ui/core';
import GuideEmpPopup from './component/GuideEmpPopup';
import GuideDeptPopup from './component/GuideDeptPopup';
import GuideVehiclePopup from './component/GuideVehiclePopup';
import GuideDriverPopup from './component/GuideDriverPopup';
import GuideVhDeptPopup from './component/GuideVhDeptPopup';

const PopupGuidePage = () => {
	const [popupReadOnly, setPopupReadOnly] = useState(false); // 팝업 내 조회조건 Disable

	return (
		<div>
			<div className="p-16">
				<FormControlLabel
					label="팝업 내 조회조건 비활성화"
					control={
						popupReadOnly ? (
							<Checkbox checked onClick={() => setPopupReadOnly(false)} />
						) : (
							<Checkbox onClick={() => setPopupReadOnly(true)} />
						)
					}
				/>
			</div>

			<Divider />

			<div className="p-16">
				{/* `사원` 선택팝업 가이드 */}
				<GuideEmpPopup popupReadOnly={popupReadOnly} />
			</div>

			<div className="p-16">
				{/* `부서` 선택팝업 가이드 */}
				<GuideDeptPopup popupReadOnly={popupReadOnly} />
			</div>

			<div className="p-16">
				{/* `차량` 선택팝업 가이드 */}
				<GuideVehiclePopup popupReadOnly={popupReadOnly} />
			</div>

			<div className="p-16">
				{/* `운전원` 선택팝업 가이드 */}
				<GuideDriverPopup popupReadOnly={popupReadOnly} />
			</div>

			<div className="p-16">
				{/* `배차부서` 선택팝업 가이드 */}
				<GuideVhDeptPopup popupReadOnly={popupReadOnly} />
			</div>
		</div>
	);
};

export default PopupGuidePage;
