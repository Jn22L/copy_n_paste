import React from 'react';

const UutasPageGuideConfig = {
	routes: [
		{
			path: '/guide/uutas-page/popup',
			component: React.lazy(() => import('./PopupGuidePage')),
			auth: { check: false }
		},
		{
			path: '/guide/uutas-page/picker',
			component: React.lazy(() => import('./PickerGuidePage')),
			auth: { check: false }
		}
	]
};

export default UutasPageGuideConfig;
