import { useCmmCodeLoadEffect } from '@ktng/hooks';
import { UutasForm } from '@ktng/uutas';
import { IconButton, Input, MenuItem, Select } from '@material-ui/core';
import { Search } from '@material-ui/icons';
import DriverPopup from 'app/main/popup/DriverPopup';
import { closeDialog, openDialog } from 'app/store/fuse/dialogSlice';
import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';

const reqCodes = [{ commCodeChk: 'VH_DEPT_ALL' }];

const formSchema = [
	// row1
	[
		// col1
		{
			id: 'driverPopup',
			label: '운전원 선택팝업',
			align: 'left',
			required: false
		}
	]
];

const GuideDriverPopup = ({ popupReadOnly }) => {
	const dispatch = useDispatch();

	const { vhDeptCodes } = useSelector(({ ktng }) => ({
		vhDeptCodes: ktng.code.VH_DEPT_ALL
	}));

	// `운전원` 선택결과
	const [driverVhclDeptCd, setDriverVhclDeptCd] = useState('ALL'); // `운전원` 팝업 배차부서코드
	const [driverUseYn, setDriverUseYn] = useState('ALL'); // `운전원` 팝업 근무여부
	const [driverNo, setDriverNo] = useState('');
	const [driverNm, setDriverNm] = useState('');

	// `배차부서` 공통코드 리스트 조회
	useCmmCodeLoadEffect(() => {}, [reqCodes]);

	// `운전원` 팝업 열기
	function openDriverPopup(museClick) {
		dispatch(
			openDialog({
				children: (
					<DriverPopup
						onSelect={selected => {
							setDriverNo(selected.driverNo);
							setDriverNm(selected.driverNm);
							dispatch(closeDialog());
						}}
						onClose={() => dispatch(closeDialog())}
						// 조회조건
						vhclDeptCd={driverVhclDeptCd} // 팝업 열자마자 입력한 배차부서코드로 검색
						useYn={driverUseYn} // 팝업 열자마자 입력한 근무여부로 검색
						driverNo={driverNo} // 팝업 열자마자 입력한 운전원ID로 검색
						driverNm={driverNm} // 팝업 열자마자 입력한 운전원성명으로 검색
						// 옵션
						museClick={museClick} // false면, 조회결과 1건인 경우 자동선택하고 팝업을 닫음
						readOnly={popupReadOnly} // true면 팝업 내에서 조회조건 수정불가
					/>
				)
			})
		);
	}

	return (
		<UutasForm
			schema={formSchema}
			// `운전원` 팝업 예제
			driverPopup={
				<>
					<Select
						className="w-160 text-center mx-4"
						placeholder="배차부서코드"
						value={driverVhclDeptCd}
						onChange={e => setDriverVhclDeptCd(e.target.value)}
					>
						<MenuItem value="ALL">전체</MenuItem>
						{vhDeptCodes &&
							vhDeptCodes.map((code, key) => (
								<MenuItem key={key} value={code.commCode}>
									{code.commCodeName}
								</MenuItem>
							))}
					</Select>
					<Select
						className="w-84 text-center mx-4"
						placeholder="근무여부"
						value={driverUseYn}
						onChange={e => setDriverUseYn(e.target.value)}
					>
						<MenuItem value="ALL">전체</MenuItem>
						<MenuItem value="Y">근무</MenuItem>
						<MenuItem value="N">미근무</MenuItem>
					</Select>
					<Input
						className="w-96 mx-4"
						placeholder="운전원ID"
						value={driverNo}
						onChange={e => {
							setDriverNo(e.target.value);
							setDriverNm(''); // 운전원ID, 운전원성명 둘 중 하나 입력 시 다른 하나 clear
						}}
						onKeyUp={e => {
							// 운전원ID 입력 후 `Enter` 입력 시 팝업 실행
							if (e.key === 'Enter') {
								openDriverPopup(false);
							}
						}}
					/>
					<Input
						className="w-160 mx-4"
						placeholder="운전원성명"
						value={driverNm}
						onChange={e => {
							setDriverNo(''); // 운전원ID, 운전원성명 둘 중 하나 입력 시 다른 하나 clear
							setDriverNm(e.target.value);
						}}
						onKeyUp={e => {
							// 운전원성명 입력 후 `Enter` 입력 시 팝업 실행
							if (e.key === 'Enter') {
								openDriverPopup(false);
							}
						}}
					/>
					<IconButton
						size="small"
						onClick={e => openDriverPopup()} // 🔍 버튼 클릭 시 팝업 실행
					>
						<Search fontSize="small" />
					</IconButton>
				</>
			}
		/>
	);
};

export default GuideDriverPopup;
