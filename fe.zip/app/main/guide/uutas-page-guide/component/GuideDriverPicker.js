import { UutasForm } from '@ktng/uutas';
import { Typography } from '@material-ui/core';
import DriverPicker from 'app/main/popup/DriverPicker';
import React, { useState } from 'react';

const formSchema = [
	// row1
	[
		// col1
		{
			id: 'driverPopup1',
			label: '운전원 선택팝업1'
		}
	],
	// row2
	[
		// col2
		{
			id: 'driverPopup2',
			label: '운전원 선택팝업2'
		}
	],
	// row3
	[
		// col1
		{
			id: 'driverPopup3',
			label: '운전원 선택팝업3'
		}
	],
	// row4
	[
		// col1
		{
			id: 'result',
			label: '결과'
		}
	]
];

const GuideDriverPicker = ({ popupReadOnly }) => {
	const [driver, setDriver] = useState({});

	return (
		<UutasForm
			schema={formSchema}
			// `운전원` 팝업 예제1
			driverPopup1={
				<DriverPicker
					// vhclDeptCd={vhclDeptCd} // 배차부서코드 Select컴포넌트 초기값
					// driverNo={driverNo} // 운전원ID Input컴포넌트 초기값
					// driverNm={driverNm} // 운전원성명 Input컴포넌트 초기값
					onChange={data => setDriver(data)}
					// views={['driverNo', 'driverNm']} // 리스트에 있는 입력뷰만 보임 (undefined면 모두 보임)
					// disabledViews={['driverNm']} // 리스트에 있는 입력뷰를 disabled 시킴
					readOnly={popupReadOnly} // true면 팝업 내에서 조회조건 수정불가
				/>
			}
			driverPopup2={
				<DriverPicker
					onChange={data => setDriver(data)}
					views={['driverNo', 'driverNm']}
					disabledViews={['driverNm']} // 리스트에 있는 입력뷰를 disabled 시킴
				/>
			}
			driverPopup3={
				<DriverPicker
					onChange={data => setDriver(data)}
					views={['driverNo']} // 리스트에 있는 입력뷰만 보임 (undefined면 모두 보임)
				/>
			}
			result={<Typography>{JSON.stringify(driver)}</Typography>}
		/>
	);
};

export default GuideDriverPicker;
