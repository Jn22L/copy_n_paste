import { UutasForm } from '@ktng/uutas';
import { Typography } from '@material-ui/core';
import VhDeptPicker from 'app/main/popup/VhDeptPicker';
import React, { useState } from 'react';

const formSchema = [
	// row1
	[
		// col1
		{
			id: 'vhDeptPopup1',
			label: '배차부서 선택팝업1'
		}
	],
	// row2
	[
		// col1
		{
			id: 'vhDeptPopup2',
			label: '배차부서 선택팝업2'
		}
	],
	// row3
	[
		// col1
		{
			id: 'vhDeptPopup3',
			label: '배차부서 선택팝업3'
		}
	],
	// row4
	[
		// col1
		{
			id: 'result',
			label: '결과'
		}
	]
];

const GuideVhDeptPicker = ({ popupReadOnly }) => {
	const [vhDept, setVhDept] = useState({});

	return (
		<UutasForm
			schema={formSchema}
			// `배차부서` 팝업 예제1
			vhDeptPopup1={
				<VhDeptPicker
					// vhclDeptCd={vhclDeptCd} // 배차부서코드 Input컴포넌트 초기값
					// vhclDeptNm={vhDeptNm} // 배차부서명 Input컴포넌트 초기값
					onChange={data => setVhDept(data)}
					// views={['vhclDeptNo', 'vhclDeptNm']} // 리스트에 있는 입력뷰만 보임 (undefined면 모두 보임)
					// disabledViews={['vhclDeptNm']} // 리스트에 있는 입력뷰를 disabled 시킴
					readOnly={popupReadOnly} // true면 팝업 내에서 조회조건 수정불가
				/>
			}
			vhDeptPopup2={
				<VhDeptPicker
					onChange={data => setVhDept(data)}
					disabledViews={['vhclDeptNm']} // 리스트에 있는 입력뷰를 disabled 시킴
				/>
			}
			vhDeptPopup3={
				<VhDeptPicker
					onChange={data => setVhDept(data)}
					views={['vhclDeptCd']} // 리스트에 있는 입력뷰만 보임 (undefined면 모두 보임)
				/>
			}
			result={<Typography>{JSON.stringify(vhDept)}</Typography>}
		/>
	);
};

export default GuideVhDeptPicker;
