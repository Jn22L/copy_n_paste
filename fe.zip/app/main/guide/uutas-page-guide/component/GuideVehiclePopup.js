import { useCmmCodeLoadEffect } from '@ktng/hooks';
import { UutasForm } from '@ktng/uutas';
import { IconButton, Input, MenuItem, Select } from '@material-ui/core';
import { Search } from '@material-ui/icons';
import VehiclePopup from 'app/main/popup/VehiclePopup';
import { closeDialog, openDialog } from 'app/store/fuse/dialogSlice';
import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';

const reqCodes = [{ commCodeChk: 'VH_DEPT_ALL' }];

const formSchema = [
	// row1
	[
		// col1
		{
			id: 'vehiclePopup',
			label: '차량 선택팝업',
			align: 'left',
			required: false
		}
	]
];

const GuideVehiclePopup = ({ popupReadOnly }) => {
	const dispatch = useDispatch();

	const { vhDeptCodes } = useSelector(({ ktng }) => ({
		vhDeptCodes: ktng.code.VH_DEPT_ALL
	}));

	// `차량` 선택결과
	const [vehicleVhclDeptCd, setVehicleVhclDeptCd] = useState('ALL'); // `차량` 팝업 배차부서코드
	const [vhclNo, setVhclNo] = useState('');
	const [vhclNm, setVhclNm] = useState('');

	// `배차부서` 공통코드 리스트 조회
	useCmmCodeLoadEffect(() => {}, [reqCodes]);

	// `차량` 팝업 열기
	function openVehiclePopup(museClick) {
		dispatch(
			openDialog({
				children: (
					<VehiclePopup
						onSelect={selected => {
							setVhclNo(selected.vhclNo);
							setVhclNm(selected.vhclNm);
							dispatch(closeDialog());
						}}
						onClose={() => dispatch(closeDialog())}
						// 조회조건
						vhclDeptCd={vehicleVhclDeptCd} // 팝업 열자마자 입력한 배차부서코드로 검색
						vhclNo={vhclNo} // 팝업 열자마자 입력한 차량번호로 검색
						vhclNm={vhclNm} // 팝업 열자마자 입력한 차량명으로 검색
						// 옵션
						museClick={museClick} // false면, 조회결과 1건인 경우 자동선택하고 팝업을 닫음
						readOnly={popupReadOnly} // true면 팝업 내에서 조회조건 수정불가
					/>
				)
			})
		);
	}

	return (
		<UutasForm
			schema={formSchema}
			// `차량` 팝업 예제
			vehiclePopup={
				<>
					<Select
						className="w-160 text-center mx-4"
						placeholder="배차부서코드"
						value={vehicleVhclDeptCd}
						onChange={e => setVehicleVhclDeptCd(e.target.value)}
					>
						<MenuItem value="ALL">전체</MenuItem>
						{vhDeptCodes &&
							vhDeptCodes.map((code, key) => (
								<MenuItem key={key} value={code.commCode}>
									{code.commCodeName}
								</MenuItem>
							))}
					</Select>
					<Input
						className="w-96 mx-4"
						placeholder="차량번호"
						value={vhclNo}
						onChange={e => {
							setVhclNo(e.target.value);
							setVhclNm(''); // 차량번호, 차량명 둘 중 하나 입력 시 다른 하나 clear
						}}
						onKeyUp={e => {
							// 차량번호 입력 후 `Enter` 입력 시 팝업 실행
							if (e.key === 'Enter') {
								openVehiclePopup(false);
							}
						}}
					/>
					<Input
						className="w-160 mx-4"
						placeholder="차종"
						value={vhclNm}
						onChange={e => {
							setVhclNo(''); // 차량번호, 차량명 둘 중 하나 입력 시 다른 하나 clear
							setVhclNm(e.target.value);
						}}
						onKeyUp={e => {
							// 차종 입력 후 `Enter` 입력 시 팝업 실행
							if (e.key === 'Enter') {
								openVehiclePopup(false);
							}
						}}
					/>
					<IconButton
						size="small"
						onClick={e => openVehiclePopup()} // 🔍 버튼 클릭 시 팝업 실행
					>
						<Search fontSize="small" />
					</IconButton>
				</>
			}
		/>
	);
};

export default GuideVehiclePopup;
