import { UutasForm } from '@ktng/uutas';
import { IconButton, Input } from '@material-ui/core';
import { Search } from '@material-ui/icons';
import VhDeptPopup from 'app/main/popup/VhDeptPopup';
import { closeDialog, openDialog } from 'app/store/fuse/dialogSlice';
import React, { useState } from 'react';
import { useDispatch } from 'react-redux';

const formSchema = [
	// row1
	[
		// col1
		{
			id: 'vhDeptPopup',
			label: '배차부서 선택팝업',
			align: 'left',
			required: false
		}
	]
];

const GuideVhDeptPopup = ({ popupReadOnly }) => {
	const dispatch = useDispatch();

	// `배차부서` 선택결과
	const [vhclDeptCd, setVhclDeptCd] = useState('');
	const [vhclDeptNm, setVhclDeptNm] = useState('');

	// `배차부서` 팝업 열기
	function openVhDeptPopup(museClick) {
		dispatch(
			openDialog({
				children: (
					<VhDeptPopup
						onSelect={selected => {
							setVhclDeptCd(selected.vhclDeptCd);
							setVhclDeptNm(selected.vhclDeptNm);
							dispatch(closeDialog());
						}}
						onClose={() => dispatch(closeDialog())}
						// 조회조건
						vhclDeptCd={vhclDeptCd} // 팝업 열자마자 입력한 배차부서코드로 검색
						vhclDeptNm={vhclDeptNm} // 팝업 열자마자 입력한 배차부서명으로 검색
						// 옵션
						museClick={museClick} // false면, 조회결과 1건인 경우 자동선택하고 팝업을 닫음
						readOnly={popupReadOnly} // true면 팝업 내에서 조회조건 수정불가
					/>
				)
			})
		);
	}

	return (
		<UutasForm
			schema={formSchema}
			// `배차부서` 팝업 예제
			vhDeptPopup={
				<>
					<Input
						className="w-96 mx-4"
						placeholder="배차부서코드"
						value={vhclDeptCd}
						onChange={e => {
							setVhclDeptCd(e.target.value);
							setVhclDeptNm(''); // 배차부서코드, 배차부서명 둘 중 하나 입력 시 다른 하나 clear
						}}
						onKeyUp={e => {
							// 배차부서코드 입력 후 `Enter` 입력 시 팝업 실행
							if (e.key === 'Enter') {
								openVhDeptPopup(false);
							}
						}}
					/>
					<Input
						className="w-160 mx-4"
						placeholder="배차부서명"
						value={vhclDeptNm}
						onChange={e => {
							setVhclDeptCd(''); // 배차부서코드, 배차부서명 둘 중 하나 입력 시 다른 하나 clear
							setVhclDeptNm(e.target.value);
						}}
						onKeyUp={e => {
							// 배차부서명 입력 후 `Enter` 입력 시 팝업 실행
							if (e.key === 'Enter') {
								openVhDeptPopup(false);
							}
						}}
					/>
					<IconButton
						size="small"
						onClick={e => openVhDeptPopup()} // 🔍 버튼 클릭 시 팝업 실행
					>
						<Search fontSize="small" />
					</IconButton>
				</>
			}
		/>
	);
};

export default GuideVhDeptPopup;
