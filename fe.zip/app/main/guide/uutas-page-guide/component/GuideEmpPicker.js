import { UutasForm } from '@ktng/uutas';
import { Typography } from '@material-ui/core';
import EmpPicker from 'app/main/popup/EmpPicker';
import React, { useState } from 'react';

const formSchema = [
	// row1
	[
		// col1
		{
			id: 'empPopup1',
			label: '사원Picker1'
		}
	],
	// row2
	[
		// col1
		{
			id: 'empPopup2',
			label: '사원Picker2'
		}
	],
	// row3
	[
		// col1
		{
			id: 'empPopup3',
			label: '사원Picker3'
		}
	],
	// row4
	[
		// col2
		{
			id: 'result',
			label: '결과'
		}
	]
];

const GuideEmpPicker = ({ popupReadOnly }) => {
	const [emp, setEmp] = useState({});

	return (
		<UutasForm
			schema={formSchema}
			// `사원` Picker 예제1
			empPopup1={
				<EmpPicker
					// empNo={empNo} // 사번 Input컴포넌트 초기값
					// empNm={empNm} // 성명 Input컴포넌트 초기값
					onChange={data => setEmp(data)}
					// views={['empNo', 'empNm']} // 리스트에 있는 입력뷰만 보임 (undefined면 모두 보임)
					// disabledViews={['empNm']} // 리스트에 있는 입력뷰를 disabled 시킴
					readOnly={popupReadOnly} // true면 팝업 내에서 조회조건 수정불가
				/>
			}
			empPopup2={
				<EmpPicker
					onChange={data => setEmp(data)}
					disabledViews={['empNm']} // 리스트에 있는 입력뷰를 disabled 시킴
				/>
			}
			empPopup3={
				<EmpPicker
					onChange={data => setEmp(data)}
					views={['empNo']} // 리스트에 있는 입력뷰만 보임 (undefined면 모두 보임)
				/>
			}
			result={<Typography>{JSON.stringify(emp)}</Typography>}
		/>
	);
};

export default GuideEmpPicker;
