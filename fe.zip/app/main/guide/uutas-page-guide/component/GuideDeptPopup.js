import { UutasForm } from '@ktng/uutas';
import { IconButton, Input } from '@material-ui/core';
import { Search } from '@material-ui/icons';
import { KeyboardDatePicker } from '@material-ui/pickers';
import DeptPopup from 'app/main/popup/DeptPopup';
import { closeDialog, openDialog } from 'app/store/fuse/dialogSlice';
import React, { useState } from 'react';
import { useDispatch } from 'react-redux';

const formSchema = [
	// row1
	[
		// col1
		{
			id: 'deptPopup',
			label: '부서 선택팝업',
			align: 'left',
			required: false
		}
	]
];

const GuideDeptPopup = ({ popupReadOnly }) => {
	const dispatch = useDispatch();

	// `부서` 선택결과
	const [deptSymd, setDeptSymd] = useState(new Date()); // `부서` 팝업 기준일자
	const [orgCd, setOrgCd] = useState('');
	const [orgNm, setOrgNm] = useState('');

	// `부서` 팝업 열기
	function openDeptPopup(museClick) {
		dispatch(
			openDialog({
				children: (
					<DeptPopup
						onSelect={selected => {
							setOrgCd(selected.orgCd);
							setOrgNm(selected.orgNm);
							dispatch(closeDialog());
						}}
						onClose={() => dispatch(closeDialog())}
						// 조회조건
						symd={deptSymd} // 팝업 열자마자 입력한 기준일자로 검색
						orgCd={orgCd} // 팝업 열자마자 입력한 부서코드로 검색
						orgNm={orgNm} // 팝업 열자마자 입력한 부서명으로 검색
						// 옵션
						museClick={museClick} // false면, 조회결과 1건인 경우 자동선택하고 팝업을 닫음
						readOnly={popupReadOnly} // true면 팝업 내에서 조회조건 수정불가
					/>
				)
			})
		);
	}

	return (
		<UutasForm
			schema={formSchema}
			// `부서` 팝업 예제
			deptPopup={
				<>
					<KeyboardDatePicker
						className="w-160 mx-4"
						placeholder="기준일자"
						format="yyyy.MM.dd"
						value={deptSymd}
						onChange={date => setDeptSymd(date)}
						onKeyUp={e => {
							// 부서코드 입력 후 `Enter` 입력 시 팝업 실행
							if (e.key === 'Enter') {
								openDeptPopup(false);
							}
						}}
					/>
					<Input
						className="w-96 mx-4"
						placeholder="부서코드"
						value={orgCd}
						onChange={e => {
							setOrgCd(e.target.value);
							setOrgNm(''); // 부서코드, 부서명 둘 중 하나 입력 시 다른 하나 clear
						}}
						onKeyUp={e => {
							// 부서코드 입력 후 `Enter` 입력 시 팝업 실행
							if (e.key === 'Enter') {
								openDeptPopup(false);
							}
						}}
					/>
					<Input
						className="w-160 mx-4"
						placeholder="부서명"
						value={orgNm}
						onChange={e => {
							setOrgCd(''); // 부서코드, 부서명 둘 중 하나 입력 시 다른 하나 clear
							setOrgNm(e.target.value);
						}}
						onKeyUp={e => {
							// 부서명 입력 후 `Enter` 입력 시 팝업 실행
							if (e.key === 'Enter') {
								openDeptPopup(false);
							}
						}}
					/>
					<IconButton
						size="small"
						onClick={e => openDeptPopup()} // 🔍 버튼 클릭 시 팝업 실행
					>
						<Search fontSize="small" />
					</IconButton>
				</>
			}
		/>
	);
};

export default GuideDeptPopup;
