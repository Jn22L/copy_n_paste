import { UutasForm } from '@ktng/uutas';
import { Typography } from '@material-ui/core';
import VehiclePicker from 'app/main/popup/VehiclePicker';
import React, { useState } from 'react';

const formSchema = [
	// row1
	[
		// col1
		{
			id: 'vehiclePopup1',
			label: '차량 선택팝업1'
		}
	],
	// row2
	[
		// col1
		{
			id: 'vehiclePopup2',
			label: '차량 선택팝업2'
		}
	],
	// row3
	[
		// col1
		{
			id: 'vehiclePopup3',
			label: '차량 선택팝업3'
		}
	],
	// row4
	[
		// col1
		{
			id: 'result',
			label: '결과'
		}
	]
];

const GuideVehiclePicker = ({ popupReadOnly }) => {
	const [vehicle, setVehicle] = useState({});

	return (
		<UutasForm
			schema={formSchema}
			// `차량` 팝업 예제1
			vehiclePopup1={
				<VehiclePicker
					// vhclDeptCd={vhclDeptCd} // 배차부서코드 Select컴포넌트 초기값
					// vhclNo={vhclNo} // 차량번호 Input컴포넌트 초기값
					// vhclNm={vhclNm} // 차종 Input컴포넌트 초기값
					onChange={data => setVehicle(data)}
					// views={['vhclNo', 'vhclNm']} // 리스트에 있는 입력뷰만 보임 (undefined면 모두 보임)
					// disabledViews={['vhclNm']} // 리스트에 있는 입력뷰를 disabled 시킴
					readOnly={popupReadOnly} // true면 팝업 내에서 조회조건 수정불가
				/>
			}
			vehiclePopup2={
				<VehiclePicker
					onChange={data => setVehicle(data)}
					views={['vhclNo', 'vhclNm']}
					disabledViews={['vhclNm']} // 리스트에 있는 입력뷰를 disabled 시킴
				/>
			}
			vehiclePopup3={
				<VehiclePicker
					onChange={data => setVehicle(data)}
					views={['vhclNo']} // 리스트에 있는 입력뷰만 보임 (undefined면 모두 보임)
				/>
			}
			result={<Typography>{JSON.stringify(vehicle)}</Typography>}
		/>
	);
};

export default GuideVehiclePicker;
