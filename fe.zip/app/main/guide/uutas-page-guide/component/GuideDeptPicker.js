import { UutasForm } from '@ktng/uutas';
import { Typography } from '@material-ui/core';
import DeptPicker from 'app/main/popup/DeptPicker';
import React, { useState } from 'react';

const formSchema = [
	// row1
	[
		// col1
		{
			id: 'deptPopup1',
			label: '부서 선택팝업1'
		}
	],
	// row2
	[
		// col1
		{
			id: 'deptPopup2',
			label: '부서 선택팝업2'
		}
	],
	// row3
	[
		// col1
		{
			id: 'deptPopup3',
			label: '부서 선택팝업3'
		}
	],
	// row4
	[
		// col1
		{
			id: 'result',
			label: '결과'
		}
	]
];

const GuideDeptPicker = ({ popupReadOnly }) => {
	const [dept, setDept] = useState({});

	return (
		<UutasForm
			schema={formSchema}
			// `부서` 팝업 예제1
			deptPopup1={
				<DeptPicker
					// symd={symd} // 기준일자 초기값
					// orgNo={orgNo} // 부서코드 초기값
					// orgNm={orgNm} // 부서명 초기값
					onChange={data => setDept(data)}
					// views={['orgCd', 'orgNm']} // 리스트에 있는 입력뷰만 보임 (undefined면 모두 보임)
					// disabledViews={['orgNm']} // 리스트에 있는 입력뷰를 disabled 시킴
					readOnly={popupReadOnly} // true면 팝업 내에서 조회조건 수정불가
				/>
			}
			deptPopup2={
				<DeptPicker
					onChange={data => setDept(data)}
					views={['orgCd', 'orgNm']}
					disabledViews={['symd', 'orgNm']} // 리스트에 있는 입력뷰를 disabled 시킴
				/>
			}
			deptPopup3={
				<DeptPicker
					onChange={data => setDept(data)}
					views={['orgCd']} // 리스트에 있는 입력뷰만 보임 (undefined면 모두 보임)
				/>
			}
			result={<Typography>{JSON.stringify(dept)}</Typography>}
		/>
	);
};

export default GuideDeptPicker;
