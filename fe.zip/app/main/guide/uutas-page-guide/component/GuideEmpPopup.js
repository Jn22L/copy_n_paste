import { UutasForm } from '@ktng/uutas';
import { IconButton, Input } from '@material-ui/core';
import { Search } from '@material-ui/icons';
import EmpPopup from 'app/main/popup/EmpPopup';
import { closeDialog, openDialog } from 'app/store/fuse/dialogSlice';
import React, { useState } from 'react';
import { useDispatch } from 'react-redux';

const formSchema = [
	// row1
	[
		// col1
		{
			id: 'empPopup',
			label: '사원 선택팝업',
			align: 'left',
			required: false
		}
	]
];

const GuideEmpPopup = ({ popupReadOnly }) => {
	const dispatch = useDispatch();

	// `사원` 선택결과
	const [empNo, setEmpNo] = useState('');
	const [empNm, setEmpNm] = useState('');

	// `사원` 팝업 열기
	function openEmpPopup(museClick) {
		dispatch(
			openDialog({
				children: (
					<EmpPopup
						onSelect={selected => {
							setEmpNo(selected.empNo);
							setEmpNm(selected.empNm);
							dispatch(closeDialog());
						}}
						onClose={() => dispatch(closeDialog())}
						// 조회조건
						empNo={empNo} // 팝업 열자마자 입력한 사번으로 검색
						empNm={empNm} // 팝업 열자마자 입력한 성명으로 검색
						// 옵션
						museClick={museClick} // false면, 조회결과 1건인 경우 자동선택하고 팝업을 닫음
						readOnly={popupReadOnly} // true면 팝업 내에서 조회조건 수정불가
					/>
				)
			})
		);
	}

	return (
		<UutasForm
			schema={formSchema}
			// `사원` 팝업 예제
			empPopup={
				<>
					<Input
						className="w-96 mx-4"
						placeholder="사번"
						value={empNo}
						onChange={e => {
							setEmpNo(e.target.value);
							setEmpNm(''); // 사번, 성명 둘 중 하나 입력 시 다른 하나 clear
						}}
						onKeyUp={e => {
							// 사번 입력 후 `Enter` 입력 시 팝업 실행
							if (e.key === 'Enter') {
								openEmpPopup(false);
							}
						}}
					/>
					<Input
						className="w-160 mx-4"
						placeholder="성명"
						value={empNm}
						onChange={e => {
							setEmpNo(''); // 사번, 성명 둘 중 하나 입력 시 다른 하나 clear
							setEmpNm(e.target.value);
						}}
						onKeyUp={e => {
							// 성명 입력 후 `Enter` 입력 시 팝업 실행
							if (e.key === 'Enter') {
								openEmpPopup(false);
							}
						}}
					/>
					<IconButton
						size="small"
						onClick={e => openEmpPopup()} // 🔍 버튼 클릭 시 팝업 실행
					>
						<Search fontSize="small" />
					</IconButton>
				</>
			}
		/>
	);
};

export default GuideEmpPopup;
