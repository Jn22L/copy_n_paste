import React, { useState } from 'react';
import { Checkbox, Divider, FormControlLabel } from '@material-ui/core';
import GuideEmpPicker from './component/GuideEmpPicker';
import GuideDeptPicker from './component/GuideDeptPicker';
import GuideVehiclePicker from './component/GuideVehiclePicker';
import GuideDriverPicker from './component/GuideDriverPicker';
import GuideVhDeptPicker from './component/GuideVhDeptPicker';

const PickerGuidePage = () => {
	const [popupReadOnly, setPopupReadOnly] = useState(false); // 팝업 내 조회조건 Disable

	return (
		<div>
			<div className="p-16">
				<FormControlLabel
					label="팝업 내 조회조건 비활성화"
					control={
						popupReadOnly ? (
							<Checkbox checked onClick={() => setPopupReadOnly(false)} />
						) : (
							<Checkbox onClick={() => setPopupReadOnly(true)} />
						)
					}
				/>
			</div>

			<Divider />

			<div className="p-16">
				{/* `사원` Picker 가이드 */}
				<GuideEmpPicker popupReadOnly={popupReadOnly} />
			</div>

			<div className="p-16">
				{/* `부서` Picker 가이드 */}
				<GuideDeptPicker popupReadOnly={popupReadOnly} />
			</div>

			<div className="p-16">
				{/* `차량` Picker 가이드 */}
				<GuideVehiclePicker popupReadOnly={popupReadOnly} />
			</div>

			<div className="p-16">
				{/* `운전원` Picker 가이드 */}
				<GuideDriverPicker popupReadOnly={popupReadOnly} />
			</div>

			<div className="p-16">
				{/* `배차부서` Picker 가이드 */}
				<GuideVhDeptPicker popupReadOnly={popupReadOnly} />
			</div>
		</div>
	);
};

export default PickerGuidePage;
