import { CodeDialog } from '@ktng/core/CmmCode';
import { KtngConfirmDialog4 } from '@ktng/core/KtngConfirmDialog';
import KtngIbSheet from '@ktng/core/KtngIbSheet';
import KtngToolBar from '@ktng/core/KtngToolBar';
import KtngUtils from '@ktng/utils';
import { Button } from '@material-ui/core';
import AddIcon from '@material-ui/icons/Add';
import ReplayIcon from '@material-ui/icons/Replay';
import SaveIcon from '@material-ui/icons/Save';
import SaveAltIcon from '@material-ui/icons/SaveAlt';
import { closeDialog, openDialog } from 'app/store/fuse/dialogSlice';
import { loadMultiCodeList } from 'app/store/ktng/codeSlice';
import withReducer from 'app/store/withReducer';
import clsx from 'clsx';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import reducer from '../../store';
import { emptyBoardList, getBoardList, saveBoardList } from '../../store/cult001Slice';
import sheetOptions from './Cult001BoardGrdSheetOptions';

const sheetId = KtngUtils.getUid('cult001-board');

const Cult001BoardGrd = ({ className }) => {
	const dispatch = useDispatch();
	const { boards, subRouteParams, codeStore } = useSelector(({ pageGuide, ktng }) => ({
		boards: pageGuide.cult001.boards,
		subRouteParams: pageGuide.cult001.subRouteParams,
		codeStore: ktng.code
	}));

	const [sheetObj, setSheetObj] = useState(null);

	// 작성자의 게시글 목록 조회
	useEffect(() => {
		if (subRouteParams.boardWriter.length > 0) {
			dispatch(getBoardList());
		} else {
			// 메인그리드 조회결과가 없으면 서브그리드 비움
			dispatch(emptyBoardList());
		}
	}, [dispatch, subRouteParams]);

	// 그리드 생성 콜백
	function onSheetLoad(sheet) {
		setSheetObj(sheet);

		// 이벤트 등록
		// ※ `onRowAdd`, `onAfterClick`, `onAfterChange` 외 추가 이벤트 등록 시
		// sheet.bind('onBeforeClick', onSheetBeforeClick);

		// 공통코드 로드
		dispatch(
			loadMultiCodeList([
				// 필요한 공통코드 추가
				{ code1: '001', code2: '002' }
				// { code1: '002', code2: '001' },
				// { code1: '002', code2: '002' },
			])
		);
	}

	// 그리드에 공통코드 셋팅
	useEffect(() => {
		if (!sheetObj) return;

		const code001002 = codeStore['001_002'];
		if (!code001002) return;

		const { enumKeys, enumVals } = KtngUtils.cvtCodeToIbSheetEnumType(code001002);

		sheetObj.setAttribute(null, 'apprStat', 'EnumKeys', enumKeys, true);
		sheetObj.setAttribute(null, 'apprStat', 'Enum', enumVals, true);

		sheetObj.setAttribute(null, 'apprStat2', 'EnumKeys', enumKeys, true);
		sheetObj.setAttribute(null, 'apprStat2', 'Enum', enumVals, true);
	}, [sheetObj, codeStore]);

	function addRow() {
		if (!sheetObj) return;

		const newData = {
			boardCate: 'menu0501',
			boardWriter: subRouteParams.boardWriter,
			boardNo: '',
			boardTitle: '',
			boardSummary: '',
			boardHit: 0,
			modDate: new Date().getTime()
		};

		/**
		 * @param next 추가할 위치의 다음 행 객체
		 * @param visible 그리드뷰에 반영 여부
		 * @param focus 포커스 여부
		 * @param parent ... (트리구조 행에서 사용)
		 * @param init 데이터
		 * @return 추가된 행 데이터
		 */
		sheetObj.addRow(null, true, true, null, newData); // 새 행 추가
	}

	function initSheet() {
		if (!sheetObj) return;

		if (boards.length === 0) {
			sheetObj.removeAll();
		} else {
			sheetObj.loadSearchData({
				data: boards,
				append: false
			});
		}
	}

	function saveSheet() {
		if (!sheetObj) return;

		const rowToBoardMapper = row => ({
			rowStatus: row.rowStatus || 'N',
			boardNo: row.boardNo,
			boardCate: row.boardCate || '', // String
			boardTitle: row.boardTitle || '', // String
			boardSummary: row.boardSummary || '', // String
			boardContent: row.boardContent || '', // String
			boardWriter: row.boardWriter || '', // String
			writerName: row.boardWriter || '', // String
			boardHit: row.boardHit, // Long
			modDate: row.modDate // Date
		});

		// 삭제
		const deletedList = KtngUtils.getRowsByStatus(sheetObj, ['D']).map(rowToBoardMapper);
		// 추가/수정
		const changedList = KtngUtils.getRowsByStatus(sheetObj, ['I', 'U']).map(rowToBoardMapper);

		dispatch(saveBoardList({ changed: changedList, deleted: deletedList }));
	}

	function onBtnSaveClick() {
		dispatch(
			openDialog({
				children: (
					<KtngConfirmDialog4
						title="저장 확인"
						okClick={() => {
							dispatch(closeDialog());
							saveSheet();
						}}
						cancelClick={() => dispatch(closeDialog())}
					>
						변경사항을 저장하시겠습니까?
					</KtngConfirmDialog4>
				)
			})
		);
	}

	function downExcel(e) {
		if (!sheetObj) return;

		sheetObj.down2Excel({
			SheetDesign: 1,
			fileName: 'test.xlsx'
		});
		// TODO: 엑셀 다운로드
		// const header = sheetObj
		// 	.getHeaderRows()
		// 	.map(row => [
		// 		row.boardNo,
		// 		row.boardCate,
		// 		row.boardTitle,
		// 		row.boardSummary,
		// 		row.boardWriter,
		// 		row.boardHit,
		// 		row.modDate
		// 	]);
		// const data = sheetObj
		// 	.getDataRows()
		// 	.map(row => [
		// 		String(row.boardNo),
		// 		row.boardCate || '',
		// 		row.boardTitle || '',
		// 		row.boardSummary || '',
		// 		row.boardWriter || '',
		// 		String(row.boardHit),
		// 		String(row.modDate)
		// 	]);

		// console.log(header, data);
		// excelService
		// 	.download('게시판', header, data)
		// 	.then(response => {
		// 		// TODO 엑셀 다운로드
		// 		const contentDisposition = response.headers['content-disposition'];
		// 		console.log('fileName', contentDisposition);
		// 	})
		// 	.catch(err => {
		// 		console.log(err);
		// 	});
	}

	function onSheetClick({ sheet, row, col }) {
		if (col === 'apprStat2') {
			// (그리드 팝업 예제) 공통코드 셀값 변경 팝업 호출
			dispatch(
				openDialog({
					fullWidth: true,
					maxWidth: 'sm',
					children: (
						// 코드선택 다이얼로그
						<CodeDialog
							code1="001"
							code2="002"
							onSelect={selected => {
								if (sheet === null) return;

								// 코드값 저장 ex) 'A001'
								sheet.setValue(row, col, selected.code);

								// 상태컬럼 직접 업데이트 필요
								KtngUtils.updateRowStatus(sheet, row, col);
							}}
						/>
					)
				})
			);
		}

		if (col === 'btnEdit') {
			// (그리드 버튼 예제) 게시판 수정 팝업 호출
			console.log('call popup');
		}
	}

	function onSheetChange({ sheet, row, col, val, oldval }) {
		console.log('changed: ', row.SEQ, col);
	}

	return (
		<div className={clsx(className, 'flex flex-1')}>
			<div className="flex flex-col" style={{ width: '100%' }}>
				{/* 1번 그리드 명칭 */}
				<KtngToolBar title="게시글 목록" variant="subtitle1">
					{/* 상단그리드 버튼 */}
					<Button aria-label="add" color="primary" onClick={() => addRow()}>
						<AddIcon />
						<span className="hidden sm:flex pl-8">추가</span>
					</Button>
					<Button aria-label="init" color="primary" onClick={() => initSheet()}>
						<ReplayIcon />
						<span className="hidden sm:flex pl-8">초기화</span>
					</Button>
					<Button aria-label="save" color="primary" onClick={() => onBtnSaveClick()}>
						<SaveIcon />
						<span className="hidden sm:flex pl-8">저장</span>
					</Button>
					<Button aria-label="search" color="primary" onClick={e => downExcel(e)}>
						<SaveAltIcon />
						<span className="hidden sm:flex pl-8">엑셀</span>
					</Button>
				</KtngToolBar>

				<div className="flex flex-1 p-1">
					<KtngIbSheet
						// [필수 속성]
						sheetId={sheetId}
						options={sheetOptions}
						data={boards}
						// [선택 속성]
						// - 이벤트
						onLoad={onSheetLoad} // 생성된 sheet 객체 바인딩 및 공통코드 로드 수행
						//   ※ 아래 3개 외 필요한 이벤트는 `onSheetLoad`에서 직접 바인딩할 것
						onRowAdd={() => {}} // 내부공통기능 수행 후 콜백이 호출됨
						onAfterClick={onSheetClick} // 내부공통기능 수행 후 `onSheetClick` 콜백이 호출됨
						onAfterChange={onSheetChange} // 내부공통기능 수행 후 `onSheetChange` 콜백이 호출됨
						// - 스타일 속성
						// className="" // tailwind 스타일 적용 가능
						style={{ height: '200px' }} // 그리드 초기 높이 설정시에는 style만 적용됨
					/>
				</div>
			</div>
		</div>
	);
};

export default withReducer('pageGuide', reducer)(Cult001BoardGrd);
