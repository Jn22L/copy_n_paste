const options = {
	Cfg: {
		CanSelect: true, // 시트 선택 가능
		SelectingCells: 0, // 개별 셀 선택 불가능
		CanEdit: 0, // 수정 불가
		CustomScroll: 1 // 그리드와 스크롤 겹침 이슈 처리
	},
	Def: {
		Col: {
			RelWidth: 1
		}
	},
	Cols: [
		{
			Header: '순번',
			Name: 'SEQ',
			Type: 'Int',
			Width: 65,
			RelWidth: 0
		},
		{
			Header: '작성자',
			Name: 'boardWriter',
			Type: 'Text',
			RelWidth: 6
		},
		{
			Header: '게시글 수',
			Name: 'boardCnt',
			Type: 'Int',
			Format: '#,##0',
			RelWidth: 3
		}
	]
};

export default options;
