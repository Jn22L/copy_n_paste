import KtngIbSheet from '@ktng/core/KtngIbSheet';
import KtngToolBar from '@ktng/core/KtngToolBar';
import KtngUtils from '@ktng/utils';
import { Button } from '@material-ui/core';
import AddIcon from '@material-ui/icons/Add';
import SaveIcon from '@material-ui/icons/Save';
import SaveAltIcon from '@material-ui/icons/SaveAlt';
import withReducer from 'app/store/withReducer';
import clsx from 'clsx';
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import reducer from '../../store';
import { changeSubRouteParams, getWriterList } from '../../store/cult001Slice';
import sheetOptions from './Cult001BoardWriterGrdSheetOptions';

const sheetId = KtngUtils.getUid('cult001-board-writer');

const Cult001BoardWriterGrd = ({ className }) => {
	const dispatch = useDispatch();
	const { writers, routeParams } = useSelector(({ pageGuide }) => ({
		writers: pageGuide.cult001.writers,
		routeParams: pageGuide.cult001.routeParams
	}));

	// 게시판 작성자 목록 조회
	useEffect(() => {
		dispatch(getWriterList());
	}, [dispatch, routeParams]);

	function onBtnExcelClick(e) {
		console.log('TODO: Download Excel');
	}

	function onSheetClick({ sheet, row, col }) {
		const value = sheet.getValue(row, 'boardWriter');

		dispatch(changeSubRouteParams({ boardWriter: value }));
	}

	return (
		<div className={clsx(className, 'flex flex-1')}>
			<div className="flex flex-col" style={{ width: '100%' }}>
				{/* 1번 그리드 명칭 */}
				<KtngToolBar title="작성자 목록" variant="subtitle1">
					{/* 상단그리드 버튼 */}
					<Button aria-label="add" color="primary" disabled>
						<AddIcon />
						<span className="hidden sm:flex pl-8">추가</span>
					</Button>
					<Button aria-label="save" color="primary" disabled>
						<SaveIcon />
						<span className="hidden sm:flex pl-8">저장</span>
					</Button>
					<Button aria-label="search" onClick={e => onBtnExcelClick(e)} color="primary">
						<SaveAltIcon />
						<span className="hidden sm:flex pl-8">엑셀</span>
					</Button>
				</KtngToolBar>

				<div className="flex flex-1 p-1">
					<KtngIbSheet sheetId={sheetId} options={sheetOptions} data={writers} onAfterClick={onSheetClick} />
				</div>
			</div>
		</div>
	);
};

export default withReducer('pageGuide', reducer)(Cult001BoardWriterGrd);
