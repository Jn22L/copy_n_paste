import { CmmCodeSelect, CmmCodeRadio, CmmCodeCheck } from '@ktng/core/CmmCode';
import { DateRangeSelecter } from '@ktng/core/DateRangePicker';
import { KtngDeptSelector } from '@ktng/core/KtngHRDialog';
import KtngToolBar from '@ktng/core/KtngToolBar';
import { Button, Collapse, IconButton, Input, makeStyles, useTheme } from '@material-ui/core';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import ReplayIcon from '@material-ui/icons/Replay';
import SearchIcon from '@material-ui/icons/Search';
import withReducer from 'app/store/withReducer';
import clsx from 'clsx';
import Formsy from 'formsy-react';
import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import reducer from '../../store';
import { changeRouteParams } from '../../store/cult001Slice';

const useStyles = makeStyles(theme => ({
	srch: {
		'& .expand': {
			marginLeft: '10px',
			transform: 'rotate(0deg)',
			transition: theme.transitions.create('transform', {
				duration: theme.transitions.duration.shortest
			})
		},
		'& .expandOpen': {
			transform: 'rotate(180deg)'
		},
		'& input': {
			textAlign: 'center'
		},
		'& table': {
			'& tr': {
				'& th': {
					padding: '8px',
					fontWeight: '500',
					border: '1px solid rgba(0, 0, 0, 0.12)',
					whiteSpace: 'nowrap',
					textAlign: 'center',
					backgroundColor: theme.palette.secondary.light, // '#f7fafc',
					color: theme.palette.primary.main
				},
				'& th.required': {
					'&::after': {
						content: '"*"',
						color: 'red'
					}
				},
				'& td': {
					padding: '8px',
					border: '1px solid rgba(0, 0, 0, 0.12)'
				},
				'& td.combo': {
					paddingLeft: 16,
					paddingRight: 16
				},
				'& td.input': {
					textAlign: 'center'
				}
			}
		}
	}
}));

const Cult001SearchForm = () => {
	const theme = useTheme();
	const classes = useStyles(theme);
	const dispatch = useDispatch();

	// Store의 검색조건 : 조회결과에 반영된 값들
	const { routeParams } = useSelector(({ pageGuide }) => pageGuide.cult001);

	// State의 검색조건 : 조회하기 전 뷰에 셋팅된 값들
	// 초기값 : Store의 검색조건
	const [processGbCd, setProcessGbCd] = useState(routeParams.processGbCd);
	const [salesGrd, setSalesGrd] = useState(routeParams.salesGrd);
	const [approval, setApproval] = useState(routeParams.approval);
	const [approval2, setApproval2] = useState(routeParams.approval2);
	const [dept, setDept] = useState(routeParams.dept);
	const [fromto, setFromto] = useState(routeParams.fromto);
	const [boardWriter, setBoardWriter] = useState(routeParams.boardWriter);

	// 검색조건 폼 보이기/숨기기
	const [expanded, setExpanded] = useState(false);

	function initParams() {
		setProcessGbCd({ code: 'total', name: '전체' });
		setSalesGrd({ code: 'total', name: '전체' });
		setApproval({ code: 'total', name: '전체' });
		setApproval2([]);
		setDept({});
		setFromto({});
		setBoardWriter('');
	}

	function onBtnSearchClick() {
		// 뷰의 검색조건 변경사항을 Store에 반영
		dispatch(
			changeRouteParams({
				processGbCd,
				salesGrd,
				approval,
				approval2,
				dept,
				fromto,
				boardWriter
			})
		);
	}

	return (
		<div className={classes.srch}>
			{/* 검색조건 툴바 */}
			<KtngToolBar title="검색 조건" variant="subtitle1" hr>
				<Button aria-label="init" color="primary" onClick={() => initParams()}>
					<ReplayIcon />
					<span className="hidden sm:flex pl-8">초기화</span>
				</Button>
				<Button aria-label="search" color="primary" onClick={() => onBtnSearchClick()}>
					<SearchIcon />
					<span className="hidden sm:flex pl-8">조회</span>
				</Button>
				<IconButton
					className={clsx('expand', { expandOpen: expanded })} // `expanded`가 true면, .expandOpen 클래스 추가됨
					onClick={() => setExpanded(!expanded)}
					aria-expanded={expanded}
					aria-label="보이기/숨기기"
				>
					<ExpandMoreIcon />
				</IconButton>
			</KtngToolBar>

			{/* 검색조건 입력폼 */}
			<Collapse in={expanded} timeout="auto" unmountOnExit>
				<Formsy className="flex items-center w-full mb-32">
					<div className={clsx('w-full bg-white border-b')}>
						<table>
							<colgroup>
								<col style={{ width: 80 }} />
								<col style={{ width: '25%' }} />
								<col style={{ width: 80 }} />
								<col style={{ width: '25%' }} />
								<col style={{ width: 80 }} />
								<col style={{ width: '25%' }} />
								<col style={{ width: 80 }} />
								<col style={{ width: '25%' }} />
							</colgroup>
							<tbody>
								<tr>
									<th className="required">처리 구분</th>
									<td className="text-center">
										<CmmCodeSelect
											className="w-full"
											id="sltProcessGbCd"
											label="처리구분"
											name=""
											code1="001"
											code2="001"
											selected={processGbCd}
											onSelect={selected => setProcessGbCd(selected)}
											total={{ code: 'total', name: '전체' }}
										/>
									</td>
									<th>매출등급</th>
									<td className="text-center">
										<CmmCodeSelect
											className="w-full"
											id="sltSalesGrd"
											label="매출등급"
											name=""
											code1="003"
											code2="002"
											selected={salesGrd}
											onSelect={selected => setSalesGrd(selected)}
											total={{ code: 'total', name: '전체' }}
										/>
									</td>
									<th>승인/반려</th>
									<td>
										<CmmCodeRadio
											className="w-full"
											name=""
											code1="003"
											code2="003"
											selected={approval}
											onSelect={selected => setApproval(selected)}
											total={{ code: 'total', name: '전체' }}
										/>
									</td>
									<th>승인/반려2</th>
									<td>
										<CmmCodeCheck
											className="w-full"
											name=""
											code1="003"
											code2="003"
											selected={approval2}
											onSelect={selected => setApproval2(selected)}
										/>
									</td>
								</tr>
								<tr>
									<th>지점코드</th>
									<td className="text-center">
										<KtngDeptSelector
											className="w-full"
											valueFunc={item => `${item.deptNm} 부서`}
											onSelect={selected => setDept(selected)}
											deptCd="010132"
											fullWidth
										/>
									</td>
									<th>주문일자</th>
									<td className="text-left pl-16">
										<DateRangeSelecter
											className="w-full"
											options={{ placement: 'bottom-start' }}
											fromto={fromto}
											onBlur={({ startDate, endDate }) =>
												setFromto({
													startDate: new Date(startDate),
													endDate: new Date(endDate)
												})
											}
										/>
									</td>
									<th>작성자명</th>
									<td className="text-center">
										<Input
											className="flex flex-1 px-8"
											placeholder="작성자명"
											disableUnderline
											fullWidth
											type="text"
											value={boardWriter}
											onChange={e => setBoardWriter(e.target.value)}
										/>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</Formsy>
			</Collapse>
		</div>
	);
};

export default withReducer('pageGuide', reducer)(Cult001SearchForm);
