const options = {
	Cfg: {
		CanSelect: true, // 시트 선택 가능
		SelectingCells: 0, // 개별 셀 선택 불가능
		CanEdit: 1, // 수정 가능
		CustomScroll: 1 // 그리드와 스크롤 겹침 이슈 처리
	},
	Def: {
		Col: {
			RelWidth: 1
		}
	},
	Cols: [
		{
			Header: '순번',
			Name: 'SEQ',
			Type: 'Int',
			Width: 65,
			RelWidth: 0
		},
		{
			Header: {
				Value: '',
				HeaderCheck: 1
			},
			Type: 'Bool',
			Name: 'delYn',
			CanSort: false,
			Align: 'center',
			DefaultValue: false,
			NoChanged: true,
			Width: 40,
			RelWidth: 0
		},
		{
			Header: '상태',
			Name: 'rowStatus',
			Type: 'Enum',
			Align: 'center',
			DefaultValue: 'N',
			Enum: '|N|I|U|D',
			EnumKeys: '|N|I|U|D',
			CanEdit: 0,
			NoChanged: true,
			Width: 65,
			RelWidth: 0
		},
		{
			Header: '결재상태',
			Type: 'Enum',
			Name: 'apprStat',
			Align: 'right',
			DefaultValue: '', // 초기값 (Value)
			Enum: '', // Label
			EnumKeys: '' // Value
		},
		{
			Header: '결재상태2',
			Type: 'Enum',
			Name: 'apprStat2',
			Align: 'right',
			DefaultValue: '', // 초기값 (Value)
			Enum: '', // Label
			EnumKeys: '', // Value
			Icon: '/assets/images/ibsheet/search-small.png', // 좌측 아이콘 파일
			IconWidth: 15, // 아이콘 크기
			Cursor: 'pointer', // 마우스 커서를 포인터로 변경
			Width: 120,
			CanEdit: 0
		},
		{
			Header: '게시판코드',
			Name: 'boardCate',
			Type: 'Text',
			CanEdit: 0
		},
		{
			Header: '번호',
			Name: 'boardNo',
			Type: 'Text',
			CanEdit: 0
		},
		{
			Header: '제목',
			Name: 'boardTitle',
			Type: 'Text'
		},
		{
			Header: '요약',
			Name: 'boardSummary',
			Type: 'Text'
		},
		{
			Header: '조회수',
			Name: 'boardHit',
			Type: 'Int',
			Format: '#,##0',
			CanEdit: 0
		},
		{
			Header: '수정일',
			Name: 'modDate',
			Type: 'Date',
			Format: 'yyyy-MM-dd',
			CanEdit: 0
		},
		{
			Header: ' ',
			Name: 'btnEdit',
			Type: 'Button',
			DefaultValue: '수정',
			Width: 65,
			RelWidth: 0
		}
	]
};

export default options;
