import FusePageSimple from '@fuse/core/FusePageSimple';
import { Typography } from '@material-ui/core';
import ListIcon from '@material-ui/icons/List';
import React from 'react';
import Cult001BoardGrd from './component/Cult001/Cult001BoardGrd';
import Cult001BoardWriterGrd from './component/Cult001/Cult001BoardWriterGrd';
import Cult001SearchForm from './component/Cult001/Cult001SearchForm';

const Cult001Page = () => {
	return (
		<FusePageSimple
			classes={{
				header: 'min-h-72 h-auto',
				content: 'flex p-16 sm:24',
				contentWrapper: 'mb-32'
			}}
			header={
				<div className="w-full">
					<div className="flex flex-1 items-center justify-between p-16 sm:p-24">
						<div className="flex items-center">
							<ListIcon className="text-32" />
							<Typography className="hidden sm:flex mx-0 sm:mx-12" variant="h6">
								IBSheet 게시판
							</Typography>
						</div>
					</div>
				</div>
			}
			content={
				<div className="w-full flex flex-col">
					<Cult001SearchForm />

					{/* 작성자 목록 그리드뷰 */}
					<Cult001BoardWriterGrd />
					{/* 게시글 목록 그리드뷰 */}
					<Cult001BoardGrd />
				</div>
			}
		/>
	);
};

export default Cult001Page;
