import { combineReducers } from '@reduxjs/toolkit';
import cult001 from './cult001Slice';

const reducer = combineReducers({
	cult001
});

export default reducer;
