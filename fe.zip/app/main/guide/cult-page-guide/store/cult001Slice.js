import KtngUtils from '@ktng/utils';
import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import { showMessage } from 'app/store/fuse/messageSlice';
import axios from 'axios';

export const getWriterList = createAsyncThunk(
	'pageGuide/cult001/getWriterList',
	async (_, { dispatch, getState, rejectWithValue }) => {
		try {
			const { routeParams: params } = getState().pageGuide.cult001;

			const response = await axios.get('/api/board2/writer-list', { params });
			const { data } = response.data;

			if (data.length === 0) {
				dispatch(showMessage({ message: '조회된 건수가 없습니다.' }));
			} else {
				dispatch(showMessage({ message: `총 ${data.length}건 조회되었습니다.` }));

				// 메인그리드 첫행으로 서브그리드 조회
				dispatch(changeSubRouteParams({ boardWriter: data[0].boardWriter }));
			}

			const payload = {
				writers: data
			};

			return payload;
		} catch (err) {
			return KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

export const getBoardList = createAsyncThunk(
	'pageGuide/cult001/getBoardList',
	async (_, { dispatch, getState, rejectWithValue }) => {
		try {
			const { subRouteParams: params } = getState().pageGuide.cult001;

			const response = await axios.get('/api/board2/list', { params });
			const { data } = response.data;

			if (data.length === 0) {
				dispatch(showMessage({ message: '조회된 건수가 없습니다.' }));
			} else {
				dispatch(showMessage({ message: `총 ${data.length}건 조회되었습니다.` }));
			}

			const payload = {
				boards: data
			};

			return payload;
		} catch (err) {
			return KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

export const saveBoardList = createAsyncThunk(
	'pageGuide/cult001/saveBoardList',
	async ({ changed, deleted }, { dispatch, rejectWithValue }) => {
		try {
			const response = await axios.post('/api/board2/list', { changed, deleted });
			const { data } = response.data;

			if (data.length === 0) {
				dispatch(showMessage({ message: '수정된 건수가 없습니다.' }));
			} else {
				dispatch(showMessage({ message: `총 ${data.length}건 수정되었습니다.` }));
			}

			dispatch(getWriterList());

			return {};
		} catch (err) {
			return KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

const initialState = {
	writers: [],
	boards: [],
	routeParams: {
		processGbCd: { code: 'total', name: '전체' },
		salesGrd: { code: 'total', name: '전체' },
		approval: { code: 'total', name: '전체' },
		approval2: [],
		dept: {},
		fromto: {},
		boardWriter: ''
	},
	subRouteParams: {
		boardWriter: ''
	}
};

// ---------------------------------------------------------

const cult001Slice = createSlice({
	name: 'pageGuide/cult001',
	initialState,
	reducers: {
		emptyBoardList: state => {
			state.boards = initialState.boards;
		},
		emptyWriterList: state => {
			state.writers = initialState.writers;
		},
		changeRouteParams: (state, action) => {
			state.routeParams = {
				...state.routeParams,
				...action.payload
			};
		},
		changeSubRouteParams: (state, action) => {
			state.subRouteParams = {
				...state.subRouteParams,
				...action.payload
			};
		}
	},
	extraReducers: {
		[getWriterList.pending]: state => {
			state.writers = initialState.writers;
			state.subRouteParams = initialState.subRouteParams;
		},
		[getWriterList.fulfilled]: (state, action) => {
			const { writers } = action.payload;
			state.writers = writers;
		},
		[getBoardList.pending]: state => {
			state.boards = initialState.boards;
		},
		[getBoardList.fulfilled]: (state, action) => {
			const { boards } = action.payload;
			state.boards = boards;
		}
	}
});

export const { emptyBoardList, emptyWriterList, changeRouteParams, changeSubRouteParams } = cult001Slice.actions;

export default cult001Slice.reducer;
