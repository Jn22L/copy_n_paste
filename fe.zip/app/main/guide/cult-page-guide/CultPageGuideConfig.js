import React from 'react';

const CultPageGuideConfig = {
	settings: {
		layout: {
			config: {}
		}
	},
	routes: [
		{
			path: '/guide/cult-page/cult001',
			component: React.lazy(() => import('./Cult001Page')),
			auth: { check: false }
		}
	]
};

export default CultPageGuideConfig;
