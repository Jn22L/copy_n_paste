import IbsheetConfig from './ibsheet/IbsheetConfig';
import CompGuideConfig from './comp-guide/CompGuideConfig';
import CultPageGUideConfig from './cult-page-guide/CultPageGuideConfig';
import UutasPageGuideConfig from './uutas-page-guide/UutasPageGuideConfig';

const guideConfig = [IbsheetConfig, CompGuideConfig, CultPageGUideConfig, UutasPageGuideConfig];

export default guideConfig;
