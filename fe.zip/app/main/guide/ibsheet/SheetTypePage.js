import FusePageSimple from '@fuse/core/FusePageSimple';
import { makeStyles } from '@material-ui/core/styles';
import React, { useEffect } from 'react';
import loader from '@ibsheet/loader';
import IbsheetPageHader from './component/IbsheetPageHader';
import sheetTypePageObj from './sheetTypePageObj';

const useStyles = makeStyles(theme => ({
	layoutRoot: {}
}));

const sheetId = 'SheetTypePageSheet';

export default function SheetTypePage(props) {
	const classes = useStyles(props);

	useEffect(() => {
		console.log('SheetTypePage START');

		const { init: options, data, event } = sheetTypePageObj;
		options.Events = event;

		// 		id: 'sheet', // 생성할 시트의 id
		// 		el: 'sheetDiv', // 시트를 생성할 Dom 객체 및 id
		// 		options: options, // 생성될 시트의 속성
		// 		data: this.data // 생성될 시트의 정적데이터
		loader
			.createSheet({
				id: sheetId,
				el: 'sheetWrapper',
				options,
				data
			})
			.then(sheet => {
				// sheet: IBSheetInstance
				console.log('created ibsheet:', sheet.id);
			});

		return () => {
			loader.removeSheet(sheetId);
			console.log('SheetTypePage END');
		};
	}, []);

	return (
		<FusePageSimple
			classes={{
				root: classes.layoutRoot
			}}
			header={
				<IbsheetPageHader
					title={sheetTypePageObj.title}
					subtitle={sheetTypePageObj.subtitle}
					paths={sheetTypePageObj.paths}
				/>
			}
			content={<div style={{ height: '100%' }} id="sheetWrapper" />}
		/>
	);
}
