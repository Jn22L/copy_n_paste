const IbsheetNavigation = {
	id: 'ibsheet-component',
	title: 'ibsheet',
	type: 'collapse',
	icon: 'apps',
	children: [
		{
			id: 'ibsheet-sheet-sample',
			title: 'SheetSample',
			type: 'item',
			url: '/ibsheet/sheetsample'
		},
		{
			id: 'ibsheet-g1',
			title: '컬럼 유형과 기능',
			type: 'collapse',
			url: '/ibsheet/type',
			children: [
				{
					id: 'ibsheet-g1-p1',
					title: '컬럼 별 타입',
					type: 'item',
					url: '/ibsheet/type'
				}
			]
		},
		{
			id: 'ibsheet-g2',
			title: '행고정,열고정',
			type: 'collapse',
			url: '/ibsheet/section',
			children: [
				{
					id: 'ibsheet-g2-p1',
					title: '열고정',
					type: 'item',
					url: '/ibsheet/section'
				}
			]
		},
		// {
		// 	id: 'ibsheet-focus',
		// 	title: '포커스 이동',
		// 	type: 'item',
		// 	url: '/ibsheet/focus'
		// },
		// {
		// 	id: 'ibsheet-g3',
		// 	title: '숫자 연산',
		// 	type: 'collapse',
		// 	url: '/ibsheet/sum',
		// 	children: [
		// 		{
		// 			id: 'ibsheet-g3-p1',
		// 			title: '합계',
		// 			type: 'item',
		// 			url: '/ibsheet/sum'
		// 		}
		// 	]
		// },
		{
			id: 'ibsheet-formula',
			title: '포뮬러',
			type: 'item',
			url: '/ibsheet/formula'
		},
		// {
		// 	id: 'ibsheet-g4',
		// 	title: '데이터 조회',
		// 	type: 'collapse',
		// 	url: '/ibsheet/render',
		// 	children: [
		// 		{
		// 			id: 'ibsheet-g4-p1',
		// 			title: '렌더링 방식',
		// 			type: 'item',
		// 			url: '/ibsheet/render'
		// 		}
		// 	]
		// },
		// {
		// 	id: 'ibsheet-g5',
		// 	title: '데이터 저장',
		// 	type: 'collapse',
		// 	url: '/ibsheet/save',
		// 	children: [
		// 		{
		// 			id: 'ibsheet-g5-p1',
		// 			title: '렌더링 방식',
		// 			type: 'item',
		// 			url: '/ibsheet/save'
		// 		}
		// 	]
		// },
		// {
		// 	id: 'ibsheet-g6',
		// 	title: '편집',
		// 	type: 'collapse',
		// 	url: '/ibsheet/regexp',
		// 	children: [
		// 		{
		// 			id: 'ibsheet-g6-p1',
		// 			title: '정규식(RegExp)를 이용한 검증',
		// 			type: 'item',
		// 			url: '/ibsheet/regexp'
		// 		}
		// 	]
		// },
		// {
		// 	id: 'ibsheet-g7',
		// 	title: '머지',
		// 	type: 'collapse',
		// 	url: '/ibsheet/merge',
		// 	children: [
		// 		{
		// 			id: 'ibsheet-g7-p1',
		// 			title: '자동 머지',
		// 			type: 'item',
		// 			url: '/ibsheet/merge'
		// 		}
		// 	]
		// },
		// {
		// 	id: 'ibsheet-g8',
		// 	title: '헤더기능',
		// 	type: 'collapse',
		// 	url: '/ibsheet/sort',
		// 	children: [
		// 		{
		// 			id: 'ibsheet-g8-p1',
		// 			title: '소팅',
		// 			type: 'item',
		// 			url: '/ibsheet/sort'
		// 		}
		// 	]
		// },
		// {
		// 	id: 'ibsheet-tree',
		// 	title: '트리',
		// 	type: 'item',
		// 	url: '/ibsheet/tree'
		// },
		{
			id: 'ibsheet-g9',
			title: '파일 import/export',
			type: 'collapse',
			url: '/ibsheet/file-export',
			children: [
				{
					id: 'ibsheet-g9-p1',
					title: '파일 Export',
					type: 'item',
					url: '/ibsheet/file-export'
				}
			]
		}
		// {
		// 	id: 'ibsheet-context-menu',
		// 	title: '컨택스트 메뉴',
		// 	type: 'item',
		// 	url: '/ibsheet/context-menu'
		// },
		// {
		// 	id: 'ibsheet-events',
		// 	title: '이벤트',
		// 	type: 'item',
		// 	url: '/ibsheet/events'
		// },
		// {
		// 	id: 'ibsheet-message',
		// 	title: '메시지',
		// 	type: 'item',
		// 	url: '/ibsheet/message'
		// },
		// {
		// 	id: 'ibsheet-g10',
		// 	title: '멀티레코드',
		// 	type: 'collapse',
		// 	url: '/ibsheet/multirecord_goods',
		// 	children: [
		// 		{
		// 			id: 'ibsheet-g10-p1',
		// 			title: '멀티 레코드(쇼핑몰)',
		// 			type: 'item',
		// 			url: '/ibsheet/multirecord_goods'
		// 		}
		// 	]
		// },
		// {
		// 	id: 'ibsheet-g11',
		// 	title: '기타 기능',
		// 	type: 'collapse',
		// 	url: '/ibsheet/tooltip',
		// 	children: [
		// 		{
		// 			id: 'ibsheet-g11-p1',
		// 			title: '툴팁',
		// 			type: 'item',
		// 			url: '/ibsheet/tooltip'
		// 		}
		// 	]
		// }
	]
};
export default IbsheetNavigation;
