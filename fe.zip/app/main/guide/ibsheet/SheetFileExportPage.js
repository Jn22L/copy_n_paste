import React, { useEffect, useContext, useState } from 'react';
import { TextField, Button } from '@material-ui/core';
import FusePageSimple from '@fuse/core/FusePageSimple';
import useIbsheetLoad from '@ktng/hooks/useIbsheetLoad';
import FuseLoading from '@fuse/core/FuseLoading';
import loader from '@ibsheet/loader';
import AppContext from 'app/AppContext';
import IbsheetPageHader from './component/IbsheetPageHader';
import getSheetFileExportPageObj from './SheetFileExportPageObj';

const sheetId = 'fileExportSheet';
let sheetIns = null;

//
export default function SheetFileExportPage() {
	const { ibsheet } = useContext(AppContext);
	const [isLoadedIbs, setIsLoadedIbs] = useState(false);

	const [filename, setFilename] = useState(
		`${window.IBSheet.dateToString(new Date(), 'yyyy-MM-dd HH:mm')}_IBSheet엑셀 예제`
	);
	const [sheetFormulaPageObj, setSheetFormulaPageObj] = useState(null);

	useIbsheetLoad(ibsheet, ['ibsheet-common', 'ibsheet-excel', 'ibsheet-dialog'], isLoadedIbs, () => {
		console.log('SheetFileExportPage, loadComplate');
		setSheetFormulaPageObj(getSheetFileExportPageObj());
		setIsLoadedIbs(true);
	});

	useEffect(() => {
		if (!sheetFormulaPageObj) return () => {};

		const { init: options, data, event } = sheetFormulaPageObj;
		options.Events = event;

		loader
			.createSheet({
				id: sheetId,
				el: 'sheetWrapper',
				options,
				data
			})
			.then(sheet => {
				// sheet: IBSheetInstance
				sheetIns = sheet;
				console.log('created ibsheet:', sheet.id);
			});

		return () => {
			sheetIns = null;
			loader.removeSheet(sheetId);
			console.log('SheetFileExport END');
		};
	}, [sheetFormulaPageObj]);

	function actionDownload(type) {
		switch (type) {
			case 'xlsx':
				sheetIns.down2Excel({
					SheetDesign: 1,
					merge: 1,
					fileName: `${filename}.xlsx`
				});
				break;
			case 'csv':
				// Uncaught TypeError: Cannot set property 'sNameSpan' of undefined
				sheetIns.down2Text({
					colDelim: ',',
					fileName: `${filename}.csv`
				});
				break;
			case 'txt':
				sheetIns.down2Text({ fileName: `${filename}.txt` });
				break;
			case 'hml':
				//   sheet.down2Hml({ fileName: document.getElementById('filename').value });
				break;
			case 'excelDownDialog':
				sheetIns.showExcelDownloadDialog();
				break;
			// case "PDF 형식으로 내보내기":
			//   sheet.down2Pdf({"fileName":document.getElementById("filename").value,Dpi:1800, Paper:"landscape",});
			// break;
			// no default
		}
	}

	if (!isLoadedIbs || !sheetFormulaPageObj) {
		return <FuseLoading />;
	}

	return (
		<FusePageSimple
			classes={{
				// root: classes.layoutRoot,
				toolbar: 'border-b-1'
			}}
			header={
				<IbsheetPageHader
					title={sheetFormulaPageObj.title}
					subtitle={sheetFormulaPageObj.subtitle}
					paths={sheetFormulaPageObj.paths}
				/>
			}
			contentToolbar={<div className="content" dangerouslySetInnerHTML={{ __html: sheetFormulaPageObj.desc }} />}
			content={
				<div className="w-full flex flex-col">
					<div className="p-8">
						<TextField
							className="w-360"
							label="내려받을 파일명"
							variant="filled"
							size="small"
							value={filename}
							onChange={event => setFilename(event.target.value)}
						/>
						<div className="flex flex-wrap flex-1 items-center pt-8">
							<Button
								variant="outlined"
								color="primary"
								size="small"
								onClick={() => actionDownload('xlsx')}
							>
								엑셀파일 내보내기
							</Button>
							<Button
								className="ml-4"
								variant="outlined"
								color="primary"
								size="small"
								onClick={() => actionDownload('csv')}
							>
								CSV 내보내기
							</Button>
							<Button
								className="ml-4"
								variant="outlined"
								color="primary"
								size="small"
								onClick={() => actionDownload('txt')}
							>
								txt 내보내기
							</Button>
							<Button
								className="ml-4"
								variant="outlined"
								color="primary"
								size="small"
								onClick={() => actionDownload('hml')}
							>
								HML 내보내기
							</Button>
							{/* <Button
								className="ml-4"
								variant="outlined"
								color="primary"
								size="small"
								onClick={() => actionDownload('pdf')}
							>
								PDF 내보내기
							</Button> */}
							<Button
								className="ml-8"
								variant="contained"
								color="primary"
								size="small"
								onClick={() => actionDownload('excelDownDialog')}
							>
								다운로드 다이얼로그
							</Button>
						</div>
					</div>

					<div style={{ height: '100%' }} id="sheetWrapper" />
				</div>
			}
		/>
	);
}
