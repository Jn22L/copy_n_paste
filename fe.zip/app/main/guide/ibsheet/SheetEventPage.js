import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import FusePageSimple from '@fuse/core/FusePageSimple';

const useStyles = makeStyles(theme => ({
	layoutRoot: {}
}));

export default function SheetEventPage(props) {
	const classes = useStyles(props);

	return (
		<FusePageSimple
			classes={{
				root: classes.layoutRoot
			}}
			header={
				<div className="p-24">
					<h4>TITLE</h4>
				</div>
			}
			contentToolbar={
				<div className="px-24">
					<h4>Content Toolbar</h4>
				</div>
			}
			content={<div style={{ height: '100%' }} id="sheetWrapper" />}
		/>
	);
}
