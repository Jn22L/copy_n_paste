import FusePageSimple from '@fuse/core/FusePageSimple';
import { makeStyles } from '@material-ui/core/styles';
import React, { useEffect } from 'react';
import loader from '@ibsheet/loader';
import SheetSampleData from './ibsheet-data';

const useStyles = makeStyles(theme => ({
	layoutRoot: {}
}));

const sheetId = 'ExamplePage2Sheet';

// https://demo.ibleaders.com/ibsheet/v8/samples/customer-sample/html/main.html
function SheetSamplePage(props) {
	const classes = useStyles(props);

	useEffect(() => {
		console.log('SheetSample START');

		// IBSheet 렌더링..
		const { data, options } = SheetSampleData[1];
		loader
			.createSheet({
				id: sheetId,
				el: 'sheetWrapper',
				options,
				data
			})
			.then(sheet => {
				// sheet: IBSheetInstance
				console.log('created ibsheet:', sheet.id);
			});
		return () => {
			loader.removeSheet(sheetId);
			console.log('SheetSample END');
		};
	}, []);

	return (
		<FusePageSimple
			classes={{
				root: classes.layoutRoot
			}}
			header={
				<div className="p-24">
					<h4>TITLE</h4>
				</div>
			}
			contentToolbar={
				<div className="px-24">
					<h4>Content Toolbar</h4>
				</div>
			}
			content={<div style={{ height: '100%' }} id="sheetWrapper" />}
		/>
	);
}

export default SheetSamplePage;
