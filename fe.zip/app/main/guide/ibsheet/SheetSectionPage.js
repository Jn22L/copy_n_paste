import FusePageSimple from '@fuse/core/FusePageSimple';
import { Button, TextField } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import loader from '@ibsheet/loader';
import React, { useEffect, useState } from 'react';
import IbsheetPageHader from './component/IbsheetPageHader';
import sheetSectionPageObj from './sheetSectionPageObj';

const useStyles = makeStyles(theme => ({
	layoutRoot: {}
}));

const sheetId = 'SheetSectionPageSheet';

let sheetIns = null;

export default function SheetSectionPage(props) {
	const classes = useStyles(props);
	const [val1, setVal1] = useState(3);
	const [val2, setVal2] = useState(2);

	useEffect(() => {
		console.log('SheetSectionPage START');

		const { init: options, data, event } = sheetSectionPageObj;
		options.Events = event;

		loader
			.createSheet({
				id: sheetId,
				el: 'sheetWrapper',
				options,
				data
			})
			.then(sheet => {
				// sheet: IBSheetInstance
				sheetIns = sheet;
				console.log('created ibsheet:', sheet.id);
			});

		return () => {
			sheetIns = null;
			loader.removeSheet(sheetId);
			console.log('SheetSectionPage END');
		};
	}, []);

	function action() {
		// 시트 초기화시 SEQ컬럼을 생성하지 않았다 하더라도
		// SEQ컬럼은 히든된 상태로 생성되어있으므로 왼쪽 컬럼은 + 1
		console.log(`action ===> left: ${val1}, right: ${val2}`);
		sheetIns.setFixedCols(val1 + 1, val2, 1);
	}

	return (
		<FusePageSimple
			classes={{
				root: classes.layoutRoot,
				toolbar: 'border-b-1'
			}}
			header={
				<IbsheetPageHader
					title={sheetSectionPageObj.title}
					subtitle={sheetSectionPageObj.subtitle}
					paths={sheetSectionPageObj.paths}
				/>
			}
			contentToolbar={
				<div className="flex flex-wrap flex-1 items-center p-8">
					<TextField
						className="ml-4"
						label="왼쪽 컬럼 고정 갯수"
						value={val1}
						onChange={event => setVal1(event.target.value)}
					/>
					<TextField
						className="ml-4"
						label="오른쪽 컬럼 고정 갯수"
						value={val2}
						onChange={event => setVal2(event.target.value)}
					/>

					<Button className="ml-8 normal-case" color="default" variant="contained" onClick={action}>
						열고정
					</Button>
				</div>
			}
			content={<div style={{ height: '100%' }} id="sheetWrapper" />}
		/>
	);
}
