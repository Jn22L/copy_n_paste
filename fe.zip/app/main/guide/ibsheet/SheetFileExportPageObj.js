const getSheetFileExportPageObj = () => {
	return {
		// 샘플 타이틀
		title: '파일 내보내기(다운로드) 예제',
		subtitle: '시트내에 데이터를 다운로드 합니다.',
		paths: ['IBSheet', '파일 import/export'],
		// 샘플 설명
		desc:
			'down2Excel(),down2Text() 등의 함수를 통해서 시트 내에 데이터를 외부파일로 다운로드 하실 수 있습니다.<br>' +
			'import/export 관련 기능을 사용시에는 <strong>ibsheet-excel.js</strong> 파일이 include 되어야 합니다.',
		// 객체 초기화 구문
		init: {
			Cfg: {
				SearchMode: 2,
				HeaderMerge: 6,
				FitWidth: 1,
				Export: {
					// 	Url: location.href.indexOf('localhost') > -1 ? '../jsp/' : 'https://api.ibleaders.com/ibsheet/v8/'
					Down2ExcelUrl: '/api/ibsheet/down2excel',
					Down2TextUrl: '/api/ibsheet/down2text',
					Relative: true, // 주소의 상대경로 유무, false : 실제 주소(절대 경로), true : ibsheet.js 기준 상대 경로
					Method: 'POST'
				} // 다운 jsp URL
			},
			Cols: [
				{
					Header: ['신청인', '신청인'],
					Type: 'Text',
					MinWidth: 80,
					Name: 'sName',
					ColMerge: 1
				},
				{
					Header: ['선택', '선택'],
					Type: 'Bool',
					MinWidth: 80,
					Name: 'check',
					ColMerge: 1
				},
				{
					Header: ['신청사유', '신청사유'],
					Type: 'Enum',
					MinWidth: 80,
					Name: 'Reason',
					ColMerge: 0,
					Align: 'Center',
					Enum: '|야근|주말특근|휴일특근',
					EnumKeys: '|01|02|03'
				},
				{
					Header: ['신청금액', '신청금액'],
					Type: 'Int',
					MinWidth: 85,
					Name: 'Qty',
					ColMerge: 1,
					Required: 1
				},
				{
					Header: ['근태기간', '시작일'],
					Name: 'Date1',
					Extend: window.IB_Preset.YMD
				},
				{
					Header: ['근태기간', '종료일'],
					Name: 'Date2',
					Extend: window.IB_Preset.YMD
				},
				{
					Header: ['시간', '시작'],
					Name: 'Time1',
					Extend: window.IB_Preset.HM
				},
				{
					Header: ['시간', '종료'],
					Name: 'Time2',
					Extend: window.IB_Preset.HM
				},
				{
					Header: ['rDate', 'rDate'],
					Name: 'rDate',
					Extend: window.IB_Preset.YMD,
					Visible: 0
				},
				{
					Header: ['chk', 'chk'],
					Name: 'chk',
					Type: 'Bool',
					Visible: 0
				}
			]
		},

		// event구문
		event: {
			onBeforeExport: evt => {
				console.log(evt.eventName);
			},
			onExportFinish: evt => {
				console.log(evt);
			}
		},

		// data
		data: [
			{
				Reason: '01',
				sName: '강인철',
				rDate: '20030908',
				chk: 0,
				Qty: 545000,
				Time1: '1300',
				Time2: '1800'
			},
			{
				Reason: '01',
				sName: '김수용',
				rDate: '20030906',
				chk: 1,
				Qty: 500000,
				Date1: '20030906',
				Date2: '20030906',
				Time1: '0900',
				Time2: '1800'
			},
			{
				Reason: '02',
				sName: '김수용',
				rDate: '20030905',
				chk: 1,
				Qty: 500000,
				Date1: '20030905',
				Date2: '20030905',
				Time1: '0900',
				Time2: '1800'
			},
			{
				Reason: '03',
				sName: '조문성',
				rDate: '20030905',
				chk: 0,
				Qty: 50000,
				Date1: '20030905',
				Date2: '20030905',
				Time1: '1400',
				Time2: '1500'
			},
			{
				Reason: '03',
				sName: '조문성',
				rDate: '20030905',
				chk: 1,
				Qty: 150000,
				Date1: '20030901',
				Date2: '20030902',
				Time1: '0900',
				Time2: '1800'
			},
			{
				Reason: '02',
				sName: '조문성',
				rDate: '20030830',
				chk: 0,
				Qty: 200000,
				Date1: '20030830',
				Date2: '20030830',
				Time1: '1500',
				Time2: '1800'
			},
			{
				Reason: '01',
				sName: '박진성',
				rDate: '20030611',
				chk: 0,
				Qty: 155000,
				Date1: '20030611',
				Date2: '20030611',
				Time1: '2000',
				Time2: '2200'
			},
			{
				Reason: '01',
				sName: '박진성',
				rDate: '20030508',
				chk: 1,
				Qty: 0,
				Date1: '20030508',
				Date2: '20030508',
				Time1: '0900',
				Time2: '1200'
			},
			{
				Reason: '03',
				sName: '김응주',
				rDate: '19990703',
				chk: 0,
				Qty: 155000,
				Date1: '20030611',
				Date2: '20030611',
				Time1: '0900',
				Time2: '1800'
			},
			{
				Reason: '02',
				sName: '김응주',
				rDate: '20050101',
				chk: 1,
				Qty: 0,
				Date1: '20030508',
				Date2: '20030508',
				Time1: '0900',
				Time2: '1200'
			},
			{
				Reason: '01',
				sName: '김응주',
				rDate: '20000819',
				chk: 0,
				Qty: 155000,
				Date1: '20030611',
				Date2: '20030611',
				Time1: '1500',
				Time2: '1900'
			},
			{
				Reason: '03',
				sName: '신요한',
				rDate: '20111125',
				chk: 1,
				Qty: 0,
				Date1: '20010108',
				Date2: '20030508',
				Time1: '0900',
				Time2: '1200'
			}
		]
	};
};

export default getSheetFileExportPageObj;
