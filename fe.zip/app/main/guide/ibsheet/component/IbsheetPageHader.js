import React from 'react';
import { Breadcrumbs, Button, Typography, Icon } from '@material-ui/core';

export default function IbsheetPageHader({ title, subtitle, paths = [] }) {
	return (
		<div className="flex flex-wrap flex-1 items-center justify-between px-16 py-8 sm:px-24 sm:py-16 ">
			<div className="flex-col h-full">
				<Breadcrumbs className="mb-8" aria-label="breadcrumb">
					{paths.map((path, index) => {
						if (index === 0) {
							return (
								<Typography key={index} className="font-bold hover:underline" color="secondary">
									{path}
								</Typography>
							);
						}
						return (
							<Typography key={index} className="cursor-default">
								{path}
							</Typography>
						);
					})}
				</Breadcrumbs>
				<Typography className="h2" color="textPrimary">
					{title}
				</Typography>
				<Typography className="h5" color="textSecondary">
					{subtitle}
				</Typography>
			</div>
			<Button
				className="normal-case ml-8 sm:ml-0"
				variant="outlined"
				component="a"
				href="https://demo.ibleaders.com/ibsheet/v8/samples/customer-sample/html/main.html"
				target="_blank"
				role="button"
				color="default"
			>
				<Icon>link</Icon>
				<span className="mx-4 hidden sm:flex">Reference</span>
			</Button>
		</div>
	);
}
