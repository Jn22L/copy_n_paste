import React from 'react';
import SheetSamplePage from './SheetSamplePage';
import SheetEventPage from './SheetEventPage';
import SheetTypePage from './SheetTypePage';
import SheetSectionPage from './SheetSectionPage';
import SheetFormulaPage from './SheetFormulaPage';

const IbsheetConfig = {
	settings: {
		layout: {
			config: {}
		}
	},
	routes: [
		{
			path: '/ibsheet/sheetsample',
			component: SheetSamplePage,
			auth: { check: false }
		},
		{
			path: '/ibsheet/type',
			component: SheetTypePage,
			auth: { check: false }
		},
		{
			path: '/ibsheet/section',
			component: SheetSectionPage,
			auth: { check: false }
		},
		{
			path: '/ibsheet/formula',
			component: SheetFormulaPage,
			auth: { check: false }
		},
		{
			path: '/ibsheet/event',
			component: SheetEventPage,
			auth: { check: false }
		},
		{
			path: '/ibsheet/file-export',
			component: React.lazy(() => import('./SheetFileExportPage')),
			auth: { check: false }
		}
	]
};

export default IbsheetConfig;
