import React, { useEffect } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import FusePageSimple from '@fuse/core/FusePageSimple';
import loader from '@ibsheet/loader';
import sheetFormulaPageObj from './sheetFormulaPageObj';
import IbsheetPageHader from './component/IbsheetPageHader';

const useStyles = makeStyles(theme => ({
	layoutRoot: {}
}));

const sheetId = 'SheetFormulaPageSheet';

export default function SheetFormulaPage(props) {
	const classes = useStyles(props);

	useEffect(() => {
		console.log('SheetFormulaPage START');

		const { init: options, data, event } = sheetFormulaPageObj;
		options.Events = event;

		loader
			.createSheet({
				id: sheetId,
				el: 'sheetWrapper',
				options,
				data
			})
			.then(sheet => {
				// sheet: IBSheetInstance
				console.log('created ibsheet:', sheet.id);
			});

		return () => {
			loader.removeSheet(sheetId);
			console.log('SheetFormulaPage END');
		};
	}, []);

	return (
		<FusePageSimple
			classes={{
				root: classes.layoutRoot
			}}
			header={
				<IbsheetPageHader
					title={sheetFormulaPageObj.title}
					subtitle={sheetFormulaPageObj.subtitle}
					paths={sheetFormulaPageObj.paths}
				/>
			}
			contentToolbar={<div className="content" dangerouslySetInnerHTML={{ __html: sheetFormulaPageObj.desc }} />}
			content={<div style={{ height: '100%' }} id="sheetWrapper" />}
		/>
	);
}
