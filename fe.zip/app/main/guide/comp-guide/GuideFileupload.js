import FusePageSimple from '@fuse/core/FusePageSimple';
import AttachLabel from '@ktng/core/KtngAttachment/AttachLabel';
import { Button, Icon, makeStyles, Typography } from '@material-ui/core';
import AttachService from 'app/services/attachService';
import React, { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { showMessage } from 'app/store/fuse/messageSlice';

const useStyles = makeStyles({
	button: {
		textTransform: 'none'
	}
});

function GuideFileupload() {
	const classes = useStyles();
	const dispatch = useDispatch();

	const [tmpAttachInfo, setTmpAttachInfo] = useState();
	const [uploadedAttachInfo, setUploadedAttachInfo] = useState();

	useEffect(() => {
		AttachService.getFileInfo('2021010001', dispatch).then(dto => {
			console.log('tmpAttachInfo:', dto);
			setTmpAttachInfo(dto);
		});
		// eslint-disable-next-line
	}, []);

	function onChangeSimpleFile(event) {
		const file = event.target.files[0];
		event.target.value = '';
		AttachService.upload(file).then(dto => {
			setUploadedAttachInfo(dto);
			dispatch(showMessage({ message: `${dto.fileNm} 파일 업로드 완료!`, variant: 'success' }));
		});
	}

	function onRemoveFile({ attachNo, attachInfo }) {
		setUploadedAttachInfo(null);
		dispatch(showMessage({ message: `${attachInfo.fileNm} 파일 삭제 완료!`, variant: 'success' }));
	}

	return (
		<FusePageSimple
			classes={{
				header: 'min-h-72 h-72'
			}}
			header={
				<div className="p-24 flex items-center">
					<Icon className="text-32">unarchive</Icon>
					<Typography className="h2 mx-12 hidden sm:flex">파일업로드</Typography>
				</div>
			}
			content={
				<div className="p-24 w-full grid grid-cols-2 gap-4">
					<div className="p-24">
						<h4>단순파일 업로드</h4>
						<div className="p-24 grid grid-cols-2 gap-4">
							<div>
								<h5 className="font-semibold">일반형</h5>
								<br />
								<input type="file" name="file" onChange={onChangeSimpleFile} />
							</div>
							<div>
								<h5 className="font-semibold">버튼형</h5>
								<br />
								<label htmlFor="button-file">
									<input
										className="hidden"
										id="button-file"
										type="file"
										onChange={onChangeSimpleFile}
									/>
									<Button
										className={classes.button}
										component="span"
										variant="contained"
										color="default"
										startIcon={<Icon fontSize="small">arrow_upward</Icon>}
									>
										Click to Upload
									</Button>
								</label>
							</div>
						</div>
					</div>
					<div className="p-24">
						<h4>파일 다운로드</h4>
						<br />
						{/* attachNo (첨부파일ID)로 파일다운로드 */}
						<AttachLabel className="mt-10" attachNo="2021010001" readOnly />
						<AttachLabel className="mt-10" attachNo="2021010002" readOnly />
						<AttachLabel className="mt-10" attachNo="2021010003" readOnly />

						{/* attchInfo (첨부파일 객체)로 파일다운로드 */}
						<AttachLabel className="mt-10" attachInfo={tmpAttachInfo} readOnly />

						<Typography>방금 업로드한 파일</Typography>
						<AttachLabel className="mt-10" attachInfo={uploadedAttachInfo} onRemove={onRemoveFile} />
					</div>
				</div>
			}
		/>
	);
}

export default GuideFileupload;
