// import React from 'react';
import FusePageSimple from '@fuse/core/FusePageSimple';
import { KtngDeptDialog, KtngDeptSelector, KtngPersonDialog, KtngPersonSelector } from '@ktng/core/KtngHRDialog';
import { Button, Typography } from '@material-ui/core';
import Contacts from '@material-ui/icons/Contacts';
import { openDialog2 } from 'app/store/fuse/dialogSlice2';
import React from 'react';
import { useDispatch } from 'react-redux';

function GuideHrPopup() {
	const dispatch = useDispatch();
	// const page = useSelector(({ auth }) => auth.page);

	// 단일선택
	// const [selectedDept, setSelectedDept] = useState({});

	function handleDeptSelect(item, target) {
		// console.log(item, target);
	}

	function handlePersonSelect(item, target) {
		// console.log(item, target);
	}

	return (
		<FusePageSimple
			classes={{
				header: 'min-h-72 h-72'
			}}
			header={
				<div className="p-24 flex items-center">
					<Contacts className="text-32" />
					<Typography className="h2 mx-12 hidden sm:flex">HR 팝업</Typography>
				</div>
			}
			content={
				<div className="p-24">
					<Typography className="text-20" component="h1">
						HR 팝업
					</Typography>
					<br />
					<Button
						variant="contained"
						color="secondary"
						onClick={() =>
							dispatch(
								openDialog2({
									fullWidth: true,
									maxWidth: 'sm',
									children: (
										<KtngDeptDialog
											onSelect={selected => handleDeptSelect(selected)}
											deptCd="010132"
										/>
									)
								})
							)
						}
					>
						부서팝업
					</Button>
					<Button
						className="ml-10"
						variant="contained"
						color="primary"
						onClick={() =>
							dispatch(
								openDialog2({
									fullWidth: true,
									maxWidth: 'md',
									children: <KtngPersonDialog onSelect={handlePersonSelect} empNo="human12" />
								})
							)
						}
					>
						사용자팝업
					</Button>
					<br />
					<br />
					<Typography className="text-20" component="h1">
						HR 선택기
					</Typography>
					<br />
					<KtngDeptSelector
						className="w-288"
						label="부서선택"
						valueFunc={item => `부서명은: ${item.deptNm}`}
						onSelect={selected => handleDeptSelect(selected)}
						deptCd="010132"
					/>
					<br />
					<KtngPersonSelector
						className="w-288"
						valueFunc={item => `선택한 사용자: [${item.empNo}]${item.empNm}`}
						onSelect={selected => handlePersonSelect(selected)}
						empNo="22220610"
					/>
				</div>
			}
		/>
	);
}

export default GuideHrPopup;
