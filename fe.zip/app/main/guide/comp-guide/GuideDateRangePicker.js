import React, { useState } from 'react';
import { Divider, Icon, Typography } from '@material-ui/core';
import { startOfToday, add, format } from 'date-fns';
import 'react-date-range/dist/styles.css';
import 'react-date-range/dist/theme/default.css';
import FusePageSimple from '@fuse/core/FusePageSimple';
import '@ktng/core/DateRangePicker/styles.css';
import { DateRangeDropdown, DateRangeSelecter } from '@ktng/core/DateRangePicker';
import { DatePicker, DateTimePicker, KeyboardDatePicker, KeyboardDateTimePicker } from '@material-ui/pickers';

function GuideDateRangePicker() {
	const [fromto, setFromto] = useState({
		startDate: startOfToday(),
		endDate: add(startOfToday(), { days: 7 })
	});
	const [selectedDate, setSelectedDate] = useState(new Date('2020-06-01'));
	const [selectedDateTime, setSelectedDateTime] = useState(new Date('2020-06-01T21:11:54'));

	const onChageDateRange = ({ startDate, endDate }) => {
		setFromto({
			startDate: new Date(startDate),
			endDate: new Date(endDate)
		});
	};

	return (
		<FusePageSimple
			classes={{
				content: 'flex min-h-full',
				header: 'min-h-72 h-72'
			}}
			header={
				<div className="                                                                                                 p-24 flex items-center">
					<Icon className="text-32">date_range</Icon>
					<Typography className="h2 mx-12 hidden sm:flex">기간선택기</Typography>
				</div>
			}
			content={
				<div className="p-24">
					<Typography variant="subtitle1">1. 날짜 선택</Typography>
					<Divider />
					<div className="m-16 p-24 grid grid-cols-2 gap-72">
						<div>
							<h5 className="font-semibold">DatePicker</h5>
							<br />
							<DatePicker
								format="yyyy.MM.dd"
								value={selectedDate}
								onChange={date => setSelectedDate(date)}
							/>
						</div>
						<div>
							<h5 className="font-semibold">KeyboardDatePicker</h5>
							<br />
							<KeyboardDatePicker
								format="yyyy.MM.dd"
								value={selectedDate}
								onChange={date => setSelectedDate(date)}
							/>
						</div>
					</div>

					<Typography variant="subtitle1">2. 날짜/시간 선택</Typography>
					<Divider />
					<div className="m-16 p-24 grid grid-cols-2 gap-72">
						<div>
							<h5 className="font-semibold">DateTimePicker</h5>
							<br />
							<DateTimePicker
								format="yyyy.MM.dd HH:mm:ss"
								value={selectedDateTime}
								onChange={dateTime => setSelectedDateTime(dateTime)}
							/>
						</div>
						<div>
							<h5 className="font-semibold">KeyboardDateTimePicker</h5>
							<br />
							<KeyboardDateTimePicker
								format="yyyy.MM.dd HH:mm:ss"
								value={selectedDateTime}
								onChange={dateTime => setSelectedDateTime(dateTime)}
							/>
						</div>
					</div>

					<Typography variant="subtitle1">3. 년도 선택</Typography>
					<Divider />
					<div className="m-16 p-24 grid grid-cols-2 gap-72">
						<div>
							<h5 className="font-semibold">DatePicker</h5>
							<br />
							<DatePicker
								views={['year']} // year만 선택가능 (월/일 및 시간은 0으로 셋팅됨)
								format="yyyy"
								value={selectedDate}
								onChange={date => setSelectedDate(date)}
							/>
						</div>
						<div>
							<h5 className="font-semibold">KeyboardDatePicker</h5>
							<br />
							<KeyboardDatePicker
								views={['year']} // year만 선택가능 (월/일 및 시간은 0으로 셋팅됨)
								format="yyyy"
								value={selectedDate}
								onChange={date => setSelectedDate(date)}
							/>
						</div>
					</div>

					<Typography variant="subtitle1">4. 년월 선택</Typography>
					<Divider />
					<div className="m-16 p-24 grid grid-cols-2 gap-72">
						<div>
							<h5 className="font-semibold">DatePicker</h5>
							<br />
							<DatePicker
								views={['year', 'month']} // year, month만 선택가능 (일자 및 시간은 0으로 셋팅됨)
								format="yyyy.MM"
								value={selectedDate}
								onChange={date => setSelectedDate(date)}
							/>
						</div>
						<div>
							<h5 className="font-semibold">KeyboardDatePicker</h5>
							<br />
							<KeyboardDatePicker
								views={['year', 'month']} // year, month만 선택가능 (일자 및 시간은 0으로 셋팅됨)
								format="yyyy.MM"
								value={selectedDate}
								onChange={date => setSelectedDate(date)}
							/>
						</div>
					</div>

					<Typography variant="subtitle1">5. 기간 선택</Typography>
					<Divider />
					<div className="m-16 p-24 grid grid-cols-2 gap-72">
						<div>
							<h5 className="font-semibold">DateRangeSelecter</h5>
							<br />
							<DateRangeSelecter
								label="날짜/기간선택"
								options={{ placement: 'bottom-start' }}
								fromto={fromto}
								onChange={onChageDateRange}
							/>
						</div>
						<div>
							<h5 className="font-semibold">DateRangeDropdown</h5>
							<br />
							<DateRangeDropdown
								options={{ placement: 'top-start' }}
								fromto={fromto}
								onChange={onChageDateRange}
							/>
						</div>
						<div>
							<h5 className="font-semibold">선택된 기간</h5>
							<br />
							<div>
								{format(fromto.startDate, 'yyyy.MM.dd')} {'~ '}
								{format(fromto.endDate, 'yyyy.MM.dd')}
							</div>
						</div>
					</div>
				</div>
			}
		/>
	);
}

export default GuideDateRangePicker;
