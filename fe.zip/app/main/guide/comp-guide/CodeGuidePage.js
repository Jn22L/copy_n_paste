import { loadCodeList, loadMultiCodeList } from 'app/store/ktng/codeSlice';
import { useDispatch, useSelector } from 'react-redux';
import { Button, Divider, Icon, Typography, FormControl, InputLabel, FormLabel } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import FusePageSimple from '@fuse/core/FusePageSimple';
import KtngUtils from '@ktng/utils';
import React, { useEffect, useState } from 'react';
import { CmmCodeToName, CodeDialog, CmmCodeSelect, CmmCodeCheck, CmmCodeRadio } from '@ktng/core/CmmCode';
import { openDialog } from 'app/store/fuse/dialogSlice';

const useStyles = makeStyles(theme => ({
	formControl: {
		minWidth: 250
	}
}));

const CodeGuidePage = () => {
	const classes = useStyles();
	const dispatch = useDispatch();
	const code = useSelector(({ ktng }) => ktng.code);

	// 단일선택
	const [selectedCode, setSelectedCode] = useState({});
	// 복수선택
	const [selectedCodes, setSelectedCodes] = useState([]);

	useEffect(() => {
		dispatch(loadCodeList({ code1: '100', code2: 'AR_001' }));
	});

	return (
		<FusePageSimple
			classes={{
				header: 'min-h-72 h-72'
			}}
			header={
				<div className="p-24 flex items-center">
					<Icon className="text-32">unarchive</Icon>
					<Typography className="h2 mx-12 hidden sm:flex">코드 샘플 가이드</Typography>
				</div>
			}
			content={
				<div>
					<Typography className="text-20 ml-5 mt-10" component="h3">
						# 현재 ktng.code Store State
					</Typography>
					<div className="ml-10 mb-10">{JSON.stringify(code)}</div>
					<Divider />
					<Typography className="text-20 ml-5 mt-10" component="h3">
						# 코드 로딩 이벤트 컨트롤
					</Typography>
					<div className="ml-10 mb-10">
						<Button
							className="whitespace-no-wrap mt-10 mb-1"
							variant="contained"
							color="primary"
							onClick={() => dispatch(loadCodeList({ code1: '003', code2: '001' }))}
						>
							단일목록 (003 / 001) 로딩
						</Button>
						<br />
						<Button
							className="whitespace-no-wrap mt-10 mb-10"
							variant="contained"
							color="primary"
							onClick={() =>
								dispatch(
									loadMultiCodeList([
										{ code1: '009', code2: '001' },
										{ code1: '009', code2: '002' }
									])
								)
							}
						>
							다중목록 (009 / 001, 009 / 002) 로딩
						</Button>
						<div>
							<Typography className="mt-10">## 코드네임로딩1 (전처리 방식, 소스참조)</Typography>
							{KtngUtils.cmmCodeToName('100', 'AR_001', '11')}
						</div>
						<div>
							<Typography className="mt-10">## 코드네임로딩2 (후처리 방식, 소스참조)</Typography>
							<CmmCodeToName code1="100" code2="AR_002" code3="4" />
						</div>
					</div>
					<Divider />
					<Typography className="text-20 ml-5 mt-10" component="h3">
						# 태그활용 컴포넌트
					</Typography>
					<div className="ml-10 mb-10">
						<Typography className="mt-10">
							## 단일 코드 선택 컴포넌트 (selectedCode): {JSON.stringify(selectedCode)}
						</Typography>
					</div>
					<div className="ml-10 mb-10">
						<Button
							className="whitespace-no-wrap mt-10 mb-10"
							variant="contained"
							color="primary"
							onClick={() =>
								dispatch(
									openDialog({
										fullWidth: true,
										maxWidth: 'sm',
										children: (
											<CodeDialog
												code1="003"
												code2="003"
												onSelect={selected => setSelectedCode(selected)}
											/>
										)
									})
								)
							}
						>
							코드선택 다이얼로그
						</Button>
					</div>
					<div className="ml-10 mb-10">
						<FormControl variant="outlined" className={classes.formControl}>
							<InputLabel htmlFor="cmm-label-2">콤보박스 방식</InputLabel>
							<CmmCodeSelect
								id="cmm-label-2"
								label="콤보박스 방식"
								name=""
								code1="003"
								code2="002"
								selected={selectedCode}
								onSelect={selected => setSelectedCode(selected)}
								total={{ code: 'total', name: '전체' }}
							/>
						</FormControl>
					</div>
					<div className="ml-10 mb-10">
						<FormControl component="fieldset">
							<FormLabel component="legend">라디오버튼 방식</FormLabel>
							<CmmCodeRadio
								name=""
								code1="003"
								code2="003"
								selected={selectedCode}
								onSelect={selected => setSelectedCode(selected)}
							/>
						</FormControl>
					</div>
					<div className="mt-10 ml-10 mb-10">
						<Typography className="mt-10">
							## 다중 코드 선택 컴포넌트 (selectedCodes): {JSON.stringify(selectedCodes)}
						</Typography>
					</div>
					<div className="ml-10 mb-10">
						<FormControl component="fieldset">
							<FormLabel component="legend">체크박스 방식</FormLabel>
							<CmmCodeCheck
								name=""
								code1="003"
								code2="003"
								selected={selectedCodes}
								onSelect={selected => setSelectedCodes(selected)}
							/>
						</FormControl>
					</div>
				</div>
			}
		/>
	);
};

export default CodeGuidePage;
