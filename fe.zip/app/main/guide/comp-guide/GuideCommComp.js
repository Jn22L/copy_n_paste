import React from 'react';
import { Divider, Typography } from '@material-ui/core';
import {
	GuideCommCompButton,
	GuideCommCompCheckbox,
	GuideCommCompInput,
	GuideCommCompRadio,
	GuideCommCompTypography,
	GuideCommCompSelect
} from './component';

function GuideCommComp() {
	return (
		<div className="p-24">
			{/* Typography */}
			<div className="flex flex-col ">
				<Typography variant="subtitle1">1. 텍스트 출력 : Typography</Typography>
				<Divider />

				<div className="flex flex-col m-16 p-24 border-1">
					<GuideCommCompTypography />
				</div>
			</div>

			{/* Input */}
			<div className="flex flex-col ">
				<Typography variant="subtitle1">2. 텍스트 입력 : Input</Typography>
				<Divider />

				<div className="flex flex-col m-16 p-24 border-1">
					<GuideCommCompInput />
				</div>
			</div>

			{/* Select */}
			<div className="flex flex-col">
				<Typography variant="subtitle1">3. 선택박스 입력 : Select</Typography>
				<Divider />

				<div className="flex flex-col m-16 p-24 border-1">
					<GuideCommCompSelect />
				</div>
			</div>

			{/* Radio */}
			<div className="flex flex-col">
				<Typography variant="subtitle1">4. 라디오 입력 : Radio</Typography>
				<Divider />

				<div className="flex flex-col m-16 p-24 border-1">
					<GuideCommCompRadio />
				</div>
			</div>

			{/* Checkbox */}
			<div className="flex flex-col">
				<Typography variant="subtitle1">5. 체크박스 : Checkbox</Typography>
				<Divider />

				<div className="flex flex-col m-16 p-24 border-1">
					<GuideCommCompCheckbox />
				</div>
			</div>

			{/* Button */}
			<div className="flex flex-col">
				<Typography variant="subtitle1">6. 버튼 : Button</Typography>
				<Divider />

				<div className="flex flex-col m-16 p-24 border-1">
					<GuideCommCompButton />
				</div>
			</div>
		</div>
	);
}

export default GuideCommComp;
