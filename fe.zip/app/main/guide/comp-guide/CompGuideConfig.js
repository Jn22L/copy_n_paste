import React from 'react';

const CompGuideConfig = {
	settings: {
		layout: {
			config: {}
		}
	},
	routes: [
		{
			path: '/guide/comp/code',
			component: React.lazy(() => import('./CodeGuidePage')),
			auth: { check: false }
		},
		{
			path: '/guide/comp/hr',
			component: React.lazy(() => import('./GuideHrPopup'))
		},
		{
			path: '/guide/comp/code2',
			component: React.lazy(() => import('./CodeGuidePage2')),
			auth: { check: false }
		},
		{
			path: '/guide/comp/fileupload',
			component: React.lazy(() => import('./GuideFileupload')),
			auth: { check: false }
		},
		{
			path: '/guide/comp/commcomp',
			component: React.lazy(() => import('./GuideCommComp')),
			auth: { check: false }
		},
		{
			path: '/guide/comp/daterangepicker',
			component: React.lazy(() => import('./GuideDateRangePicker')),
			auth: { check: false }
		},
		{
			path: '/guide/comp/calendar',
			component: React.lazy(() => import('./GuideCalendar')),
			auth: { check: false }
		},
		{
			path: '/guide/comp/addresssearch',
			component: React.lazy(() => import('./GuideAddressSearch')),
			auth: { check: false }
		},
		{
			path: '/guide/comp/oidc',
			component: React.lazy(() => import('./GuideOIDCPage')),
			auth: { check: false }
		}
	]
};

export default CompGuideConfig;
