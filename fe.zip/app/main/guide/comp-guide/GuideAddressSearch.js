import FusePageSimple from '@fuse/core/FusePageSimple';
import { KakaoPostcodeDialog } from '@ktng/core/KakaoPostcodeDialog';
import { Button, Icon, TextField, Typography } from '@material-ui/core';
import { openDialog } from 'app/store/fuse/dialogSlice';
import React from 'react';
import { useDispatch, useSelector } from 'react-redux';

const GuideAddressSearch = () => {
	const dispatch = useDispatch();

	const { zonecode, address, latitude, longitude } = useSelector(({ ktng }) => ktng.kakaoPostcode);

	const openKakaoPostcodeDialog = () => {
		dispatch(
			openDialog({
				fullWidth: true,
				maxWidth: 'sm',
				children: <KakaoPostcodeDialog />
			})
		);
	};

	return (
		<FusePageSimple
			classes={{
				header: 'min-h-72 h-72'
			}}
			header={
				<div className="p-24 flex items-center">
					<Icon className="text-32">search</Icon>
					<Typography className="h2 mx-12 hidden sm:flex">주소 검색</Typography>
				</div>
			}
			content={
				<div className="p-24">
					<div>
						{latitude && longitude && (
							<Typography className="block mr-8 mb-16" variant="caption">
								<span className="w-80">{latitude}</span> / <span className="w-80">{longitude}</span>
							</Typography>
						)}
					</div>
					<div>
						<TextField
							className="w-80 mr-8 mb-8"
							variant="outlined"
							label="우편번호"
							type="text"
							value={zonecode}
						/>
						<TextField
							className="w-400 mr-8 mb-8"
							variant="outlined"
							label="주소"
							type="text"
							value={address}
						/>
						<Button
							className="whitespace-no-wrap mt-10 mb-1"
							variant="contained"
							color="secondary"
							onClick={openKakaoPostcodeDialog}
						>
							<Icon>search</Icon>
							<span className="hidden sm:flex pl-8">주소검색</span>
						</Button>
					</div>
				</div>
			}
		/>
	);
};

export default GuideAddressSearch;
