import FusePageSimple from '@fuse/core/FusePageSimple';
import { useCmmCodeLoadEffect } from '@ktng/hooks/index';
import KtngUtils from '@ktng/utils';
import _ from '@lodash';
import { Button, Icon, TextField, Typography } from '@material-ui/core';
import { loadCodeList } from 'app/store/ktng/codeSlice';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';

const CodeGuidePage2 = () => {
	const dispatch = useDispatch();
	const code = useSelector(({ ktng }) => ktng.code); // 코드 조회 결과
	const [loading, setLoading] = React.useState(true);
	const [firstTypeCode, setFirstTypeCode] = useState('FUEL_TY'); // 단건 조회
	const [secondTypeCode, setSecondTypeCode] = useState('1'); // 코드 → 코드명 변환
	const [reqCodes] = useState([
		// 필요한 공통코드 이곳에 추가
		{ commCodeChk: 'FUEL_TY' },
		{ commCodeChk: 'VH_TYPE' }
	]); // 다건 조회

	useEffect(() => {
		console.log('START GuideCmmCode2');
		return () => console.log('END GuideCmmCode2');
	}, []);

	// 코드 다건 조회 (hook)
	useCmmCodeLoadEffect(() => {
		setLoading(false);
	}, [reqCodes]);

	// 코드 단건 조회
	function onGetCodeBtnClick() {
		dispatch(loadCodeList({ commCodeChk: firstTypeCode }));
	}

	// codeStore로부터 코드목록 검색
	const getCodeResult = code[firstTypeCode];

	// 코드 → 코드명 변환
	const codeName = KtngUtils.cmmCodeToName(firstTypeCode, secondTypeCode);

	return (
		<FusePageSimple
			classes={{
				header: 'min-h-72 h-72'
			}}
			header={
				<div className="p-24 flex items-center">
					<Icon className="text-32">unarchive</Icon>
					<Typography className="h2 mx-12 hidden sm:flex">코드 샘플 가이드2</Typography>
				</div>
			}
			content={
				!loading && (
					<div className="p-24">
						<Typography variant="h6">코드 단건 조회</Typography>
						<div className="p-24">
							<TextField
								className="mr-8"
								variant="outlined"
								label="First Type Code"
								type="text"
								value={firstTypeCode}
								onChange={e => setFirstTypeCode(e.target.value)}
							/>
							<span className="text-gray-500">ex) FUEL_TY, VH_TYPE, ...</span>
							{/* 코드 단건 조회 결과 */}
							{!_.isEmpty(getCodeResult) && <div>{JSON.stringify(getCodeResult)}</div>}
							{_.isEmpty(getCodeResult) && ( // 존재하지 않는 코드
								<div className="p-8">
									<Button variant="contained" color="primary" onClick={onGetCodeBtnClick}>
										Load
									</Button>
									<div className="text-red-500">
										Code Store에 존재하지 않는 코드. 'Load' 버튼 눌러 서버에서 가져오기
									</div>
								</div>
							)}
						</div>

						<Typography variant="h6">코드 → 코드명 변환</Typography>
						<div className="p-24">
							<span>코드 : {firstTypeCode}</span>
							<input
								className="w-72 ml-16"
								type="text"
								value={secondTypeCode}
								onChange={e => setSecondTypeCode(e.target.value)}
							/>
							<div>코드명 : {codeName}</div>
						</div>

						<Typography variant="h6">Code Store 상태 (현재까지 조회한 코드)</Typography>
						<div className="p-24">
							{_.keys(code).map(key => (
								<div key={key}>
									<div className="font-bold">{key}</div>
									<div>{JSON.stringify(code[key])}</div>
								</div>
							))}
						</div>
					</div>
				)
			}
		/>
	);
};

export default CodeGuidePage2;
