import React, { useState } from 'react';
import { FormControlLabel, Checkbox } from '@material-ui/core';

const GuideCommCompCheckbox = () => {
	// ※ 입력 컴포넌트의 초기값이 null인 경우, 빈 문자열로 넣어줘야 함.
	const [popupReadOnly, setPopupReadOnly] = useState(false);

	return (
		<div className="p-16">
			<FormControlLabel
				label="팝업 내 조회조건 비활성화"
				control={
					popupReadOnly ? (
						<Checkbox checked onClick={() => setPopupReadOnly(false)} />
					) : (
						<Checkbox onClick={() => setPopupReadOnly(true)} />
					)
				}
			/>
		</div>
	);
};

export default GuideCommCompCheckbox;
