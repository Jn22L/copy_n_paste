import React from 'react';
import { Button } from '@material-ui/core';
import { Search } from '@material-ui/icons';

const GuideCommCompButton = () => {
	function onBtnSearchClick() {
		/* TO-DO */
		// eslint-disable-next-line
		alert('search button clicked!');
	}

	return (
		<div className="p-16 flex justify-around items-center">
			{/* 일반 버튼 */}
			<Button color="primary" onClick={onBtnSearchClick}>
				조회
			</Button>

			{/* Disabled 버튼 */}
			<Button color="primary" onClick={onBtnSearchClick} disabled>
				조회
			</Button>

			{/* 아이콘 버튼 */}
			<Button color="primary" onClick={onBtnSearchClick}>
				<Search />
				<span>조회</span>
			</Button>
		</div>
	);
};

export default GuideCommCompButton;
