import React, { useState } from 'react';
import { RadioGroup, Radio, FormControlLabel } from '@material-ui/core';

const vhDeptCode = [
	{ code: '001', name: 'AAA' },
	{ code: '002', name: 'BBB' },
	{ code: '003', name: 'CCC' },
	{ code: '004', name: 'DDD' }
];

const GuideCommCompRadio = () => {
	// ※ 입력 컴포넌트의 초기값이 null인 경우, 빈 문자열로 넣어줘야 함.
	const [vhclDeptCd, setVhclDeptCd] = useState('ALL');

	return (
		<RadioGroup row value={vhclDeptCd} onChange={e => setVhclDeptCd(e.target.value)}>
			<FormControlLabel
				value="ALL"
				control={<Radio checked={vhclDeptCd === 'ALL'} color="primary" />}
				label="전체"
				labelPlacement="end"
			/>
			{vhDeptCode.map((code, key) => (
				<FormControlLabel
					key={key}
					value={code.code}
					control={<Radio checked={vhclDeptCd === code.code} color="primary" />}
					label={code.name}
					labelPlacement="end"
				/>
			))}
		</RadioGroup>
	);
};

export default GuideCommCompRadio;
