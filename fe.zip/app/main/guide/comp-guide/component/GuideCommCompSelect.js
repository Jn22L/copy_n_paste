import React, { useState } from 'react';
import { Select, MenuItem, InputLabel, FormControl } from '@material-ui/core';

const vhDeptCodes = [
	{ code: '001', name: 'AAA' },
	{ code: '002', name: 'BBB' },
	{ code: '003', name: 'CCC' },
	{ code: '004', name: 'DDD' }
];

const GuideCommCompSelect = () => {
	// ※ 입력 컴포넌트의 초기값이 null인 경우, 빈 문자열로 넣어줘야 함.
	const [vhclDeptCd, setVhclDeptCd] = useState('ALL');

	function onBtnSearchClick() {
		/* TO-DO */
	}

	return (
		<>
			<div className="p-16">
				{/* 1. Standard */}
				<Select
					label="부서코드"
					fullWidth
					value={vhclDeptCd}
					onChange={e => setVhclDeptCd(e.target.value)}
					onKeyUp={e => {
						if (e.key === 'Enter') {
							onBtnSearchClick();
						}
					}}
				>
					{/* 기본으로 포함할 option 추가 */}
					<MenuItem value="ALL">전체</MenuItem>

					{/* 서버 등에서 가져온 데이터로 option 추가 */}
					{vhDeptCodes &&
						vhDeptCodes.map((vhDept, key) => (
							<MenuItem key={key} value={vhDept.code}>
								{vhDept.name}
							</MenuItem>
						))}
				</Select>
			</div>

			<div className="p-16">
				{/* 2. Outlined */}
				<FormControl variant="outlined" size="small" fullWidth>
					<InputLabel>부서코드</InputLabel>
					<Select
						label="부서코드"
						value={vhclDeptCd}
						onChange={e => setVhclDeptCd(e.target.value)}
						onKeyUp={e => {
							if (e.key === 'Enter') {
								onBtnSearchClick();
							}
						}}
					>
						{/* 기본으로 포함할 option 추가 */}
						<MenuItem value="ALL">전체</MenuItem>

						{/* 서버 등에서 가져온 데이터로 option 추가 */}
						{vhDeptCodes &&
							vhDeptCodes.map((vhDept, key) => (
								<MenuItem key={key} value={vhDept.code}>
									{vhDept.name}
								</MenuItem>
							))}
					</Select>
				</FormControl>
			</div>
		</>
	);
};

export default GuideCommCompSelect;
