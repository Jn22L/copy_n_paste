import React, { useState } from 'react';
import { Input, TextField } from '@material-ui/core';

const GuideCommCompInput = () => {
	// ※ 입력 컴포넌트의 초기값이 null인 경우, 빈 문자열로 넣어줘야 함.
	const [vhclDeptNm, setVhclDeptNm] = useState('');

	function onBtnSearchClick() {
		/* TO-DO */
	}

	return (
		<>
			<div className="p-16">
				{/* 1. Standard */}
				{/* HTML의 input 태그와 사용법이 비슷함 */}
				<Input
					placeholder="부서명"
					fullWidth
					type="text"
					value={vhclDeptNm}
					inputProps={{ minLength: 2, maxLength: 20 }} // 컴포넌트 내부의 실제 input 태그에 적용할 속성 정의
					onChange={e => setVhclDeptNm(e.target.value)}
					onKeyUp={e => {
						if (e.key === 'Enter') {
							onBtnSearchClick();
						}
					}}
				/>
			</div>

			<div className="p-16">
				{/* 2. Outlined */}
				{/* HTML의 input 태그와 사용법이 비슷함 */}
				<TextField
					label="부서명"
					fullWidth
					variant="outlined"
					size="small"
					type="text"
					value={vhclDeptNm}
					inputProps={{ minLength: 2, maxLength: 20 }} // 컴포넌트 내부의 실제 input 태그에 적용할 속성 정의
					onChange={e => setVhclDeptNm(e.target.value)}
					onKeyUp={e => {
						if (e.key === 'Enter') {
							onBtnSearchClick();
						}
					}}
				/>
			</div>
		</>
	);
};

export default GuideCommCompInput;
