import React from 'react';
import { Typography } from '@material-ui/core';

const GuideCommCompTypography = () => {
	return (
		<>
			<Typography variant="h5" gutterBottom>
				h5. Heading
			</Typography>
			<Typography variant="h6" gutterBottom>
				h6. Heading
			</Typography>
			<Typography variant="subtitle1" gutterBottom>
				subtitle1. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quos blanditiis tenetur
			</Typography>
			<Typography variant="body1" gutterBottom>
				body1. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quos blanditiis tenetur unde suscipit,
				quam beatae rerum inventore consectetur, neque doloribus, cupiditate numquam dignissimos laborum fugiat
				deleniti? Eum quasi quidem quibusdam.
			</Typography>
			<Typography variant="button" display="block" gutterBottom>
				button text
			</Typography>
			<Typography variant="caption" display="block" gutterBottom>
				caption text
			</Typography>
			<Typography variant="overline" display="block" gutterBottom>
				overline text
			</Typography>
			<Typography className="text-32 mx-12 font-extrabold logo-text" color="inherit">
				배차관리시스템 메인
			</Typography>
			<Typography className="text-red my-4">
				배차부서가 공란인 경우 기존 배차부서가 미사용중이거나 삭제된 부서이기 때문에 다른 배차부서로 선택해
				저장해주시기 바랍니다.
			</Typography>
		</>
	);
};

export default GuideCommCompTypography;
