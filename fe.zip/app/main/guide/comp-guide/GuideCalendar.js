import React, { useState } from 'react';
import KtngCalendar from '@ktng/core/KtngCalendar';
import { addDays } from 'date-fns';

const GuideCalendar = () => {
	const [events] = useState([
		{
			start: new Date(),
			end: addDays(new Date(), 2),
			id: '1',
			title: 'test1',
			textColor: 'yellow',
			url: '#'
			// extendedProps.
		},
		{
			start: addDays(new Date(), 5),
			end: addDays(new Date(), 9),
			id: '2',
			title: 'test2'
		}
	]);
	const [currentDate, setCurrentDate] = useState();

	return (
		<div className="p-16">
			<KtngCalendar
				title="주제..."
				// views={['dayGridMonth']} // 'dayGridMonth'(월) || 'timeGridWeek'(주) || 'timeGridDay'(일)
				events={events}
				currentDate={currentDate}
				// onDateSelect={onDateSelect}
				// onEventClick={onEventClick}
				onChangeCurrentDate={setCurrentDate}
				hideTime // 이벤트박스 내에 표시되는 시간문자열 제거
			/>
		</div>
	);
};

export default GuideCalendar;
