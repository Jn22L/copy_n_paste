import FusePageSimple from '@fuse/core/FusePageSimple';
import { Typography, Button } from '@material-ui/core';
import SettingsPowerIcon from '@material-ui/icons/SettingsPower';
import React from 'react';
import NssoService from 'app/services/nssoService';
import { useForm } from '@fuse/hooks';

export default function GuideOIDCPage() {
	const { form } = useForm(NssoService.getCodeFormObj);

	function submitGetCode() {
		document.getElementById('formEl').submit();
	}

	return (
		<FusePageSimple
			classes={{
				header: 'min-h-72 h-72'
			}}
			header={
				<div className="p-24 flex items-center">
					<SettingsPowerIcon className="text-32" />
					<Typography className="h2 mx-12 hidden sm:flex">Open ID Connect Sample</Typography>
				</div>
			}
			content={
				<div>
					<h2>GetCode</h2>
					<Button margin="normal" variant="outlined" onClick={submitGetCode}>
						GetCode
					</Button>
					<form id="formEl" action={form.authorize_url} method="POST">
						<input type="hidden" name="client_id" value={form.client_id} />
						<input type="hidden" name="redirect_uri" value={form.redirect_uri} />
						<input type="hidden" name="response_type" value={form.response_type} />
						<input type="hidden" name="scope" value={form.scope} />
						<input type="hidden" name="state" value={form.state} />
						<input type="hidden" name="nonce" value={form.nonce} />
					</form>
				</div>
			}
		/>
	);
}
