import { KtngConfirmDialog4 } from '@ktng/core/KtngConfirmDialog';
import KtngUtils from '@ktng/utils';
import _ from '@lodash';
import { Button, Link, List, ListItem, TextField, Typography } from '@material-ui/core';
import { AccessTime, AccountCircleOutlined, Info } from '@material-ui/icons';
import { Skeleton } from '@material-ui/lab';
import { closeDialog, openDialog } from 'app/store/fuse/dialogSlice';
import { showMessage } from 'app/store/fuse/messageSlice';
import { decode } from 'html-entities';
import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { insertCommentDTO, updateCommentDTO, deleteComment } from '../store/cmntyBoardCommentSlice';

export default function CmntyBoardCommentList() {
	const dispatch = useDispatch();

	const {
		pageList: { content },
		isEmptySearchResult,
		user
	} = useSelector(({ communityBoard, auth }) => ({
		pageList: communityBoard.cmntyBoardComment.pageList,
		isEmptySearchResult: communityBoard.cmntyBoardComment.isEmptySearchResult,
		user: auth.user
	}));

	const [editing, setEditing] = useState(null); // 수정중인 댓글
	const [subTarget, setSubTarget] = useState(null); // 추가중인 대댓글 상위 댓글
	const [subContent, setSubContent] = useState(''); // 등록할 대댓글내용 작성

	function isSubComment(comment) {
		return comment && comment.brdCmtDepth > 0;
	}

	function subCommentIndent(comment) {
		if (!comment) return 0;
		let depth = comment.brdCmtDepth;
		if (depth === 0) return 0;
		if (depth > 4) depth = 4;

		return 8 + (depth - 1) * 28; // 8, 36, 64, 92
	}

	function editComment() {
		if (!editing) return;

		dispatch(
			openDialog({
				children: (
					<KtngConfirmDialog4
						title="수정 확인"
						okClick={() => {
							setEditing(null);
							dispatch(closeDialog());
							dispatch(updateCommentDTO({ form: editing }));
						}}
						cancelClick={() => dispatch(closeDialog())}
					>
						댓글을 수정하시겠습니까?
					</KtngConfirmDialog4>
				)
			})
		);
	}

	function onDeleteBtnClick(comment) {
		if (!comment) return;

		const { brdCmtNo } = comment;
		const { brdMstrNo } = comment.brdMstrNo;
		const { brdCtsNo } = comment.brdCtsNo;
		dispatch(
			openDialog({
				children: (
					<KtngConfirmDialog4
						title="삭제 확인"
						okClick={() => {
							dispatch(closeDialog());
							dispatch(deleteComment({ brdMstrNo, brdCtsNo, brdCmtNo }));
						}}
						cancelClick={() => dispatch(closeDialog())}
					>
						댓글을 삭제하시겠습니까?
					</KtngConfirmDialog4>
				)
			})
		);
	}

	function saveComment() {
		if (!subTarget) return;
		if (!subContent || subContent.length === 0) {
			dispatch(showMessage({ message: '댓글 내용을 입력해주세요.' }));
			return;
		}

		dispatch(
			openDialog({
				children: (
					<KtngConfirmDialog4
						title="등록 확인"
						okClick={() => {
							dispatch(closeDialog());
							setSubTarget(null);
							setSubContent('');
							const { brdMstrNo } = subTarget.brdMstrNo;
							const { brdCtsNo } = subTarget.brdCtsNo;
							const { brdCmtNo, brdCmtDepth } = subTarget;
							dispatch(
								insertCommentDTO({
									brdMstrNo,
									brdCtsNo,
									form: {
										brdCmtGrp: brdCmtNo,
										brdCmtDepth: brdCmtDepth + 1,
										brdComment: subContent
									}
								})
							);
						}}
						cancelClick={() => dispatch(closeDialog())}
					>
						댓글을 등록하시겠습니까?
					</KtngConfirmDialog4>
				)
			})
		);
	}

	return (
		<List>
			{content && isEmptySearchResult ? (
				<ListItem className="h-80 flex flex-row justify-center items-center">
					<Info />
					<Typography className="pl-6">조회된 댓글이 없습니다.</Typography>
				</ListItem>
			) : content && content.length === 0 ? (
				_.range(10).map(key => (
					<ListItem key={key} className="px-4 py-8 border-solid border-b-1 items-start" dense>
						<div className="flex flex-1 flex-col">
							<div className="flex flex-row justify-between mb-16">
								<Skeleton className="w-0 flex-1" />
								<Skeleton className="ml-4 w-84 flex-none" />
							</div>
							<div className="px-8">
								<Skeleton />
							</div>
						</div>
					</ListItem>
				))
			) : (
				content.map(comment => (
					<ListItem key={comment.brdCmtNo} className="px-4 py-8 border-solid border-b-1 items-start" dense>
						{isSubComment(comment) && <div className={`ml-${subCommentIndent(comment)} mr-8`}>└</div>}
						<div className="flex flex-1 flex-col">
							{/* 1. 헤더: 댓글 작성자, 등록일 */}
							<div className="flex flex-row justify-between items-center mb-16 opacity-50">
								{/* 작성자 */}
								<Typography className="w-0 flex flex-row flex-1 items-center" variant="caption">
									<AccountCircleOutlined fontSize="small" />
									<span className="pl-2 truncate">
										{comment.regNm}({comment.regId})
									</span>
								</Typography>

								<div className="flex flex-row flex-none justify-end items-center">
									{/* 답댓글/수정/삭제 버튼 */}
									{/* - 답댓글 등록 버튼 */}
									{subTarget && subTarget.brdCmtNo === comment.brdCmtNo ? (
										/* eslint-disable jsx-a11y/anchor-is-valid */
										<Link
											className="ml-4 w-28 underline"
											component="button"
											variant="caption"
											aria-label="답글 작성취소"
											onClick={() => setSubTarget(null)}
										>
											취소
										</Link>
									) : (
										<Link
											className="ml-4 w-28 underline"
											component="button"
											variant="caption"
											aria-label="답글 작성"
											onClick={() => {
												setEditing(null);
												setSubTarget(comment);
											}}
										>
											답글
										</Link>
									)}

									{/* - 사용자가 댓글 작성자인 경우, `수정/삭제` 가능 */}
									{user.id === comment.regId && ( // 사용자가 댓글 작성자인 경우 `수정/삭제` 가능
										<>
											{editing && editing.brdCmtNo === comment.brdCmtNo ? ( // 댓글 편집모드인 경우
												<Link
													className="ml-4 w-28 underline"
													component="button"
													variant="caption"
													aria-label="댓글 수정취소"
													onClick={() => setEditing(null)}
												>
													취소
												</Link>
											) : (
												<Link
													className="ml-4 w-28 underline"
													component="button"
													variant="caption"
													aria-label="댓글 수정"
													onClick={() => {
														setSubTarget(null);
														setEditing(comment);
													}} // 수정폼으로 전환
												>
													수정
												</Link>
											)}
											<Link
												className="ml-4 w-28 underline"
												component="button"
												variant="caption"
												aria-label="댓글 삭제"
												onClick={() => {
													setSubTarget(null);
													setEditing(null);
													onDeleteBtnClick(comment);
												}}
											>
												삭제
											</Link>
										</>
									)}

									{/* 등록일 */}
									<Typography className="w-84 ml-4 flex flex-row items-center" variant="caption">
										<AccessTime fontSize="small" />
										<span className="pl-2">{KtngUtils.convertBoardDate(comment.regDate)}</span>
									</Typography>
								</div>
							</div>

							{/* 2. 상세: 댓글수정 입력란, 댓글내용 */}
							{editing && editing.brdCmtNo === comment.brdCmtNo ? ( // 편집모드인 경우
								// 댓글수정 입력란
								<div className="flex">
									<TextField
										name="editingContent"
										className="w-full"
										label="댓글 수정"
										variant="outlined"
										multiline
										rows="2"
										value={editing.brdComment}
										onChange={e =>
											setEditing({
												...editing,
												brdComment: e.target.value
											})
										}
									/>
									<Button
										className="h-68 ml-4"
										color="secondary"
										variant="contained"
										onClick={editComment}
									>
										수정
									</Button>
								</div>
							) : (
								// 댓글내용
								<div className="px-8">
									<Typography
										component="pre"
										className="whitespace-pre-line break-all"
										variant="body1"
									>
										{decode(comment.brdComment)}
									</Typography>
								</div>
							)}

							{/* 3. 답글작성 입력란 */}
							{subTarget && subTarget.brdCmtNo === comment.brdCmtNo && (
								<div className="mt-8 flex">
									<TextField
										name="commentContent"
										className="w-full"
										label={`@${subTarget.regNm}(${subTarget.regId})에게`}
										variant="outlined"
										multiline
										rows="2"
										value={subContent}
										onChange={e => setSubContent(e.target.value)}
									/>
									<Button
										className="h-68 ml-4"
										color="secondary"
										variant="contained"
										onClick={saveComment}
									>
										등록
									</Button>
								</div>
							)}
						</div>
					</ListItem>
				))
			)}
		</List>
	);
}
