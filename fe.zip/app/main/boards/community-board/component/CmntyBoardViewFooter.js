import { KtngConfirmDialog4 } from '@ktng/core/KtngConfirmDialog';
import { Button, IconButton, TextField, Typography } from '@material-ui/core';
import { Refresh } from '@material-ui/icons';
import { closeDialog, openDialog } from 'app/store/fuse/dialogSlice';
import { showMessage } from 'app/store/fuse/messageSlice';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router';
import { expandCommentList, getCommentList, insertCommentDTO } from '../store/cmntyBoardCommentSlice';
import CmntyBoardCommentList from './CmntyBoardCommentList';

export default function CmntyBoardViewFooter({ board }) {
	const dispatch = useDispatch();
	const routeParams = useParams();

	const { pageList: commentPageList } = useSelector(({ communityBoard }) => communityBoard.cmntyBoardComment);

	const [brdComment, setBrdComment] = useState(''); // 등록할 댓글내용 작성

	// 댓글목록 조회
	useEffect(() => {
		const { brdMstrNo, brdCtsNo } = routeParams;
		dispatch(getCommentList({ brdMstrNo, brdCtsNo }));
	}, [dispatch, routeParams]);

	function onRefresh() {
		const { brdMstrNo, brdCtsNo } = routeParams;
		dispatch(getCommentList({ brdMstrNo, brdCtsNo }));
	}

	function changePageNumber(value) {
		if (value === commentPageList.number || value > commentPageList.totalPages) return;

		const { brdMstrNo, brdCtsNo } = routeParams;
		dispatch(expandCommentList({ brdMstrNo, brdCtsNo, page: value }));
	}

	function saveComment() {
		if (!brdComment || brdComment.length === 0) {
			dispatch(showMessage({ message: '댓글 내용을 입력해주세요.' }));
			return;
		}

		dispatch(
			openDialog({
				children: (
					<KtngConfirmDialog4
						title="등록 확인"
						okClick={() => {
							dispatch(closeDialog());
							setBrdComment('');
							const { brdMstrNo } = routeParams;
							const { brdCtsNo } = board;
							dispatch(
								insertCommentDTO({
									brdMstrNo,
									brdCtsNo,
									form: {
										brdCmtGrp: '',
										brdCmtDepth: 0,
										brdComment
									}
								})
							);
						}}
						cancelClick={() => dispatch(closeDialog())}
					>
						댓글을 등록하시겠습니까?
					</KtngConfirmDialog4>
				)
			})
		);
	}

	return (
		<div className="p-8 sm:p-24 w-full">
			<div className="flex items-center">
				<Typography variant="subtitle1">댓글 보기</Typography>
				<IconButton aria-label="새로고침" onClick={onRefresh}>
					<Refresh fontSize="small" />
				</IconButton>
			</div>

			<div className="w-full flex items-center">
				<TextField
					name="brdComment"
					className="w-full border-solid border-b-1"
					label="댓글 작성"
					variant="outlined"
					multiline
					rows="2"
					value={brdComment}
					onChange={e => setBrdComment(e.target.value)}
				/>
				<Button
					className="h-68 ml-4"
					color="secondary"
					variant="contained"
					disabled={!board}
					onClick={saveComment}
				>
					등록
				</Button>
			</div>

			<CmntyBoardCommentList />
			{commentPageList.number * commentPageList.size < commentPageList.totalElements ? (
				<Button
					className="w-full"
					onClick={() => {
						changePageNumber(commentPageList.number + 1);
					}}
				>
					더보기
				</Button>
			) : (
				<div className="text-center p-4">{commentPageList.content.length > 0 && <b>마지막 댓글입니다.</b>}</div>
			)}
		</div>
	);
}
