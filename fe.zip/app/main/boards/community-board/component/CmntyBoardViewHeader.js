import React from 'react';
import { Icon, Typography } from '@material-ui/core';
import KtngUtils from '@ktng/utils';
import { useSelector } from 'react-redux';
import { Skeleton } from '@material-ui/lab';

export default function CmntyBoardViewHeader({ board }) {
	// cmtCnt(댓글수) : 댓글 작성/삭제 시 즉시 반영을 위해 현재 댓글 목록으로부터 가져옴
	const { totalElements: cmtCnt } = useSelector(({ communityBoard }) => communityBoard.cmntyBoardComment.pageList);

	if (!board) {
		return (
			<div className="flex justify-between px-8 py-8 sm:px-24 sm:py-12">
				<Skeleton className="w-0 flex-1" />
				<Skeleton className="ml-4 w-192 flex-none" />
			</div>
		);
	}
	return (
		<div className="flex justify-between px-8 py-8 sm:px-24 sm:py-12 w-full text-10 opacity-50">
			<div className="w-0 flex flex-row flex-1 items-center">
				<Icon fontSize="small">account_circle</Icon>
				<Typography className="ml-2 truncate" variant="caption">
					{board.regNm}({board.regId})
				</Typography>
			</div>
			<div className="ml-4 flex flex-row flex-none items-center">
				<Icon fontSize="small">remove_red_eye</Icon>
				<Typography className="ml-2 mr-6" variant="caption">
					{KtngUtils.getCommaNum(board.brdHit)}
				</Typography>
				<Icon fontSize="small">sms</Icon>
				<Typography className="ml-2 mr-6" variant="caption">
					{KtngUtils.getCommaNum(cmtCnt)}
				</Typography>
				<Icon className="ml-6" fontSize="small">
					access_time
				</Icon>
				<Typography className="ml-2" variant="caption">
					{KtngUtils.convertBoardDate(board.regDate)}
				</Typography>
			</div>
		</div>
	);
}
