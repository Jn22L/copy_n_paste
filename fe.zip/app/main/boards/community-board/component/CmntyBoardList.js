import KtngUtils from '@ktng/utils';
import _ from '@lodash';
import { Badge, Icon, List, ListItem, Typography, withStyles } from '@material-ui/core';
import { AccessTime, Info, SmsOutlined, VisibilityOutlined } from '@material-ui/icons';
import { Skeleton } from '@material-ui/lab';
import React from 'react';
import { useSelector } from 'react-redux';
import { useHistory, useParams } from 'react-router';

export default function CmntyBoardList() {
	const history = useHistory();
	const routeParams = useParams();

	const { pageList, isEmptySearchResult } = useSelector(({ communityBoard }) => communityBoard.cmntyBoard);
	const { brdMstrNo } = routeParams;

	function isSubBoard(board) {
		return board && board.brdCtsDepth > 0;
	}

	function subBoardIndent(board) {
		if (!board) return 0;
		let depth = board.brdCtsDepth;
		if (depth === 0) return 0;
		if (depth > 4) depth = 4;

		return 8 + (depth - 1) * 28; // 8, 36, 64, 92
	}

	function goDetailPage(__, brdCtsNo) {
		history.push(`/board/community/${brdMstrNo}/view/${brdCtsNo}`);
	}

	// 조회수 999 이상일때 1k표시
	function countNum(num) {
		if (!num) return '0';
		if (num > 999) {
			let cnt = Math.floor(num / 100);
			cnt = `${cnt / 10}K`;
			return cnt;
		}
		return String(num);
	}

	// 뱃지 스타일 적용
	const StyledBadge = withStyles(theme => ({
		badge: {
			fontSize: 7,
			right: -5,
			top: 10,
			border: `2px solid ${theme.palette.background.paper}`,
			padding: '0 4px'
		}
	}))(Badge);

	return (
		<List>
			{pageList.content && isEmptySearchResult ? (
				<ListItem className="h-80 flex flex-row justify-center items-center">
					<Info />
					<Typography className="pl-6">조회된 게시글이 없습니다.</Typography>
				</ListItem>
			) : pageList.content && pageList.content.length === 0 ? (
				_.range(10).map(key => (
					<ListItem
						key={key}
						className="h-80 cursor-pointer border-solid border-b-1 px-8 sm:px-16 py-8 items-start"
					>
						<div className="flex flex-1 flex-col">
							<div className="flex justify-between mb-4">
								<Skeleton className="w-96" />
								<Skeleton className="w-192" />
							</div>
							<div className="px-8">
								<Skeleton />
							</div>
						</div>
					</ListItem>
				))
			) : (
				pageList.content.map(board => (
					<ListItem
						key={board.brdCtsNo}
						className="h-80 cursor-pointer border-solid border-b-1 px-8 sm:px-16 py-8 items-start"
						onClick={e => goDetailPage(e, board.brdCtsNo)}
						dense
						button
					>
						{isSubBoard(board) && <div className={`ml-${subBoardIndent(board)} mr-8`}>└</div>}
						<div className="flex flex-1 flex-col overflow-hidden">
							<div className="flex justify-between items-center mb-4 opacity-50">
								<Typography className="truncate flex flex-row items-center" variant="caption">
									<Icon fontSize="small">account_circle</Icon>
									<span className="pl-2 w-96 truncate">
										{board.regNm}({board.regId})
									</span>
								</Typography>
								<div className="w-192 flex flex-row justify-end items-center">
									<StyledBadge
										className="mr-24"
										max={999}
										badgeContent={countNum(board.brdHit)}
										color="primary"
									>
										<VisibilityOutlined />
									</StyledBadge>
									<StyledBadge
										className="mr-20"
										badgeContent={KtngUtils.getCommaNum(board.cmtCnt)}
										color="primary"
									>
										<SmsOutlined />
									</StyledBadge>
									<Typography className="w-84 ml-2 flex flex-row items-center" variant="caption">
										<AccessTime fontSize="small" />
										<span className="pl-2">{KtngUtils.convertBoardDate(board.regDate)}</span>
									</Typography>
								</div>
							</div>

							<div className="px-8">
								<Typography className="truncate" variant="body1">
									{board.brdTitle}
								</Typography>
							</div>
						</div>
					</ListItem>
				))
			)}
		</List>
	);
}
