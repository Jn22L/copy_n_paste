import FusePageCarded from '@fuse/core/FusePageCarded';
import { KtngSpeedDial } from '@ktng/core/KtngSpeedDial';
import useHideOnScrollDown from '@ktng/hooks/useHideOnScrollDown';
import { CircularProgress, Icon, IconButton, Input, MenuItem, Paper, Select, Typography } from '@material-ui/core';
import { makeStyles, ThemeProvider, useTheme } from '@material-ui/core/styles';
import { PostAdd, Search } from '@material-ui/icons';
import { SpeedDialAction } from '@material-ui/lab';
import withReducer from 'app/store/withReducer';
import React, { useEffect, useState } from 'react';
import InfiniteScroll from 'react-infinite-scroll-component';
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router';
import CmntyBoardList from './component/CmntyBoardList';
import reducer from './store';
import { changeBrdMstrNo, changeSearchParams, expandBoardList, getBoardList } from './store/cmntyBoardSlice';

const LoadingCircularProgress = ({ className }) => (
	<div className={className}>
		<CircularProgress />
	</div>
);

const useStyles = makeStyles(() => ({
	loading: {
		textAlign: 'center',
		width: '100%',
		height: 60
	}
}));

function CmntyBoardListPage({ history }) {
	const classes = useStyles();
	const dispatch = useDispatch();
	const routeParams = useParams();
	const theme = useTheme();
	const favHidden = useHideOnScrollDown({
		scrollableTarget: document.querySelector('div[id=scroll-wrapper]')
	});

	const { pageList, params, brdMstrNo, navi } = useSelector(({ communityBoard, fuse }) => ({
		pageList: communityBoard.cmntyBoard.pageList,
		params: communityBoard.cmntyBoard.params,
		brdMstrNo: communityBoard.cmntyBoard.params.brdMstrNo,
		navi: [] // fuse.navigation.entities.applications.children[4].children
	}));

	const [searchType, setSearchType] = useState(params.searchType || 'ALL');
	const [searchText, setSearchText] = useState(params.searchText || '');

	// TODO : tb_board_master 의 정보로 내용 재구성 필요
	const { title, icon } = navi.find(item => item.url && item.url.indexOf(brdMstrNo) > -1) || {
		title: '커뮤니티형 게시판(모바일)',
		icon: 'toc'
	};

	// URL 파라미터 적용
	useEffect(() => {
		const { brdMstrNo: _brdMstrNo, pageNum: page = 1, pageSize: size = 20 } = routeParams;
		if (brdMstrNo !== _brdMstrNo) {
			// brdMstrNo 변경되면 목록 및 검색어 초기화, 스크롤 맨위로
			dispatch(changeBrdMstrNo(_brdMstrNo));
			setSearchType('ALL');
			setSearchText('');
			document.querySelector('div[id=scroll-wrapper]').scrollTop = 0;
		}
		dispatch(changeSearchParams({ page, size }));
	}, [dispatch, brdMstrNo, routeParams]);

	// 조회
	useEffect(() => {
		if (!brdMstrNo) return () => {};

		const promise = dispatch(getBoardList(brdMstrNo));
		return () => promise.abort(); // 중복된 조회요청 취소
	}, [dispatch, brdMstrNo]);

	function goNewPage() {
		history.push(`/board/community/${brdMstrNo}/new`);
	}

	function onRefresh() {
		dispatch(getBoardList(brdMstrNo));
	}

	function changePageNumber(value) {
		if (value === pageList.number || value > pageList.totalPages) return;
		dispatch(expandBoardList({ brdMstrNo, page: value }));
	}

	function keyPress(e) {
		if (e.keyCode === 13) {
			onBtnSearchClick();
		}
	}

	function onBtnSearchClick(_) {
		dispatch(changeSearchParams({ searchType, searchText, page: 1, size: 10 }));
		dispatch(getBoardList(brdMstrNo));
	}

	return (
		<FusePageCarded
			classes={{
				content: 'flex'
			}}
			header={
				<div className="flex flex-1 items-center justify-between p-16 sm:p-24">
					<div className="flex items-center">
						<Icon style={{ fontSize: 32 }}>{icon}</Icon>
						<Typography className="hidden sm:flex mx-0 sm:mx-12" variant="h6">
							{title}
						</Typography>
					</div>
					<div className="flex flex-1 items-center justify-center px-12">
						<ThemeProvider theme={theme}>
							<Paper className="flex items-center w-full max-w-512 px-8 py-4 rounded-8" elevation={1}>
								<Select
									labelId="search-type"
									id="search-type"
									className="min-w-80"
									disableUnderline
									value={searchType}
									onChange={({ target: { value } }) => setSearchType(value)}
								>
									<MenuItem value="ALL">전체</MenuItem>
									<MenuItem value="TITLE">제목</MenuItem>
									<MenuItem value="CONTENT">내용</MenuItem>
									<MenuItem value="WRITTER">아이디</MenuItem>
								</Select>
								<Input
									placeholder="검색..."
									className="flex flex-1 px-8"
									disableUnderline
									fullWidth
									value={searchText}
									onKeyDown={keyPress}
									onChange={({ target: { value } }) => setSearchText(value)}
									inputProps={{ 'aria-label': 'Search' }}
								/>
								<IconButton aria-label="search" color="primary" size="small" onClick={onBtnSearchClick}>
									<Search />
								</IconButton>
							</Paper>
						</ThemeProvider>
					</div>
				</div>
			}
			content={
				<>
					<div id="scroll-wrapper" className="w-full flex flex-col overflow-y-auto">
						<InfiniteScroll
							dataLength={pageList.content.length}
							next={() => changePageNumber(pageList.number + 1)}
							hasMore={pageList.number * pageList.size < pageList.totalElements}
							loader={<LoadingCircularProgress className={classes.loading} />}
							endMessage={
								<div className={classes.loading}>
									{pageList.content.length > 0 && <b>마지막 게시물입니다.</b>}
								</div>
							}
							refreshFunction={onRefresh}
							pullDownToRefresh
							pullDownToRefreshThreshold={50}
							pullDownToRefreshContent={<LoadingCircularProgress className={classes.loading} />}
							releaseToRefreshContent={<LoadingCircularProgress className={classes.loading} />}
							scrollableTarget="scroll-wrapper"
						>
							<CmntyBoardList />
						</InfiniteScroll>
						<KtngSpeedDial ariaLabel="플로팅 버튼" hidden={favHidden}>
							<SpeedDialAction icon={<PostAdd />} tooltipTitle="등록" tooltipOpen onClick={goNewPage} />
						</KtngSpeedDial>
					</div>
				</>
			}
			innerScroll
		/>
	);
}

export default withReducer('communityBoard', reducer)(CmntyBoardListPage);
