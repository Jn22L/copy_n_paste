import React from 'react';
import { Redirect } from 'react-router';

const CmntyBoardConfig = {
	settings: {
		layout: {}
	},
	routes: [
		{
			path: '/board/community/:brdMstrNo/list/:pageNum/:pageSize?',
			component: React.lazy(() => import('./CmntyBoardListPage'))
		},
		{
			path: '/board/community/:brdMstrNo/new/:pBrdCtsNo?',
			component: React.lazy(() => import('./CmntyBoardEditPage'))
		},
		{
			path: '/board/community/:brdMstrNo/view/:brdCtsNo',
			component: React.lazy(() => import('./CmntyBoardViewPage'))
		},
		{
			path: '/board/community/:brdMstrNo/edit/:brdCtsNo',
			component: React.lazy(() => import('./CmntyBoardEditPage'))
		},
		{
			path: '/board/community/:brdMstrNo/list',
			component: ({ match }) => <Redirect to={`/board/community/${match.params.brdMstrNo}/list/1`} />,
			isProxy: true
		},
		{
			path: '/board/community/infinite-scroll-page',
			component: React.lazy(() => import('./InfiniteScrollListPage'))
		}
	]
};

export default CmntyBoardConfig;
