import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { showMessage } from 'app/store/fuse/messageSlice';
import KtngUtils from '@ktng/utils';

// ---------------------------------------------------------
// boardServie 를 base로...
const callGetBoardListAPI = async (brdMstrNo, params, dispatch) => {
	// params 값 해처모여
	const { page, size, searchType, searchText } = params;
	const _page = page - 1; // 서버에서는 page값이 0이 처음이고, 화면에서 1이 처음임.
	const _size = size >= 0 ? size : 10;
	const _searchType = !searchText ? undefined : searchType;
	const _searchText = !searchText ? undefined : searchText;
	const _params = KtngUtils.removeEmptyAttr({
		page: _page,
		size: _size,
		searchType: _searchType,
		searchText: _searchText
	});
	// 요청
	const response = await axios.get(`/api/board/content/${brdMstrNo}/list`, {
		params: _params
	});
	// 결과값 가공
	const data = await response.data.data;

	const { content, size: __size, number, totalElements, totalPages } = data;

	if (content.length === 0) {
		dispatch(showMessage({ message: '조회된 게시글이 없습니다.' }));
	} else {
		dispatch(showMessage({ message: `총 ${content.length}건의 게시글이 조회되었습니다.` }));
	}

	const payload = {
		params: _params,
		pageList: { content, size: __size, number: number + 1, totalElements, totalPages },
		isEmptySearchResult: content.length === 0
	};

	return payload;
};

export const getBoardList = createAsyncThunk(
	'communityBoard/cmntyBoard/getBoardList',
	async (brdMstrNo, { dispatch, getState, rejectWithValue }) => {
		try {
			const { params } = getState().communityBoard.cmntyBoard;
			return await callGetBoardListAPI(brdMstrNo, params, dispatch);
		} catch (err) {
			return KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

export const expandBoardList = createAsyncThunk(
	'communityBoard/cmntyBoard/expandBoardList',
	async ({ brdMstrNo, page }, { dispatch, getState, rejectWithValue }) => {
		try {
			const { params: _params } = getState().communityBoard.cmntyBoard;
			const params = {
				..._params,
				page
			};

			return await callGetBoardListAPI(brdMstrNo, params, dispatch);
		} catch (err) {
			return KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

export const getBoardDTO = createAsyncThunk(
	'communityBoard/cmntyBoard/getBoardDTO',
	async ({ brdMstrNo, brdCtsNo }, { dispatch, rejectWithValue }) => {
		try {
			if (!brdMstrNo) {
				throw new Error('brdMstrNo Parameter is undefined!!');
			}
			const response = await axios.get(`/api/board/content/${brdMstrNo}/${brdCtsNo}`);
			const data = await response.data.data;
			return data;
		} catch (err) {
			return KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

export const insertBoardDTO = createAsyncThunk(
	'communityBoard/cmntyBoard/insertBoardDTO',
	async ({ brdMstrNo, form }, { dispatch, rejectWithValue }) => {
		try {
			if (!brdMstrNo) {
				throw new Error('brdMstrNo Parameter is undefined!!');
			}
			const response = await axios.post(`/api/board/content/${brdMstrNo}`, { ...form });
			const data = await response.data;
			return data;
		} catch (err) {
			return KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

export const updateBoardDTO = createAsyncThunk(
	'communityBoard/cmntyBoard/updateBoardDTO',
	async ({ brdMstrNo, form }, { dispatch, rejectWithValue }) => {
		try {
			if (!brdMstrNo) {
				throw new Error('brdMstrNo Parameter is undefined!!');
			}
			const response = await axios.put(`/api/board/content/${brdMstrNo}`, { ...form });
			const data = await response.data;
			return data;
		} catch (err) {
			return KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

export const deleteBoard = createAsyncThunk(
	'communityBoard/cmntyBoard/deleteBoard',
	async ({ brdMstrNo, brdCtsNo }, { dispatch, rejectWithValue }) => {
		try {
			if (!brdMstrNo) {
				throw new Error('brdMstrNo Parameter is undefined!!');
			}
			const response = await axios.delete(`/api/board/content/${brdMstrNo}/${brdCtsNo}`);
			const data = await response.data;
			return data;
		} catch (err) {
			return KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

// ---------------------------------------------------------

const initialState = {
	isEmptySearchResult: false,
	pageList: {
		content: [],
		number: 1, // pageNum
		size: 0, // pageSize
		totalElements: 0,
		totalPages: 0
	},
	params: {
		brdMstrNo: null,
		page: 1,
		size: 10,
		searchType: 'ALL', // ALL: 전체, TITLE: 제목, CONTENT: 내용
		searchText: ''
	}
};

const _emptyBoardList = state => {
	state.isEmptySearchResult = false;
	state.pageList = initialState.pageList;
};

// ---------------------------------------------------------
const cmntyBoardSlice = createSlice({
	name: 'communityBoard/cmntyBoard',
	initialState,
	reducers: {
		emptyBoardList: (state, action) => _emptyBoardList(state),
		changeBrdMstrNo: (state, action) => {
			state.params = {
				...initialState.params,
				brdMstrNo: action.payload
			};
		},
		changeSearchParams: (state, action) => {
			state.params = {
				...state.params,
				...action.payload
			};
		}
	},
	extraReducers: {
		[getBoardList.pending]: (state, action) => _emptyBoardList(state),
		[getBoardList.fulfilled]: (state, action) => {
			const { pageList, isEmptySearchResult } = action.payload;
			state.pageList = pageList;
			state.isEmptySearchResult = isEmptySearchResult;
		},
		[expandBoardList.fulfilled]: (state, action) => {
			const { pageList, isEmptySearchResult } = action.payload;
			// const content = [];
			// const _content = [...state.pageList.content, ...pageList.content];
			const content = [...state.pageList.content, ...pageList.content];

			// 답글의 부모글이 존재하지 않는 경우 더미게시글로 채워줌
			// if (_content.length > 0) {
			// 	let prev = null; // 상단글
			// 	const parentStk = []; // 부모 스택
			// 	_content.forEach(item => {
			// 		// 답글인 경우
			// 		if (item.brdCtsNo === item.brdCtsGrp) {
			// 			// 상단글이 존재하지 않거나 부모가 아닌 경우
			// 			if (!prev || prev.brdCtsNo !== item.brdCtsGrp) {
			// 				// 추가할 더미게시글 목록의 시작 depth 결정
			// 				const { brdCtsDepth: depth } = item;
			// 				let parentStartDepth = 0;
			// 				while (parentStk.length > 0) {
			// 					const parent = parentStk[parentStk.length - 1]; // 부모스택 peek
			// 					// 기원이 같고 depth가 작으면 부모
			// 					if (parent.brdCtsGrp === item.brdCtsGrp && parent.brdCtsDepth < depth) {
			// 						parentStartDepth = parent.brdCtsDepth;
			// 						break; // (pass) depth 결정
			// 					}
			// 					parentStk.pop(); // 부모 아니면 pop
			// 				}

			// 				for (let i = parentStartDepth; i < depth; i += 1) {
			// 					const parent = {
			// 						brdCtsDepth: i,
			// 						brdCtsGrp: item.brdCtsGrp,
			// 						brdTitle: '삭제된 글입니다.'
			// 					};

			// 					content.push(parent); // 부모글 추가
			// 					parentStk.push(parent); // 부모스택 push
			// 				}
			// 			}
			// 		}

			// 		// 현재글 추가
			// 		content.push(item);
			// 		prev = item; // 상단글 변경
			// 	});
			// }

			state.pageList = {
				...pageList,
				content
			};
			state.isEmptySearchResult = isEmptySearchResult;
		},
		[insertBoardDTO.fulfilled]: (/* state, action */) => {},
		[getBoardDTO.fulfilled]: (/* state, action */) => {},
		[deleteBoard.fulfilled]: (/* state, action */) => {},
		[updateBoardDTO.fulfilled]: (/* state, action */) => {}
	}
});

export const { emptyBoardList, changeBrdMstrNo, changeSearchParams } = cmntyBoardSlice.actions;

export default cmntyBoardSlice.reducer;
