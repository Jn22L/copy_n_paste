import { combineReducers } from '@reduxjs/toolkit';
import cmntyBoard from './cmntyBoardSlice';
import cmntyBoardComment from './cmntyBoardCommentSlice';

const reducer = combineReducers({
	cmntyBoard,
	cmntyBoardComment
});

export default reducer;
