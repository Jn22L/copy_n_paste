import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { showMessage } from 'app/store/fuse/messageSlice';
import KtngUtils from '@ktng/utils';

// ---------------------------------------------------------
const callGetCommentListAPI = async (brdMstrNo, brdCtsNo, params, dispatch) => {
	// params 값 해처모여
	const { page, size, searchType, searchText } = params;
	const _page = page - 1; // 서버에서는 page값이 0이 처음이고, 화면에서 1이 처음임.
	const _size = size >= 0 ? size : 10;
	const _searchType = !searchText ? undefined : searchType;
	const _searchText = !searchText ? undefined : searchText;
	const _params = KtngUtils.removeEmptyAttr({
		page: _page,
		size: _size,
		searchType: _searchType,
		searchText: _searchText
	});
	// 요청
	const response = await axios.get(`/api/board/comment/${brdMstrNo}/${brdCtsNo}/list`, {
		params: _params
	});
	// 결과값 가공
	const data = await response.data.data;

	const { content, size: __size, number, totalElements, totalPages } = data;

	if (content.length === 0) {
		dispatch(showMessage({ message: '조회된 댓글이 없습니다.' }));
	} else {
		dispatch(showMessage({ message: `총 ${content.length}건의 댓글이 조회되었습니다.` }));
	}

	const payload = {
		params: _params,
		pageList: { content, size: __size, number: number + 1, totalElements, totalPages },
		isEmptySearchResult: content.length === 0
	};

	return payload;
};

export const getCommentList = createAsyncThunk(
	'communityBoard/cmntyBoardSlice/getCommentList',
	async ({ brdMstrNo, brdCtsNo }, { dispatch, getState, rejectWithValue }) => {
		try {
			const { params } = getState().communityBoard.cmntyBoardComment;
			return await callGetCommentListAPI(brdMstrNo, brdCtsNo, params, dispatch);
		} catch (err) {
			return KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

export const expandCommentList = createAsyncThunk(
	'communityBoard/cmntyBoardSlice/expandCommentList',
	async ({ brdMstrNo, brdCtsNo, page }, { dispatch, getState, rejectWithValue }) => {
		try {
			const { params: _params } = getState().communityBoard.cmntyBoardComment;
			const params = {
				..._params,
				page
			};

			return await callGetCommentListAPI(brdMstrNo, brdCtsNo, params, dispatch);
		} catch (err) {
			return KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

export const insertCommentDTO = createAsyncThunk(
	'communityBoard/cmntyBoardSlice/insertCommentDTO',
	async ({ brdMstrNo, brdCtsNo, form }, { dispatch, rejectWithValue }) => {
		try {
			if (!brdMstrNo) {
				throw new Error('brdMstrNo Parameter is undefined!!');
			}
			const response = await axios.post(`/api/board/comment/${brdMstrNo}/${brdCtsNo}`, { ...form });
			const data = await response.data;

			dispatch(getCommentList({ brdMstrNo, brdCtsNo }));

			return data;
		} catch (err) {
			return KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

export const updateCommentDTO = createAsyncThunk(
	'communityBoard/cmntyBoardSlice/updateCommentDTO',
	async ({ form }, { dispatch, rejectWithValue }) => {
		try {
			const response = await axios.put(`/api/board/comment`, { ...form });
			const data = await response.data;

			const { brdMstrNo } = form.brdMstrNo;
			const { brdCtsNo } = form.brdCtsNo;

			dispatch(getCommentList({ brdMstrNo, brdCtsNo }));

			return data;
		} catch (err) {
			return KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

export const deleteComment = createAsyncThunk(
	'communityBoard/cmntyBoardSlice/deleteComment',
	async ({ brdMstrNo, brdCtsNo, brdCmtNo }, { dispatch, rejectWithValue }) => {
		try {
			if (!brdMstrNo) {
				throw new Error('brdMstrNo Parameter is undefined!!');
			}
			const response = await axios.delete(`/api/board/comment/${brdMstrNo}/${brdCtsNo}/${brdCmtNo}`);
			const data = await response.data;

			dispatch(getCommentList({ brdMstrNo, brdCtsNo }));

			return data;
		} catch (err) {
			return KtngUtils.catchThunkErrorHandler(err, dispatch, rejectWithValue);
		}
	}
);

// ---------------------------------------------------------

const initialState = {
	isEmptySearchResult: false,
	pageList: {
		content: [],
		number: 1, // pageNum
		size: 0, // pageSize
		totalElements: 0,
		totalPages: 0
	},
	params: {
		page: 1,
		size: 10,
		searchType: 'ALL', // ALL: 전체, TITLE: 제목, CONTENT: 내용
		searchText: ''
	}
};

const _emptyCommentList = state => {
	state.isEmptySearchResult = false;
	state.pageList = initialState.pageList;
};

// ---------------------------------------------------------
const cmntyBoardCommentSlice = createSlice({
	name: 'communityBoard/cmntyBoardComment',
	initialState,
	reducers: {
		emptyCommentList: (state, action) => _emptyCommentList(state),
		changeSearchParams: (state, action) => {
			state.params = {
				...state.params,
				...action.payload
			};
		}
	},
	extraReducers: {
		[getCommentList.pending]: (state, action) => _emptyCommentList(state),
		[getCommentList.fulfilled]: (state, action) => {
			const { pageList, isEmptySearchResult } = action.payload;
			state.pageList = pageList;
			state.isEmptySearchResult = isEmptySearchResult;
		},
		[expandCommentList.fulfilled]: (state, action) => {
			const { pageList, isEmptySearchResult } = action.payload;
			state.pageList = {
				...pageList,
				content: [...state.pageList.content, ...pageList.content]
			};
			state.isEmptySearchResult = isEmptySearchResult;
		},
		[insertCommentDTO.fulfilled]: (/* state, action */) => {},
		[deleteComment.fulfilled]: (/* state, action */) => {},
		[updateCommentDTO.fulfilled]: (/* state, action */) => {}
	}
});

export const { emptyCommentList, changeSearchParams } = cmntyBoardCommentSlice.actions;

export default cmntyBoardCommentSlice.reducer;
