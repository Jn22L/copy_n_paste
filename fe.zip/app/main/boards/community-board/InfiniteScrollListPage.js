import { Typography } from '@material-ui/core';
import React, { useState } from 'react';
import InfiniteScroll from 'react-infinite-scroll-component';

const InfiniteScrollListPage = () => {
	const [items, setItems] = useState(Array.from({ length: 20 }));

	function refreshFunction() {
		setItems(Array.from({ length: 20 }));
	}

	function onNext() {
		setTimeout(() => {
			setItems(items.concat(Array.from({ length: 20 })));
		}, 1500);
	}

	return (
		<div
			id="scrollableDiv"
			style={{
				width: '100%',
				overflow: 'auto'
			}}
		>
			<Typography variant="h4">무한 스크롤 테스트</Typography>
			<InfiniteScroll
				dataLength={items.length}
				next={onNext}
				hasMore
				loader={<h4>Loading...</h4>}
				endMessage={
					<p style={{ textAlign: 'center' }}>
						<b>조회 완료</b>
					</p>
				}
				refreshFunction={refreshFunction}
				pullDownToRefresh
				pullDownToRefreshThreshold={50}
				pullDownToRefreshContent={<h3 style={{ textAlign: 'center' }}>&#8595;</h3>}
				releaseToRefreshContent={<h3 style={{ textAlign: 'center' }}>&#8593;</h3>}
				scrollableTarget="scrollableDiv"
			>
				{items.map((i, index) => (
					<div
						style={{
							height: 80,
							border: '1px solid green',
							margin: 6,
							padding: 8
						}}
						key={index}
					>
						div - #{index}
					</div>
				))}
			</InfiniteScroll>
		</div>
	);
};

export default InfiniteScrollListPage;
