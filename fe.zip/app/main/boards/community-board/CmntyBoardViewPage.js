import FusePageSimple from '@fuse/core/FusePageSimple';
import { useDeepCompareEffect } from '@fuse/hooks';
import { KtngConfirmDialog4 } from '@ktng/core/KtngConfirmDialog';
import { KtngSpeedDial } from '@ktng/core/KtngSpeedDial';
import useHideOnScrollDown from '@ktng/hooks/useHideOnScrollDown';
import { Divider, Icon, Typography } from '@material-ui/core';
import { Delete, Edit, PostAdd } from '@material-ui/icons';
import { Skeleton, SpeedDialAction } from '@material-ui/lab';
import { closeDialog, openDialog } from 'app/store/fuse/dialogSlice';
import { showMessage } from 'app/store/fuse/messageSlice';
import withReducer from 'app/store/withReducer';
import parse from 'html-react-parser';
import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router';
import CmntyBoardViewHeader from './component/CmntyBoardViewHeader';
import CmntyBoardViewFooter from './component/CmntyBoardViewFooter';
import reducer from './store';
import { deleteBoard, getBoardDTO } from './store/cmntyBoardSlice';

function CmntyBoardViewPage({ history }) {
	const dispatch = useDispatch();
	const routeParams = useParams();
	const favHidden = useHideOnScrollDown({
		scrollableTarget: document.querySelector('.container div[class*=-contentWrapper-]')
	});

	const { user } = useSelector(({ auth }) => auth);

	const [item, setItem] = useState(null);

	const favActions = [
		{ id: 0, icon: <PostAdd />, tooltipTitle: '답글작성', onClick: goNewSubBoard, auth: false },
		{ id: 1, icon: <Delete />, tooltipTitle: '삭제', onClick: onDeleteBtnClick, auth: true },
		{ id: 2, icon: <Edit />, tooltipTitle: '수정', onClick: goEditPage, auth: true }
	];

	// 게시글 조회
	useDeepCompareEffect(() => {
		const { brdCtsNo, brdMstrNo } = routeParams;

		dispatch(getBoardDTO({ brdMstrNo, brdCtsNo })).then(data => {
			const { requestStatus } = data.meta;
			if (requestStatus === 'fulfilled') {
				setItem(data.payload);
			}
		});
	}, [dispatch, routeParams]);

	function goEditPage() {
		if (!item) return;

		const { brdMstrNo, brdCtsNo } = routeParams;

		history.push(`/board/community/${brdMstrNo}/edit/${brdCtsNo}`);
	}

	function onDeleteBtnClick() {
		if (!item) return;

		dispatch(
			openDialog({
				children: (
					<KtngConfirmDialog4
						title="삭제 확인"
						okClick={() => {
							dispatch(closeDialog());

							const { brdMstrNo } = routeParams;
							const { brdCtsNo } = item;

							// 서버호출
							dispatch(deleteBoard({ brdMstrNo, brdCtsNo })).then(data => {
								const { requestStatus } = data.meta;
								if (requestStatus === 'fulfilled') {
									dispatch(showMessage({ message: '게시물 삭제 성공' }));
									history.goBack();
								}
							});
						}}
						cancelClick={() => dispatch(closeDialog())}
					>
						게시글을 삭제하시겠습니까?
					</KtngConfirmDialog4>
				)
			})
		);
	}

	function goNewSubBoard() {
		if (!item) return;

		const { brdMstrNo } = routeParams;
		const { brdCtsNo } = item;
		history.push(`/board/community/${brdMstrNo}/new/${brdCtsNo}`);
	}

	return (
		<FusePageSimple
			classes={{ content: 'flex' }}
			header={
				<div className="p-24">
					<Typography className="flex sm:mb-12 cursor-pointer" color="inherit" onClick={history.goBack}>
						<Icon className="text-20">arrow_back</Icon>
						<span className="mx-4">게시판</span>
					</Typography>
					<Typography className="h2" color="textPrimary">
						게시물 확인
					</Typography>
				</div>
			}
			content={
				<div className="w-full">
					<div className="overflow-y-auto overflow-x-hidden">
						<div className="p-16 sm:p-24 w-full">
							{item ? (
								<Typography className="break-all" variant="body1">
									{item.brdTitle}
								</Typography>
							) : (
								<Skeleton />
							)}
						</div>

						<Divider />

						{/* 게시글 상세 헤더 */}
						<CmntyBoardViewHeader board={item} />

						<Divider />

						{item ? (
							<Typography className="p-8 sm:p-24 w-full break-all" variant="body1">
								{item.brdSummary}
							</Typography>
						) : (
							<div className="p-8 sm:p-24 w-full">
								<Skeleton />
							</div>
						)}

						<Divider />

						{/* 게시글 상세 내용 */}
						<div className="p-8 sm:p-24 w-full min-h-200 joditEditor break-all">
							{item ? (
								item.brdContent && parse(item.brdContent, { trim: true })
							) : (
								<Skeleton className="w-full" />
							)}
						</div>

						<Divider />

						{/* 게시글 상세 풋터 (댓글) */}
						<CmntyBoardViewFooter board={item} />

						<KtngSpeedDial ariaLabel="플로팅 버튼" hidden={!item || !item.regId || favHidden}>
							{favActions.map(
								favAction =>
									(!favAction.auth || (favAction.auth && item && user.id === item.regId)) && (
										<SpeedDialAction
											key={favAction.id}
											icon={favAction.icon}
											tooltipTitle={favAction.tooltipTitle}
											tooltipOpen
											onClick={favAction.onClick}
										/>
									)
							)}
						</KtngSpeedDial>
					</div>
				</div>
			}
			innerScroll
		/>
	);
}

export default withReducer('communityBoard', reducer)(CmntyBoardViewPage);
