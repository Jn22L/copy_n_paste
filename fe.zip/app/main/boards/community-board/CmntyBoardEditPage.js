import FusePageSimple from '@fuse/core/FusePageSimple';
import { useDeepCompareEffect, useForm } from '@fuse/hooks';
import { KtngConfirmDialog4 } from '@ktng/core/KtngConfirmDialog';
import { KtngJoditEditor } from '@ktng/core/KtngJoditEditor';
import KtngUtils from '@ktng/utils';
import _ from '@lodash';
import { Button, Divider, Icon, TextField, Typography } from '@material-ui/core';
import { closeDialog, openDialog } from 'app/store/fuse/dialogSlice';
import { showMessage } from 'app/store/fuse/messageSlice';
import withReducer from 'app/store/withReducer';
import React, { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { useParams } from 'react-router';
import reducer from './store';
import { getBoardDTO, insertBoardDTO, updateBoardDTO } from './store/cmntyBoardSlice';

const initForm = {
	brdCtsNo: '',
	brdCtsGrp: '',
	brdCtsDepth: 0,
	brdTitle: '',
	brdSummary: '',
	brdContent: ''
};

function CmntyBoardEditPage({ history }) {
	const dispatch = useDispatch();
	const routeParams = useParams();

	const [item, setItem] = useState(null); // 게시글 수정 시 기존 값
	const { form, handleChange, setForm, setInForm } = useForm(null); // 서버에 보낼 값

	useDeepCompareEffect(() => {
		const { brdMstrNo, brdCtsNo, pBrdCtsNo } = routeParams;
		if (!brdCtsNo) {
			// 신규등록
			initForm.pBrdCtsNo = pBrdCtsNo;
			setItem(initForm);

			if (pBrdCtsNo) {
				// 답글 등록인 경우
				dispatch(getBoardDTO({ brdMstrNo, brdCtsNo: pBrdCtsNo })).then(data => {
					const { requestStatus } = data.meta;
					if (requestStatus === 'fulfilled') {
						const masterBoard = data.payload;
						let brdTitle = '';
						if (masterBoard.brdTitle) {
							brdTitle = `Re:${masterBoard.brdTitle}`;
						}
						setInForm('brdCtsGrp', masterBoard.brdCtsGrp);
						setInForm('brdCtsDepth', masterBoard.brdCtsDepth + 1);
						setInForm('brdTitle', brdTitle);
					}
				});
			}
		} else {
			// 게시물 수정
			dispatch(getBoardDTO({ brdMstrNo, brdCtsNo })).then(data => {
				const { requestStatus } = data.meta;
				if (requestStatus === 'fulfilled') {
					setItem(data.payload);
				}
			});
		}
	}, [dispatch, routeParams]);

	useEffect(() => {
		if ((item && !form) || (item && form && item.brdCtsNo !== form.brdCtsNo)) {
			setForm(item);
		}
	}, [item, form, setForm]);

	function saveConfirmOpen() {
		dispatch(
			openDialog({
				children: (
					<KtngConfirmDialog4
						title="확인"
						okClick={() => {
							dispatch(closeDialog());
							save();
						}}
						cancelClick={() => dispatch(closeDialog())}
					>
						게시글을 저장 하시겠습니까?
					</KtngConfirmDialog4>
				),
				fullWidth: true,
				maxWidth: 'xs'
			})
		);
	}
	function save() {
		const { brdMstrNo } = routeParams;
		const { brdCtsNo } = form;
		if (brdCtsNo) {
			dispatch(updateBoardDTO({ brdMstrNo, form })).then(data => {
				const { requestStatus } = data.meta;
				if (requestStatus === 'fulfilled') {
					dispatch(showMessage({ message: '게시물 수정 성공' }));
					history.goBack();
				}
			});
		} else {
			dispatch(insertBoardDTO({ brdMstrNo, form })).then(data => {
				const { requestStatus } = data.meta;
				if (requestStatus === 'fulfilled') {
					dispatch(showMessage({ message: '게시물 등록 성공' }));
					history.push(`/board/community/${brdMstrNo}/list/1`);
				}
			});
		}
	}

	function goBack() {
		history.goBack();
	}

	function canBeSave() {
		return form && form.brdTitle && form.brdSummary && form.brdContent && !_.isEqual(item, form);
	}

	return (
		<FusePageSimple
			classes={{
				toolbar: 'p-0',
				content: 'flex'
			}}
			header={
				<div className="p-24">
					<Typography className="flex cursor-pointer" color="inherit" onClick={goBack}>
						<Icon className="text-20">arrow_back</Icon>
						<span className="mx-4">게시판</span>
					</Typography>
					<Typography className="h2" color="textPrimary">
						게시물 관리
					</Typography>
				</div>
			}
			contentToolbar={
				<div className="p-16 sm:p-24 w-full">
					{item && (
						<>
							{item.brdCtsNo && (
								<Typography className="ml-2 text-10 opacity-50" variant="caption">
									{item.brdCtsNo}
								</Typography>
							)}
							{item.brdCtsNo && (
								<div className="flex mr-16 text-16 sm:text-20">
									<Typography className="truncate">{item.brdTitle}</Typography>
									<Typography className="w-72 ml-4">수정</Typography>
								</div>
							)}
							<Typography className="text-16 sm:text-20">
								{item.pBrdCtsNo && '답글등록'}
								{!item.brdCtsNo && !item.pBrdCtsNo && '신규등록'}
							</Typography>
						</>
					)}
				</div>
			}
			content={
				<div className="w-full">
					{item && item.brdCtsNo && (
						<>
							<div className="flex justify-between px-16 py-8 sm:px-24 sm:py-12 w-full text-10 opacity-50">
								<div className="flex flex-row">
									<Icon fontSize="small">account_circle</Icon>
									<Typography className="ml-2" variant="caption">
										{item.regNm}({item.regId})
									</Typography>
								</div>
								<div className="flex flex-row">
									<Icon fontSize="small">remove_red_eye</Icon>
									<Typography className="ml-2" variant="caption">
										{item.brdHit}
									</Typography>
									<Icon className="ml-6" fontSize="small">
										access_time
									</Icon>
									<Typography className="ml-2" variant="caption">
										{KtngUtils.convertBoardDate(item.regDate)}
									</Typography>
								</div>
							</div>
							<Divider />
						</>
					)}
					{form && (
						<div className="p-16 sm:p-24 w-full">
							<Typography className="my-8" variant="subtitle1">
								게시글 제목*
							</Typography>
							<TextField
								className="mb-8"
								id="brdTitle"
								name="brdTitle"
								fullWidth
								value={form.brdTitle}
								onChange={handleChange}
							/>
							<Typography className="my-8" variant="subtitle1">
								게시글 요약
							</Typography>
							<TextField
								className="mb-8"
								id="brdSummary"
								name="brdSummary"
								fullWidth
								value={form.brdSummary}
								onChange={e => {
									console.log(e);
									handleChange(e);
								}}
							/>
							<Typography className="my-8" variant="subtitle1">
								게시글 내용*
							</Typography>
							<KtngJoditEditor
								name="brdContent"
								value={form.brdContent}
								// eslint-disable-next-line jsx-a11y/tabindex-no-positive
								tabIndex={1}
								onBlur={(e, value) => {
									setInForm('brdContent', value);
								}}
								// onChange={} // `onChange`로 value 수정 시 editor에 focus 유지가 되지 않아 에러 발생함
							/>
						</div>
					)}
					<div className="p-16 sm:p-24 w-full">
						<Button
							className="whitespace-no-wrap"
							variant="contained"
							color="secondary"
							disabled={!canBeSave()}
							onClick={saveConfirmOpen}
						>
							<Icon>save</Icon>
							<span className="hidden sm:flex pl-8">저장</span>
						</Button>
					</div>
				</div>
			}
		/>
	);
}

export default withReducer('communityBoard', reducer)(CmntyBoardEditPage);
