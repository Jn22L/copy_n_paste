import CmntyBoardConfig from './community-board/CmntyBoardConfig';

const boardsConfig = [CmntyBoardConfig];

export default boardsConfig;
