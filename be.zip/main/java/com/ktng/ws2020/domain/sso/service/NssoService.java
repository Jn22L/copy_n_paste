package com.ktng.ws2020.domain.sso.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ktng.ws2020.da.dao.NssoSessionRepository;
import com.ktng.ws2020.da.model.NssoSessionEntity;
import com.ktng.ws2020.domain.common.model.UutasMenuTreeDTO;
import com.ktng.ws2020.domain.common.model.UutasUserDTO;
import com.ktng.ws2020.domain.common.service.UutasUserService;
import com.ktng.ws2020.domain.menu.service.MenuService;
import com.ktng.ws2020.domain.sso.model.IamLoginUserDTO;
import com.ktng.ws2020.global.config.security.userdetails.IamUserDetails;
import com.ktng.ws2020.infra.nsso.model.NssoIdTokenInfoResult;
import com.ktng.ws2020.infra.nsso.service.NssoApiService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class NssoService {

	@Autowired
	private NssoSessionRepository nssoSessionRepository;
	
	@Autowired
	private NssoApiService nssoApiService;
	
	@Autowired
	private UutasUserService uutasUserService;
	
	@Autowired
	private MenuService menuService;
	
	private final String issType = "NSSO";
	
	@Transactional
	public IamLoginUserDTO saveSession(
			IamUserDetails principal, String idToken) throws JsonProcessingException, ParseException {
		log.debug("NssoService.saveSession() ...");
		
		// 1. RestTemplate 사용해서 idToken정보 validatiaon처리 -> _nsid 획득
		NssoIdTokenInfoResult token = nssoApiService.getTokenInfo(idToken);
		
		String empNo       = principal.getUsername();
		String issType     = principal.getIssType();
		Date   expiredAt   = principal.getExpireAt();
		String accessToken = principal.getAccessToken();
		String sid         = token.getNsid();

		Date lastLogonDt = null; 
		String lastLogonIp = ""; 
		log.debug("token={}, ", token);
		log.debug("lastlogondt={}, lastlogonip={}", token.getLastlogondt(), token.getLastlogonip());
		if (token.getLastlogondt() != null && token.getLastlogonip() != null) {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss", Locale.KOREA);
			lastLogonDt = sdf.parse(token.getLastlogondt());
			lastLogonIp = token.getLastlogonip();
			principal.setLoginDate(lastLogonDt);
			principal.setLoginIp(lastLogonIp);
		}
		
		// 2. DB에 토큰정보, 만료일, 마지막접속시간, 마지막접속IP 저장
		NssoSessionEntity session = NssoSessionEntity.builder()
				.empNo(empNo)
				.sid(sid)
				.issType(issType)
				.idToken(idToken)
				.accessToken(accessToken)
				.expiredAt(expiredAt)
				.lastLogonDt(lastLogonDt)
				.lastLogonIp(lastLogonIp)
				.build();
		nssoSessionRepository.save(session);
		
		// 배차관리 사용자정보 조회
		// UutasUserDTO uutasUser = uutasUserService.getUserByEmpNo(empNo); // 일반 로그인		
		UutasUserDTO uutasUser = uutasUserService.getUserByEmpNoIpAddr(empNo, principal.getLoginIp()); //관리자 체크로그인
		
		// 배차관리 메뉴 리스트 조회
		List<UutasMenuTreeDTO> uutasMenus = menuService.getNavMenuListByRoleCd(uutasUser.getRoleCd());
		
		return IamLoginUserDTO.of(principal, uutasUser, uutasMenus);
	}
	
	@Transactional
	public void updateToken(
			final NssoSessionEntity session,
			final String newAccessToken,
			final Date expireAt) throws JsonProcessingException {
		
		// 기존토큰 revoke 요청
		nssoApiService.revokeToken(session.getAccessToken());
		
		// 토큰정보 갱신
		NssoSessionEntity newSession = NssoSessionEntity.builder()
				.empNo(session.getEmpNo())
				.idToken(session.getIdToken())
				.sid(session.getSid())
				.issType(issType)
				.accessToken(newAccessToken)
				.expiredAt(expireAt)
				.lastLogonDt(session.getLastLogonDt())
				.lastLogonIp(session.getLastLogonIp())
				.build();
		
		nssoSessionRepository.save(newSession);
	}
	
	public void refreshSession(String empNo, String accessToken) {
		nssoSessionRepository.updateAccessToken(empNo, accessToken);
	}
	
	public void revokeSession(String accessToken) {
		nssoSessionRepository.deleteByAccessToken(accessToken);
	}
	
	public void deleteSession(String sid) {
		nssoSessionRepository.deleteBySid(sid);
	}
}
