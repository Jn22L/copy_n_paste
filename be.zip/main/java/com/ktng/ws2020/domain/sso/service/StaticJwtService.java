package com.ktng.ws2020.domain.sso.service;

import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.List;

import javax.crypto.spec.SecretKeySpec;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ktng.ws2020.da.dao.NssoSessionRepository;
import com.ktng.ws2020.da.model.IamUserEntity;
import com.ktng.ws2020.da.model.NssoSessionEntity;
import com.ktng.ws2020.domain.common.model.UutasMenuTreeDTO;
import com.ktng.ws2020.domain.common.model.UutasUserDTO;
import com.ktng.ws2020.domain.common.service.UutasUserService;
import com.ktng.ws2020.domain.menu.service.MenuService;
import com.ktng.ws2020.domain.sso.model.IamLoginUserDTO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class StaticJwtService {
	

    @Value("${ktng.static-jwt.secret}")
    String secret;
	
	@Autowired
	private NssoSessionRepository nssoSessionRepository;
	
	@Autowired
	private UutasUserService uutasUserService;
	
	@Autowired
	private MenuService menuService;
	
	private final String issType = "staticJwt"; 
	
	// StaticJwtAuthenticationProvider.jwtDecoder 과 동일함
	public JwtDecoder jwtDecoder() {
        SecretKeySpec key = new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), "HmacSHA256");
        return NimbusJwtDecoder.withSecretKey(key).build();
    }
	
	@Transactional
	public IamLoginUserDTO saveSession(String accessToken, IamUserEntity user) {
		log.debug("StaticJwtService.saveSession() ...");
		// accessToekn -> Jwt convert
		Jwt jwt= jwtDecoder().decode(accessToken);
		String empNo = jwt.getClaimAsString("sub");
		
		// IamUserDetailsService.getIssTypeByiss 로직과 중복됨.
        String iss = jwt.getClaimAsString("iss");
        
        Date expiredAt = (Date) Date.from(jwt.getClaimAsInstant("exp"));
        
		// DB에 토큰정보, 만료일
		NssoSessionEntity session = NssoSessionEntity.builder()
				.empNo(empNo)
				.idToken(null)
				.sid(null)
				.issType(issType) 
				.accessToken(accessToken)
				.expiredAt(expiredAt)
				.lastLogonDt(null)
				.lastLogonIp(null)
				.build();
		nssoSessionRepository.save(session);

		// 배차관리 사용자정보 조회
		UutasUserDTO uutasUser = uutasUserService.getUserByEmpNo(empNo);
		// 배차관리 메뉴 리스트 조회
		List<UutasMenuTreeDTO> uutasMenus = menuService.getNavMenuListByRoleCd(uutasUser.getRoleCd());
		
		// IamUserEntity to IamLoginUserDTO
		return IamLoginUserDTO.of(user, uutasUser, uutasMenus, accessToken, issType);
	}
	
	@Transactional
	public void updateToken(
			final NssoSessionEntity session,
			final String newAccessToken,
			final Date expireAt) throws JsonProcessingException {
		
		// 토큰정보 갱신
		NssoSessionEntity newSession = NssoSessionEntity.builder()
				.empNo(session.getEmpNo())
				.idToken(null)
				.sid(null)
				.issType(issType)
				.accessToken(newAccessToken)
				.expiredAt(expireAt)
				.lastLogonDt(null)
				.lastLogonIp(null)
				.build();
		
		nssoSessionRepository.save(newSession);
	}

}
