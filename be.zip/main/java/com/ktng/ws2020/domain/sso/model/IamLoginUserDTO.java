package com.ktng.ws2020.domain.sso.model;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.ktng.ws2020.da.model.IamUserEntity;
import com.ktng.ws2020.domain.common.model.UutasMenuTreeDTO;
import com.ktng.ws2020.domain.common.model.UutasUserDTO;
import com.ktng.ws2020.global.config.security.userdetails.IamUserDetails;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class IamLoginUserDTO {
	
	private String username;
	private String name;
//	private String password;
//	private String userType;
	private String groupCd;
	private String groupNm;
	private String parCd;
	private String parNm;
	private String manDeptCd;
	private String manDeptNm;
	private Date loginDate;
	private String loginIp;
	private String issType;
	private String accessToken;
	
	private List<String> role;

	@Setter
	private UutasUserDTO uutasUser;

	@Setter
	private List<UutasMenuTreeDTO> menus;

	public static IamLoginUserDTO of(IamUserDetails principal, UutasUserDTO uutasUser, List<UutasMenuTreeDTO> menus) {
		return IamLoginUserDTO.builder()
				.username (principal.getUsername() )
				.name     (principal.getName()     )
				.groupCd  (principal.getGroupCd()  )
				.groupNm  (principal.getGroupNm()  )
				.parCd    (principal.getParCd()    )
				.parNm    (principal.getParNm()    )
				.manDeptCd(principal.getManDeptCd())
				.manDeptNm(principal.getManDeptNm())
				.loginDate(principal.getLoginDate())
				.loginIp  (principal.getLoginIp()  )
				.issType  (principal.getIssType()      )
				.role     (principal.getAuthorities()
							.stream()
							.map(role -> role.getAuthority())
							.collect(Collectors.toList()) )
				.uutasUser(uutasUser)
				.menus(menus)
				.build();
	}
	
	public static IamLoginUserDTO of(
			IamUserDetails principal, UutasUserDTO uutasUser, List<UutasMenuTreeDTO> menus, Date lastLogonDt, String lastLogonIp) {
		return IamLoginUserDTO.builder()
				.username (principal.getUsername() )
				.name     (principal.getName()     )
				.groupCd  (principal.getGroupCd()  )
				.groupNm  (principal.getGroupNm()  )
				.parCd    (principal.getParCd()    )
				.parNm    (principal.getParNm()    )
				.manDeptCd(principal.getManDeptCd())
				.manDeptNm(principal.getManDeptNm())
				.loginDate(lastLogonDt             )
				.loginIp  (lastLogonIp             )
				.issType  (principal.getIssType()  )
				.role     (principal.getAuthorities()
							.stream()
							.map(role -> role.getAuthority())
							.collect(Collectors.toList()) )
				.uutasUser(uutasUser)
				.menus(menus)
				.build();
	}
	
	public static IamLoginUserDTO of(IamUserEntity user, UutasUserDTO uutasUser, List<UutasMenuTreeDTO> menus, String accessToken, String issType) {
		return IamLoginUserDTO.builder()
				.username   (user.getUserCd()     )
				.name       (user.getUserNm()        )
				.groupCd    (user.getWorkDeptCd())
				.groupNm    (user.getWorkDeptNm())
				.parCd      (user.getParCd()     )
				.parNm      (user.getParNm()     )
				.manDeptCd  (user.getManaDeptCd() )
				.manDeptNm  (user.getManaDeptNm() )
				.accessToken(accessToken           )
				.issType    (issType               )
				.role       (Stream.of(uutasUser.getRoleCd())
						        .collect(Collectors.toList())   )
				.uutasUser(uutasUser              )
				.menus(menus                      )
				.build();
	}
	
}
