package com.ktng.ws2020.domain.sso.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StaticJwtResponse {

	private String accessToken;
	private String iss;
	final private String tokenType = "Bearer";
	
}
