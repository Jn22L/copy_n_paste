package com.ktng.ws2020.domain.sso.exception;

import java.util.Map;

import com.ktng.ws2020.global.error.exception.BusinessException;
import com.ktng.ws2020.global.error.exception.ErrorCode;

public class UserLoginException extends BusinessException {

    private Map<String, String> error;
    
    public UserLoginException(Map<String, String> error, ErrorCode errorCode) {
    	super(errorCode);
    	this.error = error;
    }
    
    public UserLoginException(ErrorCode errorCode) {
    	super(errorCode);
    }
    
    public Map<String, String> getError() {
        return error;
    }
}
