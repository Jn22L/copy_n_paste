package com.ktng.ws2020.domain.sso.web;

import java.text.ParseException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ktng.ws2020.domain.common.model.UutasMenuTreeDTO;
import com.ktng.ws2020.domain.common.model.UutasUserDTO;
import com.ktng.ws2020.domain.common.service.UutasUserService;
import com.ktng.ws2020.domain.menu.service.MenuService;
import com.ktng.ws2020.domain.sso.model.IamLoginUserDTO;
import com.ktng.ws2020.domain.sso.service.NssoService;
import com.ktng.ws2020.global.common.response.CommonResult;
import com.ktng.ws2020.global.common.response.SingleResult;
import com.ktng.ws2020.global.common.response.service.ResponseService;
import com.ktng.ws2020.global.config.security.userdetails.IamUserDetails;
import com.ktng.ws2020.global.error.exception.InvalidValueException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/sso")
public class SsoController {

	@Autowired
	ResponseService responseService;
	
	@Autowired
	NssoService nssoService;

	@Autowired
	UutasUserService uutasUserService;

	@Autowired
	MenuService menuService;
	
	@PostMapping(path = "/loginSuccess")
	public SingleResult<IamLoginUserDTO> loginSuccess(
			@AuthenticationPrincipal Authentication authentication, 
			@RequestParam("idToken") String idToken ) throws JsonProcessingException, ParseException {
		log.debug("authentication : {}", authentication.getPrincipal());
		IamUserDetails principal = (IamUserDetails)authentication.getPrincipal();
		// TODO iss 가 iam 인경우만 수행 처리 
		IamLoginUserDTO user = nssoService.saveSession(principal, idToken);
		
		return responseService.getSingleResult(user);
	}
	
	@PostMapping(path = "/sign")
	public SingleResult<IamLoginUserDTO> sign(
			@AuthenticationPrincipal Authentication authentication){
		IamUserDetails principal = (IamUserDetails)authentication.getPrincipal();
		
		UutasUserDTO uutasUser = uutasUserService.getUserByEmpNo(principal.getUsername());
		List<UutasMenuTreeDTO> menus = menuService.getNavMenuListByRoleCd(uutasUser.getRoleCd());

		IamLoginUserDTO user = IamLoginUserDTO.of(principal, uutasUser, menus); 
		return responseService.getSingleResult(user);
	}

	@GetMapping(path = "/refresh")
	public CommonResult refresh(@AuthenticationPrincipal Authentication authentication) {
		IamUserDetails principal = (IamUserDetails)authentication.getPrincipal();
		// TODO iss 가 iam 인경우만 수행 처리		
		nssoService.refreshSession(principal.getUsername(), principal.getAccessToken());
		return responseService.getSuccessResult();
	}
	
	// 세션정보 삭제 (FE에서 호출)
	@GetMapping(path = "/revoke")
	public CommonResult logout(HttpServletRequest request) {
		String accessToken = request.getHeader("accessToken");
		if (accessToken == null || accessToken.length() == 0) {
			throw new InvalidValueException("헤더에서 access token을 찾을 수 없음");
		}
		nssoService.revokeSession(accessToken);
		return responseService.getSuccessResult();
	}

	// 세션정보 삭제 (SSO:iam.ktng.com에서 호출)
	@GetMapping(path = "/logout")
	public CommonResult logout(String iss, String sid) {
		log.info("iss={}, sid={}", iss, sid);
		// TODO iss 가 iam 인경우만 수행 처리
		nssoService.deleteSession(sid);
		return responseService.getSuccessResult();
	}
}
