package com.ktng.ws2020.domain.sso.web;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ktng.ws2020.da.dao.IamUserRepository;
import com.ktng.ws2020.da.model.IamUserEntity;
import com.ktng.ws2020.domain.sso.exception.UserLoginException;
import com.ktng.ws2020.domain.sso.model.IamLoginUserDTO;
import com.ktng.ws2020.domain.sso.model.StaticJwtResponse;
import com.ktng.ws2020.domain.sso.service.StaticJwtService;
import com.ktng.ws2020.global.common.response.SingleResult;
import com.ktng.ws2020.global.common.response.service.ResponseService;
import com.ktng.ws2020.global.config.security.StaticJwtCreator;
import com.ktng.ws2020.global.error.exception.ErrorCode;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/sso")
public class StaticJwtController {
	
    @Value("${ktng.static-jwt.issuer}")
    String issuer;

	@Autowired
	private StaticJwtCreator staticJwtCreator;
	
	@Autowired 
	private IamUserRepository iamUserRepository;
	
	@Autowired
	private StaticJwtService staticJwtService;
	
	@Autowired 
	private PasswordEncoder passwordEncoder;
	
	@Autowired
	ResponseService responseService;
	
	// 토큰발급과 사용자정보 같이 던짐...
    @PostMapping(value = "/static/login")
    public SingleResult<IamLoginUserDTO> staticSignin(
    		@RequestParam("empNo") String empNo,
    		@RequestParam("password") String password ){
    	
    	IamUserEntity user = iamUserRepository.findById(empNo)
                .orElseThrow( () -> new UsernameNotFoundException("유저를 찾을 수 없습니다."));

        // 비밀번호 일치 테스트
    	String password1 = user.getTotId() + password; // 사용자 입력 패스워드
    	String password2 = "{SHA-256}" + user.getPwd().toLowerCase(); // 사번+패스워드, sha-256 암호화
    	boolean result = passwordEncoder.matches(password1, password2);
    	
    	if (!result) {
    		// 비밀번호 불일치 에러 발생
    		HashMap<String, String> errMap = new HashMap<>();
			errMap.put("password", ErrorCode.PASSWORD_NOT_MATCHE.getMsg());
			throw new UserLoginException(errMap, ErrorCode.PASSWORD_NOT_MATCHE);
    	}
    	
    	// 토큰생성
    	String accessToken = staticJwtCreator.createToken(empNo);
    	
    	// 세선졍보 생성
    	IamLoginUserDTO dto = staticJwtService.saveSession(accessToken, user);
    	return responseService.getSingleResult(dto);
    }
    

    
    
    // ----------------------------------------------
    
    @ExceptionHandler(UserLoginException.class)
    protected ResponseEntity<SingleResult<Map<String, String>>> handleUserLoginException(UserLoginException e) {
        log.error("handleUserLoginException", e);
        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Type", "application/json;charset=UTF-8");
        
        final ErrorCode errorCode = e.getErrorCode();
        SingleResult<Map<String, String>> errorResponse = new SingleResult<Map<String, String>>();
        errorResponse.setErrorCode(errorCode);
        errorResponse.setData(e.getError());
        
        return new ResponseEntity<>(
        		errorResponse, headers, 
        		HttpStatus.valueOf(errorCode.getStatus()));
    }
}
