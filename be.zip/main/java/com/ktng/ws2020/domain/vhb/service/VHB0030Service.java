package com.ktng.ws2020.domain.vhb.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktng.ws2020.domain.vhb.dao.VHB0030Mapper;
import com.ktng.ws2020.domain.vhb.model.VHB0030MstDTO;
import com.ktng.ws2020.domain.vhb.model.VHB0030SubDTO;

@Service
public class VHB0030Service {

	@Autowired
	private VHB0030Mapper vhb0030Mapper;

	/* 조회 */
	public List<VHB0030MstDTO> selectMstGrid(String vhYyyymm, String partCd, String depCd) {
		return vhb0030Mapper.selectMstGrid(vhYyyymm, partCd, depCd);
	}
	
	/* 조회 */
	public List<VHB0030SubDTO> selectSubGrid(String applyNo) {
		return vhb0030Mapper.selectSubGrid(applyNo);
	}	

}
