package com.ktng.ws2020.domain.vhb.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktng.ws2020.domain.vhb.dao.VHB0010MstMapper;
import com.ktng.ws2020.domain.vhb.model.VHB0010MstDTO;

@Service
public class VHB0010MstService {

	@Autowired
	private VHB0010MstMapper vhb0010MstMapper;

	/* 조회 */
	public List<VHB0010MstDTO> selectGrid(String vhclDeptCd, String sregYear) {
		return vhb0010MstMapper.selectGrid(vhclDeptCd, sregYear);
	}

}
