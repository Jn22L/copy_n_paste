package com.ktng.ws2020.domain.vhb.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * 게시물 상세
 * @author t0210023
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class VHB0010SubDTO {
	private String boardId;
	private String boardTitle;
	private String boardContent;
	private String regDate;
	private String startDate;
	private String endDate;
	private String viewNum;
	private String regDeptCd;
	private String regId;
}
