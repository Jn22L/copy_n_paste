package com.ktng.ws2020.domain.vhb.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class VHB0030SubDTO {

	private String  assignNo;   /* 배차번호 */
	private String  depatureDt; /* 출발일자 */
	private String  depatureTm; /* 출발시간 */
	private String  arrivalDt;  /* 도착일자 */
	private String  arrivalTm;  /* 도착시간 */
	private String  destination;/* 행선지   */ 
	private String  vhclNo;     /* 차량번호 */
	private String  driverNm;   /* 운전자   */
	private String  cellPn;     /* 운전자번화번호 */
	
}
