package com.ktng.ws2020.domain.vhb.exception;

import com.ktng.ws2020.global.error.exception.BusinessException;
import com.ktng.ws2020.global.error.exception.ErrorCode;

public class VHB0020UpdateFailException extends BusinessException {

	private static final long serialVersionUID = -6700524932937649945L;

	public VHB0020UpdateFailException() {
        super(ErrorCode.VHB0020_UPDATE_FAIL);
    }

	public VHB0020UpdateFailException(String message) {
        super(message, ErrorCode.VHB0020_UPDATE_FAIL);
    }

}
