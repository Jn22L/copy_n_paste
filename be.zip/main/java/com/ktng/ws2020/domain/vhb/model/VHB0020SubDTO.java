package com.ktng.ws2020.domain.vhb.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class VHB0020SubDTO {
	private String applyNo;                 /* 신청번호          */
	private String applyDt;                 /* 신청일자          */
	private String applyEmpNo;             /* 신청자사번        */
	private String applyEmpNm;      /* 신청자이름        */
	private String applyCellPhnNo;      /* 신청자연락처      */
	private String chiefEmpNo;             /* 사용자사번        */
	private String chiefEmpNm;      /* 사용자이름        */
	private String chiefParCd;             /* 사용자기관코드    */
	private String chiefParNm;
	private String chiefDeptCd;            /* 사용자부서코드    */
	private String chiefDeptNm;
	private String chiefJobNm;             /* 사용자직무명      */
	private String chiefCellPn;            /* 사용자휴대전화번호*/
	private String usePurpose;              /* 사용목적          */
	private String destination;              /* 행선지            */
	private String depatureDt;              /* 출발일            */
	private String depatureTm;              /* 출발시간          */
	private String arrivalDt;               /* 도착일            */
	private String arrivalTm;               /* 도착시간          */
	private String boardNo;                 /* 탑승인원          */
	private String fileTitle;            /* 첨부파일명        */
	private String vhclDeptCd;             /* 배차부서          */
	private String receiptResult;
	private String vhEtc;
	private String vhType;
	private String passstop;
	private String departure;
}
