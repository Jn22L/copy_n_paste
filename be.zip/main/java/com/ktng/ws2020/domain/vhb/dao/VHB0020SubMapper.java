package com.ktng.ws2020.domain.vhb.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ktng.ws2020.domain.vhb.model.VHB0020SubDTO;
import com.ktng.ws2020.domain.vhc.model.VHC0040SMSDTO;

@Mapper
public interface VHB0020SubMapper {

	// 배차신청건 상세 조회
	public VHB0020SubDTO selectOne(
			@Param("applyNo") String applyNo);

	// 배차신청건 ID 생성 및 추가
	public int insertOne(
			@Param("vhb0020") VHB0020SubDTO vhb0020,
			@Param("regEmpNo") String regEmpNo);

	// 배차신청건 수정
	public int updateOne(
			@Param("vhb0020") VHB0020SubDTO vhb0020,
			@Param("altEmpNo") String altEmpNo);

	// 배차신청건 삭제
	public int deleteOne(
			@Param("applyNo") String applyNo);

	// 입력/수정 후 발송할 SMS 내용 생성 및 조회
	public VHC0040SMSDTO selectSmsContent(
			@Param("vhclDeptCd") String vhclDeptCd,
			@Param("departureDt") String departureDt); // yyyyMMdd

}
