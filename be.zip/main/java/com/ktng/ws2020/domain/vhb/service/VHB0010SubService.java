package com.ktng.ws2020.domain.vhb.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktng.ws2020.domain.vhb.dao.VHB0010SubMapper;
import com.ktng.ws2020.domain.vhb.model.VHB0010SubDTO;

@Service
public class VHB0010SubService {

	@Autowired
	private VHB0010SubMapper vhb0010SubMapper;

	/* 조회 */
	public VHB0010SubDTO selectOne(String boardId) {
		return vhb0010SubMapper.selectOne(boardId);
	}

	/* 조회수 증가 */
	public int increaseViewNum(String boardId, String altEmpNo) {
		// 조회수 컬럼 '1' 증가
		return vhb0010SubMapper.increaseViewNum(boardId, altEmpNo);
	}

}
