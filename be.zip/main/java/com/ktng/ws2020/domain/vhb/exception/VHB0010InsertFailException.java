package com.ktng.ws2020.domain.vhb.exception;

import com.ktng.ws2020.global.error.exception.BusinessException;
import com.ktng.ws2020.global.error.exception.ErrorCode;

public class VHB0010InsertFailException extends BusinessException {
	private static final long serialVersionUID = -8163875188978085214L;

	public VHB0010InsertFailException() {
        super(ErrorCode.VHB0010_INSERT_FAIL);
    }

	public VHB0010InsertFailException(String message) {
        super(message, ErrorCode.VHB0010_INSERT_FAIL);
    }

}
