package com.ktng.ws2020.domain.vhb.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktng.ws2020.domain.vhb.dao.VHB0040Mapper;
import com.ktng.ws2020.domain.vhb.model.VHB0040DTO;

@Service
public class VHB0040Service {

	@Autowired
	private VHB0040Mapper vhb0040Mapper;

	/* 조회 */
	public List<VHB0040DTO> selectCalendarMain(String vhDeptCd, String vhYyyymm) {
		return vhb0040Mapper.selectCalendarMain(vhDeptCd, vhYyyymm);
	}
	
	/* 총 운용차량 조회 */
	public List<VHB0040DTO> selectCalendarVhclCnt(String vhDeptCd) {
		return vhb0040Mapper.selectCalendarVhclCnt(vhDeptCd);
	}	
	
	/* 상세팝업조회 */
	public List<VHB0040DTO> selectCalendarPopup(String vhDeptCd, String calYyyymmdd) {
		return vhb0040Mapper.selectCalendarPopup(vhDeptCd, calYyyymmdd);
	}

}
