package com.ktng.ws2020.domain.vhb.exception;

import com.ktng.ws2020.global.error.exception.BusinessException;
import com.ktng.ws2020.global.error.exception.ErrorCode;

public class VHB0010DeleteFailException extends BusinessException {
	private static final long serialVersionUID = -1639819576336352515L;

	public VHB0010DeleteFailException() {
        super(ErrorCode.VHB0010_DELETE_FAIL);
    }

	public VHB0010DeleteFailException(String message) {
        super(message, ErrorCode.VHB0010_DELETE_FAIL);
    }

}
