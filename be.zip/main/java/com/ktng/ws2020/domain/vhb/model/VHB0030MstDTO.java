package com.ktng.ws2020.domain.vhb.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class VHB0030MstDTO {
	private String applyDt;         /* 신청일자 */
	private String chiefEmpNm;      /* 사용자   */
	private String depatureDt;      /* 출발일   */
	private String depatureTm;      /* 출발시간 */
	private String arrivalDt;       /* 도착일   */
	private String arrivalTm;       /* 도착시간 */
	private String destination;     /* 행선지   */
	private String vhChk;           /* 배차여부 */
	private String rejectCause;     /* 반려사유 */
	private String boardNo;         /* 탑승인원 */
	private String usePurpose;      /* 사용목적 */
	private String applyNo;         /* 신청번호 */
	private String vhEtc;           /* 비고     */
	private String vhTypeNm;        /* 용도     */ 	
}
