package com.ktng.ws2020.domain.vhb.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktng.ws2020.domain.vhb.dao.VHB0020MstMapper;
import com.ktng.ws2020.domain.vhb.model.VHB0020MstDTO;

@Service
public class VHB0020MstService {

	@Autowired
	private VHB0020MstMapper vhb0020MstMapper;

	/* 조회 */
	public List<VHB0020MstDTO> selectGrid(String vhYyyymm, String partCd) {
		return vhb0020MstMapper.selectGrid(vhYyyymm, partCd);
	}

}
