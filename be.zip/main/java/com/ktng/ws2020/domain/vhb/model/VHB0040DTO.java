package com.ktng.ws2020.domain.vhb.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class VHB0040DTO {
	
    /* 캘런더 메인 */
	
	private String ymd;        /* 일자     */
	private String week;       /* 요일     */
	private String minusDd;    /* 감산일수 */  
	private String moonYmd;    /* 음력일자 */
	private String note;       /* 비고     */
	private String carCnt;     /* 운행건수 */

	/* 캘린더 상단 총 운용차량 */
	
	private String aCnt;       /* 업무용(승용) 건수 */
	private String bCnt;       /* 업무용(승합) 건수 */
	private String cCnt;       /* 업무용(버스) 건수 */
	private String dCnt;       /* 임원용       건수 */

	/* 캘런더 건수 클릭시 팝업 */
	
	private String depatureDt;  /* 출발일자 */
	private String depatureTm;  /* 출발시간 */
	private String arrivalDt;   /* 도착일자 */
	private String arrivalTm;   /* 도착시간 */
	private String empNm;       /* 신청자   */
	private String parNm;       /* 기관     */
	private String depNm;       /* 부서     */
	private String chiefJobNm;  /* 사용자   */
	private String chiefNm;     /* 사용목적 */
	private String chiefCellPn; /* 전화번호 */
	private String usePurpose;  /* 사용목적 */
	private String destination; /* 행선지   */
	private String vhTypeNm;    /* 배차차량 */
	private String vhclNo;      /* 차량번호 */
	
}
