package com.ktng.ws2020.domain.vhb.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ktng.ws2020.domain.vhb.model.VHB0040DTO;

@Mapper
public interface VHB0040Mapper {

	public List<VHB0040DTO> selectCalendarMain    (@Param("vhDeptCd") String vhDeptCd, @Param("vhYyyymm") String vhYyyymm);
	public List<VHB0040DTO> selectCalendarVhclCnt (@Param("vhDeptCd") String vhDeptCd);
	public List<VHB0040DTO> selectCalendarPopup   (@Param("vhDeptCd") String vhDeptCd, @Param("calYyyymmdd") String calYyyymmdd);
	
}
