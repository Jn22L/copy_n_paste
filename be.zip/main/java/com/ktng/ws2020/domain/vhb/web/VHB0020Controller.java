package com.ktng.ws2020.domain.vhb.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ktng.ws2020.da.model.enums.AtchFileType;
import com.ktng.ws2020.domain.attach.service.AttachService;
import com.ktng.ws2020.domain.common.model.UutasUserDTO;
import com.ktng.ws2020.domain.common.service.UutasUserService;
import com.ktng.ws2020.domain.vhb.exception.VHB0020DeleteFailException;
import com.ktng.ws2020.domain.vhb.exception.VHB0020InsertFailException;
import com.ktng.ws2020.domain.vhb.exception.VHB0020UpdateFailException;
import com.ktng.ws2020.domain.vhb.model.VHB0020MstDTO;
import com.ktng.ws2020.domain.vhb.model.VHB0020SubDTO;
import com.ktng.ws2020.domain.vhb.service.VHB0020MstService;
import com.ktng.ws2020.domain.vhb.service.VHB0020SubService;
import com.ktng.ws2020.global.common.response.CommonResult;
import com.ktng.ws2020.global.common.response.ListResult;
import com.ktng.ws2020.global.common.response.SingleResult;
import com.ktng.ws2020.global.common.response.service.ResponseService;
import com.ktng.ws2020.global.config.security.userdetails.IamUserDetails;
import com.ktng.ws2020.infra.eai.exception.EAIRunFailException;

import egovframework.rte.fdl.cmmn.exception.FdlException;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/vhb0020")
public class VHB0020Controller {

	@Autowired
	private VHB0020MstService vhb0020MstService;

	@Autowired
	private VHB0020SubService vhb0020SubService;

	@Autowired
	private AttachService attachService;

	@Autowired
	private UutasUserService uutasUserService; // 로그인사용자의 부서(depCd) 조회

	@Autowired
	private ResponseService responseService;

	/**
	 * 배차신청건 리스트 조회
	 *
	 * @param vhYyyymm 검색할 차량출발년월
	 * @param partCd 신청부서
	 */
	@GetMapping
	public ListResult<VHB0020MstDTO> selectMstGrid(
			@RequestParam(value = "vhYyyymm", required = false) String vhYyyymm,
			@RequestParam(value = "partCd") String partCd) {
		List<VHB0020MstDTO> vhb0020List = vhb0020MstService.selectGrid(vhYyyymm, partCd);

		return responseService.getListResult(vhb0020List);
	}

	/**
	 * 배차신청건 상세 조회
	 *
	 * @param applyNo 조회할 신청번호
	 */
	@GetMapping("/{applyNo}")
	public SingleResult<VHB0020SubDTO> selectSubOne(
			@PathVariable("applyNo") String applyNo) {
		// 배차신청건 상세 조회
		VHB0020SubDTO vhb0020 = vhb0020SubService.selectOne(applyNo);

		return responseService.getSingleResult(vhb0020);
	}

	/**
	 * 배차신청건 상세 추가 반영
	 *
	 * @param vhb0020 추가할 배차신청건
	 * @param auth 로그인된 사용자정보를 가져올 때 사용
	 */
	@PostMapping
	public SingleResult<VHB0020SubDTO> insertSubOne(
			@RequestBody VHB0020SubDTO vhb0020,
			@RequestParam(value = "file", required = false) MultipartFile file,
    		@AuthenticationPrincipal Authentication auth) { 
		IamUserDetails user = (IamUserDetails) auth.getPrincipal();
		UutasUserDTO uutasUser = uutasUserService.getUserByEmpNo(user.getUsername());

		// 1. 입력
		int addCnt = vhb0020SubService.insertOne(vhb0020, user.getUsername(), uutasUser.getPartCd());
		if (addCnt == 0) {
			throw new VHB0020InsertFailException();
		}

		// 2. SMS발송
		try {
			vhb0020SubService.sendSms(vhb0020);
		} catch (EAIRunFailException e) {
			throw new VHB0020UpdateFailException("SMS발송 실패 (EAIRunFail)");
		} catch (JsonProcessingException e) {
			throw new VHB0020UpdateFailException("SMS발송 실패 (JsonProcessing)");
		}

		return responseService.getSingleResult(vhb0020);
	}

	/**
	 * 배차신청건 상세 수정 반영
	 *
	 * @param vhb0020 수정할 배차신청건
	 * @param auth 로그인된 사용자정보를 가져올 때 사용
	 */
	@PutMapping
	public CommonResult updateSubOne(
			@RequestBody VHB0020SubDTO vhb0020,
    		@AuthenticationPrincipal Authentication auth) { 
		IamUserDetails user = (IamUserDetails) auth.getPrincipal();
		UutasUserDTO uutasUser = uutasUserService.getUserByEmpNo(user.getUsername());

		// 관리자이거나 자신의 신청 건만 수정가능
		if (!vhb0020SubService.hasMngAuth(uutasUser.getRoleCd())) {
			VHB0020SubDTO _vhb0020 = vhb0020SubService.selectOne(vhb0020.getApplyNo());
			if (_vhb0020 == null) {
				throw new VHB0020UpdateFailException("수정할 배차신청건이 없습니다.");
			}

			if (!_vhb0020.getApplyEmpNo().contentEquals(user.getUsername())) {
				throw new VHB0020UpdateFailException("해당 배차신청건에 대한 수정권한이 없습니다.");
			}
		}

		// 1. 수정
		int updCnt = vhb0020SubService.updateOne(vhb0020, user.getUsername());
		if (updCnt == 0) {
			throw new VHB0020UpdateFailException();
		}

		// 2. SMS발송
		try {
			vhb0020SubService.sendSms(vhb0020);
		} catch (EAIRunFailException e) {
			throw new VHB0020UpdateFailException("SMS발송 실패 (EAIRunFail)");
		} catch (JsonProcessingException e) {
			throw new VHB0020UpdateFailException("SMS발송 실패 (JsonProcessing)");
		}

		return responseService.getSuccessResult();
	}

	@PutMapping("/{applyNo}/upload-file")
	public CommonResult uploadFile(
			@PathVariable("applyNo") String applyNo,
			@RequestParam("file") MultipartFile file,
			@AuthenticationPrincipal Authentication auth) throws FdlException {
		IamUserDetails user = (IamUserDetails) auth.getPrincipal();
		UutasUserDTO uutasUser = uutasUserService.getUserByEmpNo(user.getUsername());

		// 관리자이거나 자신의 신청 건만 파일첨부 가능
		if (!vhb0020SubService.hasMngAuth(uutasUser.getRoleCd())) {
			VHB0020SubDTO _vhb0020 = vhb0020SubService.selectOne(applyNo);
			if (_vhb0020 == null) {
				throw new VHB0020UpdateFailException("파일을 첨부할 배차신청건이 없습니다.");
			}

			if (!_vhb0020.getApplyEmpNo().contentEquals(user.getUsername())) {
				throw new VHB0020UpdateFailException("해당 배차신청건에 대한 파일첨부 권한이 없습니다.");
			}
		}

		if (file != null) {
			try {
				attachService.remove(applyNo);
			} catch (Exception e) {
				log.info("{} 삭제 실패", applyNo);
			}
			try {
				attachService.store(applyNo, file, AtchFileType.ATCHF999, user.getUsername());
			} catch (FdlException e) {
				throw new VHB0020UpdateFailException("배차신청건 파일첨부 실패.");
			}
		}

		return responseService.getSuccessResult();
	}

	@DeleteMapping("/{applyNo}/delete-file")
	public CommonResult deleteFile(
			@PathVariable("applyNo") String applyNo,
			@AuthenticationPrincipal Authentication auth) throws FdlException {
		IamUserDetails user = (IamUserDetails) auth.getPrincipal();
		UutasUserDTO uutasUser = uutasUserService.getUserByEmpNo(user.getUsername());

		// 관리자이거나 자신의 신청 건만 파일삭제 가능
		if (!vhb0020SubService.hasMngAuth(uutasUser.getRoleCd())) {
			VHB0020SubDTO _vhb0020 = vhb0020SubService.selectOne(applyNo);
			if (_vhb0020 == null) {
				throw new VHB0020UpdateFailException("파일을 삭제할 배차신청건이 없습니다.");
			}

			if (!_vhb0020.getApplyEmpNo().contentEquals(user.getUsername())) {
				throw new VHB0020UpdateFailException("해당 배차신청건에 대한 파일삭제 권한이 없습니다.");
			}
		}

		try {
			attachService.remove(applyNo);
		} catch (Exception e) {
			throw new VHB0020DeleteFailException("배차신청건 파일삭제 실패.");
		}

		return responseService.getSuccessResult();
	}

	/**
	 * 배차신청건 상세 삭제 반영
	 *
	 * @param applyNo 삭제할 신청번호
	 * @param auth 로그인된 사용자정보를 가져올 때 사용
	 */
	@DeleteMapping("/{applyNo}")
	public CommonResult deleteSubOne(
			@PathVariable("applyNo") String applyNo,
    		@AuthenticationPrincipal Authentication auth) { 
		IamUserDetails user = (IamUserDetails) auth.getPrincipal();
		UutasUserDTO uutasUser = uutasUserService.getUserByEmpNo(user.getUsername());

		// 관리자이거나 자신의 신청 건만 삭제가능
		if (!vhb0020SubService.hasMngAuth(uutasUser.getRoleCd())) {
			VHB0020SubDTO vhb0020 = vhb0020SubService.selectOne(applyNo);
			if (vhb0020 == null) {
				throw new VHB0020UpdateFailException("삭제할 배차신청건이 없습니다.");
			}
			
			if (!vhb0020.getApplyEmpNo().contentEquals(user.getUsername())) {
				throw new VHB0020DeleteFailException("해당 배차신청건에 대한 삭제권한이 없습니다.");
			}
		}

		// 1. 첨부파일 삭제
		try {
			attachService.remove(applyNo);
		} catch (FdlException e) {
			log.info("{} 파일이 없습니다.", applyNo);
		}

		// 2. 배차신청 삭제
		int delCnt = vhb0020SubService.deleteOne(applyNo);
		if (delCnt == 0) {
			throw new VHB0020DeleteFailException();
		}

    	return responseService.getSuccessResult();
	}

}
