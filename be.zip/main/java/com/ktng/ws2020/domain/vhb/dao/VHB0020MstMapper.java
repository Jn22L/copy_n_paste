package com.ktng.ws2020.domain.vhb.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ktng.ws2020.domain.vhb.model.VHB0020MstDTO;

@Mapper
public interface VHB0020MstMapper {

	/* 1. grid CRUD */
	public List<VHB0020MstDTO> selectGrid(
			@Param("vhYyyymm") String vhYyyymm,
			@Param("partCd") String partCd);
}
