package com.ktng.ws2020.domain.vhb.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ktng.ws2020.domain.common.model.UutasUserDTO;
import com.ktng.ws2020.domain.common.service.UutasUserService;
import com.ktng.ws2020.domain.vhb.model.VHB0030MstDTO;
import com.ktng.ws2020.domain.vhb.model.VHB0030SubDTO;
import com.ktng.ws2020.domain.vhb.service.VHB0030Service;
import com.ktng.ws2020.global.common.response.ListResult;
import com.ktng.ws2020.global.common.response.service.ResponseService;
import com.ktng.ws2020.global.config.security.userdetails.IamUserDetails;


@RestController
@RequestMapping("/api/vhb0030")
public class VHB0030Controller {

	@Autowired
	private VHB0030Service vhb0030Service;

	@Autowired
	private UutasUserService uutasUserService; // 로그인사용자의 부서(depCd) 조회

	@Autowired
	private ResponseService responseService;

	/**
	 * 배차 신청사항 조회
	 *
	 * @param vhYyyymm 검색할 차량출발년월
	 * @param partCd 신청부서
	 */
    @GetMapping("/selectVhb0030MstList")
	public ListResult<VHB0030MstDTO> selectMstGrid(
			@RequestParam(value = "vhYyyymm", required = false) String vhYyyymm,
			@RequestParam(value = "partCd", required = false) String partCd,
    		@AuthenticationPrincipal Authentication auth) {
		IamUserDetails user = (IamUserDetails) auth.getPrincipal();
		UutasUserDTO uutasUser = uutasUserService.getUserByEmpNo(user.getUsername());

		List<VHB0030MstDTO> vhb0030MstList = vhb0030Service.selectMstGrid(vhYyyymm, partCd, uutasUser.getDepCd());

		return responseService.getListResult(vhb0030MstList);
	}
    
	/**
	 * 배차 결과 조회
	 *
	 * @param applyNo 배차신청번호
	 */
    @GetMapping("/selectVhb0030SubList")
	public ListResult<VHB0030SubDTO> selectSubGrid(
			@RequestParam(value = "applyNo", required = false) String applyNo,
    		@AuthenticationPrincipal Authentication auth) {
    	
		List<VHB0030SubDTO> vhb0030SubList = vhb0030Service.selectSubGrid(applyNo);

		return responseService.getListResult(vhb0030SubList);
	}    


}
