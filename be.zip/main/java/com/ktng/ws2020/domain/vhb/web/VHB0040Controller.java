package com.ktng.ws2020.domain.vhb.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ktng.ws2020.global.common.response.ListResult;
import com.ktng.ws2020.global.common.response.service.ResponseService;
import com.ktng.ws2020.global.config.security.userdetails.IamUserDetails;

import com.ktng.ws2020.domain.vhb.model.VHB0040DTO;
import com.ktng.ws2020.domain.vhb.service.VHB0040Service;

@RestController
@RequestMapping("/api/vhb0040")
public class VHB0040Controller {

	@Autowired
	private VHB0040Service vhb0040Service;

	@Autowired
	private ResponseService responseService;

	/**
	 * 조회
	 *
	 * @param vhDeptCd 배차부서
	 * @param vhYyyymm 배차년월
	 */
    @GetMapping("/selectVhb0040MstList")
	public ListResult<VHB0040DTO> selectCalendarMain(
			@RequestParam(value = "vhDeptCd", required = false) String vhDeptCd,
			@RequestParam(value = "vhYyyymm", required = false) String vhYyyymm,
    		@AuthenticationPrincipal Authentication auth) {
		IamUserDetails user = (IamUserDetails) auth.getPrincipal();
		
		List<VHB0040DTO> vhb0040List1 = vhb0040Service.selectCalendarMain(vhDeptCd, vhYyyymm);

		return responseService.getListResult(vhb0040List1);
	}
    
    
	/**
	 * 총 운용차량 조회
	 *
	 * @param vhDeptCd 배차부서
	 */
    @GetMapping("/selectCalendarVhclCnt")
	public ListResult<VHB0040DTO> selectCalendarVhclCnt(
			@RequestParam(value = "vhDeptCd", required = false) String vhDeptCd,
    		@AuthenticationPrincipal Authentication auth) {
		IamUserDetails user = (IamUserDetails) auth.getPrincipal();
		
		List<VHB0040DTO> vhb0040List2 = vhb0040Service.selectCalendarVhclCnt(vhDeptCd);

		return responseService.getListResult(vhb0040List2);
	}
    
	/**
	 * 상세팝업조회
	 *
	 * @param vhDeptCd 배차부서
	 * @param calYyyymmdd 운행일자
	 */
    @GetMapping("/selectCalendarPopup")
	public ListResult<VHB0040DTO> selectCalendarPopup(
			@RequestParam(value = "vhDeptCd", required = false) String vhDeptCd,
			@RequestParam(value = "calYyyymmdd", required = false) String calYyyymmdd,
    		@AuthenticationPrincipal Authentication auth) {
		IamUserDetails user = (IamUserDetails) auth.getPrincipal();
		
		List<VHB0040DTO> vhb0040List3 = vhb0040Service.selectCalendarPopup(vhDeptCd, calYyyymmdd);

		return responseService.getListResult(vhb0040List3);
	}

}
