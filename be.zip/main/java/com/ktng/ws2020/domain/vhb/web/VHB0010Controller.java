package com.ktng.ws2020.domain.vhb.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ktng.ws2020.domain.common.model.UutasUserDTO;
import com.ktng.ws2020.domain.common.service.UutasUserService;
import com.ktng.ws2020.domain.vhb.exception.VHB0010InsertFailException;
import com.ktng.ws2020.domain.vhb.exception.VHB0010UpdateFailException;
import com.ktng.ws2020.domain.vhb.model.VHB0010MstDTO;
import com.ktng.ws2020.domain.vhb.model.VHB0010SubDTO;
import com.ktng.ws2020.domain.vhb.service.VHB0010MstService;
import com.ktng.ws2020.domain.vhb.service.VHB0010SubService;
import com.ktng.ws2020.global.common.response.CommonResult;
import com.ktng.ws2020.global.common.response.ListResult;
import com.ktng.ws2020.global.common.response.SingleResult;
import com.ktng.ws2020.global.common.response.service.ResponseService;
import com.ktng.ws2020.global.config.security.userdetails.IamUserDetails;
import com.ktng.ws2020.global.error.exception.ErrorCode;

@RestController
@RequestMapping("/api/vhb0010")
public class VHB0010Controller {

	@Autowired
	private VHB0010MstService vhb0010MstService; // 게시물 리스트

	@Autowired
	private VHB0010SubService vhb0010SubService; // 게시물 상세
	
	@Autowired
	private UutasUserService uutasUserService; // 게시물 작성자정보 조회

	@Autowired
	private ResponseService responseService;

	/**
	 * 게시물 리스트 조회
	 *
	 * @param vhclDeptCd 검색할 배차부서코드
	 * @param useYn 검색할 사용여부
	 */
	@GetMapping
	public ListResult<VHB0010MstDTO> selectMstGrid(
			@RequestParam(value = "vhclDeptCd", required = false) String vhclDeptCd,
			@RequestParam(value = "sregYear", required = false) String sregYear) {
		List<VHB0010MstDTO> vhb0010List = vhb0010MstService.selectGrid(vhclDeptCd, sregYear);

		return responseService.getListResult(vhb0010List);
	}

	/**
	 * 게시물 상세 조회
	 *
	 * @param boardId 조회할 게시번호
	 */
	@GetMapping("/{boardId}")
	public SingleResult<VHB0010SubDTO> selectSubOne(
			@PathVariable("boardId") String boardId,
    		@AuthenticationPrincipal Authentication auth) {
		IamUserDetails user = (IamUserDetails) auth.getPrincipal();

		// 1. 게시물 상세 조회
		VHB0010SubDTO vhb0010 = vhb0010SubService.selectOne(boardId);

		// 2. 게시물 조회수 증가
		// 본인 게시물이 아닌 경우,
		if (!vhb0010.getRegId().contentEquals(user.getUsername())) {
			// 게시물 조회 시 조회수 1 증가
			vhb0010SubService.increaseViewNum(boardId, user.getUsername());
			
			Long viewNum = Long.valueOf(vhb0010.getViewNum()) + 1;
			vhb0010.setViewNum(String.valueOf(viewNum));
		}

		return responseService.getSingleResult(vhb0010);
	}


}
