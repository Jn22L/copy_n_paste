package com.ktng.ws2020.domain.vhb.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ktng.ws2020.domain.vhb.model.VHB0030MstDTO;
import com.ktng.ws2020.domain.vhb.model.VHB0030SubDTO;

@Mapper
public interface VHB0030Mapper {

	public List<VHB0030MstDTO> selectMstGrid(@Param("vhYyyymm") String vhYyyymm, @Param("partCd") String partCd, @Param("depCd") String depCd);
	public List<VHB0030SubDTO> selectSubGrid(@Param("applyNo") String applyNo);
}
