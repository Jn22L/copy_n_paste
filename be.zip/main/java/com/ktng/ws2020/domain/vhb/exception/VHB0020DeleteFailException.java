package com.ktng.ws2020.domain.vhb.exception;

import com.ktng.ws2020.global.error.exception.BusinessException;
import com.ktng.ws2020.global.error.exception.ErrorCode;

public class VHB0020DeleteFailException extends BusinessException {

	private static final long serialVersionUID = -3998367217556354378L;

	public VHB0020DeleteFailException() {
        super(ErrorCode.VHB0020_DELETE_FAIL);
    }

	public VHB0020DeleteFailException(String message) {
        super(message, ErrorCode.VHB0020_DELETE_FAIL);
    }

}
