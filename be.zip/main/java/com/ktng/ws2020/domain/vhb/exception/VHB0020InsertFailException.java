package com.ktng.ws2020.domain.vhb.exception;

import com.ktng.ws2020.global.error.exception.BusinessException;
import com.ktng.ws2020.global.error.exception.ErrorCode;

public class VHB0020InsertFailException extends BusinessException {

	private static final long serialVersionUID = 5744512898689084947L;

	public VHB0020InsertFailException() {
        super(ErrorCode.VHB0020_INSERT_FAIL);
    }

	public VHB0020InsertFailException(String message) {
        super(message, ErrorCode.VHB0020_INSERT_FAIL);
    }

}
