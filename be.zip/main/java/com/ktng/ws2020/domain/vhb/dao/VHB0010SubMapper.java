package com.ktng.ws2020.domain.vhb.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ktng.ws2020.domain.vhb.model.VHB0010SubDTO;

@Mapper
public interface VHB0010SubMapper {

	// 게시물 상세 조회
	public VHB0010SubDTO selectOne(
			@Param("boardId") String boardId);

	// 조회수 증가
	public int increaseViewNum(
			@Param("boardId") String boardId,
			@Param("altEmpNo") String altEmpNo);

}
