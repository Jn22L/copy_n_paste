package com.ktng.ws2020.domain.vhb.exception;

import com.ktng.ws2020.global.error.exception.BusinessException;
import com.ktng.ws2020.global.error.exception.ErrorCode;

public class VHB0010UpdateFailException extends BusinessException {
	private static final long serialVersionUID = 7202524482335084286L;

	public VHB0010UpdateFailException() {
        super(ErrorCode.VHB0010_UPDATE_FAIL);
    }

	public VHB0010UpdateFailException(String message) {
        super(message, ErrorCode.VHB0010_UPDATE_FAIL);
    }

}
