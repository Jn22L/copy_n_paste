package com.ktng.ws2020.domain.vhb.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ktng.ws2020.domain.vhb.dao.VHB0020SubMapper;
import com.ktng.ws2020.domain.vhb.model.VHB0020SubDTO;
import com.ktng.ws2020.domain.vhc.model.VHC0040SMSDTO;
import com.ktng.ws2020.infra.eai.EaiSmsService;
import com.ktng.ws2020.infra.eai.exception.EAIRunFailException;

@Service
public class VHB0020SubService {

	@Autowired
	private VHB0020SubMapper vhb0020SubMapper;

	@Autowired
	private EaiSmsService eaiSmsService;

	/* 조회 */
	public VHB0020SubDTO selectOne(String boardId) {
		return vhb0020SubMapper.selectOne(boardId);
	}

	/* 추가 */
	public int insertOne(VHB0020SubDTO vhb0020, String regEmpNo, String regDeptCd) {
		return vhb0020SubMapper.insertOne(vhb0020, regEmpNo);
	}

	/* 수정 */
	@Transactional
	public int updateOne(VHB0020SubDTO vhb0020, String altEmpNo) {
		VHB0020SubDTO _vhb0020 = vhb0020SubMapper.selectOne(vhb0020.getApplyNo());
		if (_vhb0020 == null) return 0; // 신청번호가 없으면 수정안함

		return vhb0020SubMapper.updateOne(vhb0020, altEmpNo);
	}

	/* 삭제 */
	public int deleteOne(String boardId) {
		return vhb0020SubMapper.deleteOne(boardId);
	}

	// 유틸
	public void sendSms(VHB0020SubDTO vhb0020) throws EAIRunFailException, JsonProcessingException {
		VHC0040SMSDTO smsContent = vhb0020SubMapper.selectSmsContent(vhb0020.getVhclDeptCd(), vhb0020.getDepatureDt());

		eaiSmsService.sendEaiSmsMsg(smsContent);
	}

	public boolean hasMngAuth(String roleCd) {
		switch (roleCd) {
		case "ADMIN_ROLE":
		case "MNG_ROLE":
			return true;
//		case "ADMIN_COMM_ROLE":
//		case "USR_ROLE":
		default:
			return false;
		}
	}

}
