package com.ktng.ws2020.domain.vhb.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ktng.ws2020.domain.vhb.model.VHB0010MstDTO;

@Mapper
public interface VHB0010MstMapper {

	/* 1. grid CRUD */
	public List<VHB0010MstDTO> selectGrid(
			@Param("vhclDeptCd") String vhclDeptCd, // 관리부서코드 
			@Param("sregYear") String sregYear // 등록년도 (yyyy)
		);

}
