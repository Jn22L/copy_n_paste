package com.ktng.ws2020.domain.attach.exception;

public class FileRemoveException extends RuntimeException {

	private static final long serialVersionUID = 2131866370944693267L;

	public FileRemoveException(String message) {
		super(message);
	}

	public FileRemoveException(String message, Throwable cause) {
		super(message, cause);
	}
}
