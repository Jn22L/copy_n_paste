package com.ktng.ws2020.domain.attach.service;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.ktng.ws2020.da.dao.AttachRepository;
import com.ktng.ws2020.da.model.AttachEntity;
import com.ktng.ws2020.da.model.enums.AtchFileType;
import com.ktng.ws2020.domain.attach.exception.FileDownloadException;
import com.ktng.ws2020.domain.attach.exception.FileUploadException;
import com.ktng.ws2020.global.util.FileUtils;

import egovframework.rte.fdl.cmmn.exception.FdlException;

@Service
public class AttachService {
    
    @Autowired
    AttachRepository attachRepository;
    
    private final Path fileLocation;
    
    public AttachService(@Value("${file.upload-dir}")String uploadDir)  {
        this.fileLocation = Paths.get(uploadDir)
                .toAbsolutePath().normalize();
        try {
            Files.createDirectories(this.fileLocation);
        }catch(Exception e) {
            throw new FileUploadException("파일을 업로드할 디렉토리를 생성하지 못했습니다.", e);
        }
    }

    public AttachEntity store(MultipartFile file, AtchFileType fileType, String empCode) throws FdlException {
    	Long attachNo = attachRepository.findNextId(); // attachNoGnrService.getNextStringId(); // 첨부문서번호 체번

        return this.store(String.valueOf(attachNo), file, fileType, empCode);
    }
    public AttachEntity store(String attachNo, MultipartFile file, AtchFileType fileType, String empCode) throws FdlException {
        String originalfileName = StringUtils.cleanPath(file.getOriginalFilename());
        String[] storeFileResult = FileUtils.storeFile(attachNo, this.fileLocation, file);
        String saveFileNm = storeFileResult[0];
        String filePath = storeFileResult[1];
        
        // AttachEntity 저장
        AttachEntity ae = AttachEntity.builder()
                .attachNo(attachNo)
                .saveFileNm(saveFileNm)
                .fileNm(originalfileName)
                .filePath(filePath)
                .contentType(file.getContentType())
                .fileSize(file.getSize())
                .fileType(fileType)
                .downCnt(0L)
                .edmsYn(false)
                .modId(empCode)
                .regId(empCode)
                .build();
        attachRepository.save(ae);
        
        return ae;
    }
    
    public Resource loadAttachNoAsResource(AttachEntity ae) {

    	//다운로드 카운트를 +1 함.
        ae.setDownCnt(ae.getDownCnt()==null ? 1 : ae.getDownCnt()+1);
        attachRepository.save(ae);
        
        Resource file = FileUtils.loadFilePathAsResource( ae.getFilePath() );
        
        return file;
    }

    // attachNo가 있는 상태에서 파일삭제 처리
    // 삭제된 AttachEntity 반환
    public AttachEntity remove(String attachNo) throws FdlException {

        AttachEntity ae = attachRepository.findById(attachNo)
                .orElseThrow(() -> new FileDownloadException(attachNo+"의 파일정보를 찾을 수 없습니다."));

        if(FileUtils.removeFile(this.fileLocation, ae.getSaveFileNm())){
            attachRepository.delete(ae);
            return ae;
        }
        return null;
    }

    // TODO : attachNo가 있는 상태에서 파일업로드 처리 
    // TODO : 첨부문서리스트 List<MultipartFile> 파일업로드 처리
    
    public class AttachDownResult {
        public AttachEntity ae;
        public Resource file;

        public AttachDownResult(AttachEntity ae, Resource file) {
            this.ae = ae;
            this.file = file;
        }
    }

}