package com.ktng.ws2020.domain.attach.exception;

import com.ktng.ws2020.global.error.exception.BusinessException;
import com.ktng.ws2020.global.error.exception.ErrorCode;

public class FileNotFoundException extends BusinessException {

	private static final long serialVersionUID = 7730201941889467086L;

	public FileNotFoundException(String message) {
        super(message, ErrorCode.FILE_NOT_FOUND);
    }
}
