package com.ktng.ws2020.domain.attach.model;

import com.ktng.ws2020.da.model.AttachEntity;
import com.ktng.ws2020.da.model.enums.AtchFileType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AttachDTO {
    
    private String attachNo;
    private String fileNm;
    private Long fileSize;
    private AtchFileType fileType;
    private Long downCnt;
    private boolean edmsYn;
    
    public static AttachDTO of(final AttachEntity en) {
        AttachDTO dto = AttachDTO.builder()
                .attachNo(en.getAttachNo())
                .fileNm(en.getFileNm())
                .fileSize(en.getFileSize())
                .fileType(en.getFileType())
                .downCnt(en.getDownCnt())
                .edmsYn(en.isEdmsYn())
                .build();
        
        return dto;
    }
}
