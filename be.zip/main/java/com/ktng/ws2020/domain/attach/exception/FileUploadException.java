package com.ktng.ws2020.domain.attach.exception;

public class FileUploadException extends RuntimeException {
    
	private static final long serialVersionUID = -2125650150617959323L;

	public FileUploadException(String message) {
        super(message);
    }
    
    public FileUploadException(String message, Throwable cause) {
        super(message, cause);
    }
    
}