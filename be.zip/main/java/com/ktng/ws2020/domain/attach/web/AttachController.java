package com.ktng.ws2020.domain.attach.web;

import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.ktng.ws2020.da.dao.AttachRepository;
import com.ktng.ws2020.da.model.AttachEntity;
import com.ktng.ws2020.da.model.enums.AtchFileType;
import com.ktng.ws2020.domain.attach.exception.FileDownloadException;
import com.ktng.ws2020.domain.attach.exception.FileNotFoundException;
import com.ktng.ws2020.domain.attach.exception.FileRemoveException;
import com.ktng.ws2020.domain.attach.exception.FileUploadException;
import com.ktng.ws2020.domain.attach.model.AttachDTO;
import com.ktng.ws2020.domain.attach.service.AttachService;
import com.ktng.ws2020.global.common.response.CommonResult;
import com.ktng.ws2020.global.common.response.ListResult;
import com.ktng.ws2020.global.common.response.SingleResult;
import com.ktng.ws2020.global.common.response.service.ResponseService;
import com.ktng.ws2020.global.config.security.userdetails.IamUserDetails;
import com.ktng.ws2020.global.util.FileNameEncoder;
import com.ktng.ws2020.global.util.MediaUtils;

import egovframework.rte.fdl.cmmn.exception.FdlException;
import eu.bitwalker.useragentutils.UserAgent;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(value = "/api/attach")
public class AttachController {

	@Autowired
	AttachService attachService;

//    @Autowired
//    EDMSAtchService edmsAtchService; 

	@Autowired
	AttachRepository attachRepository;

	@Autowired
	private ResponseService responseService;

	@PostMapping("/upload")
	public SingleResult<AttachDTO> uploadFile(
			@RequestParam(value = "attachNo", required = false) String attachNo,
			@RequestParam("file") MultipartFile file,
			@AuthenticationPrincipal Authentication auth) throws FdlException {
		IamUserDetails user = (IamUserDetails) auth.getPrincipal();

		AttachEntity ae = null;
		if (attachNo == null) {
			ae = attachService.store(file, AtchFileType.ATCHF999, user.getUsername());
		} else {
			if (attachRepository.findById(attachNo).isPresent()) {
				throw new FileUploadException(attachNo + " 파일이 이미 존재하고 있습니다.");
			}
			ae = attachService.store(attachNo, file, AtchFileType.ATCHF999, user.getUsername());
		}

		return responseService.getSingleResult(AttachDTO.of(ae));
	}

//    @PostMapping("/upload-edms")
//    public SingleResult<AttachDTO> uploadEDMSFile(
//            @RequestParam("file") MultipartFile file,
//			@AuthenticationPrincipal Authentication auth) throws FdlException, JsonMappingException, UnsupportedEncodingException, JsonProcessingException, FileUploadException {
//    	
//		IamUserDetails user = (IamUserDetails) auth.getPrincipal();
//        String loginUid = user.getUsername();
//        
//        AttachEntity ae = edmsAtchService.store(file, AtchFileType.EDMSF001, loginUid);
//    	
//    	return responseService
//                .getSingleResult( AttachDTO.of(ae) );
//    }

//	@PostMapping("/uploadfiles")
//	public ListResult<AttachDTO> uploadFiles(@RequestParam("files") MultipartFile[] files,
//			@AuthenticationPrincipal Authentication auth) throws FdlException {
//		IamUserDetails user = (IamUserDetails) auth.getPrincipal();
//
//		List<AttachDTO> list = new ArrayList<AttachDTO>();
//		for (int i = 0; i < files.length; i++) {
//			MultipartFile file = files[i];
//			log.info(file.toString());
//			AttachEntity ae = attachService.store(file, AtchFileType.ATCHF999, user.getUsername());
//			if (ae != null) {
//				list.add(AttachDTO.of(ae));
//			}
//		}
//
//		return responseService.getListResult(list);
//	}

	@GetMapping("/{attachNo}")
	public SingleResult<AttachDTO> getAttachDTO(@PathVariable String attachNo) {
		AttachEntity ae = attachRepository.findById(attachNo)
				.orElseThrow(() -> new FileNotFoundException(attachNo + "의 파일정보를 찾을 수 없습니다."));

		return responseService.getSingleResult(AttachDTO.of(ae));
	}

	@GetMapping("/")
	public ListResult<AttachDTO> getAttachDTOs(String[] attachNos) {
		List<AttachDTO> list = attachRepository.findAllById(Arrays.asList(attachNos)).stream().map(AttachDTO::of)
				.collect(Collectors.toList());

		return responseService.getListResult(list);
	}

	@GetMapping("/down/{attachNo}")
	public ResponseEntity<Resource> getFile(@PathVariable String attachNo, HttpServletRequest request)
			throws UnsupportedEncodingException {
		AttachEntity ae = attachRepository.findById(attachNo)
				.orElseThrow(() -> new FileDownloadException(attachNo + "의 파일정보를 찾을 수 없습니다."));

		Resource file = null;
		if (ae.isEdmsYn()) {
			// EDMS 파일다운로드
//    		file = edmsAtchService.loadAttachNoAsResource(ae);
			return ResponseEntity.status(HttpStatus.NOT_IMPLEMENTED).build();
		} else {
			file = attachService.loadAttachNoAsResource(ae);
		}

		HttpHeaders headers = new HttpHeaders();
		UserAgent userAgent = UserAgent.parseUserAgentString(request.getHeader("User-Agent"));

		String fileName = FileNameEncoder.encode(userAgent.getBrowser().getGroup(), ae.getFileNm());
		headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"");
		if (MediaUtils.containsImageMediaType(ae.getContentType())) {
			headers.setContentType(MediaType.valueOf(ae.getContentType()));
		} else {
			headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
		}

		return ResponseEntity.ok().headers(headers).body(file);
	}

	@DeleteMapping
	public CommonResult deleteFiles(@RequestParam(value = "attachNos", required = false) String[] attachNos) {
		// TODO: 파일삭제권한 체크

		Stream.of(attachNos).forEach(attachNo -> {
			try {
				attachService.remove(attachNo);
			} catch (FdlException e) {
				throw new FileRemoveException(attachNo + "파일 삭제 실패");
			}
		});
		
		return responseService.getSuccessResult();
	}

}
