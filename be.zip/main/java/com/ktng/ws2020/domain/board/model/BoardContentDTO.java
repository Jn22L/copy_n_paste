package com.ktng.ws2020.domain.board.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ktng.ws2020.da.model.BoardContentEntity;
import com.ktng.ws2020.da.model.BoardMasterEntity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class BoardContentDTO {

	private String brdCtsNo;
	private BoardMasterEntity brdMstrNo;
	private String brdCtsGrp;
	private Integer brdCtsSorts;
	private Integer brdCtsDepth;
	private String brdTitle;
	private String brdSummary;
	private String brdContent;
	private Long brdHit;
	private String modId;
	private String regId;
	private String regNm;
	
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="Asia/Seoul")
    private Date modDate;
    
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="Asia/Seoul")
    private Date regDate;
    
	public void setBrdCtsGrp(String brdCtsGrp) {
		this.brdCtsGrp = brdCtsGrp;
	}    
    
	public BoardContentEntity insertAs(
			String brdCtsNo,
			BoardMasterEntity brdMstrNo,
			String brdCtsGrp,
			Integer brdCtsSorts,
			String regId
	) {
		return BoardContentEntity.builder()
				.brdCtsNo(brdCtsNo)
        		.brdMstrNo(brdMstrNo)
        		.brdCtsGrp(brdCtsGrp)
        		.brdCtsSorts(brdCtsSorts)
        		.brdCtsDepth(this.brdCtsDepth)
        		.brdTitle(this.brdTitle)
        		.brdSummary(this.brdSummary)
        		.brdContent(this.brdContent)
        		.brdHit(0l)
    			.regId(regId)
                .build();
	}

	public BoardContentEntity updateAs(
			String modId
	) {
		return BoardContentEntity.builder()
				.brdCtsNo(this.brdCtsNo)
        		.brdMstrNo(this.brdMstrNo)
        		.brdCtsGrp(this.brdCtsGrp)
        		.brdCtsSorts(this.brdCtsSorts)
        		.brdCtsDepth(this.brdCtsDepth)
        		.brdTitle(this.brdTitle)
        		.brdSummary(this.brdSummary)
        		.brdContent(this.brdContent)
        		.brdHit(this.brdHit)
        		.regDate(this.regDate)
    			.regId(this.regId)
    			.modId(modId)
                .build();
	}

    public static BoardContentDTO of(final BoardContentEntity en, String regNm) {
    	BoardContentDTO dto = BoardContentDTO.builder()
    			.brdCtsNo(en.getBrdCtsNo())
    			.brdMstrNo(en.getBrdMstrNo())
    			.brdCtsGrp(en.getBrdCtsGrp())
    			.brdCtsSorts(en.getBrdCtsSorts())
    			.brdCtsDepth(en.getBrdCtsDepth())
    			.brdTitle(en.getBrdTitle())
    			.brdSummary(en.getBrdSummary())
    			.brdContent(en.getBrdContent())
    			.brdHit(en.getBrdHit())
    			.modDate(en.getModDate())
    			.modId(en.getModId())
    			.regDate(en.getRegDate())
    			.regId(en.getRegId())
    			.regNm(regNm)
    			.build();
        return dto;
    }

}
