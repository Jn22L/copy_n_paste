package com.ktng.ws2020.domain.board.web;


import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ktng.ws2020.da.dao.BoardContentRepository;
import com.ktng.ws2020.da.dao.BoardMasterRepository;
import com.ktng.ws2020.da.model.BoardContentEntity;
import com.ktng.ws2020.da.model.BoardMasterEntity;
import com.ktng.ws2020.domain.board.model.BoardContentDTO;
import com.ktng.ws2020.domain.board.model.BoardContentListDTO;
import com.ktng.ws2020.domain.board.model.enums.ContentSearchType;
import com.ktng.ws2020.domain.board.service.BoardContentService;
import com.ktng.ws2020.global.common.response.CommonResult;
import com.ktng.ws2020.global.common.response.SingleResult;
import com.ktng.ws2020.global.common.response.service.ResponseService;
import com.ktng.ws2020.global.config.security.userdetails.IamUserDetails;
import com.ktng.ws2020.global.error.exception.EntityNotFoundException;

import egovframework.rte.fdl.cmmn.exception.FdlException;
import egovframework.rte.fdl.idgnr.EgovIdGnrService;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(value = "/api/board/content")
public class BoardContentController {
    
//    @Autowired
//    private BoardContentRepository boardContentRepository;
    
//    @Autowired
//    private BoardMasterRepository boardMasterRepository;

     @Autowired
     private BoardContentService boardContentService;

    @Autowired
    private ResponseService responseService;

    @Resource(name = "brdCtsNoGnrService")
    EgovIdGnrService brdCtsNoGnrService;
    
    // GET /board/content/{brdMstrNo}/list
    // boardCate의 모든 게시물을 조회한다.
    @GetMapping(value = "/{brdMstrNo}/list")
    public SingleResult<Page<BoardContentListDTO>> findBrdCtsListDTOBybrdMstrNo(
            @PathVariable String brdMstrNo, final Pageable pageable,
            @RequestParam(required = false) ContentSearchType searchType, 
            @RequestParam(required = false) String searchText) {
    	
    	BoardMasterEntity boardMasterEntity = null; // boardMasterRepository.findByBrdMstrNo(brdMstrNo);
    	
        Page<BoardContentListDTO> boardPage = boardContentService.findBoardList(boardMasterEntity, pageable, searchType, searchText);

        return responseService.getSingleResult(boardPage);
    }
    
    // GET /board/content/{brdMstrNo}/{brdCtsNo}
    // brdCtsNo로 게시물을 조회한다.
    @GetMapping(value = "/{brdMstrNo}/{brdCtsNo}")
    public SingleResult<BoardContentDTO> findBoardContentDTO(
            @PathVariable String brdMstrNo, @PathVariable String brdCtsNo,
            @AuthenticationPrincipal Authentication authentication){
    	
    	IamUserDetails principal = (IamUserDetails)authentication.getPrincipal();
        String loginUid = principal.getUsername();
        
        BoardMasterEntity boardMasterEntity = null; // boardMasterRepository.findByBrdMstrNo(brdMstrNo);
        
        BoardContentDTO dto = boardContentService.findBoardDTO(boardMasterEntity, brdCtsNo, loginUid);
        
        return responseService.getSingleResult(dto);
    }
    
    // POST /board/content/{brdMstrNo}/{brdCtsNo}
    // 게시물을 입력한다.
    @PostMapping(value = "/{brdMstrNo}")
    public SingleResult<BoardContentDTO> insert(
            @PathVariable String brdMstrNo, @RequestBody BoardContentDTO dto,
            @AuthenticationPrincipal Authentication authentication
            ) throws FdlException{
        
    	
    	IamUserDetails principal = (IamUserDetails)authentication.getPrincipal();
        String loginUid = principal.getUsername();
        
        BoardMasterEntity boardMasterEntity = null; // boardMasterRepository.findByBrdMstrNo(brdMstrNo);
        
        String brdCtsNo = brdCtsNoGnrService.getNextStringId(); // 게시물번호 체번
        
        //원글일때 ctsGrp에 자기글번호 등록
        String brdCtsGrp = dto.getBrdCtsGrp();
        Integer brdCtsSorts = 0;
        if (brdCtsGrp == null || brdCtsGrp.isEmpty()) {
        	brdCtsGrp = new String(brdCtsNo);
        }

        BoardContentEntity en = dto.insertAs(brdCtsNo, boardMasterEntity, brdCtsGrp, brdCtsSorts, loginUid);
//        en = boardContentRepository.save(en);
        dto = BoardContentDTO.of(en, null);
        
        return responseService.getSingleResult(dto);
    }
    
    // PUT /board/content/{brdMstrNo}
    // 게시물을 수정한다.
    @PutMapping(value = "/{brdMstrNo}")
    public SingleResult<BoardContentDTO> update(
            @PathVariable String brdMstrNo, @RequestBody BoardContentDTO dto,
            @AuthenticationPrincipal Authentication authentication){
        
    	IamUserDetails principal = (IamUserDetails)authentication.getPrincipal();
        String loginUid = principal.getUsername();
        
    	BoardContentEntity en = null; // boardContentRepository.save(dto.updateAs(loginUid));
        dto = BoardContentDTO.of(en, null);
        
        return responseService.getSingleResult(dto);
    }
    
    // DELETE /board/content/{brdMstrNo}/{brdCtsNo}
    @DeleteMapping(value = "/{brdMstrNo}/{brdCtsNo}")
    public CommonResult delete(
            @PathVariable String brdMstrNo, @PathVariable String brdCtsNo){
        
    	BoardMasterEntity boardMasterEntity = null; // boardMasterRepository.findByBrdMstrNo(brdMstrNo);
    	
    	BoardContentEntity en = null; // boardContentRepository.findByBrdMstrNoAndBrdCtsNo(boardMasterEntity, brdCtsNo);
        if (en == null) {
            throw new EntityNotFoundException(brdCtsNo+"의 게시물을 찾을수 없습니다.");
        }
//        boardContentRepository.delete(en);
        return responseService.getSuccessResult();
    }

}
