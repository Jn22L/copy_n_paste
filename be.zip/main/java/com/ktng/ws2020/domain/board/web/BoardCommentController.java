package com.ktng.ws2020.domain.board.web;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ktng.ws2020.da.dao.BoardCommentRepository;
import com.ktng.ws2020.da.dao.BoardContentRepository;
import com.ktng.ws2020.da.dao.BoardMasterRepository;
import com.ktng.ws2020.da.model.BoardCommentEntity;
import com.ktng.ws2020.da.model.BoardContentEntity;
import com.ktng.ws2020.da.model.BoardMasterEntity;
import com.ktng.ws2020.domain.board.model.BoardCommentDTO;
import com.ktng.ws2020.domain.board.model.BoardCommentListDTO;
import com.ktng.ws2020.domain.board.service.BoardCommentService;
import com.ktng.ws2020.global.common.response.CommonResult;
import com.ktng.ws2020.global.common.response.SingleResult;
import com.ktng.ws2020.global.common.response.service.ResponseService;
import com.ktng.ws2020.global.config.security.userdetails.IamUserDetails;
import com.ktng.ws2020.global.error.exception.EntityNotFoundException;

import egovframework.rte.fdl.cmmn.exception.FdlException;
import egovframework.rte.fdl.idgnr.EgovIdGnrService;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(value = "/api/board/comment")
public class BoardCommentController {
    
//	@Autowired
//    private BoardMasterRepository boardMasterRepository;
	
//    @Autowired
//    private BoardContentRepository boardContentRepository;
    
//    @Autowired
//    private BoardCommentRepository boardCommentRepository;

    @Autowired
    private BoardCommentService boardCommentService;
    
    @Autowired
    private ResponseService responseService;

    @Resource(name = "brdCmtNoGnrService")
    EgovIdGnrService brdCmtNoGnrService;
    
    // GET /board/comment/{brdMstrNo}/{brdCtsNo}/list
    // brdCtsNo의 모든 댓글을 조회한다.
    @GetMapping(value = "/{brdMstrNo}/{brdCtsNo}/list")
    public SingleResult<Page<BoardCommentListDTO>> findBrdCmtListDTO(
            @PathVariable String brdMstrNo, @PathVariable String brdCtsNo,
            final Pageable pageable,
            @AuthenticationPrincipal Authentication authentication){
    	
        BoardMasterEntity boardMasterEntity = null; // boardMasterRepository.findByBrdMstrNo(brdMstrNo);
        BoardContentEntity boardContentEntity = null; // boardContentRepository.findByBrdMstrNoAndBrdCtsNo(boardMasterEntity, brdCtsNo);

        Page<BoardCommentListDTO> boardCommentPage = boardCommentService.findBoardCommentList(boardMasterEntity, boardContentEntity, pageable);

        return responseService.getSingleResult(boardCommentPage);
    }
    
    // POST /board/comment/{brdMstrNo}/{brdCtsNo}
    // 댓글을 입력한다.
    @PostMapping(value = "/{brdMstrNo}/{brdCtsNo}")
    public SingleResult<BoardCommentDTO> insert(
            @PathVariable String brdMstrNo, @PathVariable String brdCtsNo,
            @RequestBody BoardCommentDTO dto,
            @AuthenticationPrincipal Authentication authentication
            ) throws FdlException{
        
    	
    	IamUserDetails principal = (IamUserDetails)authentication.getPrincipal();
        String loginUid = principal.getUsername();
        
        BoardMasterEntity boardMasterEntity = null; // boardMasterRepository.findByBrdMstrNo(brdMstrNo);
        BoardContentEntity boardContentEntity = null; // boardContentRepository.findByBrdMstrNoAndBrdCtsNo(boardMasterEntity, brdCtsNo);

        String brdCmtNo = brdCmtNoGnrService.getNextStringId(); // 댓글번호 체번
        
        //원 댓글일때 ctsGrp에 자기글번호 등록
        String brdCmtGrp = dto.getBrdCmtGrp();
        Integer brdCmtSorts = 0;
        if (brdCmtGrp == null || brdCmtGrp.isEmpty()) {
        	brdCmtGrp = new String(brdCmtNo);
        }

        BoardCommentEntity en = dto.insertAs(brdCmtNo, boardMasterEntity, boardContentEntity, brdCmtGrp, brdCmtSorts, loginUid);
//        en = boardCommentRepository.save(en);
        dto = BoardCommentDTO.of(en, null);
        
        return responseService.getSingleResult(dto);
    }

    // PUT /board/comment
    // 게시물을 수정한다.
    @PutMapping
    public SingleResult<BoardCommentDTO> update(
            @RequestBody BoardCommentDTO dto,
            @AuthenticationPrincipal Authentication authentication){

    	IamUserDetails principal = (IamUserDetails)authentication.getPrincipal();
        String loginUid = principal.getUsername();

//    	BoardCommentEntity en = boardCommentRepository.save(dto.updateAs(loginUid));
//        dto = BoardCommentDTO.of(en, null);

        return responseService.getSingleResult(dto);
    }

    // DELETE /board/comment/{brdMstrNo}/{brdCtsNo}/{brdCmtNo}
    @DeleteMapping(value = "/{brdMstrNo}/{brdCtsNo}/{brdCmtNo}")
    public CommonResult delete(
            @PathVariable String brdMstrNo, @PathVariable String brdCtsNo, @PathVariable String brdCmtNo){

    	BoardMasterEntity boardMasterEntity = null; // boardMasterRepository.findByBrdMstrNo(brdMstrNo);
    	BoardContentEntity boardContentEntity = null; // boardContentRepository.findByBrdMstrNoAndBrdCtsNo(boardMasterEntity, brdCtsNo);

    	BoardCommentEntity en = null; // boardCommentRepository.findByBrdMstrNoAndBrdCtsNoAndBrdCmtNo(boardMasterEntity, boardContentEntity, brdCmtNo);
        if (en == null) {
            throw new EntityNotFoundException(brdCmtNo+"의 댓글을 찾을수 없습니다.");
        }
//        boardCommentRepository.delete(en);
        return responseService.getSuccessResult();
    }

}
