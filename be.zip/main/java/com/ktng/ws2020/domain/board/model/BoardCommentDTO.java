package com.ktng.ws2020.domain.board.model;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ktng.ws2020.da.model.BoardCommentEntity;
import com.ktng.ws2020.da.model.BoardContentEntity;
import com.ktng.ws2020.da.model.BoardMasterEntity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class BoardCommentDTO {

	private String brdCmtNo;
	private BoardMasterEntity brdMstrNo;
	private BoardContentEntity brdCtsNo;
	private String brdCmtGrp;
	private Integer brdCmtSorts;
	private Integer brdCmtDepth;
	private String brdComment;
	private String modId;
	private String regId;
	private String regNm;
	
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="Asia/Seoul")
    private Date modDate;
    
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="Asia/Seoul")
    private Date regDate;

	public BoardCommentEntity insertAs(
			String brdCmtNo,
			BoardMasterEntity brdMstrNo,
			BoardContentEntity brdCtsNo,
			String brdCmtGrp,
			Integer brdCmtSorts,
			String regId
	) {
		return BoardCommentEntity.builder()
				.brdCmtNo(brdCmtNo)
				.brdMstrNo(brdMstrNo)
        		.brdCtsNo(brdCtsNo)
        		.brdCmtGrp(brdCmtGrp)
        		.brdCmtSorts(brdCmtSorts)
        		.brdCmtDepth(this.brdCmtDepth)
        		.brdComment(this.brdComment)
        		.regId(regId)
                .build();
	}

	public BoardCommentEntity updateAs(
			String modId
	) {
		return BoardCommentEntity.builder()
				.brdCmtNo(this.brdCmtNo)
				.brdMstrNo(this.brdMstrNo)
        		.brdCtsNo(this.brdCtsNo)
        		.brdCmtGrp(this.brdCmtGrp)
        		.brdCmtSorts(this.brdCmtSorts)
        		.brdCmtDepth(this.brdCmtDepth)
        		.brdComment(this.brdComment)
        		.regDate(this.regDate)
        		.regId(this.regId)
        		.modId(modId)
                .build();
	}

	public static BoardCommentDTO of(final BoardCommentEntity en, String regNm) {
    	BoardCommentDTO dto = BoardCommentDTO.builder()
    			.brdCmtNo(en.getBrdCmtNo())
    			.brdMstrNo(en.getBrdMstrNo())
    			.brdCtsNo(en.getBrdCtsNo())
    			.brdCmtGrp(en.getBrdCmtGrp())
    			.brdCmtSorts(en.getBrdCmtSorts())
    			.brdCmtDepth(en.getBrdCmtDepth())
    			.brdComment(en.getBrdComment())
    			.modId(en.getModId())
    			.regId(en.getRegId())
    			.modDate(en.getModDate())
    			.regDate(en.getRegDate())
    			.regNm(regNm)
    			.build();
        return dto;
    }
    
}
