package com.ktng.ws2020.domain.board.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.ktng.ws2020.da.dao.BoardContentRepository;
import com.ktng.ws2020.da.dao.IamUserRepository;
import com.ktng.ws2020.da.model.BoardContentEntity;
import com.ktng.ws2020.da.model.BoardMasterEntity;
import com.ktng.ws2020.da.model.IamUserEntity;
import com.ktng.ws2020.domain.board.model.BoardContentDTO;
import com.ktng.ws2020.domain.board.model.BoardContentListDTO;
import com.ktng.ws2020.domain.board.model.enums.ContentSearchType;
import com.ktng.ws2020.global.error.exception.EntityNotFoundException;
import com.ktng.ws2020.global.util.PageableUtils;

import lombok.extern.slf4j.Slf4j;

// JPA만 사용한 예제
@Slf4j
@Service
public class BoardContentService {

//    @Autowired
//    BoardContentRepository boardContentRepository;

    @Autowired
    private IamUserRepository iamUserRepository;

    public Page<BoardContentListDTO> findBoardList(
    		BoardMasterEntity boardMasterEntity, final Pageable pageable, 
            ContentSearchType searchType, String searchText){
        
    	// 조회 시 brdCtsNo 오름차순 정렬 필수
    	List<BoardContentListDTO> boardList = null;
    	if (searchText==null || searchText.length() == 0) {
            boardList = null; // boardContentRepository.findBoardList(boardMasterEntity);            
        }
        else if (      ContentSearchType.ALL     == searchType) {
        	boardList = null; // boardContentRepository.findBoardListCateLikeAll(
//            		boardMasterEntity, "%"+searchText+"%");
        }
        else if (ContentSearchType.TITLE   == searchType) {
        	boardList = null; // boardContentRepository.findBoardListCateLikeTitle(
//            		boardMasterEntity, "%"+searchText+"%");
        }
        else if (ContentSearchType.CONTENT == searchType) {
        	boardList = null; // boardContentRepository.findBoardListCateLikeContent(
//            		boardMasterEntity, "%"+searchText+"%");
        }else { //if (ContentSearchType.WRITTER == searchType) {
        	boardList = null; // boardContentRepository.findBoardListCateLikeRegId(
//            		boardMasterEntity, "%"+searchText+"%");
        }
        
    	List<BoardContentListDTO> result = new ArrayList<>();

    	// 답글 정렬
    	// TODO: 게시글 정렬하는 이중for문 로직 개선 필요
    	boardList.forEach(board -> {
    		if (board.getBrdCtsNo().equals(board.getBrdCtsGrp())) { // 상위 게시글이 없으면
    			result.add(0, board); // 맨 앞에 삽입
    		} else { // 상위 게시글이 있으면
    			String pBrdCtsNo = board.getBrdCtsGrp(); // 상위 게시글 id
    			int pDepth = board.getBrdCtsDepth() - 1; // 상위 게시글 depth

    			// 상위 게시글 위치 탐색
    			int pIdx = -1;
    			for (int i = 0; i < result.size(); i++) {
    				if (result.get(i).getBrdCtsNo().equals(pBrdCtsNo)) {
    					pIdx = i;
    					break;
    				}
    			}

				result.add(pIdx + 1, board); // 상위 게시글 다음 인덱스에 삽입
    		}
    	});
    	
    	return PageableUtils.extractPage(result, pageable);
    }

    public BoardContentDTO findBoardDTO(BoardMasterEntity boardMasterEntity, String brdCtsNo, String loginUid) {
    	
    	BoardContentEntity en = null; // boardContentRepository.findByBrdMstrNoAndBrdCtsNo(boardMasterEntity, brdCtsNo);
    	
        if (en == null) {
            throw new EntityNotFoundException(brdCtsNo+"의 게시물을 찾을수 없습니다.");
        }
        // 게시글 조회수 증가(자신이 조회할 때 제외)
        if ( !loginUid.equals( en.getRegId() ) ) {
            en.setBrdHit( en.getBrdHit() + 1 );
//            boardContentRepository.save(en);
        }
        // 사용자 명 찾기
        String empNo = en.getRegId();
        if (empNo == null) {
        	throw new EntityNotFoundException("게시물 작성자를 찾을 수 없습니다.");
        }

        IamUserEntity ue = iamUserRepository.findById( empNo ).orElse(null);

        // BoardContentEntity -> BoardContentDTO
        BoardContentDTO dto = BoardContentDTO.of(en, (ue==null) ? "unknown" : ue.getUserNm());
        
        return dto;
    }
}
