package com.ktng.ws2020.domain.board.model.enums;

public enum ContentSearchType {
	ALL, TITLE, CONTENT, WRITTER
}
