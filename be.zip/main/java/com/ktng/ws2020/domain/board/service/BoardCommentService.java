package com.ktng.ws2020.domain.board.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.ktng.ws2020.da.dao.BoardCommentRepository;
import com.ktng.ws2020.da.model.BoardContentEntity;
import com.ktng.ws2020.da.model.BoardMasterEntity;
import com.ktng.ws2020.domain.board.model.BoardCommentListDTO;
import com.ktng.ws2020.global.util.PageableUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class BoardCommentService {

//    @Autowired
//    BoardCommentRepository boardCommentRepository;

    public Page<BoardCommentListDTO> findBoardCommentList(
    		BoardMasterEntity brdMstrNo, BoardContentEntity brdCtsNo, Pageable pageable) {
    	
    	// 조회 시 brdCmtNo 오름차순 정렬 필수
    	List<BoardCommentListDTO> boardCommentList = null; // boardCommentRepository.findBoardCommentList(brdMstrNo, brdCtsNo);
    	List<BoardCommentListDTO> result = new ArrayList<>();
    	
    	// 답댓글 정렬
    	// TODO: 댓글 정렬하는 이중for문 로직 개선 필요
    	boardCommentList.forEach(comment -> {
    		if (comment.getBrdCmtNo().equals(comment.getBrdCmtGrp())) { // 상위 댓글이 없으면
    			result.add(0, comment); // 맨 앞에 삽입
    		} else { // 상위 댓글이 있으면
    			String pBrdCmtNo = comment.getBrdCmtGrp(); // 상위 댓글 ID

    			// 상위 댓글 위치 탐색
    			int pIdx = -1;
    			for (int i = 0; i < result.size(); i++) {
    				if (result.get(i).getBrdCmtNo().equals(pBrdCmtNo)) {
    					pIdx = i;
    					break;
    				}
    			}

				result.add(pIdx + 1, comment); // 상위 댓글 다음 인덱스에 삽입
    		}
    	});

    	return PageableUtils.extractPage(result, pageable);
    }

}
