package com.ktng.ws2020.domain.board.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ktng.ws2020.da.model.BoardContentEntity;
import com.ktng.ws2020.da.model.BoardMasterEntity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class BoardCommentListDTO {

	private String brdCmtNo;
	private BoardMasterEntity brdMstrNo;
	private BoardContentEntity brdCtsNo;
	private String brdCmtGrp;
	private Integer brdCmtSorts;
	private Integer brdCmtDepth;
	private String brdComment;
	private String modId;
	private String regId;
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Seoul")
	private Date modDate;
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Seoul")
	private Date regDate;
	private String regNm;

}
