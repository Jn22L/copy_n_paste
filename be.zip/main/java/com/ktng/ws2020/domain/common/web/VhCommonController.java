package com.ktng.ws2020.domain.common.web;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ktng.ws2020.domain.common.model.VhCommonCodeDTO;
import com.ktng.ws2020.domain.common.model.VhCommonDeptDTO;
import com.ktng.ws2020.domain.common.model.VhCommonDriverDTO;
import com.ktng.ws2020.domain.common.model.VhCommonEmpDTO;
import com.ktng.ws2020.domain.common.model.VhCommonVehicleDTO;
import com.ktng.ws2020.domain.common.model.VhCommonVhDeptDTO;
import com.ktng.ws2020.domain.common.service.VhCommonService;
import com.ktng.ws2020.global.common.response.ListResult;
import com.ktng.ws2020.global.common.response.SingleResult;
import com.ktng.ws2020.global.common.response.service.ResponseService;

@RestController
@RequestMapping("/api/common")
public class VhCommonController {

	@Autowired
	private VhCommonService vhCommonService;
	
	@Autowired
	private ResponseService responseService;

	/**
	 * (팝업용) 사원 리스트 조회
	 *
	 * @param empNo 검색 사번
	 * @param empNm 검색 성명
	 * @return
	 */
	@GetMapping(value = "/emp")
	public ListResult<VhCommonEmpDTO> getVhEmpList(
			@RequestParam(value = "empNo", required = false) String empNo,
			@RequestParam(value = "empNm", required = false) String empNm) {
		List<VhCommonEmpDTO> empList = vhCommonService.getEmpList(empNo, empNm);

		return responseService.getListResult(empList);
	}

	/**
	 * (팝업용) 부서 리스트 조회
	 *
	 * @param symd 검색 기준일자 yyyyMMdd (필수)
	 * @param orgCd 검색 조직코드
	 * @param orgFullNm 검색 조직명
	 * @param parCd 검색 기관코드 (미사용중)
	 * @return
	 */
	@GetMapping(value = "/dept")
	public ListResult<VhCommonDeptDTO> getDeptList(
			@RequestParam(value = "symd") String symd,
			@RequestParam(value = "orgCd", required = false) String orgCd,
			@RequestParam(value = "orgFullNm", required = false) String orgFullNm,
			@RequestParam(value = "parCd", required = false) String parCd) {
		List<VhCommonDeptDTO> deptList = vhCommonService.getDeptList(symd, orgCd, orgFullNm, parCd);

		return responseService.getListResult(deptList);
	}

	/**
	 * (팝업용) 차량 리스트 조회
	 *
	 * @param vhclDeptCd 검색 배차부서코드
	 * @param vhclNo 검색 차량번호
	 * @param vhclNm 검색 차량명
	 * @return
	 */
	@GetMapping(value = "/vehicle")
	public ListResult<VhCommonVehicleDTO> getVehicleList(
			@RequestParam(value = "vhclDeptCd", required = false) String vhclDeptCd,
			@RequestParam(value = "vhclNo", required = false) String vhclNo,
			@RequestParam(value = "vhclNm", required = false) String vhclNm) {
		List<VhCommonVehicleDTO> vehicleList = vhCommonService.getVehicleList(vhclDeptCd, vhclNo, vhclNm);
		
		return responseService.getListResult(vehicleList);
	}

	/**
	 * (팝업용) 운전원 리스트 조회
	 *
	 * @param vhclDeptCd 검색 배차부서코드
	 * @param useYn 검색 근무여부
	 * @param driverNo 검색 운전원ID
	 * @param driverNm 검색 운전원성명
	 * @return
	 */
	@GetMapping(value = "/driver")
	public ListResult<VhCommonDriverDTO> getDriverList(
			@RequestParam(value = "vhclDeptCd", required = false) String vhclDeptCd,
			@RequestParam(value = "useYn", required = false) String useYn,
			@RequestParam(value = "driverNo", required = false) String driverNo,
			@RequestParam(value = "driverNm", required = false) String driverNm) {
		List<VhCommonDriverDTO> driverList = vhCommonService.getDriverList(vhclDeptCd, useYn, driverNo, driverNm);

		return responseService.getListResult(driverList);
	}

	/**
	 * (팝업용) 배차부서 리스트 조회
	 *
	 * @param vhclDeptNo 검색 배차부서코드
	 * @param vhclDeptNm 검색 배차부서명
	 * @return
	 */
	@GetMapping(value = "/vhDept")
	public ListResult<VhCommonVhDeptDTO> getVhDeptList(
			@RequestParam(value = "vhclDeptCd", required = false) String vhclDeptCd,
			@RequestParam(value = "vhclDeptNm", required = false) String vhclDeptNm) {
		List<VhCommonVhDeptDTO> vhDeptList = vhCommonService.getVhDeptList(vhclDeptCd, vhclDeptNm);

		return responseService.getListResult(vhDeptList);
	}

	/**
	 * 공통코드 리스트 조회
	 *
	 * @param commCodeChk 조회할 그룹코드
	 * @return
	 */
	@GetMapping(value = "/code/{commCodeChk}")
	public ListResult<VhCommonCodeDTO> getCodeList(
			@PathVariable("commCodeChk") String commCodeChk) {
		List<VhCommonCodeDTO> codeList = vhCommonService.getCodeList(commCodeChk);

		return responseService.getListResult(codeList);
	}

	/**
	 * 한번에 여러 공통코드 리스트 조회
	 * 
	 * @param commCodeChks 검색할 그룹코드 리스트
	 * @return
	 */
	@GetMapping(value = "/code")
	public SingleResult<HashMap<String, List<VhCommonCodeDTO>>> getMultipleCodeList(
			@RequestParam("commCodeChks") String[] commCodeChks) {
		HashMap<String, List<VhCommonCodeDTO>> codesMap = vhCommonService.getCodesMap(commCodeChks); 

		return responseService.getSingleResult(codesMap);
	}
}
