package com.ktng.ws2020.domain.common.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class VhCommonVehicleDTO {
	private String vhclNo;
	private String vhclNm;
	private String vhType;
}
