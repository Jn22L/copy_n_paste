package com.ktng.ws2020.domain.common.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktng.ws2020.domain.common.dao.UutasUserMapper;
import com.ktng.ws2020.domain.common.model.UutasUserDTO;

@Service
public class UutasUserService {
	
	@Autowired
	private UutasUserMapper uutasUserMapper;

	public UutasUserDTO getUserByEmpNo(String empNo) {
		return uutasUserMapper.selectUserByEmpNo(empNo);
	}
	
	public UutasUserDTO getUserByEmpNoIpAddr(String empNo, String ipAddr) {
		return uutasUserMapper.selectUserByEmpNoIpAddr(empNo, ipAddr);
	}	

}
