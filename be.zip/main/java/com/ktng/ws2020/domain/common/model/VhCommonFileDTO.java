package com.ktng.ws2020.domain.common.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class VhCommonFileDTO {
	private String applyNo;
	private String fileTitle;
	private String filePath;
	private String fileName;
}
