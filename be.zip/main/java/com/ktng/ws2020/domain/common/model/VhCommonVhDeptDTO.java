package com.ktng.ws2020.domain.common.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class VhCommonVhDeptDTO {
	private String vhclDeptCd; // 부서코드
	private String vhclDeptNm; // 부서명
}
