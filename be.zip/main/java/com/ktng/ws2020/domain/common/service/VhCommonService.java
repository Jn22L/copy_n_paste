package com.ktng.ws2020.domain.common.service;

import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.EnumUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktng.ws2020.domain.code.service.CodeService;
import com.ktng.ws2020.domain.common.dao.VhCommonMapper;
import com.ktng.ws2020.domain.common.model.VhCommonCodeDTO;
import com.ktng.ws2020.domain.common.model.VhCommonCodeDTO.CodeChk;
import com.ktng.ws2020.domain.common.model.VhCommonDeptDTO;
import com.ktng.ws2020.domain.common.model.VhCommonDriverDTO;
import com.ktng.ws2020.domain.common.model.VhCommonEmpDTO;
import com.ktng.ws2020.domain.common.model.VhCommonVehicleDTO;
import com.ktng.ws2020.domain.common.model.VhCommonVhDeptDTO;

@Service
public class VhCommonService {

	@Autowired
	private VhCommonMapper vhCommonMapper;

	@Autowired
	private CodeService codeService;

	// (팝업용) 사원 리스트 조회
	public List<VhCommonEmpDTO> getEmpList(String empNo, String empNm) {
		return vhCommonMapper.selectEmpList(empNo, empNm);
	}

	// (팝업용) 부서 리스트 조회
	public List<VhCommonDeptDTO> getDeptList(String symd, String orgCd, String orgFullNm, String parCd) {
		return vhCommonMapper.selectDeptList(symd, orgCd, orgFullNm, parCd);
	}

	// (팝업용) 차량 리스트 조회
	public List<VhCommonVehicleDTO> getVehicleList(String vhclDeptCd, String vhclNo, String vhclNm) {
		return vhCommonMapper.selectVehicleList(vhclDeptCd, vhclNo, vhclNm);
	}

	// (팝업용) 운전원 리스트 조회
	public List<VhCommonDriverDTO> getDriverList(String vhclDeptCd, String useYn, String driverNo, String driverNm) {
		return vhCommonMapper.selectDriverList(vhclDeptCd, useYn, driverNo, driverNm);
	}

	// (팝업용) 배차부서 리스트 조회
	public List<VhCommonVhDeptDTO> getVhDeptList(String vhclDeptCd, String vhclDeptNm) {
		return vhCommonMapper.selectVhDeptList(
				new String[] { "MGR", "DGN" }, // 배차, 지정차량
				vhclDeptCd, vhclDeptNm);
	}

	// 공통코드 리스트 조회
	public List<VhCommonCodeDTO> getCodeList(String commCodeChk) {
		List<VhCommonCodeDTO> codeList = codeService.getCodeList(commCodeChk, null).stream()
				.map(code -> VhCommonCodeDTO.of(code))
				.collect(Collectors.toList());
		return codeList;
	}

	// 한번에 여러 공통코드 리스트 조회
	public HashMap<String, List<VhCommonCodeDTO>> getCodesMap(String[] commCodeChks) {
		HashMap<String, List<VhCommonCodeDTO>> codesMap = new HashMap<>();
		Stream.of(commCodeChks).forEach(commCodeChk -> {
			List<VhCommonCodeDTO> codes = null;

			CodeChk codeChk = EnumUtils.getEnum(CodeChk.class, commCodeChk);
			if (codeChk == null) {
				codeChk = CodeChk.OTHERS;
			}

			switch (codeChk) {
			case EMP:
				codes = vhCommonMapper.selectEmpList(null, null).stream()
					.map(emp -> VhCommonCodeDTO.of(emp))
					.collect(Collectors.toList());
				break;
			case DEPT:
				codes = vhCommonMapper.selectDeptList(null, null, null, null).stream()
					.map(dept -> VhCommonCodeDTO.of(dept))
					.collect(Collectors.toList());
				break;
			case VEHICLE:
				codes = vhCommonMapper.selectVehicleList(null, null, null).stream()
					.map(vehicle -> VhCommonCodeDTO.of(vehicle))
					.collect(Collectors.toList());
				break;
			case DRIVER:
				codes = vhCommonMapper.selectDriverList(null, null, null, null).stream()
					.map(driver -> VhCommonCodeDTO.of(driver))
					.collect(Collectors.toList());
				break;
			case VH_DEPT:
				// 배차부서 ONLY
				codes = vhCommonMapper.selectVhDeptList(new String[] { "MGR" }, null, null).stream()
					.map(vhDept -> VhCommonCodeDTO.of(vhDept))
					.collect(Collectors.toList());
				break;
			case VH_DEPT_ALL:
				// 배차, 지정차량
				codes = vhCommonMapper.selectVhDeptList(new String[] { "MGR", "DGN" }, null, null).stream()
					.map(vhDept -> VhCommonCodeDTO.of(vhDept))
					.collect(Collectors.toList());
				break;
			case FILE:
				codes = vhCommonMapper.selectFileList(null).stream()
					.map(file -> VhCommonCodeDTO.of(file))
					.collect(Collectors.toList());
			case OTHERS:
				codes = codeService.getCodeList(commCodeChk, null).stream()
					.map(code -> VhCommonCodeDTO.of(code))
					.collect(Collectors.toList());
			}

			codesMap.put(commCodeChk, codes);
		});

		return codesMap;
	}

}
