package com.ktng.ws2020.domain.common.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class VhCommonDeptDTO {
	private String orgCd; /* 조직코드 */
	private String orgNm; /* 조직명 */
	private String orgFullNm; /* 조직명(Full) */
	private String parCd; /* 기관코드 */
	private String parNm; /* 기관명 */
}
