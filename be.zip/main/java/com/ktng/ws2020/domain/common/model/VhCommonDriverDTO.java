package com.ktng.ws2020.domain.common.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class VhCommonDriverDTO {
	private String driverNo;
	private String driverNm;
	private String cellPn;
}
