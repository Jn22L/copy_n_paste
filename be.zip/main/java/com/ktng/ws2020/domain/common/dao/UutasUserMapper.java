package com.ktng.ws2020.domain.common.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ktng.ws2020.domain.common.model.UutasUserDTO;

@Mapper
public interface UutasUserMapper {

	public UutasUserDTO selectUserByEmpNo(@Param("empNo") String empNo);
	public UutasUserDTO selectUserByEmpNoIpAddr(@Param("empNo") String empNo, @Param("ipAddr") String ipAddr); // 관리자체크(nsso 로그인시)

}
