package com.ktng.ws2020.domain.common.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class VhCommonEmpDTO {
	private String empNo;          /* 사번 */
	private String empNm;          /* 성명 */
	private String parCd;  /* 기관코드     */
	private String parNm;  /* 기관명       */
	private String partCd; /* 근무부서코드 */
	private String partNm; /* 근무부서명   */       
	private String posGrdNm;      /* 직급            */
	private String jobNm;          /* 직무            */
	private String parDepNm;      /* 소속(기관명+관리부서명) */
	private String firstHireYmd;  /* 입사일자        */
	private String inOffiYnNm;   /* 재직여부명      */
	private String empGubun;       /* 정규직(01) 혹은 기간제(02) */
	private String cellPhnNo; /* 연락처 */
}
