package com.ktng.ws2020.domain.common.model;

import java.util.List;

import com.ktng.ws2020.domain.menu.model.MenuDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Builder
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class UutasMenuTreeDTO {
	private final static String DIR = "dir";

	private String id; // menuCd;
	private String title; // menuNm;
	private String type; // 'group' | 'collapse' | 'item'
	private String icon; // 'apps' | 'widgets' | 'library_books'
	private String url; // menuUrl;
	private List<UutasMenuTreeDTO> children;

	public static UutasMenuTreeDTO of(MenuDTO menu, List<UutasMenuTreeDTO> children) {
		String id = menu.getObjCd();
		String type = null;
		if (id.endsWith("0000") || id.endsWith("000")) type = "collapse";
		else type = "item";

		String icon = menu.getIconInfo();
		if (icon == null) icon = "";
		if (icon.length() == 0) {
			if (id.endsWith("0000")) icon = "apps";
			else if (id.endsWith("000")) icon = "widgets";
			else icon = ""; // "library_books";
		}

		String url = null;
		if (!menu.getUrl().contentEquals(DIR)) {
			url = menu.getUrl();
		}

		return UutasMenuTreeDTO.builder()
				.id(id)
				.title(menu.getName())
				.type(type)
				.icon(icon)
				.url(url)
				.children(children)
				.build();
	}

}
