package com.ktng.ws2020.domain.common.model;

import com.ktng.ws2020.da.model.CodeEntity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@Getter
@AllArgsConstructor
@Builder
public class VhCommonCodeDTO {
	public enum CodeChk { 
		EMP, // 사원
		DEPT, // 부서
		VEHICLE, // 차량
		DRIVER, // 운전원
		VH_DEPT, // 배차부서 (배차부서 ONLY)
		VH_DEPT_ALL, // 배차부서 (배차, 지정차량)
		FILE, // 파일
		OTHERS // 그외 (공통코드 테이블에 존재하는 코드 처리로 분기하기 위한 용도)
	};

	private String commCodeChk; // 코드구분
	private String commCode; // 코드
	private String commCodeName; // 코드명
	private Long seq; // 출력순번

	/* 3. 사원 공통코드 */
	public static VhCommonCodeDTO of(VhCommonEmpDTO emp) {
		return VhCommonCodeDTO.builder()
				.commCodeChk(CodeChk.EMP.name())
				.commCode(emp.getEmpNo())
				.commCodeName(emp.getEmpNm())
				.seq(0L)
				.build();
	}

	/* 4. 부서 공통코드 */
	public static VhCommonCodeDTO of(VhCommonDeptDTO dept) {
		return VhCommonCodeDTO.builder()
				.commCodeChk(CodeChk.DEPT.name())
				.commCode(dept.getOrgCd())
				.commCodeName(dept.getOrgNm())
				.seq(0L)
				.build();
	}

	/* 5. 차량 공통코드 */
	public static VhCommonCodeDTO of(VhCommonVehicleDTO vehicle) {
		return VhCommonCodeDTO.builder()
				.commCodeChk(CodeChk.VEHICLE.name())
				.commCode(vehicle.getVhclNo())
				.commCodeName(vehicle.getVhclNm())
				.seq(0L)
				.build();
	}

	/* 6. 운전원 공통코드 */
	public static VhCommonCodeDTO of(VhCommonDriverDTO driver) {
		return VhCommonCodeDTO.builder()
				.commCodeChk(CodeChk.DRIVER.name())
				.commCode(driver.getDriverNo())
				.commCodeName(driver.getDriverNm())
				.seq(0L)
				.build();
	}

	/* 7, 8. 배차부서 공통코드 */
	public static VhCommonCodeDTO of(VhCommonVhDeptDTO vhDept) {
		return VhCommonCodeDTO.builder()
				.commCodeChk(CodeChk.VH_DEPT.name())
				.commCode(vhDept.getVhclDeptCd())
				.commCodeName(vhDept.getVhclDeptNm())
				.seq(0L)
				.build();
	}

	/* 9. 첨부파일 공통코드 */
	public static VhCommonCodeDTO of(VhCommonFileDTO file) {
		return VhCommonCodeDTO.builder()
				.commCodeChk(CodeChk.FILE.name())
				.commCode(file.getApplyNo())
				.commCodeName(file.getFileName())
				.seq(0L)
				.build();
	}

	/* 그외 공통코드 변환 */
	public static VhCommonCodeDTO of(CodeEntity code) {
		return VhCommonCodeDTO.builder()
				.commCodeChk(code.getCommCodeChk())
				.commCode(code.getCommCode())
				.commCodeName(code.getCommCodeName())
				.seq(code.getSeq())
				.build();
	}

}
