package com.ktng.ws2020.domain.common.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Builder
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class UutasUserDTO {
	private String empNo;
	private String empNm;
	private String cellPhnNo;
	private String parCd;  /* 기관코드     */
	private String parNm;  /* 기관명       */
	private String depCd;  /* 관리부서코드 */
	private String depNm;  /* 관리부서명   */
	private String partCd; /* 근무부서코드 */
	private String partNm; /* 근무부서명   */
	private String roleCd; 
	private String vhclDeptCd;
	private String loginUserGubun; /* 운전원 일부제한은 프로그램 에서 처리 */
}
