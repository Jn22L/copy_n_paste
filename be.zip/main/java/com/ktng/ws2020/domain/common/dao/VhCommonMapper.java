package com.ktng.ws2020.domain.common.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ktng.ws2020.domain.common.model.VhCommonDeptDTO;
import com.ktng.ws2020.domain.common.model.VhCommonDriverDTO;
import com.ktng.ws2020.domain.common.model.VhCommonEmpDTO;
import com.ktng.ws2020.domain.common.model.VhCommonFileDTO;
import com.ktng.ws2020.domain.common.model.VhCommonVehicleDTO;
import com.ktng.ws2020.domain.common.model.VhCommonVhDeptDTO;

@Mapper
public interface VhCommonMapper {

	public List<VhCommonEmpDTO> selectEmpList(
			@Param("empNo") String empNo, // 사번
			@Param("empNm") String empNm); // 이름

	public List<VhCommonDeptDTO> selectDeptList(
			@Param("symd") String symd, // yyyyMMdd
			@Param("orgCd") String orgCd, // 부서코드
			@Param("orgFullNm") String orgFullNm, // 부서명
			@Param("parCd") String parCd); // 기관코드 (화면에 따라 로그인의 PAR_CD 셋팅)

	public List<VhCommonVehicleDTO> selectVehicleList(
			@Param("vhclDeptCd") String vhclDeptCd, // 배차부서코드
			@Param("vhclNo") String vhclNo,
			@Param("vhclNm") String vhclNm);

	public List<VhCommonDriverDTO> selectDriverList(
			@Param("vhclDeptCd") String vhclDeptCd, // 배차부서코드
			@Param("useYn") String useYn, // 근무여부
			@Param("driverNo") String driverNo,
			@Param("driverNm") String driverNm);
	
	public List<VhCommonVhDeptDTO> selectVhDeptList(
			@Param("authGubuns") String[] authGubuns, // 조회할 관리권한 리스트
			@Param("vhclDeptCd") String vhclDeptCd,
			@Param("vhclDeptNm") String vhclDeptNm);

	public List<VhCommonFileDTO> selectFileList(
			@Param("applyNo") String applyNo); // 신청번호

}
