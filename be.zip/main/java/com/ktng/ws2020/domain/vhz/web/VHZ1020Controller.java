package com.ktng.ws2020.domain.vhz.web;

import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ktng.ws2020.domain.vhz.service.VHZ1020Service;
import com.ktng.ws2020.da.model.CodeEntity;
import com.ktng.ws2020.domain.vhz.model.VHZ1020DTO;
import com.ktng.ws2020.global.common.response.CommonResult;
import com.ktng.ws2020.global.common.response.ListResult;
import com.ktng.ws2020.global.common.response.service.ResponseService;
import com.ktng.ws2020.global.config.security.userdetails.IamUserDetails;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/vhz1020")
public class VHZ1020Controller {

	@Autowired
	private VHZ1020Service vhz1020Service;
	
	@Autowired
    private ResponseService responseService;

    /**
    * 공통코드를 조회한다.
    * @param 
    * @throws 
    */	
    @GetMapping("/selectCommCodeList")
    public ListResult<VHZ1020DTO> selectRoleListByRolcd(
    		@RequestParam(value = "grpCode", required = false) String grpCode,
    		@RequestParam(value = "grpName", required = false) String grpName,
    		@AuthenticationPrincipal Authentication auth) {
    	
    	IamUserDetails user = (IamUserDetails) auth.getPrincipal();
    	List<VHZ1020DTO> vhz1020List = vhz1020Service.selectCommCodeList(grpCode, grpName);

    	return responseService.getListResult(vhz1020List);
    }
    

}
