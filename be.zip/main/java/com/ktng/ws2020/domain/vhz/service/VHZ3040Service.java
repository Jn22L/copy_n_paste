package com.ktng.ws2020.domain.vhz.service;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktng.ws2020.da.model.CodeEntity;
import com.ktng.ws2020.da.model.ids.CodeID;
import com.ktng.ws2020.domain.vhz.dao.VHZ3040Mapper;
import com.ktng.ws2020.domain.vhz.model.VHZ3040DTO;
import com.ktng.ws2020.domain.menu.model.MenuTreeDTO;

@Service
public class VHZ3040Service {
	
	@Autowired
	private VHZ3040Mapper vhz3040Mapper;

	public List<VHZ3040DTO>  selectAdmIpList(String empNo, String empNm) {
		return vhz3040Mapper.selectAdmIpList(empNo, empNm);
	}
	
    // N건 입력한다.  
    public void insertAdmIpList(List<VHZ3040DTO> lvo, String modifier) throws Exception{
		for(VHZ3040DTO vo: lvo) {
			vo.setRegId(modifier);
			vhz3040Mapper.insertAdmIpList(vo);
		}
    }   
    
    // N건 수정한다.     
    public void updateAdmIpList(List<VHZ3040DTO> lvo, String modifier) throws Exception{
		for(VHZ3040DTO vo: lvo) {
			vo.setModId(modifier);
			vhz3040Mapper.updateAdmIpList(vo);
		}
    }     	
    
    // N건 삭제한다.   
    public void deleteAdmIpList(List<VHZ3040DTO> lvo) throws Exception{
		for(VHZ3040DTO vo: lvo) {
			vhz3040Mapper.deleteAdmIpList(vo);
		}
    }       
	

}
