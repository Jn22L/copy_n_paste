package com.ktng.ws2020.domain.vhz.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ktng.ws2020.domain.vhz.model.VHZ3020DTO;
import java.util.List;

@Mapper
public interface VHZ3020Mapper {

	public List<VHZ3020DTO> selectRoleMenuList(@Param("roleCd") String roleCd, @Param("menuCd") String menuCd);
	public int insertRoleMenuList(VHZ3020DTO vo) throws Exception ;
	// public int updateRoleMenuList(@Param("vo") VHZ3020DTO vo,  @Param("modifier")String modifier) throws Exception ;
	public int updateRoleMenuList(VHZ3020DTO vo) throws Exception ;
	public int deleteRoleMenuList(VHZ3020DTO vo) throws Exception ;
	
}

