package com.ktng.ws2020.domain.vhz.service;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktng.ws2020.da.model.CodeEntity;
import com.ktng.ws2020.da.model.ids.CodeID;
import com.ktng.ws2020.domain.vhz.dao.VHZ3030Mapper;
import com.ktng.ws2020.domain.vhz.model.VHZ3030DTO;
import com.ktng.ws2020.domain.menu.model.MenuTreeDTO;

@Service
public class VHZ3030Service {
	
	@Autowired
	private VHZ3030Mapper vhz3030Mapper;

	public List<VHZ3030DTO>  selectTempUserList(String empNo, String empNm) {
		return vhz3030Mapper.selectTempUserList(empNo, empNm);
	}
	
    // N건 입력한다.  
    public void insertTempUserList(List<VHZ3030DTO> lvo, String regId) throws Exception{
		for(VHZ3030DTO vo: lvo) {
			vo.setRegId(regId);
			vhz3030Mapper.insertTempUserList(vo);
		}
    }   
    
    // N건 수정한다.     
    public void updateTempUserList(List<VHZ3030DTO> lvo, String modId) throws Exception{
		for(VHZ3030DTO vo: lvo) {
			vo.setModId(modId);
			vhz3030Mapper.updateTempUserList(vo);
		}
    }     	
    
    // N건 삭제한다.   
    public void deleteTempUserList(List<VHZ3030DTO> lvo) throws Exception{
		for(VHZ3030DTO vo: lvo) {
			vhz3030Mapper.deleteTempUserList(vo);
		}
    }       
	

}
