package com.ktng.ws2020.domain.vhz.service;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktng.ws2020.da.model.CodeEntity;
import com.ktng.ws2020.da.model.ids.CodeID;
import com.ktng.ws2020.domain.vhz.dao.VHZ2030Mapper;
import com.ktng.ws2020.domain.vhz.model.VHZ2030DTO;
import com.ktng.ws2020.domain.menu.model.MenuTreeDTO;

@Service
public class VHZ2030Service {
	
	@Autowired
	private VHZ2030Mapper vhz2030Mapper;

	public List<VHZ2030DTO>  selectMenuList(String menuCd, String menuNm) {
		return vhz2030Mapper.selectMenuList(menuCd, menuNm);
	}
	
    // N건 입력한다.  
    public void insertMenuList(List<VHZ2030DTO> lvo, String modifier) throws Exception{
		for(VHZ2030DTO vo: lvo) {
			vo.setRgst(modifier);
			vhz2030Mapper.insertMenuList(vo);
		}
    }   
    
    // N건 수정한다.     
    public void updateMenuList(List<VHZ2030DTO> lvo, String modifier) throws Exception{
		for(VHZ2030DTO vo: lvo) {
			vo.setRgst(modifier);
			vhz2030Mapper.updateMenuList(vo);
		}
    }     	
    
    // N건 삭제한다.   
    public void deleteMenuList(List<VHZ2030DTO> lvo) throws Exception{
		for(VHZ2030DTO vo: lvo) {
			vhz2030Mapper.deleteMenuList(vo);
		}
    }       
	

}
