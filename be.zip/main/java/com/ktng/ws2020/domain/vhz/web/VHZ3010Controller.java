package com.ktng.ws2020.domain.vhz.web;

import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ktng.ws2020.domain.vhz.service.VHZ3010Service;
import com.ktng.ws2020.da.model.CodeEntity;
import com.ktng.ws2020.domain.vhz.dao.VHZ3010Mapper;
import com.ktng.ws2020.domain.vhz.model.VHZ3010DTO;
import com.ktng.ws2020.global.common.response.CommonResult;
import com.ktng.ws2020.global.common.response.ListResult;
import com.ktng.ws2020.global.common.response.service.ResponseService;
import com.ktng.ws2020.global.config.security.userdetails.IamUserDetails;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/vhz3010")
public class VHZ3010Controller {

	@Autowired
	private VHZ3010Service vhz3010Service;
	
	@Autowired
    private ResponseService responseService;

    /**
    * 권한을 조회한다.
    * @param 
    * @throws 
    */	
    @GetMapping("/selectRoleListByRolcd")
    public ListResult<VHZ3010DTO> selectRoleListByRolcd(
    		@RequestParam(value = "roleCd", required = false) String roleCd,
    		@RequestParam(value = "roleNm", required = false) String roleNm,
    		@AuthenticationPrincipal Authentication auth) {
    	
    	IamUserDetails user = (IamUserDetails) auth.getPrincipal();
    	// UutasUserDTO uutasUser = uutasUserMapper.selectUserByEmpNo(user.getUsername());

    	System.out.println("조건1:" + roleCd);
    	System.out.println("조건2:" + roleNm);
    	List<VHZ3010DTO> vhz3010List = vhz3010Service.selectRoleListByRolcd(roleCd, roleNm);

    	return responseService.getListResult(vhz3010List);
    }
    
    /**
    * 권한을 저장한다.
    * @param 
    * @throws
    */    
    @PostMapping(value = "/save")
    @Transactional
    public CommonResult saveCodeList(@RequestBody Map<String, List<VHZ3010DTO>> rolesMap,
    		@AuthenticationPrincipal Authentication auth) throws Exception {

    	IamUserDetails user = (IamUserDetails) auth.getPrincipal();
    	log.debug("@@@@@ user: {}", user.toString());
    	// TODO user 권한 체크
    	
    	// 작업순서 : 삭제 → 수정 → 추가
    	List<VHZ3010DTO> delList = rolesMap.get("D");
    	vhz3010Service.deleteRoleList(delList);
    	
    	List<VHZ3010DTO> updList = rolesMap.get("U");
    	vhz3010Service.updateRoleList(updList, user.getUsername());    	
    	
    	List<VHZ3010DTO> insList = rolesMap.get("I");
    	vhz3010Service.insertRoleList(insList, user.getUsername());

    	return responseService.getSuccessResult();
    }    

}
