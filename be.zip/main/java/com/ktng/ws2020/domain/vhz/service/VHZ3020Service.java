package com.ktng.ws2020.domain.vhz.service;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktng.ws2020.da.model.CodeEntity;
import com.ktng.ws2020.da.model.ids.CodeID;
import com.ktng.ws2020.domain.vhz.dao.VHZ3020Mapper;
import com.ktng.ws2020.domain.vhz.model.VHZ3020DTO;
import com.ktng.ws2020.domain.menu.model.MenuTreeDTO;

@Service
public class VHZ3020Service {
	
	@Autowired
	private VHZ3020Mapper vhz3020Mapper;

	public List<VHZ3020DTO>  selectRoleMenuList(String roleCd, String roleNm) {
		return vhz3020Mapper.selectRoleMenuList(roleCd, roleNm);
	}
	
    // N건 입력한다.  
    public void insertRoleMenuList(List<VHZ3020DTO> lvo, String modifier) throws Exception{
		for(VHZ3020DTO vo: lvo) {
			vo.setRgst(modifier);
			vhz3020Mapper.insertRoleMenuList(vo);
		}
    }   
    
    // N건 수정한다.     
    public void updateRoleMenuList(List<VHZ3020DTO> lvo, String modifier) throws Exception{
		for(VHZ3020DTO vo: lvo) {
			vo.setRgst(modifier);
			vhz3020Mapper.updateRoleMenuList(vo);
		}
    }     	
    
    // N건 삭제한다.   
    public void deleteRoleMenuList(List<VHZ3020DTO> lvo) throws Exception{
		for(VHZ3020DTO vo: lvo) {
			vhz3020Mapper.deleteRoleMenuList(vo);
		}
    }       
	

}
