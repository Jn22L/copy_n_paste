package com.ktng.ws2020.domain.vhz.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class VHZ2030DTO {
	private String menuCd;
	private String menuNm;
	private String upprMenuCd;
	private String orderNo;
	private String menuTyp;
	private String menuLvl;
	private String menuUrl;
	private String stdt;
	private String eddt;
	private String rgst;
	private String createDate;
	private String modifyDate;
} 
