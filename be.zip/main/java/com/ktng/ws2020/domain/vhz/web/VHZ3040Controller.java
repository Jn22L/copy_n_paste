package com.ktng.ws2020.domain.vhz.web;

import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ktng.ws2020.domain.vhz.service.VHZ3040Service;
import com.ktng.ws2020.domain.vhz.model.VHZ3040DTO;
import com.ktng.ws2020.da.model.CodeEntity;
import com.ktng.ws2020.global.common.response.CommonResult;
import com.ktng.ws2020.global.common.response.ListResult;
import com.ktng.ws2020.global.common.response.service.ResponseService;
import com.ktng.ws2020.global.config.security.userdetails.IamUserDetails;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/vhz3040")
public class VHZ3040Controller {

	@Autowired
	private VHZ3040Service vhz3040Service;
	
	@Autowired
    private ResponseService responseService;

    /**
    * 권한메뉴를 조회한다.
    * @param 
    * @throws 
    */	
    @GetMapping("/selectAdmIpList")
    public ListResult<VHZ3040DTO> selectAdmIpList(
    		@RequestParam(value = "empNo", required = false) String empNo,
    		@RequestParam(value = "ipAddr", required = false) String ipAddr,
    		@AuthenticationPrincipal Authentication auth) {
    	
    	//IamUserDetails user = (IamUserDetails) auth.getPrincipal();

    	List<VHZ3040DTO> vhz3030List = vhz3040Service.selectAdmIpList(empNo, ipAddr);
    	return responseService.getListResult(vhz3030List);
    }
    
    /**
    * 권한메뉴를 저장한다.
    * @param 
    * @throws
    */    
    @PostMapping(value = "/save")
    @Transactional
    public CommonResult saveAdmIpList(@RequestBody Map<String, List<VHZ3040DTO>> paramMap,
    		@AuthenticationPrincipal Authentication auth) throws Exception {

    	IamUserDetails user = (IamUserDetails) auth.getPrincipal();
    	log.debug("@@@@@ user: {}", user.toString());
    	// TODO user 권한 체크
    	
    	// 작업순서 : 삭제 → 수정 → 추가
    	List<VHZ3040DTO> delList = paramMap.get("D");
    	vhz3040Service.deleteAdmIpList(delList);
    	
    	List<VHZ3040DTO> updList = paramMap.get("U");
    	vhz3040Service.updateAdmIpList(updList, user.getUsername());    	
    	
    	List<VHZ3040DTO> insList = paramMap.get("I");
    	vhz3040Service.insertAdmIpList(insList, user.getUsername());

    	return responseService.getSuccessResult();
    }    

}
