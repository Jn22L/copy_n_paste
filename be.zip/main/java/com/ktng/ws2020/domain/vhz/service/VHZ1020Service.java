package com.ktng.ws2020.domain.vhz.service;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktng.ws2020.da.model.CodeEntity;
import com.ktng.ws2020.da.model.ids.CodeID;
import com.ktng.ws2020.domain.vhz.dao.VHZ1020Mapper;
import com.ktng.ws2020.domain.vhz.model.VHZ1020DTO;
import com.ktng.ws2020.domain.menu.model.MenuTreeDTO;

@Service
public class VHZ1020Service {
	
	@Autowired
	private VHZ1020Mapper vhz1020Mapper;

	public List<VHZ1020DTO>  selectCommCodeList(String grpCode, String grpName) {
		return vhz1020Mapper.selectCommCodeList(grpCode, grpName);
	}
	
	

}
