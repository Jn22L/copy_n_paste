package com.ktng.ws2020.domain.vhz.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class VHZ3040DTO {
	private String empNo;
	private String empNm;
	private String ipAddr;
	private String limitDate;
	private String regId;
	private String modId;	
	
} 