package com.ktng.ws2020.domain.vhz.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class VHZ3030DTO {
	private String empNo;
	private String empNm;
	private String cellPhnNo;
	private String parCd;
	private String parNm;
	private String depCd;
	private String depNm;
	private String partCd;
	private String partNm;
	private String roleCd;
	private String vhclDeptCd;
	private String loginUserGubun;
	private String regId;
	private String modId;		
} 