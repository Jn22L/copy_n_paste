package com.ktng.ws2020.domain.vhz.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ktng.ws2020.domain.vhz.model.VHZ1020DTO;
import java.util.List;

@Mapper
public interface VHZ1020Mapper {

	public List<VHZ1020DTO> selectCommCodeList(@Param("grpCode") String grpCode, @Param("grpName") String grpName);

	
}

