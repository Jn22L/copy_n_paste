package com.ktng.ws2020.domain.vhz.service;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktng.ws2020.da.model.CodeEntity;
import com.ktng.ws2020.da.model.ids.CodeID;
import com.ktng.ws2020.domain.vhz.dao.VHZ3010Mapper;
import com.ktng.ws2020.domain.vhz.model.VHZ3010DTO;
import com.ktng.ws2020.domain.menu.model.MenuTreeDTO;

@Service
public class VHZ3010Service {
	
	@Autowired
	private VHZ3010Mapper vhz3010Mapper;

	public List<VHZ3010DTO>  selectRoleListByRolcd(String roleCd, String roleNm) {
		return vhz3010Mapper.selectRoleListByRolcd(roleCd, roleNm);
	}
	
    // N건 입력한다.  
    public void insertRoleList(List<VHZ3010DTO> lvo, String modifier) throws Exception{
		for(VHZ3010DTO vo: lvo) {
			vo.setRgst(modifier);
			vhz3010Mapper.insertRoleList(vo);
		}
    }   
    
    // N건 수정한다.     
    public void updateRoleList(List<VHZ3010DTO> lvo, String modifier) throws Exception{
		for(VHZ3010DTO vo: lvo) {
			vhz3010Mapper.updateRoleList(vo, modifier);
		}
    }     	
    
    // N건 삭제한다.   
    public void deleteRoleList(List<VHZ3010DTO> lvo) throws Exception{
		for(VHZ3010DTO vo: lvo) {
			vhz3010Mapper.deleteRoleList(vo);
		}
    }       
	

}
