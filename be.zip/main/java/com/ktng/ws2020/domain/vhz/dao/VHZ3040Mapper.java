package com.ktng.ws2020.domain.vhz.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ktng.ws2020.domain.vhz.model.VHZ3040DTO;
import java.util.List;

@Mapper
public interface VHZ3040Mapper {

	public List<VHZ3040DTO> selectAdmIpList(@Param("empNo") String empNo, @Param("ipAddr") String ipAddr);
	public int insertAdmIpList(VHZ3040DTO vo) throws Exception ;
	public int updateAdmIpList(VHZ3040DTO vo) throws Exception ;
	public int deleteAdmIpList(VHZ3040DTO vo) throws Exception ;
	
}

