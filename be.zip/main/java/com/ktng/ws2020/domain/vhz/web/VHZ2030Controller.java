package com.ktng.ws2020.domain.vhz.web;

import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ktng.ws2020.domain.vhz.service.VHZ2030Service;
import com.ktng.ws2020.domain.vhz.model.VHZ2030DTO;
import com.ktng.ws2020.da.model.CodeEntity;
import com.ktng.ws2020.global.common.response.CommonResult;
import com.ktng.ws2020.global.common.response.ListResult;
import com.ktng.ws2020.global.common.response.service.ResponseService;
import com.ktng.ws2020.global.config.security.userdetails.IamUserDetails;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/vhz2030")
public class VHZ2030Controller {

	@Autowired
	private VHZ2030Service vhz2030Service;
	
	@Autowired
    private ResponseService responseService;

    /**
    * 권한메뉴를 조회한다.
    * @param 
    * @throws 
    */	
    @GetMapping("/selectMenuList")
    public ListResult<VHZ2030DTO> selectRoleListByRolcd(
    		@RequestParam(value = "menuCd", required = false) String menuCd,
    		@RequestParam(value = "menuNm", required = false) String menuNm,
    		@AuthenticationPrincipal Authentication auth) {
    	
    	IamUserDetails user = (IamUserDetails) auth.getPrincipal();
    	// UutasUserDTO uutasUser = uutasUserMapper.selectUserByEmpNo(user.getUsername());

    	List<VHZ2030DTO> vhz2030List = vhz2030Service.selectMenuList(menuCd, menuNm);

    	return responseService.getListResult(vhz2030List);
    }
    
    /**
    * 권한메뉴를 저장한다.
    * @param 
    * @throws
    */    
    @PostMapping(value = "/save")
    @Transactional
    public CommonResult saveCodeList(@RequestBody Map<String, List<VHZ2030DTO>> paramMap,
    		@AuthenticationPrincipal Authentication auth) throws Exception {

    	IamUserDetails user = (IamUserDetails) auth.getPrincipal();
    	log.debug("@@@@@ user: {}", user.toString());
    	// TODO user 권한 체크
    	
    	// 작업순서 : 삭제 → 수정 → 추가
    	List<VHZ2030DTO> delList = paramMap.get("D");
    	vhz2030Service.deleteMenuList(delList);
    	
    	List<VHZ2030DTO> updList = paramMap.get("U");
    	vhz2030Service.updateMenuList(updList,user.getUsername());    	
    	
    	List<VHZ2030DTO> insList = paramMap.get("I");
    	vhz2030Service.insertMenuList(insList,user.getUsername());

    	return responseService.getSuccessResult();
    }    

}
