package com.ktng.ws2020.domain.vhz.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class VHZ3010DTO {
	private String roleCd;
	private String roleNm;
	private String rmk;
	private String rgst;
} 