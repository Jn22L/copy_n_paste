package com.ktng.ws2020.domain.vhz.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ktng.ws2020.domain.vhz.model.VHZ3030DTO;
import java.util.List;

@Mapper
public interface VHZ3030Mapper {

	public List<VHZ3030DTO> selectTempUserList(@Param("empNo") String empNo, @Param("empNm") String empNm);
	public int insertTempUserList(VHZ3030DTO vo) throws Exception ;
	public int updateTempUserList(VHZ3030DTO vo) throws Exception ;
	public int deleteTempUserList(VHZ3030DTO vo) throws Exception ;
	
}

