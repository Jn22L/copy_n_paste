package com.ktng.ws2020.domain.vhz.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

@Builder
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class VHZ1020DTO {
	private String grpCode;
	private String grpName;
	private String commCode;
	private String commName;	
} 