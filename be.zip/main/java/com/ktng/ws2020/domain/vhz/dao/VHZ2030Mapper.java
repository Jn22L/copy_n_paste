package com.ktng.ws2020.domain.vhz.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ktng.ws2020.domain.vhz.model.VHZ2030DTO;
import java.util.List;

@Mapper
public interface VHZ2030Mapper {

	public List<VHZ2030DTO> selectMenuList(@Param("menuCd") String menuCd, @Param("menuNm") String menuNm);
	public int insertMenuList(VHZ2030DTO vo) throws Exception ;
	public int updateMenuList(VHZ2030DTO vo) throws Exception ;
	public int deleteMenuList(VHZ2030DTO vo) throws Exception ;
	
}

