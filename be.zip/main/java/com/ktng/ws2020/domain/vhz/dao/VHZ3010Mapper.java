package com.ktng.ws2020.domain.vhz.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ktng.ws2020.domain.vhz.model.VHZ3010DTO;
import java.util.List;

@Mapper
public interface VHZ3010Mapper {

	public List<VHZ3010DTO> selectRoleListByRolcd(@Param("roleCd") String roleCd, @Param("roleNm") String roleNm);
	public int insertRoleList(VHZ3010DTO vo) throws Exception ;
	public int updateRoleList(@Param("vo") VHZ3010DTO vo, @Param("modifier")String modifier) throws Exception ;
	public int deleteRoleList(VHZ3010DTO vo) throws Exception ;
	
}

