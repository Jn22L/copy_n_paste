package com.ktng.ws2020.domain.vhd.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ktng.ws2020.domain.vhd.model.VHD0110DTO;
import com.ktng.ws2020.domain.vhd.service.VHD0110Service;
import com.ktng.ws2020.global.common.response.ListResult;
import com.ktng.ws2020.global.common.response.service.ResponseService;
import com.ktng.ws2020.global.config.security.userdetails.IamUserDetails;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/vhd0110")
public class VHD0110Controller {

	@Autowired
	private VHD0110Service vhd0110Service;
	
	@Autowired
    private ResponseService responseService;

    /**
    * 버스운행일지 메뉴를 조회한다.
    * @param 
    * @throws 
    */	
    @GetMapping("/selectDailyBusLogList")
    public ListResult<VHD0110DTO> selectDailyBusLogList(
    		@RequestParam(value = "fromYmd", required = true) String fromYmd,
    		@RequestParam(value = "toYmd", required = true) String toYmd,
    		@RequestParam(value = "driverNo", required = false) String driverNo,
    		@RequestParam(value = "driverNm", required = false) String driverNm,
    		@AuthenticationPrincipal Authentication auth) {
    	
    	IamUserDetails user = (IamUserDetails) auth.getPrincipal();
    	List<VHD0110DTO> vhd0110List = vhd0110Service.selectDailyBusLogList(fromYmd, toYmd, driverNo, driverNm);

    	return responseService.getListResult(vhd0110List);
    }
    
}
