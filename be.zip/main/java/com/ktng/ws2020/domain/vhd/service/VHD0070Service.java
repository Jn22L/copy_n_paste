package com.ktng.ws2020.domain.vhd.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktng.ws2020.domain.vhd.dao.VHD0070Mapper;
import com.ktng.ws2020.domain.vhd.model.VHD0070DTO;

@Service
public class VHD0070Service {
	
	@Autowired
	private VHD0070Mapper vhd0070Mapper;

	public List<VHD0070DTO>  selectRunHistoryListForSale(String vhclDeptCd) {
		return vhd0070Mapper.selectRunHistoryListForSale(vhclDeptCd);
	}
	
	public List<VHD0070DTO>  selectRunHistoryListForSaleDtl(String vhclNo, String yyyyMm) {
		return vhd0070Mapper.selectRunHistoryListForSaleDtl(vhclNo, yyyyMm);
	}
	
	/* 추가, 수정 */
	@Transactional
	public void saveGrid(List<VHD0070DTO> vhd0070List, String altEmpNo) {
		vhd0070List.forEach(vhd0070 -> {
			// ID로 기존 데이터 조회
			VHD0070DTO _vhd0070 = vhd0070Mapper.selectById(vhd0070.getRunDt(), vhd0070.getVhclNo(), vhd0070.getRunSeq());
			if (_vhd0070 == null) {
				// 기존 데이터가 없으면 insert
				vhd0070Mapper.insertGrid(vhd0070, altEmpNo);
			} else {
				// 있으면 update
				vhd0070Mapper.updateGrid(vhd0070, altEmpNo);
			}
		});
	}

	/* 삭제 */
	@Transactional
	public void deleteGrid(List<VHD0070DTO> vhd0070List) {
		vhd0070List.forEach(vhd0070 -> {
			// 삭제할 Entity 조회 및 확인
			vhd0070Mapper.deleteGrid(vhd0070);
		});
	}

}
