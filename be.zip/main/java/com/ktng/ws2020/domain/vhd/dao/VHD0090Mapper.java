package com.ktng.ws2020.domain.vhd.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ktng.ws2020.domain.vhd.model.VHD0090DTO;

@Mapper
public interface VHD0090Mapper {
	
	public List<VHD0090DTO> selectRunlogTotalList(@Param("fromYmd") String fromYmd, @Param("toYmd") String toYmd, @Param("vhclNo") String vhclNo);

	public List<VHD0090DTO> selectRunlogSaleTotalList(@Param("fromYmd") String fromYmd, @Param("toYmd") String toYmd, @Param("vhclNo") String vhclNo);
	
}
