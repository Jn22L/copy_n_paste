package com.ktng.ws2020.domain.vhd.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktng.ws2020.domain.vhd.dao.VHD0080Mapper;
import com.ktng.ws2020.domain.vhd.model.VHD0080DTO;

@Service
public class VHD0080Service {
	
	@Autowired
	private VHD0080Mapper vhd0080Mapper;

	public List<VHD0080DTO>  selectRunHistoryListForSale(String vhclNo, String fromYmd, String toYmd) {
		return vhd0080Mapper.selectRunHistoryListForSale(vhclNo, fromYmd, toYmd);
	}
	
	public List<VHD0080DTO>  selectRunHistoryListForSaleDtl(String vhclNo, String fromYmd, String toYmd) {
		return vhd0080Mapper.selectRunHistoryListForSaleDtl(vhclNo, fromYmd, toYmd);
	}

}
