package com.ktng.ws2020.domain.vhd.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ktng.ws2020.domain.vhd.model.VHD0080DTO;

@Mapper
public interface VHD0080Mapper {

	public List<VHD0080DTO> selectRunHistoryListForSale(@Param("vhclNo") String vhclNo, @Param("fromYmd") String fromYmd, @Param("toYmd") String toYmd);
	
	public List<VHD0080DTO> selectRunHistoryListForSaleDtl(@Param("vhclNo") String vhclNo, @Param("fromYmd") String fromYmd, @Param("toYmd") String toYmd);
	
}

