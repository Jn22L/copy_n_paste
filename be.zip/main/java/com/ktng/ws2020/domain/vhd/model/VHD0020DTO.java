package com.ktng.ws2020.domain.vhd.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class VHD0020DTO {
	private String assignNo;
	private String depatureDtTm;
	private String arrivalDtTm;
	private String vhclNo;
	private String vhclNm;
	private String driverNm;
	private String chiefDeptNm;
	private String chiefEmpNm;
	private String destination;
	private String usePurpose;
	private String passstop;
	private String driveNote;
	private String standbyTime;
	private String befAccrueKm;
	private String driveKm;
	private String accrueKm;
	private String dayOil;
	private String accrueOil;
	private String bigo;
} 