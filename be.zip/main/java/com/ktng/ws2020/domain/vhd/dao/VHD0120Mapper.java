package com.ktng.ws2020.domain.vhd.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ktng.ws2020.domain.vhd.model.VHD0120DTO;

@Mapper
public interface VHD0120Mapper {

	/* 1. grid CRUD */
	public List<VHD0120DTO> selectGridList(
			@Param("yyyymm") String runDt,
			@Param("loginUserCd") String UserCd
			);

	public void insertVhd0120(@Param("selectedRow") VHD0120DTO selectedRow, @Param("altEmpNo") String altEmpNo);
	
	public void deleteVhd0120(@Param("params") VHD0120DTO params);
	
}
