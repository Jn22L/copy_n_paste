package com.ktng.ws2020.domain.vhd.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ktng.ws2020.domain.vhd.model.VHD0080DTO;
import com.ktng.ws2020.domain.vhd.service.VHD0080Service;
import com.ktng.ws2020.global.common.response.ListResult;
import com.ktng.ws2020.global.common.response.service.ResponseService;
import com.ktng.ws2020.global.config.security.userdetails.IamUserDetails;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/vhd0080")
public class VHD0080Controller {

	@Autowired
	private VHD0080Service vhd0080Service;
	
	@Autowired
    private ResponseService responseService;

    /**
    * 운행기록부 조회(영업용)를 조회한다.
    * @param 
    * @throws 
    */	
    @GetMapping("/selectRunHistoryListForSale")
    public ListResult<VHD0080DTO> selectRunHistoryListForSale(
    		@RequestParam(value = "vhclNo", required = false) String vhclNo,
    		@RequestParam(value = "fromYmd", required = false) String fromYmd,
    		@RequestParam(value = "toYmd", required = false) String toYmd,
    		@AuthenticationPrincipal Authentication auth) {
    	
    	IamUserDetails user = (IamUserDetails) auth.getPrincipal();
    	// UutasUserDTO uutasUser = uutasUserMapper.selectUserByEmpNo(user.getUsername());
    	
    	List<VHD0080DTO> vhd0080List = vhd0080Service.selectRunHistoryListForSale(vhclNo, fromYmd, toYmd);

    	return responseService.getListResult(vhd0080List);
    }
    
    /**
    * 선택한 차량의 상세내역을 조회한다.
    * @param 
    * @throws 
    */	
    @GetMapping("/selectRunHistoryListForSaleDtl")
    public ListResult<VHD0080DTO> selectRunHistoryListForSaleDtl(
    		@RequestParam(value = "vhclNo", required = false) String vhclNo,
    		@RequestParam(value = "fromYmd", required = false) String fromYmd,
    		@RequestParam(value = "toYmd", required = false) String toYmd,
    		@AuthenticationPrincipal Authentication auth) {
    	
    	IamUserDetails user = (IamUserDetails) auth.getPrincipal();
    	// UutasUserDTO uutasUser = uutasUserMapper.selectUserByEmpNo(user.getUsername());
    	
    	List<VHD0080DTO> vhd0080List = vhd0080Service.selectRunHistoryListForSaleDtl(vhclNo, fromYmd, toYmd);

    	return responseService.getListResult(vhd0080List);
    }

}
