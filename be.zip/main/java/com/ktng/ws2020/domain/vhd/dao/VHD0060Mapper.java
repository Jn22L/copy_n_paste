package com.ktng.ws2020.domain.vhd.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ktng.ws2020.domain.vhd.model.VHD0060DTO;

@Mapper
public interface VHD0060Mapper {

	public List<VHD0060DTO> selectRunHistoryListForWork(@Param("vhclNo") String vhclNo, @Param("fromYmd") String fromYmd, @Param("toYmd") String toYmd);
	
	public List<VHD0060DTO> selectRunHistoryListForWorkDtl(@Param("vhclNo") String vhclNo, @Param("fromYmd") String fromYmd, @Param("toYmd") String toYmd);
	
}

