package com.ktng.ws2020.domain.vhd.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ktng.ws2020.domain.vhd.model.VHD0020DTO;
import java.util.List;

@Mapper
public interface VHD0020Mapper {

	public List<VHD0020DTO> selectVhd0020List(@Param("vhclDeptCd") String vhclDeptCd, 
			                                  @Param("fromYmd") String fromYmd, 
			                                  @Param("toYmd") String toYmd,
			                                  @Param("chiefDeptCd") String chiefDeptCd,
			                                  @Param("driverNo") String driverNo,
			                                  @Param("vhclNo") String vhclNo			
			                                 );
	
}