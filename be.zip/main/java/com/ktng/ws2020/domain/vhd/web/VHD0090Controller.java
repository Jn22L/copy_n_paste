package com.ktng.ws2020.domain.vhd.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ktng.ws2020.domain.vhd.model.VHD0090DTO;
import com.ktng.ws2020.domain.vhd.service.VHD0090Service;
import com.ktng.ws2020.global.common.response.ListResult;
import com.ktng.ws2020.global.common.response.service.ResponseService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/vhd0090")
public class VHD0090Controller {

	@Autowired
	private VHD0090Service vhd0090Service;
	
	@Autowired
    private ResponseService responseService;

    /**
    * 운행기록 집계표 메뉴를 조회한다.
    * @param 
    * @throws 
    */	
    @GetMapping("/selectRunlogTotalList")
    public ListResult<VHD0090DTO> selectRunlogTotalList(
    		@RequestParam(value = "reportGbn", required = false) String reportGbn,
    		@RequestParam(value = "fromYmd", required = false) String fromYmd,
    		@RequestParam(value = "toYmd", required = false) String toYmd,
    		@RequestParam(value = "vhclNo", required = false) String vhclNo,
    		@AuthenticationPrincipal Authentication auth) {
    	
    	List<VHD0090DTO> vhd0090List = null; 
    	
    	if("2".equals(reportGbn)) {
    		vhd0090List = vhd0090Service.selectRunlogSaleTotalList(fromYmd, toYmd, vhclNo); //영업용
    	}else {
    		vhd0090List = vhd0090Service.selectRunlogTotalList(fromYmd, toYmd, vhclNo); //업무용
    	}
    	
    	return responseService.getListResult(vhd0090List);
    }
    
}
