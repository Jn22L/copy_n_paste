package com.ktng.ws2020.domain.vhd.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ktng.ws2020.domain.vhd.model.VHD0050DTO;

@Mapper
public interface VHD0050Mapper {

	public List<VHD0050DTO> selectRunHistoryList(@Param("vhclDeptCd") String vhclDeptCd, @Param("driverNo") String driverNo, @Param("driverNm") String driverNm, @Param("fromYmd") String fromYmd, @Param("toYmd") String toYmd);
	
}

