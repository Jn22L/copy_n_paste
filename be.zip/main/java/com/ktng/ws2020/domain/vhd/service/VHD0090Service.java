package com.ktng.ws2020.domain.vhd.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktng.ws2020.domain.vhd.dao.VHD0090Mapper;
import com.ktng.ws2020.domain.vhd.model.VHD0090DTO;

@Service
public class VHD0090Service {
	
	@Autowired
	private VHD0090Mapper vhd0090Mapper;
	
	public List<VHD0090DTO>  selectRunlogTotalList(String fromYmd, String toYmd, String vhclNo) {
		return vhd0090Mapper.selectRunlogTotalList(fromYmd, toYmd, vhclNo);
	}

	public List<VHD0090DTO>  selectRunlogSaleTotalList(String fromYmd, String toYmd, String vhclNo) {
		return vhd0090Mapper.selectRunlogSaleTotalList(fromYmd, toYmd, vhclNo);
	}
	
}
