package com.ktng.ws2020.domain.vhd.web;

import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ktng.ws2020.domain.vhd.service.VHD0020Service;
import com.ktng.ws2020.domain.vhd.model.VHD0020DTO;
import com.ktng.ws2020.da.model.CodeEntity;
import com.ktng.ws2020.global.common.response.CommonResult;
import com.ktng.ws2020.global.common.response.ListResult;
import com.ktng.ws2020.global.common.response.service.ResponseService;
import com.ktng.ws2020.global.config.security.userdetails.IamUserDetails;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/vhd0020")
public class VHD0020Controller {

	@Autowired
	private VHD0020Service vhd0020Service;
	
	@Autowired
    private ResponseService responseService;

    /**
    * 배차일지를 조회한다.
    * @param 
    * @throws 
    */	
    @GetMapping("/selectVhd0020List")
    public ListResult<VHD0020DTO> selectRoleListByRolcd(
    		@RequestParam(value = "vhclDeptCd", required = false) String vhclDeptCd,
    		@RequestParam(value = "fromYmd", required = false) String fromYmd,
    		@RequestParam(value = "toYmd", required = false) String toYmd,
    		@RequestParam(value = "chiefDeptCd", required = false) String chiefDeptCd,
    		@RequestParam(value = "driverNo", required = false) String driverNo,
    		@RequestParam(value = "vhclNo", required = false) String vhclNo,    		
    		@AuthenticationPrincipal Authentication auth) {
    	
    	IamUserDetails user = (IamUserDetails) auth.getPrincipal();

    	List<VHD0020DTO> vhd0020List = vhd0020Service.selectVhd0020List(vhclDeptCd, fromYmd, toYmd, chiefDeptCd, driverNo, vhclNo );

    	return responseService.getListResult(vhd0020List);
    }
    
}
