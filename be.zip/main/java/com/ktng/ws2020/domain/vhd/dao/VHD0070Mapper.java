package com.ktng.ws2020.domain.vhd.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ktng.ws2020.domain.vhd.model.VHD0070DTO;

@Mapper
public interface VHD0070Mapper {

	public List<VHD0070DTO> selectRunHistoryListForSale(@Param("vhclDeptCd") String vhclDeptCd);
	
	public List<VHD0070DTO> selectRunHistoryListForSaleDtl(@Param("vhclNo") String vhclNo, @Param("yyyyMm") String yyyyMm);
	
	public int insertGrid(@Param("vhd0070") VHD0070DTO vhd0070, @Param("altEmpNo") String altEmpNo);

	public int updateGrid(@Param("vhd0070") VHD0070DTO vhd0070, @Param("altEmpNo") String altEmpNo);

	public int deleteGrid(@Param("vhd0070") VHD0070DTO vhd0070);

	/* id로 조회 */
	public VHD0070DTO selectById(@Param("runDt") String runDt, @Param("vhclNo") String vhclNo, @Param("runSeq") String runSeq);
}

