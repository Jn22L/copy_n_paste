package com.ktng.ws2020.domain.vhd.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * 버스일지결재
 * @author t0210022
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class VHD0120DTO {
	private String ckBox;		// 체크박스
	private String yyyymm;		// 운행년월
	private String empNo;		// 사번
	private String seq;			// SEQ
	private String empNm;		// 성명
	private String runTm;		// 버스운행시간 -> 결재완료시:집계시간, 결재전:운행일지등록 시간
	private String approverEmpNo;	// 결재자 사번
	private String approverEmpNm;	// 결재자 이름
	private String approveTy;	// 결재상태
	private String approveDt;	// 결재일자
	private String insOrUpd;	// INS_OR_UPD
	private String cancelBtn;	// 취소버튼 toggle (1:보임,0:안보임)
}
