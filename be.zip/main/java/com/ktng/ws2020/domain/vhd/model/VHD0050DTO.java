package com.ktng.ws2020.domain.vhd.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class VHD0050DTO {
	private String empNo;
	private String orgNm;
	private String empNm;
	private String workTm;
	private String realRunTm;
	private String standbyTm;
	private String totRunKm;
	private String cafeteriaCnt;
	private String outlodgCnt;
	private String vhclDeptCd;
	private String driverNo;
	private String driverNm;
	private String fromYmd;
	private String toYmd;
} 