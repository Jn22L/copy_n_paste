package com.ktng.ws2020.domain.vhd.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Builder
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class VHD0110DTO {
	private String vhclNo;
	private String vhclType;
	private String empNo;
	private String partNm;
	private String empNm;
	private String runDt;
	private String realRunTm;
	private String reason;
	private String runSeq;
}
