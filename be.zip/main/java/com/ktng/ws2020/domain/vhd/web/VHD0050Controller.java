package com.ktng.ws2020.domain.vhd.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ktng.ws2020.domain.vhd.model.VHD0050DTO;
import com.ktng.ws2020.domain.vhd.service.VHD0050Service;
import com.ktng.ws2020.global.common.response.ListResult;
import com.ktng.ws2020.global.common.response.service.ResponseService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/vhd0050")
public class VHD0050Controller {

	@Autowired
	private VHD0050Service vhd0050Service;
	
	@Autowired
    private ResponseService responseService;

    /**
    * 권한메뉴를 조회한다.
    * @param 
    * @throws 
    */	
    @GetMapping("/selectRunHistoryList")
    public ListResult<VHD0050DTO> selectRoleListByRolcd(
    		@RequestParam(value = "vhclDeptCd", required = false) String vhclDeptCd,
    		@RequestParam(value = "driverNo", required = false) String driverNo,
    		@RequestParam(value = "driverNm", required = false) String driverNm,
    		@RequestParam(value = "fromYmd", required = false) String fromYmd,
    		@RequestParam(value = "toYmd", required = false) String toYmd,
    		@AuthenticationPrincipal Authentication auth) {
    	
    	//IamUserDetails user = (IamUserDetails) auth.getPrincipal();
    	// UutasUserDTO uutasUser = uutasUserMapper.selectUserByEmpNo(user.getUsername());
    	
    	List<VHD0050DTO> vhd0050List = vhd0050Service.selectRunHistoryList(vhclDeptCd, driverNo, driverNm, fromYmd, toYmd);

    	return responseService.getListResult(vhd0050List);
    }

}
