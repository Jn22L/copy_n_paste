package com.ktng.ws2020.domain.vhd.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ktng.ws2020.domain.vhd.model.VHD0060DTO;
import com.ktng.ws2020.domain.vhd.service.VHD0060Service;
import com.ktng.ws2020.global.common.response.ListResult;
import com.ktng.ws2020.global.common.response.service.ResponseService;
import com.ktng.ws2020.global.config.security.userdetails.IamUserDetails;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/vhd0060")
public class VHD0060Controller {

	@Autowired
	private VHD0060Service vhd0060Service;
	
	@Autowired
    private ResponseService responseService;

    /**
    * 운행기록부 조회(업무용)를 조회한다.
    * @param 
    * @throws 
    */	
    @GetMapping("/selectRunHistoryListForWork")
    public ListResult<VHD0060DTO> selectRunHistoryListForSale(
    		@RequestParam(value = "vhclNo", required = false) String vhclNo,
    		@RequestParam(value = "fromYmd", required = false) String fromYmd,
    		@RequestParam(value = "toYmd", required = false) String toYmd,
    		@AuthenticationPrincipal Authentication auth) {
    	
    	IamUserDetails user = (IamUserDetails) auth.getPrincipal();
    	// UutasUserDTO uutasUser = uutasUserMapper.selectUserByEmpNo(user.getUsername());
    	
    	List<VHD0060DTO> vhd0060List = vhd0060Service.selectRunHistoryListForWork(vhclNo, fromYmd, toYmd);

    	return responseService.getListResult(vhd0060List);
    }
    
    /**
    * 선택한 차량의 상세내역을 조회한다.
    * @param 
    * @throws 
    */	
    @GetMapping("/selectRunHistoryListForWorkDtl")
    public ListResult<VHD0060DTO> selectRunHistoryListForSaleDtl(
    		@RequestParam(value = "vhclNo", required = false) String vhclNo,
    		@RequestParam(value = "fromYmd", required = false) String fromYmd,
    		@RequestParam(value = "toYmd", required = false) String toYmd,
    		@AuthenticationPrincipal Authentication auth) {
    	
    	IamUserDetails user = (IamUserDetails) auth.getPrincipal();
    	// UutasUserDTO uutasUser = uutasUserMapper.selectUserByEmpNo(user.getUsername());
    	
    	List<VHD0060DTO> vhd0060List = vhd0060Service.selectRunHistoryListForWorkDtl(vhclNo, fromYmd, toYmd);

    	return responseService.getListResult(vhd0060List);
    }

}
