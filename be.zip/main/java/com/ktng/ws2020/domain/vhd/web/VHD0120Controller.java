package com.ktng.ws2020.domain.vhd.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ktng.ws2020.domain.vhd.model.VHD0120DTO;
import com.ktng.ws2020.domain.vhd.service.VHD0120Service;
import com.ktng.ws2020.global.common.response.CommonResult;
import com.ktng.ws2020.global.common.response.ListResult;
import com.ktng.ws2020.global.common.response.service.ResponseService;
import com.ktng.ws2020.global.config.security.userdetails.IamUserDetails;

@RestController
@RequestMapping("/api/vhd0120")
public class VHD0120Controller {

	@Autowired
	private VHD0120Service vhd0120Service;

	@Autowired
	private ResponseService responseService;

	/**
	 * 운행일지등록건중 업무용(버스) 리스트 조회
	 *
	 * @param runDt : 운행년월 
	 */
	@GetMapping
	public ListResult<VHD0120DTO> selectGridList(
			@RequestParam(value = "runDt", required = false) String runDt,
			@AuthenticationPrincipal Authentication auth
			) {
		
		IamUserDetails user = (IamUserDetails) auth.getPrincipal();
		
		List<VHD0120DTO> vhd0120List = vhd0120Service.selectGridList(runDt, user.getUsername());
		return responseService.getListResult(vhd0120List);
	}

	/**
	 * 배차부서 리스트 변경사항(추가/수정/삭제) 반영
	 *
	 * @param changesMap 추가(I)/수정(U)/삭제(D) 별로 변경된 데이터List를 가진 데이터Map
	 * @param auth 로그인된 사용자정보를 가져올 때 사용
	 */
	@PostMapping(value = "/insert")
	public CommonResult insertVhd0120(
			@RequestBody List<VHD0120DTO> selectedRows,
    		@AuthenticationPrincipal Authentication auth) { 
		
		IamUserDetails user = (IamUserDetails) auth.getPrincipal();
		
		vhd0120Service.insertVhd0120(selectedRows, user.getUsername());
    	return responseService.getSuccessResult();
	}
	
	
	/**
	 * 배차부서 리스트 변경사항(추가/수정/삭제) 반영
	 *
	 * @param changesMap 추가(I)/수정(U)/삭제(D) 별로 변경된 데이터List를 가진 데이터Map
	 * @param auth 로그인된 사용자정보를 가져올 때 사용
	 */
	@PostMapping(value = "/delete")
	public CommonResult deleteVhd0120(@RequestBody VHD0120DTO params) { 
		
		vhd0120Service.deleteVhd0120(params);
    	return responseService.getSuccessResult();
	}
}
