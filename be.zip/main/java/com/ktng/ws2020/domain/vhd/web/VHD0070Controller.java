package com.ktng.ws2020.domain.vhd.web;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ktng.ws2020.domain.vhd.model.VHD0070DTO;
import com.ktng.ws2020.domain.vhd.service.VHD0070Service;
import com.ktng.ws2020.global.common.response.CommonResult;
import com.ktng.ws2020.global.common.response.ListResult;
import com.ktng.ws2020.global.common.response.service.ResponseService;
import com.ktng.ws2020.global.config.security.userdetails.IamUserDetails;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/vhd0070")
public class VHD0070Controller {

	@Autowired
	private VHD0070Service vhd0070Service;
	
	@Autowired
    private ResponseService responseService;

    /**
    * 운행기록부 조회(영업용)를 조회한다.
    * @param 
    * @throws 
    */	
    @GetMapping("/selectRunHistoryListForSale")
    public ListResult<VHD0070DTO> selectRunHistoryListForSale(
    		@RequestParam(value = "vhclDeptCd", required = false) String vhclDeptCd,
    		@AuthenticationPrincipal Authentication auth) {
    	
    	IamUserDetails user = (IamUserDetails) auth.getPrincipal();
    	// UutasUserDTO uutasUser = uutasUserMapper.selectUserByEmpNo(user.getUsername());
    	
    	List<VHD0070DTO> vhd0070List = vhd0070Service.selectRunHistoryListForSale(vhclDeptCd);

    	return responseService.getListResult(vhd0070List);
    }
    
    /**
    * 선택한 차량의 상세내역을 조회한다.
    * @param 
    * @throws 
    */	
    @GetMapping("/selectRunHistoryListForSaleDtl")
    public ListResult<VHD0070DTO> selectRunHistoryListForSaleDtl(
    		@RequestParam(value = "vhclNo", required = false) String vhclNo,
    		@RequestParam(value = "yyyyMm", required = false) String yyyyMm,
    		@AuthenticationPrincipal Authentication auth) {
    	
    	IamUserDetails user = (IamUserDetails) auth.getPrincipal();
    	// UutasUserDTO uutasUser = uutasUserMapper.selectUserByEmpNo(user.getUsername());
    	
    	List<VHD0070DTO> vhd0070List = vhd0070Service.selectRunHistoryListForSaleDtl(vhclNo, yyyyMm);

    	return responseService.getListResult(vhd0070List);
    }
        
	/**
	 * 운전원 리스트 변경사항(추가/수정/삭제) 반영
	 *
	 * @param changesMap 추가(I)/수정(U)/삭제(D) 별로 변경된 데이터List를 가진 데이터Map
	 * @param auth 로그인된 사용자정보를 가져올 때 사용
	 */
	@PostMapping
	public CommonResult saveGrid(
			@RequestBody Map<String, List<VHD0070DTO>> changesMap,
    		@AuthenticationPrincipal Authentication auth) { 
		IamUserDetails user = (IamUserDetails) auth.getPrincipal();

		// 작업순서 `삭제` → `수정` → `추가`
		List<VHD0070DTO> deleteList = changesMap.get("D");
		vhd0070Service.deleteGrid(deleteList);

    	List<VHD0070DTO> updateList = changesMap.get("U");
    	vhd0070Service.saveGrid(updateList, user.getUsername());

    	List<VHD0070DTO> insertList = changesMap.get("I");
    	vhd0070Service.saveGrid(insertList, user.getUsername());

    	return responseService.getSuccessResult();
	}
    
}
