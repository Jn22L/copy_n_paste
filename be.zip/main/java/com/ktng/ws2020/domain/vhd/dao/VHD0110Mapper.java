package com.ktng.ws2020.domain.vhd.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ktng.ws2020.domain.vhd.model.VHD0110DTO;

@Mapper
public interface VHD0110Mapper {

	public List<VHD0110DTO> selectDailyBusLogList(@Param("fromYmd") String fromYmd, @Param("toYmd") String toYmd, @Param("driverNo") String driverNo, @Param("driverNm") String driverNm);
	
}
