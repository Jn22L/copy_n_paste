package com.ktng.ws2020.domain.vhd.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktng.ws2020.domain.vhd.dao.VHD0050Mapper;
import com.ktng.ws2020.domain.vhd.model.VHD0050DTO;

@Service
public class VHD0050Service {
	
	@Autowired
	private VHD0050Mapper vhd0050Mapper;

	public List<VHD0050DTO>  selectRunHistoryList(String vhclDeptCd, String driverNo, String driverNm, String fromYmd, String toYmd) {
		return vhd0050Mapper.selectRunHistoryList(vhclDeptCd, driverNo, driverNm, fromYmd, toYmd);
	}     
	

}
