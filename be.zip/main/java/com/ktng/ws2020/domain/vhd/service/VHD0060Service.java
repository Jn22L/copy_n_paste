package com.ktng.ws2020.domain.vhd.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktng.ws2020.domain.vhd.dao.VHD0060Mapper;
import com.ktng.ws2020.domain.vhd.model.VHD0060DTO;

@Service
public class VHD0060Service {
	
	@Autowired
	private VHD0060Mapper vhd0060Mapper;

	public List<VHD0060DTO>  selectRunHistoryListForWork(String vhclNo, String fromYmd, String toYmd) {
		return vhd0060Mapper.selectRunHistoryListForWork(vhclNo, fromYmd, toYmd);
	}
	
	public List<VHD0060DTO>  selectRunHistoryListForWorkDtl(String vhclNo, String fromYmd, String toYmd) {
		return vhd0060Mapper.selectRunHistoryListForWorkDtl(vhclNo, fromYmd, toYmd);
	}

}
