package com.ktng.ws2020.domain.vhd.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Builder
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class VHD0090DTO {
	private String userPartNm;
	private String vhclNo;
	private String beforeRunKm;
	private String afterRunKm;
	private String runKm;
	private String runKindKm1;
	private String runKindKm2;
	private String runKindKm3;
}
