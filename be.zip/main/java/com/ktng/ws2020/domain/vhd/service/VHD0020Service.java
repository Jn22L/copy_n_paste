package com.ktng.ws2020.domain.vhd.service;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktng.ws2020.da.model.CodeEntity;
import com.ktng.ws2020.da.model.ids.CodeID;
import com.ktng.ws2020.domain.vhd.dao.VHD0020Mapper;
import com.ktng.ws2020.domain.vhd.model.VHD0020DTO;
import com.ktng.ws2020.domain.menu.model.MenuTreeDTO;

@Service
public class VHD0020Service {
	
	@Autowired
	private VHD0020Mapper vhd0020Mapper;

	public List<VHD0020DTO>  selectVhd0020List(String vhclDeptCd, String fromYmd, String toYmd, String chiefDeptCd, String driverNo, String vhclNo) {
		return vhd0020Mapper.selectVhd0020List(vhclDeptCd, fromYmd, toYmd,chiefDeptCd, driverNo, vhclNo );
	}
	
}
