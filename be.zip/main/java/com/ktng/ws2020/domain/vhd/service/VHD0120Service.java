package com.ktng.ws2020.domain.vhd.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktng.ws2020.domain.vhd.dao.VHD0120Mapper;
import com.ktng.ws2020.domain.vhd.model.VHD0120DTO;

@Service
public class VHD0120Service {

	@Autowired
	private VHD0120Mapper vhd0120Mapper;

	/* 조회 */
	public List<VHD0120DTO> selectGridList(String runDt, String UserCd) {
		return vhd0120Mapper.selectGridList(runDt, UserCd);
	}
	
	/* 삭제 */
	public void insertVhd0120(List<VHD0120DTO> selectedRows, String altEmpNo) {
		
		selectedRows.forEach(selectedRow -> {
			vhd0120Mapper.insertVhd0120(selectedRow, altEmpNo);
		});
	}
	
	/* 삭제 */
	public void deleteVhd0120(VHD0120DTO params) {
		
//		if (params.size() == 0) return;

		// 삭제할 Entity 조회 및 확인
		vhd0120Mapper.deleteVhd0120(params);
	}
	
}
