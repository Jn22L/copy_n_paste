package com.ktng.ws2020.domain.vhd.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class VHD0060DTO {
	private String vhclNo;
	private String vhclNm;
	private String vhType;
	private String vhTypeNm;
	private String vhclDeptNm;
	private String recordDt;
	private String expireDt;
	private String vhNote;
	private String altEmpNo;
	private String altDate;
	private String runDt;
	private String userEmpNo;
	private String userEmpNm;
	private String userPartNm;
	private String userPosGrdNm;
	private String beforeRunKm;
	private String afterRunKm;
	private String runKm;
	private String runKindKm1;
	private String runKindKm2;
	private String runKindKm3;
	private String reason;
}