package com.ktng.ws2020.domain.vhd.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktng.ws2020.domain.vhd.dao.VHD0110Mapper;
import com.ktng.ws2020.domain.vhd.model.VHD0110DTO;

@Service
public class VHD0110Service {
	
	@Autowired
	private VHD0110Mapper vhd0110Mapper;

	public List<VHD0110DTO>  selectDailyBusLogList(String fromYmd, String toYmd, String driverNo, String driverNm) {
		return vhd0110Mapper.selectDailyBusLogList(fromYmd, toYmd, driverNo, driverNm);
	}
	
}
