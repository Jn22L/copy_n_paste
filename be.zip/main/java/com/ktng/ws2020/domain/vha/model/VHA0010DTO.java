package com.ktng.ws2020.domain.vha.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * 배차부서관리
 * @author t0210023
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class VHA0010DTO {
	private String vhclDeptCd;
	private String vhclDeptNm;
	private String vhclDeptPn;
	private String vhclEmpPn;
	private String recordDt;
	private String expireDt;
	private String useYn;
	private String authGubun;
	private String bonbuUseYn;
	private String note;
}
