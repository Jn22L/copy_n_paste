package com.ktng.ws2020.domain.vha.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktng.ws2020.domain.vha.dao.VHA0040SubMapper;
import com.ktng.ws2020.domain.vha.model.VHA0040SubDTO;

@Service
public class VHA0040SubService {

	@Autowired
	private VHA0040SubMapper vha0040SubMapper;

	/* 조회 */
	public VHA0040SubDTO selectOne(String boardId) {
		return vha0040SubMapper.selectOne(boardId);
	}

	/* 추가 */
	public int insertOne(VHA0040SubDTO vha0040, String regEmpNo, String regDeptCd) {
		return vha0040SubMapper.insertOne(vha0040, regEmpNo, regDeptCd);
	}

	/* 수정 */
	@Transactional
	public int updateOne(VHA0040SubDTO vha0040, String altEmpNo) {
		VHA0040SubDTO _vha0040 = vha0040SubMapper.selectOne(vha0040.getBoardId());
		if (_vha0040 == null) return 0; // 게시번호가 없으면 수정안함

		return vha0040SubMapper.updateOne(vha0040, altEmpNo);
	}

	/* 조회수 증가 */
	public int increaseViewNum(String boardId, String altEmpNo) {
		// 조회수 컬럼 '1' 증가
		return vha0040SubMapper.increaseViewNum(boardId, altEmpNo);
	}

	/* 삭제 */
	public int deleteOne(String boardId, String altEmpNo) {
		// 삭제여부 컬럼 'Y'로 수정
		return vha0040SubMapper.deleteOne(boardId, altEmpNo);
	}

}
