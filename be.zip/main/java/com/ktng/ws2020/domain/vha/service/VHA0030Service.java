package com.ktng.ws2020.domain.vha.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktng.ws2020.domain.vha.dao.VHA0030Mapper;
import com.ktng.ws2020.domain.vha.model.VHA0030DTO;

@Service
public class VHA0030Service {

	@Autowired
	private VHA0030Mapper vha0030Mapper;

	/* 조회 */
	public List<VHA0030DTO> selectGrid(String vhclDeptCd, String useYn) {
		return vha0030Mapper.selectGrid(vhclDeptCd, useYn);
	}

	/* 추가, 수정 */
	@Transactional
	public void saveGrid(List<VHA0030DTO> vha0030List, String altEmpNo) {
		vha0030List.forEach(vha0030 -> {
			// ID로 기존 데이터 조회
			VHA0030DTO _vha0030 = vha0030Mapper.selectById(vha0030.getDriverNo());
			if (_vha0030 == null) {
				// 기존 데이터가 없으면 insert
				vha0030Mapper.insertGrid(vha0030, altEmpNo);
			} else {
				// 있으면 update
				vha0030Mapper.updateGrid(vha0030, altEmpNo);
			}
		});
	}

	/* 삭제 */
	public int deleteGrid(List<VHA0030DTO> vha0030List) {
		if (vha0030List.size() == 0) return 0;

		// 삭제할 Entity 조회 및 확인
		return vha0030Mapper.deleteGrid(vha0030List);
	}

}
