package com.ktng.ws2020.domain.vha.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ktng.ws2020.domain.vha.model.VHA0040SubDTO;

@Mapper
public interface VHA0040SubMapper {

	// 게시물 상세 조회
	public VHA0040SubDTO selectOne(
			@Param("boardId") String boardId);

	// 게시물 ID 생성 및 추가
	public int insertOne(
			@Param("vha0040") VHA0040SubDTO vha0040,
			@Param("regEmpNo") String regEmpNo,
			@Param("regDeptCd") String regDeptCd);

	// 게시물 수정
	public int updateOne(
			@Param("vha0040") VHA0040SubDTO vha0040,
			@Param("altEmpNo") String altEmpNo);

	// 조회수 증가
	public int increaseViewNum(
			@Param("boardId") String boardId,
			@Param("altEmpNo") String altEmpNo);

	// 게시물 삭제처리 (`deleteStatus` 컬럼 변경)
	public int deleteOne(
			@Param("boardId") String boardId,
			@Param("altEmpNo") String altEmpNo);

}
