package com.ktng.ws2020.domain.vha.web;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ktng.ws2020.domain.vha.model.VHA0020DTO;
import com.ktng.ws2020.domain.vha.service.VHA0020Service;
import com.ktng.ws2020.global.common.response.CommonResult;
import com.ktng.ws2020.global.common.response.ListResult;
import com.ktng.ws2020.global.common.response.service.ResponseService;
import com.ktng.ws2020.global.config.security.userdetails.IamUserDetails;

@RestController
@RequestMapping("/api/vha0020")
public class VHA0020Controller {

	@Autowired
	private VHA0020Service vha0020Service;

	@Autowired
	private ResponseService responseService;

	/**
	 * 차량 리스트 조회
	 *
	 * @param vhclDeptCd 검색할 배차부서코드
	 * @param useYn 검색할 사용여부
	 */
	@GetMapping
	public ListResult<VHA0020DTO> selectGrid(
			@RequestParam(value = "vhclDeptCd", required = false) String vhclDeptCd,
			@RequestParam(value = "useYn", required = false) String useYn) {
		List<VHA0020DTO> vha0020List = vha0020Service.selectGrid(vhclDeptCd, useYn);
		return responseService.getListResult(vha0020List);
	}

	/**
	 * 차량 리스트 변경사항(추가/수정/삭제) 반영
	 *
	 * @param changesMap 추가(I)/수정(U)/삭제(D) 별로 변경된 데이터List를 가진 데이터Map
	 * @param auth 로그인된 사용자정보를 가져올 때 사용
	 */
	@PostMapping
	public CommonResult saveGrid(
			@RequestBody Map<String, List<VHA0020DTO>> changesMap,
    		@AuthenticationPrincipal Authentication auth) { 
		IamUserDetails user = (IamUserDetails) auth.getPrincipal();

		// 작업순서 `삭제` → `수정` → `추가`
		List<VHA0020DTO> deleteList = changesMap.get("D");
		vha0020Service.deleteGrid(deleteList);

    	List<VHA0020DTO> updateList = changesMap.get("U");
    	vha0020Service.saveGrid(updateList, user.getUsername());

    	List<VHA0020DTO> insertList = changesMap.get("I");
    	vha0020Service.saveGrid(insertList, user.getUsername());

    	return responseService.getSuccessResult();
	}

}
