package com.ktng.ws2020.domain.vha.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * 게시물 리스트
 * @author t0210023
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class VHA0040MstDTO {
	private String boardTitle; // 게시제목
	private String vhclDeptNm; // 배차부서명
	private String startDate; // 게시 시작일
	private String endDate; // 게시 종료일
	private String viewNum; // 조회수
	private String boardId; // 게시번호
	private String regDate; // 등록일시
}
