package com.ktng.ws2020.domain.vha.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ktng.ws2020.domain.common.model.UutasUserDTO;
import com.ktng.ws2020.domain.common.service.UutasUserService;
import com.ktng.ws2020.domain.vha.exception.VHA0040InsertFailException;
import com.ktng.ws2020.domain.vha.exception.VHA0040UpdateFailException;
import com.ktng.ws2020.domain.vha.model.VHA0040MstDTO;
import com.ktng.ws2020.domain.vha.model.VHA0040SubDTO;
import com.ktng.ws2020.domain.vha.service.VHA0040MstService;
import com.ktng.ws2020.domain.vha.service.VHA0040SubService;
import com.ktng.ws2020.global.common.response.CommonResult;
import com.ktng.ws2020.global.common.response.ListResult;
import com.ktng.ws2020.global.common.response.SingleResult;
import com.ktng.ws2020.global.common.response.service.ResponseService;
import com.ktng.ws2020.global.config.security.userdetails.IamUserDetails;

@RestController
@RequestMapping("/api/vha0040")
public class VHA0040Controller {

	@Autowired
	private VHA0040MstService vha0040MstService; // 게시물 리스트

	@Autowired
	private VHA0040SubService vha0040SubService; // 게시물 상세
	
	@Autowired
	private UutasUserService uutasUserService; // 게시물 작성자정보 조회

	@Autowired
	private ResponseService responseService;

	/**
	 * 게시물 리스트 조회
	 *
	 * @param vhclDeptCd 검색할 배차부서코드
	 * @param useYn 검색할 사용여부
	 */
	@GetMapping
	public ListResult<VHA0040MstDTO> selectMstGrid(
			@RequestParam(value = "vhclDeptCd", required = false) String vhclDeptCd,
			@RequestParam(value = "sregYear", required = false) String sregYear) {
		List<VHA0040MstDTO> vha0040List = vha0040MstService.selectGrid(vhclDeptCd, sregYear);

		return responseService.getListResult(vha0040List);
	}

	/**
	 * 게시물 상세 조회
	 *
	 * @param boardId 조회할 게시번호
	 */
	@GetMapping("/{boardId}")
	public SingleResult<VHA0040SubDTO> selectSubOne(
			@PathVariable("boardId") String boardId,
    		@AuthenticationPrincipal Authentication auth) {
		IamUserDetails user = (IamUserDetails) auth.getPrincipal();

		// 1. 게시물 상세 조회
		VHA0040SubDTO vha0040 = vha0040SubService.selectOne(boardId);

		// 2. 게시물 조회수 증가
		// 본인 게시물이 아닌 경우,
		if (!vha0040.getRegId().contentEquals(user.getUsername())) {
			// 게시물 조회 시 조회수 1 증가
			vha0040SubService.increaseViewNum(boardId, user.getUsername());
			
			Long viewNum = Long.valueOf(vha0040.getViewNum()) + 1;
			vha0040.setViewNum(String.valueOf(viewNum));
		}

		return responseService.getSingleResult(vha0040);
	}

	/**
	 * 게시물 상세 추가 반영
	 *
	 * @param vha0040 추가할 게시물
	 * @param auth 로그인된 사용자정보를 가져올 때 사용
	 */
	@PostMapping
	public CommonResult insertSubOne(
			@RequestBody VHA0040SubDTO vha0040,
    		@AuthenticationPrincipal Authentication auth) { 
		IamUserDetails user = (IamUserDetails) auth.getPrincipal();
		UutasUserDTO uutasUser = uutasUserService.getUserByEmpNo(user.getUsername());

		int addCnt = vha0040SubService.insertOne(vha0040, user.getUsername(), uutasUser.getPartCd());
		if (addCnt == 0) {
			throw new VHA0040InsertFailException();
		}

		return responseService.getSuccessResult();
	}

	/**
	 * 게시물 상세 수정 반영
	 *
	 * @param vha0040 수정할 게시물
	 * @param auth 로그인된 사용자정보를 가져올 때 사용
	 */
	@PutMapping
	public CommonResult updateSubOne(
			@RequestBody VHA0040SubDTO vha0040,
    		@AuthenticationPrincipal Authentication auth) { 
		IamUserDetails user = (IamUserDetails) auth.getPrincipal();

		int updCnt = vha0040SubService.updateOne(vha0040, user.getUsername());
		if (updCnt == 0) {
			throw new VHA0040UpdateFailException();
		}

    	return responseService.getSuccessResult();
	}

	/**
	 * 게시물 상세 삭제 반영
	 *
	 * @param boardId 삭제할 게시번호
	 * @param auth 로그인된 사용자정보를 가져올 때 사용
	 */
	@DeleteMapping("/{boardId}")
	public CommonResult deleteSubOne(
			@PathVariable("boardId") String boardId,
    		@AuthenticationPrincipal Authentication auth) { 
		IamUserDetails user = (IamUserDetails) auth.getPrincipal();

		int delCnt = vha0040SubService.deleteOne(boardId, user.getUsername());
		if (delCnt == 0) {
			throw new VHA0040UpdateFailException();
		}

    	return responseService.getSuccessResult();
	}

}
