package com.ktng.ws2020.domain.vha.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktng.ws2020.domain.vha.dao.VHA0040MstMapper;
import com.ktng.ws2020.domain.vha.model.VHA0040MstDTO;

@Service
public class VHA0040MstService {

	@Autowired
	private VHA0040MstMapper vha0040MstMapper;

	/* 조회 */
	public List<VHA0040MstDTO> selectGrid(String vhclDeptCd, String sregYear) {
		return vha0040MstMapper.selectGrid(vhclDeptCd, sregYear);
	}

}
