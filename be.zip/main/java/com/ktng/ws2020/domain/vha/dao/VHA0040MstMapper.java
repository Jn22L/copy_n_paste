package com.ktng.ws2020.domain.vha.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ktng.ws2020.domain.vha.model.VHA0040MstDTO;

@Mapper
public interface VHA0040MstMapper {

	/* 1. grid CRUD */
	public List<VHA0040MstDTO> selectGrid(
			@Param("vhclDeptCd") String vhclDeptCd, // 관리부서코드 
			@Param("sregYear") String sregYear // 등록년도 (yyyy)
		);

}
