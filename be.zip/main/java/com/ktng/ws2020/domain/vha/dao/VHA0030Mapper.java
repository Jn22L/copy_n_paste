package com.ktng.ws2020.domain.vha.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ktng.ws2020.domain.vha.model.VHA0030DTO;

@Mapper
public interface VHA0030Mapper {

	/* 1. grid CRUD */
	public List<VHA0030DTO> selectGrid(@Param("vhclDeptCd") String vhclDeptCd, @Param("useYn") String useYn);

	public int insertGrid(@Param("vha0030") VHA0030DTO vha0030, @Param("altEmpNo") String altEmpNo);

	public int updateGrid(@Param("vha0030") VHA0030DTO vha0030, @Param("altEmpNo") String altEmpNo);

	public int deleteGrid(@Param("vha0030List") List<VHA0030DTO> vha0030List);

	/* id로 조회 */
	public VHA0030DTO selectById(@Param("driverNo") String driverNo);
}
