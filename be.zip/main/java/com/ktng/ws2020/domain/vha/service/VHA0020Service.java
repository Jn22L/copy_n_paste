package com.ktng.ws2020.domain.vha.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktng.ws2020.domain.vha.dao.VHA0020Mapper;
import com.ktng.ws2020.domain.vha.model.VHA0020DTO;

@Service
public class VHA0020Service {

	@Autowired
	private VHA0020Mapper vha0020Mapper;

	/* 조회 */
	public List<VHA0020DTO> selectGrid(String vhclDeptCd, String useYn) {
		return vha0020Mapper.selectGrid(vhclDeptCd, useYn);
	}

	/* 추가, 수정 */
	@Transactional
	public void saveGrid(List<VHA0020DTO> vha0020List, String altEmpNo) {
		vha0020List.forEach(vha0020 -> {
			// ID로 기존 데이터 조회
			VHA0020DTO _vha0020 = vha0020Mapper.selectById(vha0020.getVhclNo());
			if (_vha0020 == null) {
				// 기존 데이터가 없으면 insert
				vha0020Mapper.insertGrid(vha0020, altEmpNo);
			} else {
				// 있으면 update
				vha0020Mapper.updateGrid(vha0020, altEmpNo);
			}
		});
	}

	/* 삭제 */
	public int deleteGrid(List<VHA0020DTO> vha0020List) {
		if (vha0020List.size() == 0) return 0;

		return vha0020Mapper.deleteGrid(vha0020List);
	}

}
