package com.ktng.ws2020.domain.vha.exception;

import com.ktng.ws2020.global.error.exception.BusinessException;
import com.ktng.ws2020.global.error.exception.ErrorCode;

public class VHA0040DeleteFailException extends BusinessException {
	private static final long serialVersionUID = 6529877633246331350L;

	public VHA0040DeleteFailException() {
        super(ErrorCode.VHA0040_DELETE_FAIL);
    }

	public VHA0040DeleteFailException(String message) {
        super(message, ErrorCode.VHA0040_DELETE_FAIL);
    }

}
