package com.ktng.ws2020.domain.vha.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ktng.ws2020.domain.vha.model.VHA0010DTO;

@Mapper
public interface VHA0010Mapper {

	/* 1. grid CRUD */
	public List<VHA0010DTO> selectGrid(@Param("vhclDeptNm") String vhclDeptNm);

	public int insertGrid(@Param("vha0010") VHA0010DTO vha0010, @Param("altEmpNo") String altEmpNo);

	public int updateGrid(@Param("vha0010") VHA0010DTO vha0010, @Param("altEmpNo") String altEmpNo);

	public int deleteGrid(@Param("vha0010List") List<VHA0010DTO> vha0010List);

	/* id로 조회 */
	public VHA0010DTO selectById(@Param("vhclDeptCd") String vhclDeptCd);
}
