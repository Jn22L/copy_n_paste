package com.ktng.ws2020.domain.vha.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktng.ws2020.domain.vha.dao.VHA0010Mapper;
import com.ktng.ws2020.domain.vha.model.VHA0010DTO;

@Service
public class VHA0010Service {

	@Autowired
	private VHA0010Mapper vha0010Mapper;

	/* 조회 */
	public List<VHA0010DTO> selectGrid(String vhclDeptNm) {
		return vha0010Mapper.selectGrid(vhclDeptNm);
	}

	/* 추가, 수정 */
	public void saveGrid(List<VHA0010DTO> vha0010List, String altEmpNo) {
		vha0010List.forEach(vha0010 -> {
			// ID로 기존 데이터 조회
			VHA0010DTO _vha0010 = vha0010Mapper.selectById(vha0010.getVhclDeptCd());
			if (_vha0010 == null) {
				// 기존 데이터가 없으면 insert
				vha0010Mapper.insertGrid(vha0010, altEmpNo);
			} else {
				// 있으면 update
				vha0010Mapper.updateGrid(vha0010, altEmpNo);
			}
		});
	}

	/* 삭제 */
	public int deleteGrid(List<VHA0010DTO> vha0010List) {
		if (vha0010List.size() == 0) return 0;

		// 삭제할 Entity 조회 및 확인
		return vha0010Mapper.deleteGrid(vha0010List);
	}

}
