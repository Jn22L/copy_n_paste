package com.ktng.ws2020.domain.vha.exception;

import com.ktng.ws2020.global.error.exception.BusinessException;
import com.ktng.ws2020.global.error.exception.ErrorCode;

public class VHA0040UpdateFailException extends BusinessException {
	private static final long serialVersionUID = 723029240044909637L;

	public VHA0040UpdateFailException() {
        super(ErrorCode.VHA0040_UPDATE_FAIL);
    }

	public VHA0040UpdateFailException(String message) {
        super(message, ErrorCode.VHA0040_UPDATE_FAIL);
    }

}
