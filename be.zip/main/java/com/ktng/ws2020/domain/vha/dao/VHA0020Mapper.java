package com.ktng.ws2020.domain.vha.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ktng.ws2020.domain.vha.model.VHA0020DTO;

@Mapper
public interface VHA0020Mapper {

	/* 1. grid CRUD */
	public List<VHA0020DTO> selectGrid(@Param("vhclDeptCd") String vhclDeptCd, @Param("useYn") String useYn);

	public int insertGrid(@Param("vha0020") VHA0020DTO vha0020, @Param("altEmpNo") String altEmpNo);

	public int updateGrid(@Param("vha0020") VHA0020DTO vha0020, @Param("altEmpNo") String altEmpNo);

	public int deleteGrid(@Param("vha0020List") List<VHA0020DTO> vha0020List);

	/* id로 조회 */
	public VHA0020DTO selectById(@Param("vhclNo") String vhclNo);
}
