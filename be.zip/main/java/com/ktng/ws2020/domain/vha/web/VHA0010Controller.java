package com.ktng.ws2020.domain.vha.web;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ktng.ws2020.domain.vha.model.VHA0010DTO;
import com.ktng.ws2020.domain.vha.service.VHA0010Service;
import com.ktng.ws2020.global.common.response.CommonResult;
import com.ktng.ws2020.global.common.response.ListResult;
import com.ktng.ws2020.global.common.response.service.ResponseService;
import com.ktng.ws2020.global.config.security.userdetails.IamUserDetails;

@RestController
@RequestMapping("/api/vha0010")
public class VHA0010Controller {

	@Autowired
	private VHA0010Service vha0010Service;

	@Autowired
	private ResponseService responseService;

	/**
	 * 배차부서 리스트 조회
	 *
	 * @param vhclDeptNm 검색할 배차부서명
	 */
	@GetMapping
	public ListResult<VHA0010DTO> selectGrid(
			@RequestParam(value = "vhclDeptNm", required = false) String vhclDeptNm) {
		List<VHA0010DTO> vha0010List = vha0010Service.selectGrid(vhclDeptNm);
		return responseService.getListResult(vha0010List);
	}

	/**
	 * 배차부서 리스트 변경사항(추가/수정/삭제) 반영
	 *
	 * @param changesMap 추가(I)/수정(U)/삭제(D) 별로 변경된 데이터List를 가진 데이터Map
	 * @param auth 로그인된 사용자정보를 가져올 때 사용
	 */
	@PostMapping
	public CommonResult saveGrid(
			@RequestBody Map<String, List<VHA0010DTO>> changesMap,
    		@AuthenticationPrincipal Authentication auth) { 
		IamUserDetails user = (IamUserDetails) auth.getPrincipal();

		// 작업순서 `삭제` → `수정` → `추가`
		List<VHA0010DTO> deleteList = changesMap.get("D");
		vha0010Service.deleteGrid(deleteList);

    	List<VHA0010DTO> updateList = changesMap.get("U");
    	vha0010Service.saveGrid(updateList, user.getUsername());

    	List<VHA0010DTO> insertList = changesMap.get("I");
    	vha0010Service.saveGrid(insertList, user.getUsername());

    	return responseService.getSuccessResult();
	}

}
