package com.ktng.ws2020.domain.vha.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * 운전원관리
 * @author t0210023
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class VHA0030DTO {
	private String driverNo;    /* 운전원번호          */
	private String driverNm;    /* 성명                */
	private String driverTy;    /* 구분[1:계약|2:위탁] */
	private String cellPn;      /* 휴대전화번호        */
	private String vhclDeptCd;  /* 배차부서            */
	private String recordDt;    /* 등록일              */
	private String expireDt;    /* 종료일              */
	private String useYn;       /* 근무여부            */
}
