package com.ktng.ws2020.domain.vha.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * 차량관리
 * @author t0210023
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class VHA0020DTO {
	private String vhclNo;         /* 차량번호                        */
	private String vhclNm;         /* 차종                            */
	private String ownTy;          /* 소유[1:회사|2:임차]             */
	private String fuelTy;         /* 연료[1:휘|2:경|3:LPG]           */
	private String productYm;      /* 연식                            */
	private String vhclDeptCd;     /* 배차부서                        */
	private String recordDt;       /* 등록일                          */
	private String expireDt;       /* 종료일                          */
	private String useYn;          /* 사용유무                        */
	private String vhType;
	private String vhNote;
	private String altEmpNo;       /* 변경자                          */
	private String altDate;        /* 변경일시                        */
}
