package com.ktng.ws2020.domain.vha.exception;

import com.ktng.ws2020.global.error.exception.BusinessException;
import com.ktng.ws2020.global.error.exception.ErrorCode;

public class VHA0040InsertFailException extends BusinessException {
	private static final long serialVersionUID = 2220656671998921809L;

	public VHA0040InsertFailException() {
        super(ErrorCode.VHA0040_INSERT_FAIL);
    }

	public VHA0040InsertFailException(String message) {
        super(message, ErrorCode.VHA0040_INSERT_FAIL);
    }

}
