package com.ktng.ws2020.domain.test.web;

import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ktng.ws2020.domain.test.model.Foo;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/foos")
public class FooController {
	
	@GetMapping("/{id}")
    public Foo retrieveFoo(@PathVariable("id") Long id) {
		return new Foo(id, RandomStringUtils.randomAlphabetic(6));
	}
	
}
