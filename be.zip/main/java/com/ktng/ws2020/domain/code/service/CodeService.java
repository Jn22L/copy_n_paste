package com.ktng.ws2020.domain.code.service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.ktng.ws2020.da.dao.CodeRepository;
import com.ktng.ws2020.da.model.CodeEntity;
import com.ktng.ws2020.da.model.ids.CodeID;
import com.ktng.ws2020.global.error.exception.EntityNotFoundException;

@Service
public class CodeService {
	private static final String GRP = "GRP";

    @Autowired
    CodeRepository codeRepository;

    /* 조회 */
    public List<CodeEntity> getCodeList(String commCodeChk, String commCode) {
    	if (commCodeChk == null) return codeRepository.findAll(sortByCommCodeChkAndSeq());
    	if (commCodeChk.contentEquals(GRP)) {
    		if (commCode == null) return codeRepository.findAllByCommCodeChk(GRP, sortByCommCodeAndSeq());
    		return codeRepository.findAllByCommCodeChkAndCommCode(GRP, commCode, sortByCommCodeAndSeq());
    	}

   		if (commCode == null) return codeRepository.findAllByCommCodeChk(commCodeChk, sortBySeq());
   		return codeRepository.findAllByCommCodeChkAndCommCode(commCodeChk, commCode, sortBySeq());
    }

    // 정렬
    private Sort sortByCommCodeChkAndSeq() {
    	return Sort.by("commCodeChk", "seq");
    }

    private Sort sortByCommCodeAndSeq() {
    	return Sort.by("commCode", "seq");
    }
    
    private Sort sortBySeq() {
    	return Sort.by("seq");
    }

    /* 추가, 수정 */
    public List<CodeEntity> updateCodeList(List<CodeEntity> codeList, String modifier) {
    	List<CodeEntity> _codeList = codeList.stream()
    			.map(code -> {
    				// ID로 기존 데이터 조회
    				CodeEntity _code = codeRepository.findById(CodeID.of(code)).orElse(null);
	    			if (_code == null) {
	    				// 기존 데이터가 없으면 새로 생성
	    				_code = new CodeEntity();
	    			}

	    			// 업데이트된 내용으로 수정
	    			_code.setCommCodeChk(code.getCommCodeChk());
	    			_code.setCommCode(code.getCommCode());
	    			_code.setCommCodeName(code.getCommCodeName());
	    			_code.setSeq(code.getSeq());
	    			_code.setModifier(modifier);
	    			_code.setAltdate(Instant.now());
	    			return _code;
    			})
    			.collect(Collectors.toList());

    	// 리스트 저장
    	return codeRepository.saveAll(_codeList);
    }

    /* 삭제 */
    public void deleteCodeList(List<CodeEntity> codeList) {
    	List<CodeEntity> _codeList = codeList.stream()
    			.map(code -> {
    				// ID로 기존 데이터 조회
    				CodeEntity _code = codeRepository.findById(CodeID.of(code)).orElse(null);
    				if (_code == null) {
	    				// 기존 데이터가 없으면 에러발생
	    				throw new EntityNotFoundException(code.getCommCodeChk() + "." + code.getCommCode() + " 공통코드를 찾을 수 없습니다.");
	    			}
	    			return _code;
    			})
    			.collect(Collectors.toList());

    	// 그룹코드 하위코드 리스트 조회
    	List<CodeEntity> subCodeList = new ArrayList<>();
    	_codeList.stream()
    			.filter(code -> code.getCommCodeChk().contentEquals(GRP))
    			.forEach(code -> {
    		List<CodeEntity> _subCodeList = codeRepository.findAllByCommCodeChk(code.getCommCode(), Sort.unsorted());
			subCodeList.addAll(_subCodeList);
    	});

    	// 하위 리스트 삭제
    	codeRepository.deleteAll(subCodeList);

    	// 리스트 삭제
    	codeRepository.deleteAll(_codeList);
    }

}
