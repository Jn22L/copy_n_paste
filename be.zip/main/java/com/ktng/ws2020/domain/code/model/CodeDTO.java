package com.ktng.ws2020.domain.code.model;

import com.ktng.ws2020.da.model.IamRoleEntity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class CodeDTO {

    private String code;
    private String name;

    public static CodeDTO of(IamRoleEntity en) {
        return CodeDTO.builder()
                .code(en.getRoleCd())
                .name(en.getRoleNm())
                .build();
    }

    static public CodeDTO AS(final Object[] result) {
    	CodeDTO dto = new CodeDTO((String) result[0], (String) result[1]);

		return dto;
	}

}