package com.ktng.ws2020.domain.code.web;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ktng.ws2020.da.model.CodeEntity;
import com.ktng.ws2020.domain.code.service.CodeService;
import com.ktng.ws2020.global.common.response.CommonResult;
import com.ktng.ws2020.global.common.response.ListResult;
import com.ktng.ws2020.global.common.response.service.ResponseService;
import com.ktng.ws2020.global.config.security.userdetails.IamUserDetails;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/code")
public class CodeController {

    @Autowired
    private CodeService codeService;

    @Autowired
    private ResponseService responseService;

    @GetMapping(value = {"", "/{commCodeChk}", "/{commCodeChk}/{commCode}"})
    public ListResult<CodeEntity> getCodeList(
    		@PathVariable(value = "commCodeChk", required = false) String commCodeChk,
    		@PathVariable(value = "commCode", required = false) String commCode,
    		@RequestParam(value = "commCodeName", required = false) String commCodeName,
    		@RequestParam(value = "commCodeChks", required = false) String[] commCodeChks) {
    	List<CodeEntity> codeList = codeService.getCodeList(commCodeChk, commCode);
    	
    	Map<String, Boolean> commCodeChkMap = new HashMap<>();
    	if (commCodeChks != null) {
	    	for (int i = 0; i < commCodeChks.length; i++) {
				commCodeChkMap.put(commCodeChks[i], true);
	    	}
    	}

    	codeList = codeList
    			.stream()
    			.filter(code -> {
    		    	if (commCodeName != null) {
    		    		if (code.getCommCodeName().indexOf(commCodeName) < 0) return false;
    		    	}
    		    	if (commCodeChks != null) {
    		    		if (!commCodeChkMap.containsKey(code.getCommCodeChk())) return false;
    		    	}
    		    	return true;
				})
    			.collect(Collectors.toList());
    	
    	return responseService.getListResult(codeList);
    }

    @PostMapping(value = {"", "/{commCodeChk}"})
    @Transactional
    public CommonResult saveCodeList(@RequestBody Map<String, List<CodeEntity>> codesMap,
    		@AuthenticationPrincipal Authentication auth) {
    	IamUserDetails user = (IamUserDetails) auth.getPrincipal();

    	// 작업순서 `삭제` → `수정` → `추가`
    	List<CodeEntity> deletedCodeList = codesMap.get("D");
    	codeService.deleteCodeList(deletedCodeList);

    	List<CodeEntity> updatedCodeList = codesMap.get("U");
    	codeService.updateCodeList(updatedCodeList, user.getUsername());

    	List<CodeEntity> insertedCodeList = codesMap.get("I");
    	codeService.updateCodeList(insertedCodeList, user.getUsername());

    	return responseService.getSuccessResult();
    }

}
