package com.ktng.ws2020.domain.vhc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ktng.ws2020.domain.vhc.dao.VHC0040Mapper;
import com.ktng.ws2020.domain.vhc.dao.VHC0040SMSMapper;
import com.ktng.ws2020.domain.vhc.model.VHC0040DTO;
import com.ktng.ws2020.domain.vhc.model.VHC0040SMSDTO;
import com.ktng.ws2020.infra.eai.EaiSmsService;
import com.ktng.ws2020.infra.eai.exception.EAIRunFailException;

@Service
public class VHC0040Service {

	@Autowired
	private VHC0040Mapper vhc0040Mapper;

	@Autowired
	private VHC0040SMSMapper vhc0040SMSMapper;

	@Autowired
	private EaiSmsService eaiSmsService;

	/* 조회 */
	public List<VHC0040DTO> selectApprovalMngList(String approverEmpNo, String vhclDeptCd, String fromYmd, String toYmd,
			String approveTy) {
		return vhc0040Mapper.selectApprovalMngList(approverEmpNo, vhclDeptCd, fromYmd, toYmd, approveTy);
	}

	/* 삭제 */
	public void changeApproveTy(List<VHC0040DTO> selectedRows, String altEmpNo) {

		selectedRows.forEach(selectedRow -> {
			if (selectedRow.getStatus().equals("approval")) {
				vhc0040Mapper.approvalApproveTy(selectedRow, altEmpNo);

				// 배차번호
				String assignNo = selectedRow.getAssignNo();

				/* 승인 -> 사용자에게 SMS 전송 */
				VHC0040SMSDTO userSmsDTO = vhc0040SMSMapper.userSmsAprvl(assignNo);
				/* 승인 -> 운전원에게 SMS 전송 */
				VHC0040SMSDTO driverSmsDTO = vhc0040SMSMapper.driverSmsAprvl(assignNo);
				/* 승인 -> 신청자에게 SMS 전송 */
				VHC0040SMSDTO applicantSmsDTO = vhc0040SMSMapper.applicantSmsAprvl(assignNo);

				Boolean userSendEaiSmsMsg = false;
				Boolean driverSendEaiSmsMsg = false;
				Boolean ApplicantSendEaiSmsMsg = false;
				try {

					if (userSmsDTO != null) { // sms
						userSendEaiSmsMsg = eaiSmsService.sendEaiSmsMsg(userSmsDTO);
					} else {
						String rstMsg = "사용자 SMS정보가 존재하지 않습니다.";
						throw new EAIRunFailException(rstMsg);
					}

					if (driverSmsDTO != null) { // sms
						driverSendEaiSmsMsg = eaiSmsService.sendEaiSmsMsg(driverSmsDTO);
					} else {
						String rstMsg = "운전원 SMS정보가 존재하지 않습니다.";
						throw new EAIRunFailException(rstMsg);
					}

					if (applicantSmsDTO != null) { // sms
						ApplicantSendEaiSmsMsg = eaiSmsService.sendEaiSmsMsg(applicantSmsDTO);
					} else {
						String rstMsg = "신청자 SMS정보가 존재하지 않습니다.";
						throw new EAIRunFailException(rstMsg);
					}

				} catch (EAIRunFailException | JsonProcessingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			} else if (selectedRow.getStatus().equals("reject")) {
				vhc0040Mapper.rejectApproveTy(selectedRow, altEmpNo);
			} else {
				vhc0040Mapper.cancleApproveTy(selectedRow, altEmpNo);

				// 배차번호
				String assignNo = selectedRow.getAssignNo();
				/* 승인 -> 사용자에게 SMS 전송 */
				VHC0040SMSDTO userSmsDTO = vhc0040SMSMapper.userSmsCncl(assignNo);
				/* 승인 -> 운전원에게 SMS 전송 */
				VHC0040SMSDTO driverSmsDTO = vhc0040SMSMapper.driverSmsCncl(assignNo);

				Boolean userSendEaiSmsMsg = false;
				Boolean driverSendEaiSmsMsg = false;

				try {

					if (userSmsDTO != null) { // sms
						userSendEaiSmsMsg = eaiSmsService.sendEaiSmsMsg(userSmsDTO);
					} else {
						String rstMsg = "사용자 SMS정보가 존재하지 않습니다.";
						throw new EAIRunFailException(rstMsg);
					}

					if (driverSmsDTO != null) { // sms
						driverSendEaiSmsMsg = eaiSmsService.sendEaiSmsMsg(driverSmsDTO);
					} else {
						String rstMsg = "운전원 SMS정보가 존재하지 않습니다.";
						throw new EAIRunFailException(rstMsg);
					}

				} catch (EAIRunFailException | JsonProcessingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});

	}

}
