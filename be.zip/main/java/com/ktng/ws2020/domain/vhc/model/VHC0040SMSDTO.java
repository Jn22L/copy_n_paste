package com.ktng.ws2020.domain.vhc.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class VHC0040SMSDTO {
	private String smsSendNo;		// 발신자 전화번호
	private String smsRecvNo;		// 수신자 전화번호
	private String smsMessage;		// 내용
}
