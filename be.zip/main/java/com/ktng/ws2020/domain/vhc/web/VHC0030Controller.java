package com.ktng.ws2020.domain.vhc.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ktng.ws2020.domain.vhc.model.VHC0030DTO;
import com.ktng.ws2020.domain.vhc.service.VHC0030Service;
import com.ktng.ws2020.global.common.response.CommonResult;
import com.ktng.ws2020.global.common.response.ListResult;
import com.ktng.ws2020.global.common.response.service.ResponseService;
import com.ktng.ws2020.global.config.security.userdetails.IamUserDetails;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/vhc0030")
public class VHC0030Controller {

	@Autowired
	private VHC0030Service vhc0030Service;

	@Autowired
	private ResponseService responseService;

	/**
	 * 배차부서 리스트 조회
	 *
	 * @param vhclDeptNm 검색할 배차부서명
	 */
	@GetMapping
	public ListResult<VHC0030DTO> selectApprovalList(
			@RequestParam(value = "vhclDeptCd", required = false) String vhclDeptCd,
			@RequestParam(value = "fromYmd", required = false) String fromYmd,
			@RequestParam(value = "toYmd", required = false) String toYmd,
    		@RequestParam(value = "approveTy", required = false) String approveTy
			) {
		
		log.info("##### selectApprovalList");
		log.info("##### fromYmd"+fromYmd);
		log.info("##### toYmd"+toYmd);
		log.info("##### approveTy"+approveTy);
		
		List<VHC0030DTO> vhc0030List = vhc0030Service.selectApprovalList(vhclDeptCd, fromYmd, toYmd, approveTy);
		return responseService.getListResult(vhc0030List);
	}

	/**
	 * 배차부서 리스트 변경사항(추가/수정/삭제) 반영
	 *
	 * @param changesMap 추가(I)/수정(U)/삭제(D) 별로 변경된 데이터List를 가진 데이터Map
	 * @param auth 로그인된 사용자정보를 가져올 때 사용
	 */
	@PostMapping
	public CommonResult changeApproveTy(
			@RequestBody List<VHC0030DTO> selectedRows,
    		@AuthenticationPrincipal Authentication auth) { 
		IamUserDetails user = (IamUserDetails) auth.getPrincipal();

		log.info("##### selectedRows : "+selectedRows.toString());
		
		vhc0030Service.changeApproveTy(selectedRows, user.getUsername());
		
		// 작업순서 `삭제` → `수정` → `추가`
//		List<VHA0010DTO> deleteList = changesMap.get("D");
//		vhc0030Service.deleteGrid(deleteList);
//
//    	List<VHA0010DTO> updateList = changesMap.get("U");
//    	vhc0030Service.saveGrid(updateList, user.getUsername());
//
//    	List<VHA0010DTO> insertList = changesMap.get("I");
//    	vhc0030Service.saveGrid(insertList, user.getUsername());

    	return responseService.getSuccessResult();
	}

}
