package com.ktng.ws2020.domain.vhc.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ktng.ws2020.domain.vhc.model.VHC0040SMSDTO;

@Mapper
public interface VHC0040SMSMapper {

	/* 승인 -> 사용자에게 SMS 전송 */
	public VHC0040SMSDTO userSmsAprvl(@Param("assignNo") String assignNo);
	/* 승인 -> 운전원에게 SMS 전송 */
	public VHC0040SMSDTO driverSmsAprvl(@Param("assignNo") String assignNo);
	/* 승인 -> 신청자에게 SMS 전송 */
	public VHC0040SMSDTO applicantSmsAprvl(@Param("assignNo") String assignNo);
	
	/* 취소 -> 사용자에게 SMS 전송 */
	public VHC0040SMSDTO userSmsCncl(@Param("assignNo") String assignNo);
	/* 취소 -> 운전원에게 SMS 전송 */
	public VHC0040SMSDTO driverSmsCncl(@Param("assignNo") String assignNo);

}
