package com.ktng.ws2020.domain.vhc.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ktng.ws2020.domain.vha.model.VHA0010DTO;
import com.ktng.ws2020.domain.vhc.model.VHC0030DTO;

@Mapper
public interface VHC0030Mapper {

	/* 1. grid CRUD */
	public List<VHC0030DTO> selectApprovalList(
			@Param("vhclDeptCd") String vhclDeptCd,
			@Param("fromYmd") String fromYmd,
			@Param("toYmd") String toYmd,
			@Param("approveTy") String approveTy
			);

	public void approvalApproveTy(@Param("selectedRow") VHC0030DTO selectedRow, @Param("altEmpNo") String altEmpNo);
	
	public void cancleApproveTy(@Param("selectedRow") VHC0030DTO selectedRow, @Param("altEmpNo") String altEmpNo);
	
	public int insertGrid(@Param("vha0010") VHA0010DTO vha0010, @Param("altEmpNo") String altEmpNo);

	public int updateGrid(@Param("vha0010") VHA0010DTO vha0010, @Param("altEmpNo") String altEmpNo);

	public int deleteGrid(@Param("vha0010List") List<VHA0010DTO> vha0010List);

	/* id로 조회 */
	public VHA0010DTO selectById(@Param("vhclDeptCd") String vhclDeptCd);
}
