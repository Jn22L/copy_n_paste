package com.ktng.ws2020.domain.vhc.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * 결재상신
 * @author t0210022
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class VHC0030DTO {
	private String ckBox;
	private String approveTyNm;	// 결재
	private String assignDt;	// 배차일자
	private String depatureDt;	// 출발일자
	private String depatureTm;	// 출발시간
	private String arrivalDt;	// 도착일자
	private String arrivalTm;	// 도착시간
	private String destination; // 행선지
	private String vhclNo;	// 차량번호
	private String vhclNm;	// 차종
	private String driverNm;	// 운전자
	private String chiefEmpNm;	// 사용자
	private String usePurpose;	// 사용목적
	private String vhclEmpNm;	// 담당자
	private String rejectCause;	// 반려사유
	private String assignNo;
	private String approveTy;
	private String approverEmpNo;
	private String rejectChk;
	
	private String status;
}
