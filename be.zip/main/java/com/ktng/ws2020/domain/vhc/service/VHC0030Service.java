package com.ktng.ws2020.domain.vhc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktng.ws2020.domain.vha.model.VHA0010DTO;
import com.ktng.ws2020.domain.vhc.dao.VHC0030Mapper;
import com.ktng.ws2020.domain.vhc.model.VHC0030DTO;

@Service
public class VHC0030Service {

	@Autowired
	private VHC0030Mapper vhc0030Mapper;

	/* 조회 */
	public List<VHC0030DTO> selectApprovalList(String vhclDeptCd, String fromYmd, String toYmd, String approveTy) {
		return vhc0030Mapper.selectApprovalList(vhclDeptCd, fromYmd, toYmd, approveTy);
	}
	
	/* 삭제 */
	public void changeApproveTy(List<VHC0030DTO> selectedRows, String altEmpNo) {
		
		selectedRows.forEach(selectedRow -> {
			if(selectedRow.getStatus().equals("approval")) {
				vhc0030Mapper.approvalApproveTy(selectedRow, altEmpNo);
			} else {
				vhc0030Mapper.cancleApproveTy(selectedRow, altEmpNo);
			}
		});
		
//		if(selectedRows.get(0).getStatus().equals("approval") ) {
//			return vhc0030Mapper.approvalApproveTy(selectedRows);
//		}else {
//			return vhc0030Mapper.cancleApproveTy(selectedRows);
//		}
	}


	/* 추가, 수정 */
	public void saveGrid(List<VHA0010DTO> vha0010List, String altEmpNo) {
		vha0010List.forEach(vha0010 -> {
			// ID로 기존 데이터 조회
			VHA0010DTO _vha0010 = vhc0030Mapper.selectById(vha0010.getVhclDeptCd());
			if (_vha0010 == null) {
				// 기존 데이터가 없으면 insert
				vhc0030Mapper.insertGrid(vha0010, altEmpNo);
			} {
				// 있으면 update
				vhc0030Mapper.updateGrid(vha0010, altEmpNo);
			}
		});
	}

	/* 삭제 */
	public int deleteGrid(List<VHA0010DTO> vha0010List) {
		if (vha0010List.size() == 0) return 0;

		// 삭제할 Entity 조회 및 확인
		return vhc0030Mapper.deleteGrid(vha0010List);
	}

}
