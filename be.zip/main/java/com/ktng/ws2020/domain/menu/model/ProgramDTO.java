package com.ktng.ws2020.domain.menu.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ProgramDTO {
	private String lvl2Name;
	private String lvl3Name;
	private String resCd;
	private String objCd;
	private String parentCd;
	private String name;
	private String objLevel;
	private String seq;
	private String url;
	private String objType;
	private String description;
	private String useYn;
	private String createDate;
	private String modifyDate;
	private String iconInfo;
	private String lvl2Seq;
	private String lvl3Seq;
}
