package com.ktng.ws2020.domain.menu.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktng.ws2020.domain.common.model.UutasMenuTreeDTO;
import com.ktng.ws2020.domain.menu.dao.MenuMapper;
import com.ktng.ws2020.domain.menu.model.MenuDTO;
import com.ktng.ws2020.domain.menu.model.MenuTreeDTO;
import com.ktng.ws2020.domain.menu.model.ProgramDTO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class MenuService {
	private final static Pattern menuCdPtn = Pattern.compile("^VH[A-Z]{1}[0-9]{4}$"); // 총 7자리. 앞 4자리는 그룹번호, 뒤 3자리는 노드번호

	@Autowired
	MenuMapper menuMapper;

	/* 조회 */
	public List<ProgramDTO> getProgramList(String roleCd) {
		return menuMapper.selectProgramsByRoleCd(roleCd);
	}

	public List<MenuTreeDTO> getMenuListByRoleCd(String roleCd) {
		List<MenuDTO> menuList = menuMapper.selectMenusByRoleCd(roleCd);
		
		return getMenuChildren(menuList, null, null);
	}

	// Navigation Menu
	public List<UutasMenuTreeDTO> getNavMenuListByRoleCd(String roleCd) {
		List<MenuDTO> menuList = menuMapper.selectMenusByRoleCd(roleCd);

		return getNavMenuChildren(menuList, null, null);
	}

	/**
	 * 메뉴 리스트를 트리구조로 변환 (재귀)
	 *
	 * @param list 변환할 메뉴 리스트
	 * @param visited 현재까지 방문한 곳 (기본값: null)
	 * @param menuCd 자식노드를 조사할 노드ID (기본값: null)
	 * @return 변환된 트리구조 반환
	 */
	private List<MenuTreeDTO> getMenuChildren(List<MenuDTO> list, boolean[] visited, String menuCd) {
		if (visited == null) {
			visited = new boolean[list.size()];
			Arrays.fill(visited, false);
		}

		List<MenuTreeDTO> tree = new ArrayList<>();

		for (int i = 0; i < list.size(); i++) {
			if (visited[i]) continue;

			MenuDTO item = list.get(i);

			String childMenuCd = item.getObjCd();
			String parentMenuCd = this.getParentMenuCd(childMenuCd);

			if ( (menuCd == null && this.isRoot(childMenuCd)) || // menuCd가 null이면, 최상위 노드만 찾기
					(menuCd != null && menuCd.contentEquals(parentMenuCd)) ) { // menuCd가 null이 아니면, menuCd와 부모자식으로 연결된 노드만 찾기 
				// 방문 확인
				visited[i] = true;

				// childMenuCd의 자식노드 탐색
				List<MenuTreeDTO> children = getMenuChildren(list, visited, item.getObjCd());

				// 정렬
				children.sort((o1, o2) -> o1.getObjCd().compareTo(o2.getObjCd()));

				// 트리에 추가
				tree.add(MenuTreeDTO.of(item, children, list.size()));
			}
		}

		return tree;
	}

	/**
	 * 메뉴 리스트를 네비게이션용 트리구조로 변환 (재귀)
	 *
	 * @param list 변환할 메뉴 리스트
	 * @param visited 현재까지 방문한 곳 (기본값: null)
	 * @param menuCd 자식노드를 조사할 노드ID (기본값: null)
	 * @return 변환된 트리구조 반환
	 */
	private List<UutasMenuTreeDTO> getNavMenuChildren(List<MenuDTO> list, boolean[] visited, String menuCd) {
		if (visited == null) {
			visited = new boolean[list.size()];
			Arrays.fill(visited, false);
		}

		List<UutasMenuTreeDTO> tree = new ArrayList<>();

		for (int i = 0; i < list.size(); i++) {
			if (visited[i]) continue;

			MenuDTO item = list.get(i);

			String childMenuCd = item.getObjCd();
			String parentMenuCd = this.getParentMenuCd(childMenuCd);

			if ( (menuCd == null && this.isRoot(childMenuCd)) || // menuCd가 null이면, 최상위 노드만 찾기
					(menuCd != null && menuCd.contentEquals(parentMenuCd)) ) { // menuCd가 null이 아니면, menuCd와 부모자식으로 연결된 노드만 찾기 
				// 방문 확인
				visited[i] = true;

				// childMenuCd의 자식노드 탐색
				List<UutasMenuTreeDTO> children = getNavMenuChildren(list, visited, item.getObjCd());

				// 정렬
				children.sort((o1, o2) -> o1.getId().compareTo(o2.getId()));

				// 트리에 추가
				tree.add(UutasMenuTreeDTO.of(item, children));
			}
		}

		return tree;
	}

	/**
	 * 최상위 노드여부 반환
	 *
	 * @param menuCd 확인할 노드ID
	 * @return 최상위 노드여부
	 */
	private boolean isRoot(String menuCd) {
		return menuCd.endsWith("0000");
	}

	private boolean validateMenuCd(String menuCd) {
		if (menuCd == null) return false;
		if (!menuCdPtn.matcher(menuCd).matches()) {
			log.debug("메뉴CD({})의 형식이 잘못되었습니다. (7자리, 앞 4자리는 그룹번호, 뒤 3자리는 노드번호)", menuCd);
			return false;
		}
		return true;
	}

	private Integer getNodeLevel(String menuCd) {
		if (menuCd.endsWith("0000")) return 1;
		if (menuCd.endsWith("000")) return 2;
		return 3;
	}

	/**
	 * 부모 메뉴ID
	 *
	 * @param menuCd 자식노드ID
	 * @return 부모노드ID
	 */
	private String getParentMenuCd(String menuCd) {
		if (!validateMenuCd(menuCd)) return null;

		Integer level = this.getNodeLevel(menuCd);
		if (level == null) return null;

		String grpNo = menuCd.substring(0, 1 + level);
		while (grpNo.length() < 7) {
			grpNo += "0";
		}

		return grpNo;
	}

}
