package com.ktng.ws2020.domain.menu.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Builder
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class MenuTreeDTO {
	private String resCd;
	private String objCd;
	private String parentCd;
	private String name;
	private int objLevel;
	private int seq;
	private String url;
	private String objType;
	private String description;
	private String useYn;
	private String createDate;
	private String modifyDate;
	private String korName;
	private String iconInfo;
	private String menuGb;

	/* IBSheet 트리구조 구성을 위한 Key 이름 지정 */
	@JsonProperty("Items")
	private List<MenuTreeDTO> items;
	private int itemSize;

	public static MenuTreeDTO of(MenuDTO menu, List<MenuTreeDTO> items, int itemSize) {
		return MenuTreeDTO.builder()
				.resCd(menu.getResCd())
				.objCd(menu.getObjCd())
				.parentCd(menu.getParentCd())
				.name(menu.getName())
				.objLevel(menu.getObjLevel())
				.seq(menu.getSeq())
				.url(menu.getUrl())
				.objType(menu.getObjType())
				.description(menu.getDescription())
				.useYn(menu.getUseYn())
				.createDate(menu.getCreateDate())
				.modifyDate(menu.getModifyDate())
				.korName(menu.getKorName())
				.iconInfo(menu.getIconInfo())
				.menuGb(menu.getMenuGb())
				.items(items)
				.itemSize(itemSize)
				.build();
	}

}
