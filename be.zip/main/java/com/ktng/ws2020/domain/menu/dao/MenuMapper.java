package com.ktng.ws2020.domain.menu.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ktng.ws2020.domain.menu.model.MenuDTO;
import com.ktng.ws2020.domain.menu.model.ProgramDTO;

@Mapper
public interface MenuMapper {

	public List<ProgramDTO> selectProgramsByRoleCd(
			@Param("roleCd") String roleCd);

	public List<MenuDTO> selectMenusByRoleCd(
			@Param("roleCd") String roleCd);

}
