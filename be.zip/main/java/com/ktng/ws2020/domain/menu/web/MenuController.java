package com.ktng.ws2020.domain.menu.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ktng.ws2020.domain.common.dao.UutasUserMapper;
import com.ktng.ws2020.domain.common.model.UutasUserDTO;
import com.ktng.ws2020.domain.menu.model.MenuTreeDTO;
import com.ktng.ws2020.domain.menu.model.ProgramDTO;
import com.ktng.ws2020.domain.menu.service.MenuService;
import com.ktng.ws2020.global.common.response.ListResult;
import com.ktng.ws2020.global.common.response.service.ResponseService;
import com.ktng.ws2020.global.config.security.userdetails.IamUserDetails;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/menu")
public class MenuController {

	@Autowired
	private MenuService menuService;

	@Autowired
	private UutasUserMapper uutasUserMapper;
	
	@Autowired
    private ResponseService responseService;

    @GetMapping("/prg")
    public ListResult<ProgramDTO> getProgramList(
    		@AuthenticationPrincipal Authentication auth) {
    	IamUserDetails user = (IamUserDetails) auth.getPrincipal();
    	UutasUserDTO uutasUser = uutasUserMapper.selectUserByEmpNo(user.getUsername());

    	List<ProgramDTO> programList = menuService.getProgramList(uutasUser.getRoleCd());

    	return responseService.getListResult(programList);
    }

    @GetMapping("/menu")
    public ListResult<MenuTreeDTO> getMenuList(
    		@AuthenticationPrincipal Authentication auth) {
    	IamUserDetails user = (IamUserDetails) auth.getPrincipal();
    	UutasUserDTO uutasUser = uutasUserMapper.selectUserByEmpNo(user.getUsername());

    	List<MenuTreeDTO> menuList = menuService.getMenuListByRoleCd(uutasUser.getRoleCd());

    	return responseService.getListResult(menuList);
    }

}
