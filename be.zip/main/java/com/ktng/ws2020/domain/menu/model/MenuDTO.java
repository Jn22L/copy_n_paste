package com.ktng.ws2020.domain.menu.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MenuDTO {
	private String resCd;
	private String objCd;
	private String parentCd;
	private String name;
	private int objLevel;
	private int seq;
	private String url;
	private String objType;
	private String description;
	private String useYn;
	private String createDate;
	private String modifyDate;
	private String korName;
	private String iconInfo;
	private String menuGb;
}
