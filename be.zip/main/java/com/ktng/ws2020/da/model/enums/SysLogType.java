package com.ktng.ws2020.da.model.enums;

public enum SysLogType {
	REACTPATH("loggingReactPath"),
	CALLEDMS("loggingCallEDMS"),
	CALLEAI("loggingCallEAI"),
	CALLEPOST("loggingCallEPOST"),
	TFAPRV4J("loggingTransferAprv4j");

	String code;

	SysLogType(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static SysLogType fromString(String text) {
		for (SysLogType r : SysLogType.values()) {
			if (r.code.equalsIgnoreCase(text)) {
				return r;
			}
		}
		return null;
	}

}
