package com.ktng.ws2020.da.model.ids;

import com.ktng.ws2020.da.model.CodeEntity;
import lombok.*;

import java.io.Serializable;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter @Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class CodeID implements Serializable {

    private static final long serialVersionUID = 4556742118883170274L;

    private String commCodeChk;
    private String commCode;

    public static CodeID of(CodeEntity ce){
        return CodeID.builder()
                .commCodeChk(ce.getCommCodeChk())
                .commCode(ce.getCommCode())
                .build();
    }

}
