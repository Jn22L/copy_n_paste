package com.ktng.ws2020.da.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@Entity 
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "iv_iam_tpl_user_int", schema = "EAI")
public class IamUserEntity {
    @Id
    @Column(nullable = false, length = 64) 
    private String userCd;
    @Column(nullable = false, length = 64) 
    private String userNm;
    private String totId;
    private String stdt;
    private String eddt;
    private String pwd;
    private Date pwdChgDate;
    private String compId;
    private String compCd;
    private String compNm;
    private String empNo;
    private String empCd;
    private String sawonDv;
    private String sex;
    private String birthYmd;
    private String birthDv;
    private String grdNm;
    private String grdCd;
    private String jobNm;
    private String jobCd;
    private String titlNm;
    private String titlCd;
    private String eml;
    private String extno;
    private String mobno;
    private String addr;
    private String telno;
    private String parCd;
    private String parNm;
    private String workDeptCd;
    private String workDeptNm;
    private String issDeptCd;
    private String issDeptNm;
    private String manaDeptCd;
    private String manaDeptNm;
    private String ssnBirth;
    private String assignment;
    private String exptrYn;
    private String nmAsci;
    private String workDeptNmAsci;
    private String grdNmAsci;
    private String jobNmAsci;
    private String titlNmAsci;
    private String mdmId;
    private String mdmCc;
    private String status;
//    private String sendDv;
    private String rgst;
    private Date createDate;
    private Date modifyDate;
    private Date deleteDate;
    private String nCompId;
    private String asEmpNo;

    @Transient
    @Setter
    private Date loginDate;
    @Transient
    @Setter
    private String loginIp;
}
