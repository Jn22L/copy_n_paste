package com.ktng.ws2020.da.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Builder
//@Entity 
@Getter
@NoArgsConstructor
@AllArgsConstructor
// @Table(name = "tb_organ")
public class IamOrgEntity_bak {
    @Column(length = 3) 
    private String compId;
    @Column(length = 20) 
    private String compCode;
    @Column(length = 64) 
    private String compName;
    @Column(nullable = false, length = 64)
    @Id
    private String groupCode;
    @Column(nullable = false, length = 64) 
    private String groupName;
    @Column(nullable = false, length = 1) 
    private String groupType;
    @Column(length = 3) 
    private String orgKind; // 조직구분 코드(정규, 임시, 가상 ...)
    @Column(length = 1) 
    private String parDeptChk; // 기관부서 구분(1.기관, 2.부서)
    @Column(length = 100) 
    private String orgEngNm;
    @Column(length = 100) 
    private String orgLname;
    @Column(length = 50) 
    private String orgSname;
    @Column(length = 100) 
    private String orgHname;
    @Column(length = 64) 
    private String parentGroupCd;
    @Column(length = 6) 
    private String orgChk;
    @Column(length = 6) 
    private String parType; // 기관분류
    @Column(length = 6) 
    private String orgKindCd; // 부서분류 코드
    @Column(length = 6) 
    private String parKindCd; // 기관분류 코드
    @Column(length = 8) 
    private String openDate;
    @Column(length = 8) 
    private String endDate;
    @Column(length = 20) 
    private String tel;
    @Column(length = 20) 
    private String fax;
    @Column(length = 10) 
    private String post;
    @Column(length = 100) 
    private String addr;
    @Column(length = 1) 
    private String makeGrp;
    @Column(length = 1) 
    private String rawGrp;
    @Column(length = 1) 
    private String cryGrp;
    @Column(length = 6) 
    private String salePrtRnk;
    @Column(length = 6) 
    private String grdAreaGrd;
    @Column(length = 64) 
    private String workDeptCode;
    @Column(length = 4) 
    private String unitPartCd;
    @Column(length = 8) 
    private String unitDeptCd;
    @Column(length = 64) 
    private String managerId;
    @Column(length = 64) 
    private String managerNm;
    private Integer orderNum;
    private Integer seq;
}
