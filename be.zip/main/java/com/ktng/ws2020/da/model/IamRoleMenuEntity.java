package com.ktng.ws2020.da.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter @Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "wt_cm_role_menu")
public class IamRoleMenuEntity implements Serializable {
	private static final long serialVersionUID = 1L;

//    @Id
//    @Column(nullable = false, length = 430) 
//    private String roleCd;
//    @Id
//    @Column(nullable = false, length = 430) 
//    private String menuCd;
    @Column(length = 64) 
    private String stdt;
    @Column(length = 64) 
    private String eddt;
    @Column(length = 64) 
    private String sendDv;
    @Column(length = 20) 
    private String rgst;
    @Column(length = 11) 
    private Date createDate;
    @Column(length = 11)
    private Date deleteDate;
    
    @Id
    @ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
    @JoinColumn(name = "roleCd")
    private IamRoleEntity role;
    
    @Id
    @ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
    @JoinColumn(name = "menuCd")
    private IamMenuEntity menu;
}