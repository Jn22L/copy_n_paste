package com.ktng.ws2020.da.model;

import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

//@Entity
@Getter 
@Builder
@NoArgsConstructor
@AllArgsConstructor
// @Table(name = "tb_board_content")
public class BoardContentEntity {

    @Id
    @Column(nullable = false, length = 20)
    private String brdCtsNo; // BRDCTS00000000000001
    
    @OneToOne
    @JoinColumn(name = "brd_mstr_no", foreignKey = @ForeignKey(name="fk_tb_board_content_1"))
    private BoardMasterEntity brdMstrNo;
    
    @Column(nullable = false, length = 20)
    private String brdCtsGrp;
    
    @Column(columnDefinition = "DECIMAL")
    private Integer brdCtsSorts;
    
    @Column(columnDefinition = "DECIMAL")
    private Integer brdCtsDepth;
    
    @Column(nullable = false, length = 255)
    private String brdTitle;
    
    @Column(length = 255)
    private String brdSummary;
    
    @Column(columnDefinition = "TEXT")
    private String brdContent;

    @Setter
    private Long brdHit;
    
    private String modId;
    
    @UpdateTimestamp
    private Date modDate;
    
    private String regId;
    
    @CreationTimestamp
    private Date regDate;
}
