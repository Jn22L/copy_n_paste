package com.ktng.ws2020.da.model;

import java.time.Instant;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@NoArgsConstructor
@Table(name = "wt_cm_menu")
public class IamMenuEntity {

    @Id
    @Column(nullable = false, length = 430) 
    private String menuCd;
    @Column(nullable = false, length = 430) 
    private String menuNm;
    @Column(length = 430)
    private String upprMenuCd;
    @Column(length = 100)
    private String menuTyp;
    @Column(length = 100)
    private String menuLvl;
    @Column(length = 400)
    private String menuUrl;
    @Column(length = 4000)
    private String rmk;
    @Column(length = 64)
    private String stdt;
    @Column(length = 64)
    private String eddt;
    @Column(length = 64)
    private String sendDv;
    @Column(length = 20)
    private String rgst;
    @Column(length = 11)
    private Instant createDate;
    @Column(length = 11)
    private Instant modifyDate;
    @Column(length = 11)
    private Date deleteDate;
    @Column(length = 100)
    private String iconInfo;
    
    private Integer orderNo;
    
    @Transient
    @Setter
    private String roleCd;
    @Transient
    @Setter
    private String roleNm;
    
    @OneToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY, mappedBy = "menu")
    private List<IamRoleMenuEntity> roleMenus;
}
