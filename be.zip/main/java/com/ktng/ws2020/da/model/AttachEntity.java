package com.ktng.ws2020.da.model;

import java.time.Instant;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import com.ktng.ws2020.da.model.converter.BooleanToYNConverter;
import com.ktng.ws2020.da.model.enums.AtchFileType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "wt_vh_file")
public class AttachEntity {

    @Id
    @Column(nullable = false, length = 20)
    private String attachNo; // ATCH0000000000000001
    
    @Column(length = 255)
    private String saveFileNm; // 물리파일 명 
    
    @Column(length = 100)
    private String fileNm;   // 기존 파일명
    
    @Column(length = 255)
    private String filePath; // 물리파일 저장 경로
    
    @Column(length = 100)
    private String contentType; // MultipartFile.getContentType
    
    private Long fileSize;
    
    @Enumerated(EnumType.STRING)
    private AtchFileType fileType;
    
    @Setter
    private Long downCnt;
    
    @Setter
    @Column(columnDefinition = "CHAR(1)", length = 1)
    @Convert(converter = BooleanToYNConverter.class)
    private boolean edmsYn;
    
    @Column(updatable = false)
    private String regId;
    
    @Column(updatable = false)
    @CreationTimestamp
    private Instant regDate;
    
    private String modId;
    
    @UpdateTimestamp
    private Instant modDate;

}
