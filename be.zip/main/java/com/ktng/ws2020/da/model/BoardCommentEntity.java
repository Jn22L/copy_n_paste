package com.ktng.ws2020.da.model;

import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

//@Entity
@Getter 
@Builder
@NoArgsConstructor
@AllArgsConstructor
// @Table(name = "tb_board_comment")
public class BoardCommentEntity {

    @Id
    @Column(nullable = false, length = 30)
    private String brdCmtNo; // BRDCMT000000000000000000000001

    @OneToOne
    @JoinColumn(name = "brd_mstr_no", foreignKey = @ForeignKey(name="tb_board_comment_ibfk_1"))
    private BoardMasterEntity brdMstrNo;
    
    @OneToOne
    @JoinColumn(name = "brd_cts_no", foreignKey = @ForeignKey(name="tb_board_comment_ibfk_2"))
    private BoardContentEntity brdCtsNo;
    
    @Column(nullable = false, length = 30)
    private String brdCmtGrp; // BRDCMT000000000000000000000001
    
    @Column(columnDefinition = "DECIMAL")
    private Integer brdCmtSorts;
    
    @Column(columnDefinition = "DECIMAL")
    private Integer brdCmtDepth;
    
    @Column(columnDefinition = "TEXT")
    private String brdComment;
    
    private String modId;
    
    @UpdateTimestamp
    private Date modDate;
    
    private String regId;
    
    @CreationTimestamp
    private Date regDate;
}
