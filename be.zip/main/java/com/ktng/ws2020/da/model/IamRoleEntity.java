package com.ktng.ws2020.da.model;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Getter
@NoArgsConstructor
@Table(name = "wt_cm_role" /* , uniqueConstraints={@UniqueConstraint(name="UK_TB_ROLE_1", columnNames = {"name"})} */)
public class IamRoleEntity {

    @Id
    @Column(nullable = false, length = 430) 
    private String roleCd;
    @Column(nullable = false, length = 430) 
    private String roleNm;
    @Column(length = 4000) 
    private String rmk;
    @Column(length = 64) 
    private String stdt;
    @Column(length = 64) 
    private String eddt;
    @Column(length = 64) 
    private String sendDv;
    @Column(length = 20) 
    private String rgst;
    @Column(length = 11) 
    private Date createDate;
    @Column(length = 11) 
    private Date modifyDate;
    @Column(length = 11)
    private Date deleteDate;
    
    @OneToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY, mappedBy = "role")
    private List<IamRoleMenuEntity> roleMenus; 
}
