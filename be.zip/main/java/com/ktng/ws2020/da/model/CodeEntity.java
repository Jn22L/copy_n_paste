package com.ktng.ws2020.da.model;

import java.time.Instant;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import org.hibernate.annotations.UpdateTimestamp;

import com.ktng.ws2020.da.model.ids.CodeID;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter @Setter
@Entity
@Builder
@Table(name = "wt_cm_code")
@IdClass(CodeID.class)
public class CodeEntity {

    @Id
    @Column(nullable = false, length = 30)
    private String commCodeChk; // 코드구분

    @Id
    @Column(nullable = false, length = 30)
    private String commCode; // 코드

    @Column(nullable = false, length = 100)
    private String commCodeName; // 코드명

    @Column(nullable = true, length = 30)
    private String commCodeType; // 코드유형

    @Column(nullable = true)
    private Long seq; // 출력순번

    @Column(nullable = false, length = 8)
    private String modifier; // 작성자

    @Column(nullable = false, length = 7)
    @UpdateTimestamp
    private Instant altdate; // 작성일

}
