package com.ktng.ws2020.da.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

//@Entity
@Getter 
@Builder
@NoArgsConstructor
@AllArgsConstructor
// @Table(name = "tb_board_master")
public class BoardMasterEntity {

    @Id
    @Column(nullable = false, length = 20)
    private String brdMstrNo; // BRDMST00000000000001
    
    @Column(nullable = false, length = 20)
    private String brdMstrNm;
    
    @Column(nullable = false, length = 255)
    private String brdMstrDesc;
    
    private String modId;
    
    @UpdateTimestamp
    private Date modDate;
    
    private String regId;
    
    @CreationTimestamp
    private Date regDate;
    
}
