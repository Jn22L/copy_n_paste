package com.ktng.ws2020.da.model.enums;

public enum AtchFileType {
//    ATCHF001,           // 게시판 첨부문서
//    ATCHF002,           // 게시판 이미지첨부
//    ATCHF003,           // 소명양식 첨부파일
//    ATCHF004,           // 소명서 첨부파일
//    ATCHF005,			// 감사실적 첨부파일
//    ATCHF006,			// 사건사고 첨부파일
//    ATCHF007,           // 전자결재 첨부파일
//    EDMSF001,           // EDMS첨부문서
    ATCHF999            // 기타
}
