package com.ktng.ws2020.da.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Builder
@Entity 
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "tb_nsso_session")
public class NssoSessionEntity {

	@Id
	private String empNo;
	
	private String sid;  // NSSO 에서 로그아웃때 넘김

	// NSSO              : https://ssodev.ktng.com/
	// staticJwt(자체생성) : https://uutasdev.ktng.com/
	private String issType;
	
	@Lob
	private String accessToken;
	@Lob
	private String idToken;
	
	private Date expiredAt;
	
	private Date lastLogonDt;
	
	private String lastLogonIp;
	
}
