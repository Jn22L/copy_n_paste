package com.ktng.ws2020.da.dao;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import com.ktng.ws2020.da.model.CodeEntity;
import com.ktng.ws2020.da.model.ids.CodeID;


public interface CodeRepository extends JpaRepository<CodeEntity, CodeID> {

	List<CodeEntity> findAllByCommCodeChk(@Param(
			"commCodeChk") String commCodeChk,
			Sort sort);
	List<CodeEntity> findAllByCommCodeChkAndCommCode(
			@Param("commCodeChk") String commCodeChk,
			@Param("commCode") String commCode,
			Sort sort);
}
