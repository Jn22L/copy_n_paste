package com.ktng.ws2020.da.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ktng.ws2020.da.model.NssoSessionEntity;

public interface NssoSessionRepository extends JpaRepository<NssoSessionEntity, String> {
	
	@Transactional
	@Modifying
	@Query("delete from NssoSessionEntity e where e.sid = :sid")
	void deleteBySid(@Param("sid") String sid);

	@Transactional
	@Modifying
	@Query("update NssoSessionEntity e set e.accessToken = :accessToken where e.empNo = :empNo")
	void updateAccessToken(@Param("empNo") String empNo, @Param("accessToken") String accessToken);

	@Transactional
	@Modifying
	@Query("delete from NssoSessionEntity e where e.accessToken like :accessToken")
	void deleteByAccessToken(@Param("accessToken") String accessToken);
	
	@Query("select e from NssoSessionEntity e where e.empNo = :empNo and e.issType = :issType")
	NssoSessionEntity getNssoSessionEntity(@Param("empNo") String empNo, @Param("issType") String issType);
	
	
}
