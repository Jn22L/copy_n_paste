package com.ktng.ws2020.da.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ktng.ws2020.da.model.BoardMasterEntity;

public interface BoardMasterRepository { // extends JpaRepository<BoardMasterEntity, String>{
    
	BoardMasterEntity findByBrdMstrNo(String brdMstrNo);
   
}
