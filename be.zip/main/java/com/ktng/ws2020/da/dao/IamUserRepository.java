package com.ktng.ws2020.da.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ktng.ws2020.da.model.IamUserEntity;

public interface IamUserRepository extends JpaRepository<IamUserEntity, String> {

}
