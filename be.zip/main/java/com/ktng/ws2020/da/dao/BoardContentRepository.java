package com.ktng.ws2020.da.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ktng.ws2020.da.model.BoardContentEntity;
import com.ktng.ws2020.da.model.BoardMasterEntity;
import com.ktng.ws2020.domain.board.model.BoardContentListDTO;

public interface BoardContentRepository { // extends JpaRepository<BoardContentEntity, String>{

    static final String PAGE_QUERY = 
            "select new com.ktng.ws2020.domain.board.model.BoardContentListDTO("
                    + " be.brdCtsNo, "
                    + " be.brdMstrNo, "
                    + " be.brdCtsGrp, "
                    + " be.brdCtsSorts, "
                    + " be.brdCtsDepth, "
                    + " be.brdTitle, "
                    + " be.brdSummary, "
                    + " be.brdContent, "
                    + " be.brdHit, "
                    + " be.modDate, "
                    + " be.modId, "
                    + " be.regDate, "
                    + " be.regId, "
                    + " ue.name, "
                    + " count(ce.brdCmtNo)"
                    + ") "
                    + "from BoardContentEntity be "
                    + "left join IamUserEntity ue on be.regId = ue.empNo "
                    + "left join BoardCommentEntity ce "
                    + "       on be.brdMstrNo = ce.brdMstrNo "
                    + "      and be.brdCtsNo = ce.brdCtsNo "
                    + "where be.brdMstrNo=:brdMstrNo ";

    static final String PAGE_QUERY_SUFFIX = "group by be.brdCtsNo, "
		            + "      be.brdMstrNo, "
		            + "      be.brdCtsGrp, "
		            + "      be.brdCtsSorts, "
		            + "      be.brdCtsDepth, "
		            + "      be.brdTitle, "
		            + "      be.brdSummary, "
		            + "      be.brdContent, "
		            + "      be.brdHit, "
		            + "      be.modDate, "
		            + "      be.modId, "
		            + "      be.regDate, "
		            + "      be.regId, "
		            + "      ue.name "
		            + "order by be.brdCtsNo ";
    
    @Query(PAGE_QUERY + PAGE_QUERY_SUFFIX)
    List<BoardContentListDTO> findBoardList(
            @Param("brdMstrNo") BoardMasterEntity boardMasterEntity);
    
    @Query(PAGE_QUERY 
            + "and ( be.brdTitle   like :searchText "
            + "   or be.brdContent like :searchText "
            + ") "
            + PAGE_QUERY_SUFFIX)
    List<BoardContentListDTO> findBoardListCateLikeAll(
            @Param("brdMstrNo") BoardMasterEntity boardMasterEntity, 
            @Param("searchText") String searchText);
    
    @Query(PAGE_QUERY 
            + "and be.brdTitle like :searchText "
            + PAGE_QUERY_SUFFIX)
    List<BoardContentListDTO> findBoardListCateLikeTitle(
            @Param("brdMstrNo") BoardMasterEntity boardMasterEntity, 
            @Param("searchText") String searchText);
    
    @Query(PAGE_QUERY 
            + "and be.brdContent like :searchText "
            + PAGE_QUERY_SUFFIX)
    List<BoardContentListDTO> findBoardListCateLikeContent(
            @Param("brdMstrNo") BoardMasterEntity boardMasterEntity, 
            @Param("searchText") String searchText);
 
    @Query(PAGE_QUERY 
            + "and be.regId like :searchText "
            + PAGE_QUERY_SUFFIX)
    List<BoardContentListDTO> findBoardListCateLikeRegId(
            @Param("brdMstrNo") BoardMasterEntity boardMasterEntity, 
            @Param("searchText") String searchText);
    
    
    BoardContentEntity findByBrdMstrNoAndBrdCtsNo(BoardMasterEntity brdMstrNo, String brdCtsNo);
    
    List<BoardContentEntity> findAllByRegId(String regId);
   
}
