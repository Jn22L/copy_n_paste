package com.ktng.ws2020.da.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ktng.ws2020.da.model.BoardCommentEntity;
import com.ktng.ws2020.da.model.BoardContentEntity;
import com.ktng.ws2020.da.model.BoardMasterEntity;
import com.ktng.ws2020.domain.board.model.BoardCommentListDTO;

public interface BoardCommentRepository { // extends JpaRepository<BoardCommentEntity, String>{

    static final String PAGE_QUERY = 
            "select new com.ktng.ws2020.domain.board.model.BoardCommentListDTO("
                    + " be.brdCmtNo, "
            		+ " be.brdMstrNo, "
                    + " be.brdCtsNo, "
                    + " be.brdCmtGrp, "
                    + " be.brdCmtSorts, "
                    + " be.brdCmtDepth, "
                    + " be.brdComment, "
                    + " be.modId, "
                    + " be.regId, "
                    + " be.modDate, "
                    + " be.regDate, "
                    + " ue.name"
                    + ") "
                    + "from BoardCommentEntity be "
                    + "left join IamUserEntity ue on be.regId = ue.empNo "
                    + "where be.brdMstrNo=:brdMstrNo "
                    + "and be.brdCtsNo=:brdCtsNo ";
    
    @Query(PAGE_QUERY + "order by be.brdCmtNo")
    List<BoardCommentListDTO> findBoardCommentList(
    		@Param("brdMstrNo") BoardMasterEntity brdMstrNo,
            @Param("brdCtsNo") BoardContentEntity brdCtsNo);
    BoardCommentEntity findByBrdMstrNoAndBrdCtsNoAndBrdCmtNo(BoardMasterEntity brdMstrNo, BoardContentEntity brdCtsNo, String brdCmtNo);

}
