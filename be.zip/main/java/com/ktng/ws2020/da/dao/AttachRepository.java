package com.ktng.ws2020.da.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ktng.ws2020.da.model.AttachEntity;


public interface AttachRepository extends JpaRepository<AttachEntity, String> {

	@Query(
			nativeQuery = true,
			value = "SELECT NVL(MAX(TO_NUMBER(ATTACH_NO)), 0) + 1 FROM WT_VH_FILE")
	public Long findNextId();
}
