package com.ktng.ws2020.global.error.exception;

import com.ktng.ws2020.global.common.response.ResponseType;

public enum ErrorCode implements ResponseType{

    // Common
    INVALID_INPUT_VALUE(400, "C001", " 파라미터가 잘못됐습니다."),
    METHOD_NOT_ALLOWED(405, "C002", " 잘못된 방식으로 호출하였습니다."),
    ENTITY_NOT_FOUND(500, "C003", " 요청한 데이터가 존재하지 않습니다."),
    INTERNAL_SERVER_ERROR(500, "C004", "서버에러가 발생되었습니다."),
    INVALID_TYPE_VALUE(400, "C005", " 파라미터 타입이 잘못되었습니다."),
    HANDLE_ACCESS_DENIED(403, "C006", "자원에 대한 권한이 없습니다."),
    HANDLE_AUTHENTICATION(401, "C007", "인증처리 중 에러가 발생되었습니다."),
    // C006 OAuth2Exception

    // BusinessException ====================================

    //File
    FILE_UPLOAD  (500, "B001", "파일업로드에 실패하였습니다."),
    FILE_DOWNLOAD(500, "B002", "파일다운로드에 실패하였습니다."),
    EAI_RUN_FAIL (500, "B003", "EAI실행 중 오류가 발생되었습니다."),
    FILE_NOT_FOUND(404, "B004", "파일 정보가 존재하지 않습니다."),

    // Member
//    EMAIL_DUPLICATION(400, "M001", "Email is Duplication"),
//    LOGIN_INPUT_INVALID(400, "M002", "Login input is invalid"),
    PASSWORD_NOT_MATCHE (500, "M003", "비밀번호가 일치하지 않습니다."),
    
    // AuthException
    NO_AUTHENTICATION(500, "C011", "권한이 없습니다."),
    BAD_CREDENTIALS(401, "C012", "인증에 실패하였습니다."),

    
    // ExcelDownloadException
    EXCEL_NODATA (500, "C010", "엑셀 데이터가 존재하지 않습니다."),

	// 게시물관리
	VHA0040_INSERT_FAIL(400, "VHA0040_001", "게시물 등록에 실패하였습니다."),
	VHA0040_UPDATE_FAIL(400, "VHA0040_002", "게시물 수정에 실패하였습니다."),
	VHA0040_DELETE_FAIL(400, "VHA0040_003", "게시물 삭제에 실패하였습니다."),
	
	// 게시판
	VHB0010_INSERT_FAIL(400, "VHA0010_001", "게시물 등록에 실패하였습니다."),
	VHB0010_UPDATE_FAIL(400, "VHA0010_002", "게시물 수정에 실패하였습니다."),
	VHB0010_DELETE_FAIL(400, "VHA0010_003", "게시물 삭제에 실패하였습니다."),	

	// 배차신청등록
	VHB0020_INSERT_FAIL(400, "VHB0020_001", "배차신청 등록에 실패하였습니다."),
	VHB0020_UPDATE_FAIL(400, "VHB0020_002", "배차신청 수정에 실패하였습니다."),
	VHB0020_DELETE_FAIL(400, "VHB0020_003", "배차신청 삭제에 실패하였습니다."),
	
    ;
    private final String code;
    private final String msg;
    private int status;

    ErrorCode(final int status, final String code, final String message) {
        this.status = status;
        this.msg = message;
        this.code = code;
    }

    public String getMsg() {
        return this.msg;
    }

    public String getCode() {
        return code;
    }

    public int getStatus() {
        return status;
    }


}