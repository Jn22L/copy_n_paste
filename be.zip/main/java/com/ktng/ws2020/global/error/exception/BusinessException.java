package com.ktng.ws2020.global.error.exception;

import lombok.Getter;

@Getter
public class BusinessException extends RuntimeException{
    
    private ErrorCode errorCode;

    public BusinessException(String message, ErrorCode errorCode) {
        super(message);
        this.errorCode = errorCode;
    }

    public BusinessException(ErrorCode errorCode) {
        super(errorCode.getMsg());
        this.errorCode = errorCode;
    }

}
