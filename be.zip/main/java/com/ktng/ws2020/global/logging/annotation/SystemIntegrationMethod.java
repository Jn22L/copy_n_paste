package com.ktng.ws2020.global.logging.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.ktng.ws2020.da.model.enums.SysLogType;

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface SystemIntegrationMethod {

	SysLogType type() default SysLogType.REACTPATH;

}
