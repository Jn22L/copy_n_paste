package com.ktng.ws2020.global.logging.wrapper;


import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

public class SpringRequestWrapper extends HttpServletRequestWrapper {

    public SpringRequestWrapper(HttpServletRequest request) {
        super(request);
    }

    public Map<String, String> getAllHeaders() {
        final Map<String, String> headers = new HashMap<>();
        Collections.list(getHeaderNames()).forEach(it -> headers.put(it, getHeader(it)));
        return  headers;
    }
}
