package com.ktng.ws2020.global.logging;

import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.MDC;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class UniqueIDGenerator {

    private static final String REQUEST_ID_HEADER_NAME = "X-Request-ID";
    private static final String CORRELATION_ID_HEADER_NAME = "X-Correlation-ID";

    public void generateAndSetMDC(HttpServletRequest request) {
        MDC.clear();
        String requestId = request.getHeader(REQUEST_ID_HEADER_NAME);
        if (requestId == null)
            requestId = UUID.randomUUID().toString();
        MDC.put(REQUEST_ID_HEADER_NAME, requestId);

        String correlationId = request.getHeader(CORRELATION_ID_HEADER_NAME);
        if (correlationId == null)
            correlationId = UUID.randomUUID().toString();
        MDC.put(CORRELATION_ID_HEADER_NAME, correlationId);

        JwtAuthenticationToken auth = (JwtAuthenticationToken) request.getUserPrincipal();
        if (auth != null) {
        	Jwt jwt = auth.getToken();
        	Map<String, Object> claims = jwt.getClaims();
//    		claims.keySet().forEach(key -> {
//				log.info(key + ": " + claims.getOrDefault(key, ""));
//			});
			/*
			aud: [50f929da-c0dd-43a4-8e8c-05c985facab5]
			sub: t0210023
			iam: com.ktng.ws2020.da.model.IamUserEntity@1c83bd5
			session: com.ktng.ws2020.da.model.NssoSessionEntity@162d210
			scope: ["email","mobile","openid","profile","lastlogondt","lastlogonip"]
			roles: [ROLE_ADMIN, ROLE_USER]
			iss: https://ssodev.ktng.com/
			exp: 2021-04-28T02:15:30Z
			iat: 2021-04-28T01:45:30Z
			jti: ec2dcb9e-6c1d-4b33-8bf6-0d53909cdd81
			*/

			String username = (String) claims.getOrDefault("empNo", "알수없음");

			MDC.put("loginUid", username);

			log.info("iam user 요청! X-Request-ID={}, clientId={}, loginUid={}", requestId, jwt.getId(), username);
        }
    }

}
