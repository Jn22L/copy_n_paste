package com.ktng.ws2020.global.logging;

import java.lang.reflect.Method;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;

import com.ktng.ws2020.da.model.enums.SysLogType;
import com.ktng.ws2020.global.logging.annotation.SystemIntegrationClass;
import com.ktng.ws2020.global.logging.annotation.SystemIntegrationMethod;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Aspect
@Component
public class SystemIntegrationLogger {

    @Before("@within(com.ktng.ws2020.global.logging.annotation.SystemIntegrationClass)")
	public void classLogging(JoinPoint joinPoint) throws Throwable {

    	MethodSignature signature = (MethodSignature) joinPoint.getSignature();
    	Method method = signature.getMethod();

    	SystemIntegrationClass annotation = method.getDeclaringClass().getAnnotation(SystemIntegrationClass.class);
    	SysLogType type = annotation.type();

    	MDC.put("log_type", type.getCode());
    	log.info(
			"class={}, method={}",
			method.getDeclaringClass().getName(),
			method.getName()
		);
    	MDC.remove("log_type");

    }

    @Before("@annotation(com.ktng.ws2020.global.logging.annotation.SystemIntegrationMethod)")
	public void methodLogging(JoinPoint joinPoint) throws Throwable {

    	MethodSignature signature = (MethodSignature) joinPoint.getSignature();
    	Method method = signature.getMethod();

    	SystemIntegrationMethod annotation = method.getAnnotation(SystemIntegrationMethod.class);
    	SysLogType type = annotation.type();

    	MDC.put("log_type", type.getCode());
    	log.info(
			"class={}, method={}",
			method.getDeclaringClass().getName(),
			method.getName()
		);
    	MDC.remove("log_type");

    }

}
