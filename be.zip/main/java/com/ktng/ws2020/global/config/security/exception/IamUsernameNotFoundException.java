package com.ktng.ws2020.global.config.security.exception;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.oauth2.core.OAuth2Error;

// UsernameNotFoundException 에 추가적인 OAuth2Error 코드 값 넣기위해 구현
public class IamUsernameNotFoundException extends UsernameNotFoundException {
	private final Collection<OAuth2Error> errors;

	private static final long serialVersionUID = -6262907389108683531L;
	
	public IamUsernameNotFoundException(String message, Collection<OAuth2Error> errors) {
		super(message);
		this.errors = new ArrayList<>(errors);
	}

	public Collection<OAuth2Error> getErrors() {
		return this.errors;
	}
}
