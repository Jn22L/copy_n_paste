package com.ktng.ws2020.global.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import egovframework.rte.fdl.idgnr.EgovIdGnrService;
import egovframework.rte.fdl.idgnr.impl.EgovTableIdGnrServiceImpl;
import egovframework.rte.fdl.idgnr.impl.strategy.EgovIdGnrStrategyImpl;

@Configuration
public class ContextIdgen {

	@Autowired
	DataSource dataSource;

	@Bean(destroyMethod = "destroy")
	public EgovIdGnrService brdMstrNoGnrService() {
		EgovIdGnrStrategyImpl egovIdGnrStrategyImpl = new EgovIdGnrStrategyImpl();
		egovIdGnrStrategyImpl.setPrefix("BRDMST");
		egovIdGnrStrategyImpl.setCipers(14);
		egovIdGnrStrategyImpl.setFillChar('0');

		EgovTableIdGnrServiceImpl egovTableIdGnrServiceImpl = new EgovTableIdGnrServiceImpl();
		egovTableIdGnrServiceImpl.setDataSource(dataSource);
		egovTableIdGnrServiceImpl.setStrategy(egovIdGnrStrategyImpl);
		egovTableIdGnrServiceImpl.setBlockSize(1);
		egovTableIdGnrServiceImpl.setTable("IDS");
		egovTableIdGnrServiceImpl.setTableName("BRDMST");
		return egovTableIdGnrServiceImpl;
	}

	@Bean(destroyMethod = "destroy")
	public EgovIdGnrService brdCtsNoGnrService() {
		EgovIdGnrStrategyImpl egovIdGnrStrategyImpl = new EgovIdGnrStrategyImpl();
		egovIdGnrStrategyImpl.setPrefix("BRDCTS");
		egovIdGnrStrategyImpl.setCipers(14);
		egovIdGnrStrategyImpl.setFillChar('0');

		EgovTableIdGnrServiceImpl egovTableIdGnrServiceImpl = new EgovTableIdGnrServiceImpl();
		egovTableIdGnrServiceImpl.setDataSource(dataSource);
		egovTableIdGnrServiceImpl.setStrategy(egovIdGnrStrategyImpl);
		egovTableIdGnrServiceImpl.setBlockSize(1);
		egovTableIdGnrServiceImpl.setTable("IDS");
		egovTableIdGnrServiceImpl.setTableName("BRDCTS");
		return egovTableIdGnrServiceImpl;
	}

	@Bean(destroyMethod = "destroy")
	public EgovIdGnrService brdCmtNoGnrService() {
		EgovIdGnrStrategyImpl egovIdGnrStrategyImpl = new EgovIdGnrStrategyImpl();
		egovIdGnrStrategyImpl.setPrefix("BRDCMT");
		egovIdGnrStrategyImpl.setCipers(24);
		egovIdGnrStrategyImpl.setFillChar('0');

		EgovTableIdGnrServiceImpl egovTableIdGnrServiceImpl = new EgovTableIdGnrServiceImpl();
		egovTableIdGnrServiceImpl.setDataSource(dataSource);
		egovTableIdGnrServiceImpl.setStrategy(egovIdGnrStrategyImpl);
		egovTableIdGnrServiceImpl.setBlockSize(1);
		egovTableIdGnrServiceImpl.setTable("IDS");
		egovTableIdGnrServiceImpl.setTableName("BRDCMT");
		return egovTableIdGnrServiceImpl;
	}

}
