package com.ktng.ws2020.global.config;

import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

@Configuration
public class NssoRestTemplateConfig {

	@Bean
	public RestTemplate nssoRestTemplate() {
		HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
		HttpClient client = HttpClientBuilder.create().setMaxConnTotal(50) // 커넥션풀적용(최대 오픈되는 커넥션 수)
				.setMaxConnPerRoute(20) // 커넥션풀적용(IP:포트 1쌍에 대해 수행 할 연결 수제한)
				.build();

		factory.setHttpClient(client);
		factory.setConnectTimeout(30000); // 연결시간초과 타임아웃 설정 30초
		factory.setReadTimeout(30000); // 읽기시간초과 타임아웃 설정 30초
		RestTemplate restTemplate = new RestTemplate(factory);
		return restTemplate;
	}

}
