package com.ktng.ws2020.global.config.security;

import java.util.Date;

import org.springframework.core.convert.converter.Converter;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.oauth2.jwt.Jwt;

import com.ktng.ws2020.global.config.security.userdetails.IamUserDetailsService;

public class StaticJwtAuthenticationConverter implements Converter<Jwt, AbstractAuthenticationToken> {

    private final IamUserDetailsService userDetailsService;

    public StaticJwtAuthenticationConverter(IamUserDetailsService userDetailsService) {
        this.userDetailsService = userDetailsService;
    }

    @Override
    public AbstractAuthenticationToken convert(Jwt jwt) {
    	
    	String accessToken = jwt.getTokenValue();
        String empNo       = jwt.getClaimAsString("sub");
        String iss         = jwt.getClaimAsString("iss");
        Date expireAt      = (Date) Date.from(jwt.getClaimAsInstant("exp"));
        
        UserDetails userDetails = 
        		userDetailsService.loadUserByUsernameAndIss(empNo, accessToken, iss, expireAt);
        
        return new UsernamePasswordAuthenticationToken(
        		userDetails, userDetails.getPassword(), 
        		userDetails.getAuthorities() );
    }

}
