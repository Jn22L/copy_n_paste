package com.ktng.ws2020.global.config.security.nsso;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.MediaType;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.OAuth2Error;
import org.springframework.security.oauth2.jwt.JwtValidationException;
import org.springframework.security.oauth2.server.resource.web.BearerTokenAuthenticationEntryPoint;
import org.springframework.security.web.AuthenticationEntryPoint;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ktng.ws2020.global.config.security.exception.IamUsernameNotFoundException;

import lombok.extern.slf4j.Slf4j;

//NETS-OIDC 인증처리 시 예외가 발생되면 spring-boot-starter-oauth2-resource-server가  빈내용을 넘김...
//   배경설명 : https://docs.spring.io/spring-security/site/docs/current-SNAPSHOT/reference/html5/#oauth2resourceserver
// 우리는 모든에러는 ErrorResponse의 구조로 내려보내야 해서 이렇게 함..
// 참고 : https://medium.com/@beladiyahardik7/spring-security-custom-oauth2exception-in-spring-b35a62af4d34
// Okta 참고 :
// https://github.com/okta/okta-spring-boot/blob/master/oauth2/src/main/java/com/okta/spring/boot/oauth/Okta.java
@Slf4j
public class NssoBearerTokenAuthenticationEntryPoint implements AuthenticationEntryPoint {

	BearerTokenAuthenticationEntryPoint bearerTokenEntryPoint = new BearerTokenAuthenticationEntryPoint();
	
	@Override
	public void commence(
			HttpServletRequest request, HttpServletResponse response,
			AuthenticationException authException) throws JsonProcessingException, IOException {

    	// 예외처리 메시지 방식 통일
    	Map<String, Object> data = new HashMap<>();
    	data.put("code", "C007");
    	data.put("success", false);
    	data.put("msg", authException.getMessage());
    	
    	// authException => org.springframework.security.oauth2.server.resource.InvalidBearerTokenException
        // authException.getCause => org.springframework.security.oauth2.jwt.JwtValidationException
        // authException.getError => class org.springframework.security.oauth2.server.resource.BearerTokenError
    	log.debug("{}", authException.getClass());
	    if (authException instanceof OAuth2AuthenticationException) {
	    	OAuth2Error error = ((OAuth2AuthenticationException) authException).getError();
			if (authException.getCause() instanceof JwtValidationException) {
				JwtValidationException cause = (JwtValidationException)authException.getCause();
				List<String> errors = cause.getErrors()
					.stream()
					.map(err -> err.getErrorCode())
					.collect(Collectors.toList());
				errors.add( error.getErrorCode() );
				data.put("errors", errors); 
			}else {
				data.put("errors", Arrays.asList(error.getErrorCode(), error.getDescription()));
			}
	    }else if (authException instanceof IamUsernameNotFoundException) {
	    	// IamUserDetailsService.loadUserByUsernameAndIss 에서 에러 발생
	    	List<String> errors = ((IamUsernameNotFoundException) authException).getErrors()
					.stream()
					.map(err -> err.getErrorCode())
					.collect(Collectors.toList());
	    	errors.add( "username_not_found" );
			data.put("errors", errors);
	    }else {
	    	data.put("errors", authException.getMessage());	
	    }
	    
    	response.setContentType(MediaType.APPLICATION_JSON_UTF8.toString());
    	ObjectMapper mapper = new ObjectMapper();        	
        response.getWriter().print(mapper.writeValueAsString(data));
        
        bearerTokenEntryPoint.commence(request, response, authException);
	}
}
