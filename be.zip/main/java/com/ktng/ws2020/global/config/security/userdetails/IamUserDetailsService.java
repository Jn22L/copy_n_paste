package com.ktng.ws2020.global.config.security.userdetails;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.oauth2.core.OAuth2Error;
import org.springframework.security.oauth2.jwt.JwtValidationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ktng.ws2020.da.dao.IamUserRepository;
import com.ktng.ws2020.da.dao.NssoSessionRepository;
import com.ktng.ws2020.da.model.IamUserEntity;
import com.ktng.ws2020.da.model.NssoSessionEntity;
import com.ktng.ws2020.domain.common.model.UutasUserDTO;
import com.ktng.ws2020.domain.common.service.UutasUserService;
import com.ktng.ws2020.domain.sso.service.NssoService;
import com.ktng.ws2020.domain.sso.service.StaticJwtService;
import com.ktng.ws2020.global.config.security.exception.IamUsernameNotFoundException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class IamUserDetailsService implements UserDetailsService {
	
    @Autowired
    private IamUserRepository iamUserRepository;
    
	@Autowired
	NssoSessionRepository nssoSessionRepository;
	
	@Autowired
	NssoService nssoService;
	
	@Autowired
	StaticJwtService staticJwtService;

	@Autowired
	private UutasUserService uutasUserService;

	@Value("${ktng.nsso.url}")
	private String nssoUrl; 
	
	@Value("${ktng.static-jwt.issuer}")
	private String staticJwtUrl; 

	private final List<String> ignoreSessionUrls = Arrays.asList("/api/sso/loginSuccess");

	// 이메소드 안씀
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException, JwtValidationException {
//		log.debug("Loading user details for user {} ...", username);
//		
//		IamUserEntity iam = iamUserRepository.findById(username)
//				.orElseThrow(() -> new UsernameNotFoundException(username+"의 IAM 유저정보가 없습니다."));
//		iam.getRoles();
//
//		NssoSessionEntity session = nssoSessionRepository.findById(username).orElse(null);
//		if (session == null) {
//			throw new UsernameNotFoundException(username+"의 session 정보가 없습니다.") ;
//		}
//		
//		return IamUserDetails.of(
//				iam, 
//				session.getLastLogonDt(), session.getLastLogonIp(), session.getIss());

		throw new UsernameNotFoundException("loadUserByUsername don't use!!") ;
	}
	
	@Transactional
	public UserDetails loadUserByUsernameAndIss(
			String username, String accessToken, String iss, Date expireAt
			) throws IamUsernameNotFoundException {
		log.debug("Loading user details for user: {}, iss: {}...", username, iss);
		
		String empNo = username.replace("ktg", "");
		IamUserEntity iam = iamUserRepository.findById(empNo)
				.orElseThrow(() -> {
					String message = username+"의 IAM 유저정보가 없습니다.";
					
					return new IamUsernameNotFoundException(
							message, 
							Arrays.asList(new OAuth2Error("iam_not_exist", message, null))
						);
				});

		// 배차관리 사용자정보 조회
		UutasUserDTO uutasUser = uutasUserService.getUserByEmpNo(empNo);
		if (uutasUser == null) {
			String message = username+"의 배차관리 유저정보가 없습니다.";

			throw new  IamUsernameNotFoundException(
					message, 
					Arrays.asList(new OAuth2Error("iam_not_exist", message, null))
				);
		}
		
		String issType = getIssTypeByiss(iss);

		if (nssoUrl.equals(iss)) {
			// nsso에서 생성된 토큰인경우
		
			// 인증객체 생성 전에 세션정보가 반드시 있어야 하지만, 없는경우가 있음.
			//  1. loginSuccess 화면단 로그인 성공 시
			HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
			String requestUrl = request.getRequestURL().toString();
			boolean ignored = ignoreSessionUrls
						.stream()
						.anyMatch(url -> requestUrl.contains(url) );
			if (ignored) {
				return IamUserDetails.of(iam, uutasUser.getRoleCd(), null, null, accessToken, issType, expireAt);
			}
		}
			
		NssoSessionEntity session = nssoSessionRepository.getNssoSessionEntity(empNo, issType);
		if (session == null) {
			String message = issType+"에서 "+empNo+"로 session 발급정보가 없습니다.";
			throw new IamUsernameNotFoundException(
					message, 
					Arrays.asList(new OAuth2Error("session_not_exist", message, null))
				);
		}
		
		if (nssoUrl.equals(iss) || staticJwtUrl.equals(iss)) {
			// 넘어온 토큰과 DB세션테이블의 토큰정보가 다른경우 (중복로그인 시도)
			// 1. 새로운 PC에서 접속하면 요청에 신규 토큰이 발급되어서 넘어온경우
			// 2. 토큰 시간 만료로 refresh하여 갱신된 경우
			//     => 이전 토큰은 revoke 요청 & 토큰정보 갱신 처리
			// 3. 현재 PC에 있는 토큰이 revoke된 토큰일 경우
			//     => 이미 토큰이 DB에 없을거라 위 로직처리에서 걸러짐
			if(!accessToken.equals( session.getAccessToken() )) {
				try {
					if (session == null || !session.getExpiredAt().before(expireAt)) {
						String message = "유효한 SSO 세션정보가 아닙니다.";
						throw new IamUsernameNotFoundException(
								message, 
								Arrays.asList(new OAuth2Error("session_not_equals", message, null))
							);
					}
					if (nssoUrl.equals(iss)) {
						// NOSS토큰발급인 경우 : 토큰 revoke 처리 REST호출 + DB세션테이블 update
						nssoService.updateToken(session, accessToken, expireAt);						
					}else if (staticJwtUrl.equals(iss)) {
						// 자체 발급토큰경우 : DB세션테이블 update
						staticJwtService.updateToken(session, accessToken, expireAt);
					}
				} catch (JsonProcessingException e) {
					log.error("HandleJsonProcessingException", e);
					String message = username+"의 session 정보 업데이트중 에러가 발생하였습니다.";
					throw new IamUsernameNotFoundException(
							message, 
							Arrays.asList(new OAuth2Error("session_not_exist", message, null))
						);
				}
			}
		}
		
		return IamUserDetails.of(
				iam, 
				uutasUser.getRoleCd(),
				session.getLastLogonDt(), session.getLastLogonIp(),
				accessToken, 
				issType,
				expireAt );		
	}
	
	// iss to issType
	private String getIssTypeByiss(String iss) {
		if      (nssoUrl.equals(iss))      return "NSSO";
		else if (staticJwtUrl.equals(iss)) return "staticJwt";
		return iss;
	}

}
