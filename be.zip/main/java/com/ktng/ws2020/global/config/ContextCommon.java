package com.ktng.ws2020.global.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;

@Configuration
public class ContextCommon {
	
	@Bean
	public ReloadableResourceBundleMessageSource messageSource() {
		ReloadableResourceBundleMessageSource rrbms = new ReloadableResourceBundleMessageSource();
		rrbms.setBasenames(new String[] {
				"classpath:egovframework/rte/fdl/idgnr/messages/idgnr"
		});
		rrbms.setCacheSeconds(60);
		return rrbms;
	}

}
