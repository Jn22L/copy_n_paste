package com.ktng.ws2020.global.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.security.web.AuthenticationEntryPoint;

import com.ktng.ws2020.global.config.security.NSSOJwtAuthenticationConverter;
import com.ktng.ws2020.global.config.security.StaticJwtAuthenticationConverter;
import com.ktng.ws2020.global.config.security.StaticJwtAuthenticationProvider;
import com.ktng.ws2020.global.config.security.exception.RestAccessDeniedHandler;
import com.ktng.ws2020.global.config.security.exception.RestAuthenticationEntryPoint;
import com.ktng.ws2020.global.config.security.nsso.NSSOJwtValidator;
import com.ktng.ws2020.global.config.security.nsso.NssoBearerTokenAuthenticationEntryPoint;
import com.ktng.ws2020.global.config.security.userdetails.IamUserDetailsService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
	
	@Value("${spring.security.oauth2.resourceserver.jwt.jwk-set-uri}")
	private String jwkSetUri;
	
	@Autowired
	private NSSOJwtValidator jwtValidator;
	
    @Bean
    public PasswordEncoder passwordEncoder() {
        return PasswordEncoderFactories.createDelegatingPasswordEncoder();
    }

	@Autowired
	private IamUserDetailsService iamUserDetailsService;
	

    @Bean
    RestAccessDeniedHandler accessDeniedHandler() {
        return new RestAccessDeniedHandler();
    }
    
    @Bean
    RestAuthenticationEntryPoint authenticationEntryPoint() {
    	return new RestAuthenticationEntryPoint();        
    }

    
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http
			.sessionManagement()
			.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
			.and()
			
			.exceptionHandling()
			.accessDeniedHandler(accessDeniedHandler())
			.authenticationEntryPoint(authenticationEntryPoint())
			.and()

//			ROLE_ADMIN 			관리
//			ROLE_ADMIN_COMM 	공통관리
//			ROLE_MGR 			배차
//			ROLE_USR 			일반유저

			.authorizeRequests()
			.antMatchers(HttpMethod.POST, "/api/code/**").hasAnyRole("ADMIN", "ADMIN_COMM")
			.antMatchers(HttpMethod.DELETE, "/api/attach/**").hasAnyRole("ADMIN")
			.antMatchers(
					"/api/sso/revoke", 
					"/api/sso/logout",
					"/api/sso/static/login", 
					"/api/code/**",
					"/api/common/**",
					"/api/menu/**",
					"/api/ibsheet/down2excel",
					"/api/ibsheet/loadexcel").permitAll()
			.anyRequest().authenticated()
			.and()
			
			.csrf().disable()
			.oauth2ResourceServer()
			.authenticationEntryPoint(bearerTokenEntryPoint())
			.jwt()
			.decoder(jwtDecoder())
			.jwtAuthenticationConverter(nssoJwtAuthenticationConverter())
			;
	}

    @Bean
    NSSOJwtAuthenticationConverter nssoJwtAuthenticationConverter() {
        return new NSSOJwtAuthenticationConverter(iamUserDetailsService);
    }
    
	@Bean
    StaticJwtAuthenticationProvider staticJwtAuthenticationProvider() {
        return new StaticJwtAuthenticationProvider(new StaticJwtAuthenticationConverter(iamUserDetailsService));
    }
	
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.authenticationProvider(staticJwtAuthenticationProvider());
        auth.userDetailsService(iamUserDetailsService);
    }

    private static AuthenticationEntryPoint bearerTokenEntryPoint() {
        return new NssoBearerTokenAuthenticationEntryPoint();
    }
    
    @Bean(name = "jwtDecoder")
    JwtDecoder jwtDecoder() {
        NimbusJwtDecoder jwtDecoder = NimbusJwtDecoder
    			.withJwkSetUri(jwkSetUri)
    			.build();
        // validator 추가
        jwtDecoder.setJwtValidator(jwtValidator);
        // converter 추가
//        jwtDecoder.setClaimSetConverter(iamClaimSetConverter);
        
        return jwtDecoder;
    }
}
