package com.ktng.ws2020.global.config.security.nsso;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.oauth2.core.OAuth2Error;
import org.springframework.security.oauth2.core.OAuth2ErrorCodes;
import org.springframework.security.oauth2.core.OAuth2TokenValidator;
import org.springframework.security.oauth2.core.OAuth2TokenValidatorResult;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ktng.ws2020.da.dao.NssoSessionRepository;
import com.ktng.ws2020.da.model.NssoSessionEntity;
import com.ktng.ws2020.domain.sso.service.NssoService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class NSSOJwtValidator implements OAuth2TokenValidator<Jwt> {

	private final Duration clockSkew = Duration.of(60, ChronoUnit.SECONDS);
	
	private final List<String> ignoreSessionUrls = Arrays.asList("/api/sso/loginSuccess");
	
	OAuth2Error error = new OAuth2Error("sso_logout", "sso_logout : KT&G SSO logout user", null);
	
	@Value("${ktng.nsso.client-id}")
    private String nssoClientId;
	

	@Autowired
	NssoSessionRepository nssoSessionRepository;
	
	@Autowired
	NssoService ssoService;

	@Override
	public OAuth2TokenValidatorResult validate(Jwt jwt) {
		log.info("SsoValidator.validate() ...");
		
		Map<String, Object> claims = jwt.getClaims();
		
		// expire된 토큰인지 검사
		Instant expiry = jwt.getExpiresAt();

		if (expiry != null) {
			if (Instant.now(Clock.systemUTC()).minus(clockSkew).isAfter(expiry)) {
				return OAuth2TokenValidatorResult.failure(
					new OAuth2Error(
						"expired_token",
						String.format("토큰이 만료되었습니다. (%s)", expiry.atZone(ZoneId.of("Asia/Seoul"))),
						null
					)
				);
			}
		}

		Instant notBefore = jwt.getNotBefore();

		if (notBefore != null) {
			if (Instant.now(Clock.systemUTC()).plus(clockSkew).isBefore(notBefore)) {
				return OAuth2TokenValidatorResult.failure(
					new OAuth2Error(
						"not_available_token",
						String.format("토큰 처리시간이 유효하지 않습니다. (%s)", notBefore.atZone(ZoneId.of("Asia/Seoul"))),
						null
					)
				);
			}
		}

		
		// 요청 clientId가 서버의 clientId와 일치하지 않은 요청 인 경우..
		boolean isClientMatch = jwt.getAudience()
				.stream()
				.allMatch(p->p.equals(nssoClientId));
		
		if (!isClientMatch) {
			return OAuth2TokenValidatorResult.failure(
				new OAuth2Error(
					OAuth2ErrorCodes.INVALID_CLIENT, 
					"clientId가 서버정보와 일치하지 않습니다.", 
					null 
				)
			);
		}
		
		
		return OAuth2TokenValidatorResult.success();
	}

}
