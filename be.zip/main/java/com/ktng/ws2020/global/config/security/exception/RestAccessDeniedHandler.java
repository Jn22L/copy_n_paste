package com.ktng.ws2020.global.config.security.exception;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ktng.ws2020.global.error.exception.ErrorCode;

import lombok.extern.slf4j.Slf4j;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Component
public class RestAccessDeniedHandler implements AccessDeniedHandler {
	
	private final ErrorCode ACCESS_DENIED_ERRORCODE = ErrorCode.HANDLE_ACCESS_DENIED;

    @Override
    public void handle(
    		HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, 
    		AccessDeniedException e) throws IOException, ServletException {

    	log.error("RestAccessDeniedHandler::handle", e);
    	
    	// 예외처리 메시지 방식 통일
    	Map<String, Object> data = new HashMap<>();
    	data.put("code", ACCESS_DENIED_ERRORCODE.getCode());
    	data.put("success", false);
    	data.put("msg", ACCESS_DENIED_ERRORCODE.getMsg());

        //httpServletResponse.setStatus(HttpServletResponse.SC_FORBIDDEN);
        //httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        httpServletResponse.setStatus(ACCESS_DENIED_ERRORCODE.getStatus());
        httpServletResponse.setContentType(MediaType.APPLICATION_JSON_UTF8.toString());
        OutputStream out = httpServletResponse.getOutputStream();
        
        ObjectMapper mapper = new ObjectMapper();
        mapper.writerWithDefaultPrettyPrinter().writeValue(out, data);
        //mapper.writeValue(out, response);
        out.flush();
    }
}
