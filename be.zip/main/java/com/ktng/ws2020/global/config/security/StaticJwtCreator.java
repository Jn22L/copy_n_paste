package com.ktng.ws2020.global.config.security;

import java.util.Calendar;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTCreationException;

@Service
public class StaticJwtCreator {

    @Value("${ktng.static-jwt.issuer}")
    String issuer;

    @Value("${ktng.static-jwt.secret}")
    String secret;

    public String createToken(String empNo) {
        try {
            Algorithm algorithm = Algorithm.HMAC256(secret);
            String token = JWT.create()
                    .withIssuer(issuer)
                    .withSubject(empNo)
                    // 60 * 60 * 24 = 하루(X), 60 * 30 = 30분(O) 
                    .withExpiresAt(timeOffset(60 * 30)) 
                    .sign(algorithm);
            return token;
        } catch (JWTCreationException exception) {
            // Invalid Signing configuration / Couldn't convert Claims.
            return exception.toString();
        }
    }

    private Date timeOffset(int seconds) {
        Date current = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(current);
        calendar.add(Calendar.SECOND, seconds);
        return calendar.getTime();
    }
    
}
