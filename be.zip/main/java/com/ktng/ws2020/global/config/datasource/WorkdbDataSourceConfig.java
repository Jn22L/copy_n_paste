package com.ktng.ws2020.global.config.datasource;

import java.io.IOException;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateProperties;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateSettings;
import org.springframework.boot.autoconfigure.orm.jpa.JpaProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;

import com.zaxxer.hikari.HikariDataSource;

@PropertySource(value = {"${application.jdbc.properties}"})
@Configuration
@EnableJpaRepositories(
		entityManagerFactoryRef = "workdbEntityManagerFactory",
		transactionManagerRef = "workdbTransactionManager",
		basePackages = {"com.ktng.ws2020.da"})
public class WorkdbDataSourceConfig {
	
	@Autowired
	private JpaProperties JpaProperties;
	
	@Autowired
	private HibernateProperties hibernateProperties;
	
	@Primary
	@Bean(name = "workdbDataSource")
	@Qualifier("workdbDataSource")
	@ConfigurationProperties(prefix="spring.datasource.ds-workdb")
	public DataSource workdbDatasource() throws IOException {
		return DataSourceBuilder.create().type(HikariDataSource.class).build();
	}
	
	@Primary
	@Bean(name = "workdbEntityManagerFactory")
	public LocalContainerEntityManagerFactoryBean workdbEntityManagerFactory(
	        EntityManagerFactoryBuilder builder, 
	        @Autowired 
	        @Qualifier("workdbDataSource") 
	        DataSource workdbDataSource ) {
		
		Map<String, Object> properties = hibernateProperties.determineHibernateProperties(
				JpaProperties.getProperties(), new HibernateSettings());
		
		return builder.dataSource(workdbDataSource)
				.properties(properties)
				.packages(new String[]{"com.ktng.ws2020.da.model"})
				.persistenceUnit("workdb")
				.build();
	}
	
	@Primary
	@Bean(name = "workdbTransactionManager")
	public PlatformTransactionManager workdbTransactionManager(
	        EntityManagerFactoryBuilder builder, 
	        @Autowired 
	        @Qualifier("workdbDataSource") 
	        DataSource workdbDataSource ) {
		return new JpaTransactionManager(workdbEntityManagerFactory(builder, workdbDataSource).getObject());
	}
	
}