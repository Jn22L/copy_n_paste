package com.ktng.ws2020.global.config.security.exception;

import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.MediaType;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ktng.ws2020.global.error.exception.ErrorCode;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class RestAuthenticationEntryPoint implements AuthenticationEntryPoint {

	private final ErrorCode AUTHENTICATION_ERRORCODE = ErrorCode.HANDLE_AUTHENTICATION;
	
    @Override
    public void commence(
    		HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, 
    		AuthenticationException e) throws IOException, ServletException {
    	
    	log.error("RestAuthenticationEntryPoint::commence", e);
    	
    	// 예외처리 메시지 방식 통일
    	Map<String, Object> data = new HashMap<>();
    	data.put("code", AUTHENTICATION_ERRORCODE.getCode());
    	data.put("success", false);
    	data.put("msg", AUTHENTICATION_ERRORCODE.getMsg());

        //httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
    	httpServletResponse.setStatus(AUTHENTICATION_ERRORCODE.getStatus());
        httpServletResponse.setContentType(MediaType.APPLICATION_JSON_UTF8.toString());
        OutputStream out = httpServletResponse.getOutputStream();
        
        ObjectMapper mapper = new ObjectMapper();
        mapper.writerWithDefaultPrettyPrinter().writeValue(out, data);
        out.flush();
    }
}
