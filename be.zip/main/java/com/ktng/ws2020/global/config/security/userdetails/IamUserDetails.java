package com.ktng.ws2020.global.config.security.userdetails;

import java.util.Collection;
import java.util.Date;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.ktng.ws2020.da.model.IamUserEntity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter @Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class IamUserDetails implements UserDetails  {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	// IAM_USER
	private String username;
	private String name;
	private String password;
	private String userType;
	private String groupCd;
	private String groupNm;
	private String parCd;
	private String parNm;
	private String manDeptCd;
	private String manDeptNm;
	
	// NSSO token
	private Date loginDate;
	private String loginIp;
	private String accessToken;
	private String issType; // NSSO, staticJwt
	private Date expireAt;
	
	private Collection<? extends GrantedAuthority> authorities;
	
	public static IamUserDetails of(
			IamUserEntity user,
			String roleCd,
			Date loginDate, String loginIp, String accessToken, String issType, Date expireAt ) {
		IamUserDetails result =  IamUserDetails.builder()
				.username   ( user.getUserCd() )
				.name       ( user.getUserNm() )
				.password   ( user.getPwd() )     // 사번+패스워드 sha-256 암호화
				.userType   ( user.getSawonDv() ) // 사원구분 1:정규직, 2:비정규직, 3:임시, 4:기타 
				.groupCd    ( user.getWorkDeptCd())
				.groupNm    ( user.getWorkDeptNm())
				.parCd      ( user.getParCd())
				.parNm      ( user.getParNm())
				.manDeptCd  ( user.getManaDeptCd() )
				.manDeptNm  ( user.getManaDeptNm() )
				.loginDate  ( loginDate )
				.loginIp    ( loginIp )
				.accessToken( accessToken )
				.issType    ( issType )
				.expireAt   ( expireAt )
				.build();
				
        if (roleCd != null) {
        	result.setAuthorities(
        			Stream.of(roleCd)
	                    .map(_roleCd -> new SimpleGrantedAuthority(_roleCd) )
	                    .collect(Collectors.toList()) );
        }

        return result;
	}

	@Override
    public boolean isAccountNonExpired() {      
        return true;
    }
    @Override
    public boolean isAccountNonLocked() {       
        return true;
    }
    @Override
    public boolean isCredentialsNonExpired() {      
        return true;
    }
    @Override
    public boolean isEnabled() {        
        return true;
    }


}
