package com.ktng.ws2020.global.util;

import eu.bitwalker.useragentutils.Browser;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.EnumSet;
import java.util.Map;
import java.util.function.Function;
import java.util.function.UnaryOperator;
import java.util.stream.Collectors;

public enum FileNameEncoder {

    IE(Browser.IE, it -> {
        try {
            return URLEncoder.encode(it, StandardCharsets.UTF_8.name().replaceAll("\\+", "%20"));
        } catch (UnsupportedEncodingException e) {
            return it;
        }
    }),
    CHROME (Browser.CHROME,  it -> {
    	try {
	    	StringBuffer sb = new StringBuffer();
	    	for(int i=0; i<it.length(); i++) {
	    		char c = it.charAt(i);
	    		if(c > '~') {
	    			sb.append(URLEncoder.encode(Character.toString(c), "UTF-8"));
	    		} else {
	    			sb.append(c);
	    		}
	    	}
	    	return sb.toString();
    	} catch (UnsupportedEncodingException e) {
            return it;
        }
    }),
    SAFARI(Browser.SAFARI, it -> {
        try {
            return URLEncoder.encode(it, StandardCharsets.UTF_8.name().replaceAll("\\+", "%20"));
        } catch (UnsupportedEncodingException e) {
            return it;
        }
    }),
    FIREFOX(Browser.FIREFOX, getDefaultEncodeOperator()),
    OPERA  (Browser.OPERA,   getDefaultEncodeOperator()),
    UNKNOWN(Browser.UNKNOWN, getDefaultEncodeOperator());

    private final Browser browser;
    private UnaryOperator<String> encodeOperator;

    private static final Map<Browser, Function<String, String>> FILE_NAME_ENCODER_MAP;

    static {
        FILE_NAME_ENCODER_MAP = EnumSet.allOf(FileNameEncoder.class).stream()
                .collect(Collectors.toMap(FileNameEncoder::getBrowser, FileNameEncoder::getEncodeOperator));
    }

    FileNameEncoder(Browser browser, UnaryOperator<String> encodeOperator){
        this.browser = browser;
        this.encodeOperator = encodeOperator;
    }

    public Browser getBrowser() {
        return browser;
    }

    public UnaryOperator<String> getEncodeOperator() {
        return encodeOperator;
    }

    private static UnaryOperator<String> getDefaultEncodeOperator() {
        return it -> new String(it.getBytes(StandardCharsets.UTF_8), StandardCharsets.ISO_8859_1);
    }

    public static String encode(Browser browser, String fileName){
    	Function<String, String> encoder = FILE_NAME_ENCODER_MAP.get(browser);
    	if (encoder == null) {
    		encoder = FILE_NAME_ENCODER_MAP.get(Browser.CHROME);
    	}
    	return encoder.apply(fileName);
    }
}
