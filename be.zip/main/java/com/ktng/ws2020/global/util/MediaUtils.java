package com.ktng.ws2020.global.util;

import org.springframework.http.MediaType;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MediaUtils {

    private static Map<String, MediaType> mediaMap;

    static {
        mediaMap = new HashMap<>();

        mediaMap.put("JPEG", MediaType.IMAGE_JPEG);
        mediaMap.put("JPG", MediaType.IMAGE_JPEG);
        mediaMap.put("GIF", MediaType.IMAGE_GIF);
        mediaMap.put("PNG", MediaType.IMAGE_PNG);
    }

    public static MediaType getMediaType(String type) {
        return mediaMap.get(type.toUpperCase());
    }

    public static boolean containsImageMediaType(String mediaType) {
        return mediaMap.values().contains(MediaType.valueOf(mediaType));
    }

    public static List<String> imageMediaTypes =
            Arrays.asList(MediaType.IMAGE_JPEG_VALUE, MediaType.IMAGE_GIF_VALUE, MediaType.IMAGE_PNG_VALUE);
}
