package com.ktng.ws2020.global.util;


import java.util.ArrayList;
import java.util.List;
import java.util.function.LongSupplier;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.support.PageableExecutionUtils;

public class PageableUtils {
    /**
     * List 객체를 Page 객체로 감싸 반환해준다.
     * 
     * @param <T> List Item 타입
     * @param content 전체 조회한 List 객체
     * @param pageable 페이징 범위 (pageSize, pageNumber를 포함한다)
     * @return Page 객체
     */
    public static <T> Page<T> extractPage(List<T> content, Pageable pageable) {
    	// 총 건수
    	final int total = content.size();

    	// 페이징
    	// size: 10
    	// num -> startIndex, toIndex 
    	// 0   ->  0, 10
    	// 1   -> 10, 20
    	// 2   -> 20, 30
    	int startIndex = (int) pageable.getOffset(); // List 시작 인덱스
    	int toIndex = startIndex + pageable.getPageSize(); // List 끝 인덱스
    	if (toIndex > content.size()) // 마지막 페이지인 경우
    		toIndex = content.size();

    	List<T> filteredBoardList;
    	if (startIndex < content.size()) {
    		filteredBoardList = content.subList(startIndex, toIndex);
    	} else {
    		filteredBoardList = new ArrayList<>();
    	}

    	// `Page` 객체로 감싼다
    	LongSupplier totalSupplier = () -> total;
    	Page<T> pagedBoardList = PageableExecutionUtils.getPage(filteredBoardList, pageable, totalSupplier);

    	return pagedBoardList;
    }

}
