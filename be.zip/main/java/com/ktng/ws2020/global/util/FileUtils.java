package com.ktng.ws2020.global.util;

import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.UUID;

import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.ktng.ws2020.domain.attach.exception.FileDownloadException;
import com.ktng.ws2020.domain.attach.exception.FileUploadException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FileUtils {

    // 업로드된 파일을 저장하고 파일명과, 경로명을 리턴함
    public static String[] storeFile(Path fileLocation, MultipartFile file) {
    	// 파일 중복명 처리
		String genId = UUID.randomUUID().toString();
		genId = genId.replace("-", "");
    	return FileUtils.storeFile(genId, fileLocation, file);  
    }
    public static String[] storeFile(String genId, Path fileLocation, MultipartFile file) {
        String originalfileName = StringUtils.cleanPath(file.getOriginalFilename());
        String fileExtension    = StringUtils.getFilenameExtension(file.getOriginalFilename());
        
        String fileName = genId + "." + fileExtension;

        try {
            // 파일명에 부적합 문자가 있는지 확인한다.
            if(originalfileName.contains(".."))
                throw new FileUploadException("파일명에 부적합 문자가 포함되어 있습니다. " + originalfileName);
            
            Path targetLocation = fileLocation.resolve(fileName);
            Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);
            
            return new String[] { fileName, targetLocation.toAbsolutePath().toString() };
        }catch(Exception e) {
            throw new FileUploadException("["+originalfileName+"] 파일 업로드에 실패하였습니다.",e);
        }
    }
    
    // 파일불러오기
    public static Resource loadAsResource(Path path) {
        try {
            Resource resource = new UrlResource(path.toUri());
            
            if(resource.exists()) {
                return resource;
            }else {
                throw new FileDownloadException(path.getFileName() + " 파일을 찾을 수 없습니다.");
            }
        }catch(MalformedURLException e) {
            throw new FileDownloadException(path.getFileName() + " 파일을 찾을 수 없습니다.", e);
        }
    }
    public static Resource loadFilePathAsResource(String filePath) {
        Path path = Paths.get(filePath);
        return loadAsResource(path);
    }
    public static Resource loadFileNameAsResource(Path fileLocation, String fileName) {
        Path filePath = fileLocation.resolve(fileName).normalize();
        return loadAsResource(filePath);
    }
    
    // 파일삭제처리
    // 삭제한 파일명 및 경로 반환
    public static boolean removeFile(Path fileLocation, String storedFilename){
        try {
            // 파일명에 부적합 문자가 있는지 확인한다.
            if(storedFilename.contains(".."))
                throw new FileUploadException("파일명에 부적합 문자가 포함되어 있습니다. " + storedFilename);

            Path targetLocation = fileLocation.resolve(storedFilename);
            Files.delete(targetLocation);

            return true;
        }catch(Exception e) {
            log.error("["+storedFilename+"] 파일 삭제에 실패하였습니다.",e);
            return false;
        }
    }

}
