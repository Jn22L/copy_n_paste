package com.ktng.ws2020.global.common.response;

import com.ktng.ws2020.global.error.exception.ErrorCode;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CommonResult {
    
    // 응답 성공여부 : true/false
    private boolean success;
    // 응답 코드 번호 : SXXX 정상, CXXX 비정상
    private String code;
    // 응답 메시지
    private String msg;
    
    // 결과 모델에 api 요청 실패를 세팅해주는 메소드
    public void setErrorCode(final ErrorCode code) {
        this.success = false;
        this.msg     = code.getMsg();
        this.code    = code.getCode();
    }
    // 결과 모델에 api 요청 성공 데이터를 세팅해주는 메소드
    public void setSuccessCode(final ResponseCode code) {
        this.success = true;
        this.msg     = code.getMsg();
        this.code    = code.getCode();
    }
}
