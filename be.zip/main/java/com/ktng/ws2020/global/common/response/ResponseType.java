package com.ktng.ws2020.global.common.response;

public interface ResponseType {
    String getCode();
    String getMsg();
}
