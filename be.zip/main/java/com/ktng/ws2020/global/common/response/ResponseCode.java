package com.ktng.ws2020.global.common.response;

// enum으로 api 요청 결과에 대한 code, message를 정의합니다.
public enum ResponseCode implements ResponseType {
    
    SUCCESS("S001", "성공하였습니다.");
    
    String code;
    String msg;

    ResponseCode(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public String getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}
