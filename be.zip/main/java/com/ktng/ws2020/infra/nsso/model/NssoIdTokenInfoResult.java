package com.ktng.ws2020.infra.nsso.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public class NssoIdTokenInfoResult {
	@JsonProperty("active")
	private Boolean active;
	@JsonProperty("client_id")
	private String clientId;
	@JsonProperty("username")
	private String username;
	@JsonProperty("at_hash")
	private String atHash;
	@JsonProperty("sub")
	private String sub;
	@JsonProperty("lastlogondt")
	private String lastlogondt;
	@JsonProperty("iss")
	private String iss;
	@JsonProperty("lastlogonip")
	private String lastlogonip;
	@JsonProperty("nonce")
	private String nonce;
	@JsonProperty("_nuid")
	private String nuid;
	@JsonProperty("aud")
	private String aud;
	@JsonProperty("_nsid")
	private String nsid;
	@JsonProperty("auth_time")
	private Long authTime;
	@JsonProperty("exp")
	private Long exp;
	@JsonProperty("iat")
	private Long iat;
	@JsonProperty("compcode")
	private String compcode;
	@JsonProperty("jti")
	private String jti;
	@JsonProperty("email")
	private String email;
	@JsonProperty("pwdchangedt")
	private String pwdchangedt;
}

/*
{
    "active": true,
    "client_id": "649999db-f21d-4b3d-919f-068601a5521e",
    "username": "김민우",
    "at_hash": "IQKtNpob69vu2DW18pvDxA",
    "sub": "t0210023",
    "lastlogondt": "20210709164021",
    "iss": "https://ssodev.ktng.com/",
    "lastlogonip": "10.146.8.126",
    "nonce": "K6v5K1lPL-c",
    "_nuid": "t0210023",
    "aud": "649999db-f21d-4b3d-919f-068601a5521e",
    "_nsid": "6ee8e541dabc49eaa8cc8d88553ca1d2",
    "auth_time": -9223372036854775,
    "exp": 1625818223,
    "iat": 1625816423,
    "compcode": "KTG",
    "jti": "0acb39a9-27b5-412d-a564-1a5dd2ed8a3a",
    "email": "t0210023@ktng.com"
}
*/