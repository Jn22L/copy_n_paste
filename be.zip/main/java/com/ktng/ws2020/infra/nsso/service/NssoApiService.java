package com.ktng.ws2020.infra.nsso.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ktng.ws2020.infra.nsso.model.NssoIdTokenInfoResult;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
//TODO: `외부 연계 시스템` 로그수집 추가 후 주석해제할 것! 
//@SystemIntegrationClass(type = SysLogType.CALLNSSO)
public class NssoApiService {
	@Value("${ktng.nsso.client-id}")
    private String nssoClientId;
	
	@Value("${ktng.nsso.client-secret}")
	private String nssoClientSecret;
	
	@Value("${ktng.nsso.url}")
	private String nssoUrl; // https://ssodev.ktng.com/
	
	private final String tokenInfoUrl = "op/v1/token_info/";
	
	private final String revokeUrl = "op/v1/revoke/";
	
//	private final String logoutUrl = "op/v1/logout/";

	@Autowired
	private RestTemplate nssoRestTemplate;
	
	// 토큰 정보 조회
	public NssoIdTokenInfoResult getTokenInfo(String token) throws JsonProcessingException {
		HttpHeaders headers = new HttpHeaders();
		headers.setBasicAuth(nssoClientId, nssoClientSecret);
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

		MultiValueMap<String, Object> bodyMap = new LinkedMultiValueMap<>();
		bodyMap.add("token", token);

		HttpEntity<?> requestEntity = new HttpEntity<>(bodyMap, headers);

		ResponseEntity<String> response = nssoRestTemplate.exchange(this.nssoUrl + this.tokenInfoUrl, HttpMethod.POST, requestEntity,
				String.class);
		log.info("response status: " + response.getStatusCode());
		log.info("response body: " + response.getBody());
		
		ObjectMapper objectMapper = new ObjectMapper();
		NssoIdTokenInfoResult responseVO = objectMapper.readValue(response.getBody(), new TypeReference<NssoIdTokenInfoResult>() {});

		log.debug("resultData: " + responseVO);

		return responseVO;
	}
	
	// 토큰 만료 요청
	public void revokeToken(String token) throws JsonProcessingException {
		HttpHeaders headers = new HttpHeaders();
		headers.setBasicAuth(nssoClientId, nssoClientSecret);
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

		MultiValueMap<String, Object> bodyMap = new LinkedMultiValueMap<>();
		bodyMap.add("token", token);

		HttpEntity<?> requestEntity = new HttpEntity<>(bodyMap, headers);

		ResponseEntity<String> response = nssoRestTemplate.exchange(this.nssoUrl + this.revokeUrl, HttpMethod.POST, requestEntity,
				String.class);
		log.info("response status: " + response.getStatusCode());
		log.info("response body: " + response.getBody());
	}

	// SSO 로그아웃 요청 (BE에서 사용불가.. 결과로 나오는 html의 스크립트를 통해 로그아웃이 진행되므로 화면단에서만 로그아웃할 수 있음)
//	public void logoutToken(String idToken) throws JsonProcessingException {
//		HttpHeaders headers = new HttpHeaders();
//		headers.setBasicAuth(ssoClientId, ssoClientSecret);
//		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
//
//		MultiValueMap<String, Object> bodyMap = new LinkedMultiValueMap<>();
//		bodyMap.add("id_token_hint", idToken);
//
//		HttpEntity<?> requestEntity = new HttpEntity<>(bodyMap, headers);
//
//		ResponseEntity<String> response = nssoRestTemplate.exchange(this.ssoUrl + this.logoutUrl, HttpMethod.POST, requestEntity, String.class);
//		log.info("response status: " + response.getStatusCode());
//		log.info("response body: " + response.getBody());
//	}

}
