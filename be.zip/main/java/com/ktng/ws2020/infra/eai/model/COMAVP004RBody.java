package com.ktng.ws2020.infra.eai.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter @Setter
@Builder
@ToString
public class COMAVP004RBody {

}
