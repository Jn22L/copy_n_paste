package com.ktng.ws2020.infra.eai.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class COMAVP001PApvline {

	@JsonProperty("COMCD")
	private String comcd;
	@JsonProperty("EMPNO")
	private String empno;
	@JsonProperty("TYPE")
	private String type;
}

/*
      {
        "COMCD": "KTG",
        "EMPNO": "20001234",
        "TYPE": "A"
      },
	 */