package com.ktng.ws2020.infra.eai.exception;

import com.ktng.ws2020.global.error.exception.BusinessException;
import com.ktng.ws2020.global.error.exception.ErrorCode;

public class EAIRunFailException extends BusinessException{

	private static final long serialVersionUID = 4870651505996918890L;

	public EAIRunFailException(String message) {
        super(message, ErrorCode.EAI_RUN_FAIL);
    }
}
