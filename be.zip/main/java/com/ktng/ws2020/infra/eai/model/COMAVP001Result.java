package com.ktng.ws2020.infra.eai.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
public class COMAVP001Result {

	@JsonProperty("HEADER")
	private COMAVPHeader header;

	@JsonProperty("BODY")
	private COMAVP001RBody body;

	@JsonCreator
	public COMAVP001Result(@JsonProperty("HEADER") COMAVPHeader header, @JsonProperty("BODY") COMAVP001RBody body) {
		super();
		this.header = header;
		this.body = body;
	}

}
