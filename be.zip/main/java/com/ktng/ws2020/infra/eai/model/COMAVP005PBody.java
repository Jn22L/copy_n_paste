package com.ktng.ws2020.infra.eai.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class COMAVP005PBody {

	private String fiid;
	private String piid;
	private String approverId;
	private String systemcd;
	private String comcd;
	private String key;

}
