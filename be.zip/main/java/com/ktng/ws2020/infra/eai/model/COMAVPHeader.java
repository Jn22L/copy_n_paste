package com.ktng.ws2020.infra.eai.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class COMAVPHeader {

	@JsonProperty("APV_ID")
	private String apvId;
	@JsonProperty("APV_STATUS")
	private String apvStatus;
	@JsonProperty("APV_CD")
	private String apvCd;
	@JsonProperty("APV_MSG")
	private String apvMsg;

	@JsonCreator
	public COMAVPHeader(
			@JsonProperty("APV_ID") String apvId,
			@JsonProperty("APV_STATUS") String apvStatus,
			@JsonProperty("APV_CD") String apvCd,
			@JsonProperty("APV_MSG") String apvMsg
			) {
		super();
		this.apvId = apvId;
		this.apvStatus = apvStatus;
		this.apvCd = apvCd;
		this.apvMsg = apvMsg;
	}
}

/*
"HEADER": {
  "APV_ID": "APV_LEGACY_001",
  "APV_STATUS": "DRAFT",
  "APV_CD": null,
  "APV_MSG": null
},
 */