package com.ktng.ws2020.infra.eai;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ktng.eai_spring.EAISpringCommon;
import com.ktng.eai_spring.model.EAIMessageVo;
import com.ktng.ws2020.da.model.enums.SysLogType;
import com.ktng.ws2020.global.logging.annotation.SystemIntegrationClass;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@SystemIntegrationClass(type = SysLogType.CALLEAI)
public class EaiMailService {

	@Value("${ktng.eai.mail.url}")
	private String url;

	private final String IF_ID = "DRM_COMEML_001";
	private final String SYS_ID = "UADIT";

	public void send(String from, String to, String subject, String bodyText) {

//		log.info("[EAI] 메일전송 시작");

		Map<String, Object> mailMap = new HashMap<String, Object>();

		mailMap.put("from", from);
		mailMap.put("to", to);
		mailMap.put("subject", subject);

		Map<String, Object> mailBodyMap = new HashMap<String, Object>();
		mailBodyMap.put("bodyText", bodyText);

		mailMap.put("bodyElement", mailBodyMap);

		String result = null;

		try {

			// EAI로 REST 호출 결과 수신
			result = EAISpringCommon.callInterface(url, IF_ID, SYS_ID, mailMap);

		} catch (JsonProcessingException e) {
			e.printStackTrace();
			// 예외 처리 부분
		}

		@SuppressWarnings("unused")
		EAIMessageVo messageVo = null;

		// String 으로 읽기
		try {

			// SELECT인 경우 받은 JSON을 VO로 전환
			ObjectMapper mapper = new ObjectMapper();
			messageVo = mapper.readValue(result, EAIMessageVo.class);

//			log.info("[EAI] 메일전송 응답수신결과");
//			log.info("messageVo : " + messageVo);
//			log.info("messageVo.getHeader().getRstMsg() : " + messageVo.getHeader().getRstMsg());
//			log.info("messageVo.getHeader().getRstCd() : " + messageVo.getHeader().getRstCd());
//			log.info("messageVo.getBody() : " + messageVo.getBody());

			// Body 부분을 객체로 전환 (응답내용이 있을경우에만 사용, 없을경우 안써도 무방)

//			Data resultData = objectMapper.readValue( messageVo.getBody(), Data.class);
//			LinkedHashMap resultMap  = (LinkedHashMap)resultData.getData();
//			System.out.println(resultMap);

		} catch (IOException e) {
			log.error(e.toString());
		}

//		log.info("[EAI] 메일전송 종료");

	}

}
