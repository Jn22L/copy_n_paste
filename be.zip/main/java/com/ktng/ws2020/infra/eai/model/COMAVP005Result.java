package com.ktng.ws2020.infra.eai.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
public class COMAVP005Result {

	@JsonProperty("HEADER")
	private COMAVPHeader header;

	@JsonProperty("BODY")
	private COMAVP005RBody body;

	@JsonCreator
	public COMAVP005Result(@JsonProperty("HEADER") COMAVPHeader header, @JsonProperty("BODY") COMAVP005RBody body) {
		super();
		this.header = header;
		this.body = body;
	}

}
