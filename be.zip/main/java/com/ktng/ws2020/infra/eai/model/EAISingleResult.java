package com.ktng.ws2020.infra.eai.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class EAISingleResult<T> {

	@JsonProperty("DATA")
	private T data;

}
