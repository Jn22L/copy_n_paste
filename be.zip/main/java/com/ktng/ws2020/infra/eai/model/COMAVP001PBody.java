package com.ktng.ws2020.infra.eai.model;

import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class COMAVP001PBody {

	private String key;
	private String formid;
	private String empno;
	private String systemcd;
	private String comcd;
	private List<COMAVP001PApvline> apvline;
	private String htmlBody;
	private List<COMAVP001PAttchFileInfo> attachFileInfo;
	private String subject;
}
/*
"BODY": {
"key": "tttttest1",
"formid": "WF_REQUEST_LEGACY_TEST",
"empno": "201300777",
"systemcd": "HR",
"comcd": "KTG",
"apvline": [
  {
    "COMCD": "KTG",
    "EMPNO": "20001234",
    "TYPE": "A"
  },
  {
    "COMCD": "KTG",
    "EMPNO": "2012333",
    "TYPE": "A"
  },
  {
    "COMCD": "KTG",
    "EMPNO": "결재자사번",
    "TYPE": "A"
  }
],
"htmlBody": "<html><h6>기간계 테스트 바디<h6></html>",
"attachFileInfo": "",
"subject": "기간계 테스트 양식 입니다."
}
*/