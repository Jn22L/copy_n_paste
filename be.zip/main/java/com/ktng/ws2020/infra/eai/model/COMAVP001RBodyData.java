package com.ktng.ws2020.infra.eai.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
public class COMAVP001RBodyData {

	@JsonProperty("fiid")
	private String fiid;

	@JsonCreator
	public COMAVP001RBodyData(@JsonProperty("fiid") String fiid) {
		super();
		this.fiid = fiid;
	}
}
