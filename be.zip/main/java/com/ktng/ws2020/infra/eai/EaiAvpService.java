package com.ktng.ws2020.infra.eai;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ktng.eai_spring.EAISpringCommon;
import com.ktng.eai_spring.model.EAIMessageVo;
import com.ktng.ws2020.da.model.enums.SysLogType;
import com.ktng.ws2020.global.logging.annotation.SystemIntegrationClass;
import com.ktng.ws2020.infra.eai.exception.EAIRunFailException;
import com.ktng.ws2020.infra.eai.model.COMAVP001Param;
import com.ktng.ws2020.infra.eai.model.COMAVP001Result;
import com.ktng.ws2020.infra.eai.model.COMAVP004Param;
import com.ktng.ws2020.infra.eai.model.COMAVP004Result;
import com.ktng.ws2020.infra.eai.model.COMAVP005Param;
import com.ktng.ws2020.infra.eai.model.COMAVP005Result;
import com.ktng.ws2020.infra.eai.model.EAIListResult;

@Component
@SystemIntegrationClass(type = SysLogType.CALLEAI)
public class EaiAvpService {

	@Value("${ktng.eai.apv.url}")
	private String eaiApvUrl;

	private String additionalInfo = "EUEIM"; // 시스템 구분 코드

	// SRR_COMAVP_001 : 결재상신
	public List<COMAVP001Result> SRR_COMAVP_001(COMAVP001Param param) throws JsonProcessingException {

		String ifId = "SRR_COMAPV_001";

		ObjectMapper objectMapper = new ObjectMapper();
//		String messageVOJson = objectMapper.writeValueAsString(Arrays.asList( param ));
//		log.debug("param : " + messageVOJson);

		// EAI로 REST 호출 결과 수신
		String result = EAISpringCommon.callInterface(eaiApvUrl, ifId, additionalInfo, Arrays.asList(param));
//		log.debug("result : " + result);

		// 결과값 일기

		EAIMessageVo messageVo = objectMapper.readValue(result, EAIMessageVo.class);
		String rstCd = messageVo.getHeader().getRstCd();
		String rstMsg = messageVo.getHeader().getRstMsg();

//		log.debug("messageVo : " + messageVo);
//		log.debug("messageVo.getHeader().getRstCd()  : " + rstCd);
//		log.debug("messageVo.getHeader().getRstMsg() : " + rstMsg);

		if ("9999".equals(rstCd)) {
			// log.info("EAI 실패 : "+rstMsg);
			throw new EAIRunFailException(rstMsg);
		}
		EAIListResult<COMAVP001Result> resultData = objectMapper.readValue(messageVo.getBody(),
				new TypeReference<EAIListResult<COMAVP001Result>>() {
				});
//		log.debug("resultVO : " + resultData.getData());

		return resultData.getData();
	}

	// SRR_COMAVP_004 : 결재회수
	public List<COMAVP004Result> SRR_COMAVP_004(COMAVP004Param param) throws JsonProcessingException {

		String ifId = "SRR_COMAPV_004";

		ObjectMapper objectMapper = new ObjectMapper();
//		String messageVOJson = objectMapper.writeValueAsString(Arrays.asList( param ));
//		log.debug("param : " + messageVOJson);

		// EAI로 REST 호출 결과 수신
		String result = EAISpringCommon.callInterface(eaiApvUrl, ifId, additionalInfo, Arrays.asList(param));
//		log.debug("result : " + result);

		// 결과값 일기

		EAIMessageVo messageVo = objectMapper.readValue(result, EAIMessageVo.class);
		String rstCd = messageVo.getHeader().getRstCd();
		String rstMsg = messageVo.getHeader().getRstMsg();

//		log.debug("messageVo : " + messageVo);
//		log.debug("messageVo.getHeader().getRstCd()  : " + rstCd);
//		log.debug("messageVo.getHeader().getRstMsg() : " + rstMsg);

		if ("9999".equals(rstCd)) {
			// log.info("EAI 실패 : "+rstMsg);
			throw new EAIRunFailException(rstMsg);
		}
		EAIListResult<COMAVP004Result> resultData = objectMapper.readValue(messageVo.getBody(),
				new TypeReference<EAIListResult<COMAVP004Result>>() {
				});
//		log.debug("resultVO : " + resultData.getData());

		return resultData.getData();

	}

	// SRR_COMAVP_005: wiid 조회
	public List<COMAVP005Result> SRR_COMAVP_005(COMAVP005Param param) throws JsonProcessingException {

		String ifId = "SRR_COMAPV_005";

		ObjectMapper objectMapper = new ObjectMapper();
//		String messageVOJson = objectMapper.writeValueAsString(Arrays.asList( param ));
//		log.debug("param : " + messageVOJson);

		// EAI로 REST 호출 결과 수신
		String result = EAISpringCommon.callInterface(eaiApvUrl, ifId, additionalInfo, Arrays.asList(param));
//		log.debug("result : " + result);

		// 결과값 일기

		EAIMessageVo messageVo = objectMapper.readValue(result, EAIMessageVo.class);
		String rstCd = messageVo.getHeader().getRstCd();
		String rstMsg = messageVo.getHeader().getRstMsg();

//		log.debug("messageVo : " + messageVo);
//		log.debug("messageVo.getHeader().getRstCd()  : " + rstCd);
//		log.debug("messageVo.getHeader().getRstMsg() : " + rstMsg);

		if ("9999".equals(rstCd)) {
			// log.info("EAI 실패 : "+rstMsg);
			throw new EAIRunFailException(rstMsg);
		}
		EAIListResult<COMAVP005Result> resultData = objectMapper.readValue(messageVo.getBody(),
				new TypeReference<EAIListResult<COMAVP005Result>>() {
				});
//		log.debug("resultVO : " + resultData.getData());

		return resultData.getData();
	}

}
