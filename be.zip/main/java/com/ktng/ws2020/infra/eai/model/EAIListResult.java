package com.ktng.ws2020.infra.eai.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class  EAIListResult<T> {

	@JsonProperty("DATA")
	private List<T> data;

}
