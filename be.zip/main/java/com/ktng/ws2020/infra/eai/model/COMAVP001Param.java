package com.ktng.ws2020.infra.eai.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class COMAVP001Param {

	@JsonProperty("HEADER")
	private COMAVPHeader header;

	@JsonProperty("BODY")
	private COMAVP001PBody body;

}
