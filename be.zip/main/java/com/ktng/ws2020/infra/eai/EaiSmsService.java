package com.ktng.ws2020.infra.eai;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ktng.eai_spring.EAISpringCommon;
import com.ktng.eai_spring.model.EAIMessageVo;
import com.ktng.ws2020.da.model.enums.SysLogType;
import com.ktng.ws2020.domain.vhc.model.VHC0040SMSDTO;
import com.ktng.ws2020.global.logging.annotation.SystemIntegrationClass;
import com.ktng.ws2020.infra.eai.exception.EAIRunFailException;
import com.ktng.ws2020.infra.eai.model.SMS001Param;

@Component
@SystemIntegrationClass(type = SysLogType.CALLEAI)
public class EaiSmsService {

	@Value("${ktng.eai.sms.url}")
	private String eaiSmsUrl;

	private String additionalInfo = "UUTAS"; // 시스템 구분 코드

	// SMS EAI 발송
	public Boolean sendEaiSmsMsg(VHC0040SMSDTO dto) throws JsonProcessingException, EAIRunFailException {

		SMS001Param sms001Param;

		String result = "";
		String ifId = "DRD_COMSMS_001";

		String TR_CALLBACK = dto.getSmsSendNo(); // 발신자 전화번호
		String TR_MSG = dto.getSmsMessage(); // 내용
		String TR_ETC2 = " "; // ETC2

		/* 1. 수신자가 한명일때 */
		String TR_PHONE = dto.getSmsRecvNo(); // 수신자 전화번호
		// DTO parameter set
		sms001Param = new SMS001Param(TR_PHONE, TR_CALLBACK, TR_MSG, TR_ETC2);
		
		System.out.println("###### eaiSmsUrl : "+eaiSmsUrl);
		System.out.println("###### ifId : "+ifId);
		System.out.println("###### additionalInfo : "+additionalInfo);
		System.out.println("###### sms001Param : "+sms001Param);
		// EAI로 REST 호출 결과 수신
		result = EAISpringCommon.callInterface(eaiSmsUrl, ifId, additionalInfo, sms001Param);

		// 결과값 읽기
		ObjectMapper objectMapper = new ObjectMapper();
		EAIMessageVo messageVo = objectMapper.readValue(result, EAIMessageVo.class);
		String rstCd = messageVo.getHeader().getRstCd();
		String rstMsg = messageVo.getHeader().getRstMsg();

		if ("9999".equals(rstCd)) {
			throw new EAIRunFailException(rstMsg);
		}

		/* 2. 수신자가 여러명일때 */
		/*
		 * for (HashMap<String, String> receivers : dto.getReceivers()) { String
		 * TR_PHONE = receivers.get("usrCelNo"); // 수신자 전화번호
		 * 
		 * // DTO parameter set sms001Param = new SMS001Param(TR_PHONE, TR_CALLBACK,
		 * TR_MSG, TR_ETC2);
		 * 
		 * // EAI로 REST 호출 결과 수신 result = EAISpringCommon.callInterface(eaiSmsUrl, ifId,
		 * additionalInfo, sms001Param);
		 * 
		 * // 결과값 읽기 ObjectMapper objectMapper = new ObjectMapper(); EAIMessageVo
		 * messageVo = objectMapper.readValue(result, EAIMessageVo.class); String rstCd
		 * = messageVo.getHeader().getRstCd(); String rstMsg =
		 * messageVo.getHeader().getRstMsg();
		 * 
		 * if ("9999".equals(rstCd)) { throw new EAIRunFailException(rstMsg); } }
		 */

		return true;
	}
}
