package com.ktng.ws2020.infra.eai.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
public class COMAVP004Result {

	@JsonProperty("HEADER")
	private COMAVPHeader header;

	@JsonProperty("BODY")
	private COMAVP004RBody body;

	@JsonCreator
	public COMAVP004Result(@JsonProperty("HEADER") COMAVPHeader header, @JsonProperty("BODY") COMAVP004RBody body) {
		super();
		this.header = header;
		this.body = body;
	}

}
