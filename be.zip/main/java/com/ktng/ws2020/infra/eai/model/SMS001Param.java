package com.ktng.ws2020.infra.eai.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@ToString
public class SMS001Param {

	@JsonProperty("TR_PHONE")
	private String TR_PHONE; // 받는 사람

	@JsonProperty("TR_CALLBACK")
	private String TR_CALLBACK; // 보내는 사람

	@JsonProperty("TR_MSG")
	private String TR_MSG;

	@JsonProperty("TR_ETC2")
	private String TR_ETC2;

}
