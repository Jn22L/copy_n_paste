package com.ktng.ws2020.infra.eai.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter @Setter
@Builder
@ToString
public class COMAVP005RBodyData {

	@JsonProperty("wiid")
	private String wiid;

	@JsonCreator
	public COMAVP005RBodyData(
			@JsonProperty("wiid") String wiid) {
		super();
		this.wiid = wiid;
	}
}
