package com.ktng.ws2020.infra.eai.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
public class COMAVP005RBody {

	@JsonProperty("mode")
	private String mode;

	@JsonProperty("DATA")
	private COMAVP005RBodyData data;

	@JsonCreator
	public COMAVP005RBody(@JsonProperty("mode") String mode, @JsonProperty("DATA") COMAVP005RBodyData data) {
		super();
		this.mode = mode;
		this.data = data;
	}
}
