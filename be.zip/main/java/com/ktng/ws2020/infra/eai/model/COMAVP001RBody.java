package com.ktng.ws2020.infra.eai.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
public class COMAVP001RBody {

	@JsonProperty("DATA")
	private COMAVP001RBodyData data;

	@JsonCreator
	public COMAVP001RBody(@JsonProperty("DATA") COMAVP001RBodyData data) {
		super();
		this.data = data;
	}

}
