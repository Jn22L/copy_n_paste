package com.ktng.ws2020;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UutasApplication {

	public static void main(String[] args) {
		SpringApplication.run(UutasApplication.class, args);
	}

}
