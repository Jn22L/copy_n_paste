package com.ktng.ws2020;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UutasApplicationTests {

	@Test
	void contextLoads() {
	}

}
