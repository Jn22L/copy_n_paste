package com.ktng.ws2020.global.config.security;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.Jwt;

@SpringBootTest
class NSSOJwtAuthenticationConverterTest {
	
	@Autowired
	JwtDecoder jwtDecoder;

	@Test
	void test() {
		System.out.println(jwtDecoder);
		String accessToken = "eyJraWQiOiIxM2Y0OGE4NC1iYTliLTQwNzItODY0Ni1jMDdmMjU3MDYzNjMiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiI1MGY5MjlkYS1jMGRkLTQzYTQtOGU4Yy0wNWM5ODVmYWNhYjUiLCJzdWIiOiJrdGcyMjIyMDYxMCIsInNjb3BlIjpbImVtYWlsIiwibW9iaWxlIiwib3BlbmlkIiwicHJvZmlsZSIsImxhc3Rsb2dvbmR0IiwibGFzdGxvZ29uaXAiLCJjb21wY29kZSIsInB3ZGNoYW5nZWR0Il0sImlzcyI6Imh0dHBzOlwvXC9zc29kZXYua3RuZy5jb21cLyIsImV4cCI6MTYzMzU5MjMxNiwiaWF0IjoxNjMzNTkwNTE2LCJqdGkiOiJlMTY2MDU5MC1hNjlkLTQ3OGMtYWExNS00NmZhMDhlZWExNzYifQ.kfdRp3M03vscZJFNHB5ZnkxmB1U-yfTB654D4RhU6p-gS49Me12k_t5yS4A8wxaLjLs4U9wy2ge-jraNFySmtiGLr2io9W4zECq1SFfuzi0_B6o9vbAKSVAC6e7Jif9gqTk-8i5vpNv4lGBu2hU_OFpz0VBeSuXKw-DDM0rzorvuQYIjRH-xxNYoK165C4Ut7UbTp53Z5MrQWA4muicJcqADSagqVObD0Oux8QseYUKYonsFDSypBIsiGARjW7WyKEca_WSEZPdf4aYYgqtshU6ZJSG7T46y8uYV4UX0xfTfC8dX7jsAAwEvthqbbqoZSrCcRvoahtPgKnQONjKuIg";
		Jwt jwt = jwtDecoder.decode(accessToken);
		System.out.println(jwt);
		System.out.println( jwt.getClaimAsString("iss") );
	}

}
